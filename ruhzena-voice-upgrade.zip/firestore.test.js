const {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails,
} = require('@firebase/rules-unit-testing');
const { describe, it, before, after, beforeEach } = require('node:test');
const fs = require('node:fs');

const PROJECT_ID = 'gen-lang-client-0951745211';
const DB_ID = 'ai-studio-android-ruhzena-185e17cd-8465-4f47-9a27-8b690b3f09d1';

let testEnv;

function nowPast() {
  return new Date(Date.now() - 1000);
}

function validProfile(uid) {
  const ts = nowPast();
  return {
    userId: uid,
    displayName: 'Amina Rahman',
    email: 'amina@example.com',
    language: 'ENGLISH',
    characterGender: 'FEMALE',
    hydrationGoalMl: 2500,
    tasbihTotalCount: 99,
    lastReadSurah: 1,
    lastReadAyah: 5,
    createdAt: ts,
    updatedAt: ts,
  };
}

function validHabit(uid) {
  const ts = nowPast();
  return {
    userId: uid,
    title: 'Read 10 Minutes of Quran',
    category: 'Spirituality',
    currentStreak: 3,
    bestStreak: 7,
    lastCompletedDate: '2026-11-21',
    recoveryNote: '',
    createdAt: ts,
    updatedAt: ts,
  };
}

function validJournal(uid) {
  const ts = nowPast();
  return {
    userId: uid,
    title: 'Morning Reflection',
    content: 'Alhamdulillah for a peaceful Fajr and clear focus.',
    mood: 'Grateful',
    achievement: 'Completed morning adhkar',
    dateKey: '2026-11-21',
    createdAt: ts,
    updatedAt: ts,
  };
}

function validWorkout(uid) {
  const ts = nowPast();
  return {
    userId: uid,
    routineTitle: 'Full Body Mobility & Pushups',
    exercisesCompleted: 8,
    durationMinutes: 25,
    estimatedCalories: 185,
    dateKey: '2026-11-21',
    createdAt: ts,
    updatedAt: ts,
  };
}

function validWater(uid) {
  const ts = nowPast();
  return {
    userId: uid,
    amountMl: 300,
    dateKey: '2026-11-21',
    createdAt: ts,
    updatedAt: ts,
  };
}

function validBookmark(uid) {
  const ts = nowPast();
  return {
    userId: uid,
    itemType: 'QURAN',
    title: 'Al-Fatihah • Ayah 1',
    subtitle: 'In the name of Allah',
    arabicText: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
    surahNumber: 1,
    ayahNumber: 1,
    createdAt: ts,
    updatedAt: ts,
  };
}

describe('RuhZena Firestore Security Rules', () => {
  before(async () => {
    const [host, portStr] = (process.env.FIRESTORE_EMULATOR_HOST || '127.0.0.1:8085').split(':');
    testEnv = await initializeTestEnvironment({
      projectId: PROJECT_ID,
      firestore: {
        host,
        port: Number(portStr),
        rules: fs.readFileSync('firestore.rules', 'utf8'),
      },
    });
  });

  after(async () => {
    if (testEnv) {
      await testEnv.cleanup();
    }
  });

  beforeEach(async () => {
    await testEnv.clearFirestore();
  });

  it('denies unauthenticated access to all paths', async () => {
    const anonDb = testEnv.unauthenticatedContext().firestore(DB_ID);
    await assertFails(anonDb.collection('users').doc('user_alice').get());
    await assertFails(anonDb.collection('users').doc('user_alice').set(validProfile('user_alice')));
    await assertFails(anonDb.collection('users').doc('user_alice').collection('habits').get());
    await assertFails(anonDb.collection('unknown_collection').doc('doc1').get());
  });

  it('enforces owner-only profile CRUD, prevents listing /users, and rejects forged/shadow fields', async () => {
    const aliceDb = testEnv.authenticatedContext('user_alice').firestore(DB_ID);
    const bobDb = testEnv.authenticatedContext('user_bob').firestore(DB_ID);

    // Owner create succeeds
    const profile = validProfile('user_alice');
    await assertSucceeds(aliceDb.collection('users').doc('user_alice').set(profile));
    await assertSucceeds(aliceDb.collection('users').doc('user_alice').get());

    // Prevent user enumeration via collection list
    await assertFails(aliceDb.collection('users').get());

    // Cross-user read & write fail
    await assertFails(bobDb.collection('users').doc('user_alice').get());
    await assertFails(
      bobDb.collection('users').doc('user_alice').update({ displayName: 'Hacked', updatedAt: nowPast() })
    );

    // Owner update with allowed fields succeeds
    await assertSucceeds(
      aliceDb.collection('users').doc('user_alice').update({
        tasbihTotalCount: 132,
        lastReadSurah: 2,
        lastReadAyah: 255,
        updatedAt: nowPast(),
      })
    );

    // Immutable createdAt cannot be modified
    await assertFails(
      aliceDb.collection('users').doc('user_alice').update({
        createdAt: new Date(Date.now() - 60000),
        updatedAt: nowPast(),
      })
    );

    // Shadow field & @DocumentId 'id' key rejected
    await assertFails(
      aliceDb.collection('users').doc('user_alice').update({
        role: 'admin',
        updatedAt: nowPast(),
      })
    );
    await assertFails(
      bobDb.collection('users').doc('user_bob').set({ ...validProfile('user_bob'), id: 'user_bob' })
    );

    // Future timestamp rejected
    await assertFails(
      bobDb.collection('users').doc('user_bob').set({
        ...validProfile('user_bob'),
        updatedAt: new Date(Date.now() + 60000),
      })
    );

    // Out-of-range surah rejected
    await assertFails(
      aliceDb.collection('users').doc('user_alice').update({
        lastReadSurah: 115,
        updatedAt: nowPast(),
      })
    );
  });

  it('enforces owner-only CRUD & list queries on habits, journal, workouts, water_logs, and bookmarks', async () => {
    const aliceDb = testEnv.authenticatedContext('user_alice').firestore(DB_ID);
    const bobDb = testEnv.authenticatedContext('user_bob').firestore(DB_ID);

    // Habits
    await assertSucceeds(
      aliceDb.collection('users').doc('user_alice').collection('habits').doc('habit_1').set(validHabit('user_alice'))
    );
    await assertSucceeds(aliceDb.collection('users').doc('user_alice').collection('habits').get());
    await assertSucceeds(
      aliceDb.collection('users').doc('user_alice').collection('habits').doc('habit_1').update({
        currentStreak: 4,
        bestStreak: 7,
        updatedAt: nowPast(),
      })
    );
    await assertFails(bobDb.collection('users').doc('user_alice').collection('habits').get());
    await assertFails(
      aliceDb.collection('users').doc('user_alice').collection('habits').doc('habit_bad').set({
        ...validHabit('user_alice'),
        category: 'InvalidCategory',
      })
    );

    // Journal
    await assertSucceeds(
      aliceDb.collection('users').doc('user_alice').collection('journal').doc('entry_1').set(validJournal('user_alice'))
    );
    await assertSucceeds(aliceDb.collection('users').doc('user_alice').collection('journal').get());
    await assertFails(bobDb.collection('users').doc('user_alice').collection('journal').doc('entry_1').get());
    await assertFails(
      aliceDb.collection('users').doc('user_alice').collection('journal').doc('entry_big').set({
        ...validJournal('user_alice'),
        content: 'x'.repeat(4001),
      })
    );

    // Workouts
    await assertSucceeds(
      aliceDb.collection('users').doc('user_alice').collection('workouts').doc('w_1').set(validWorkout('user_alice'))
    );
    await assertSucceeds(aliceDb.collection('users').doc('user_alice').collection('workouts').get());
    await assertFails(
      aliceDb.collection('users').doc('user_alice').collection('workouts').doc('w_bad').set({
        ...validWorkout('user_alice'),
        durationMinutes: -5,
      })
    );

    // Water logs
    await assertSucceeds(
      aliceDb.collection('users').doc('user_alice').collection('water_logs').doc('wl_1').set(validWater('user_alice'))
    );
    await assertSucceeds(aliceDb.collection('users').doc('user_alice').collection('water_logs').get());
    await assertFails(
      aliceDb.collection('users').doc('user_alice').collection('water_logs').doc('wl_bad').set({
        ...validWater('user_alice'),
        amountMl: 0,
      })
    );

    // Bookmarks
    await assertSucceeds(
      aliceDb.collection('users').doc('user_alice').collection('bookmarks').doc('QURAN_1_1').set(validBookmark('user_alice'))
    );
    await assertSucceeds(aliceDb.collection('users').doc('user_alice').collection('bookmarks').get());
    await assertSucceeds(
      aliceDb.collection('users').doc('user_alice').collection('bookmarks').doc('QURAN_1_1').delete()
    );
    await assertFails(bobDb.collection('users').doc('user_alice').collection('bookmarks').get());
  });
});
