package com.example

import com.example.ruhzena.ai.IslamicKnowledgeCorpus
import com.example.ruhzena.data.islamic.BanglaPhoneticConverter
import com.example.ruhzena.data.islamic.BundledQuranSurahs
import com.example.ruhzena.data.islamic.IslamicContentData
import com.example.ruhzena.data.islamic.PrayerCalcMethod
import com.example.ruhzena.data.islamic.PrayerCalculator
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.ui.exercises.ExerciseLibrary
import com.example.ruhzena.ui.exercises.WorkoutProgramCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class RuhZenaCoreUnitTest {

    @Test
    fun all114SurahsSumTo6236AyahsAndMapReciterAudioProperly() {
        assertEquals(114, SurahCatalog.allSurahs.size)
        val totalAyahs = SurahCatalog.allSurahs.sumOf { it.ayahCount }
        assertEquals(6236, totalAyahs)

        assertEquals(1, SurahCatalog.globalAyahNumber(1, 1))
        assertEquals(6236, SurahCatalog.globalAyahNumber(114, 6))

        val r1 = SurahCatalog.reciters[0].audioUrlForGlobalAyah(1)
        val r2 = SurahCatalog.reciters[1].audioUrlForGlobalAyah(1)
        assertNotEquals(r1, r2)
        assertTrue(r1.contains("ar.alafasy/1.mp3"))
        assertTrue(r2.contains("ar.abdulbasitmurattal/1.mp3"))
    }

    @Test
    fun bundledQuranSurahsHaveArabicEnglishBanglaAndTransliterations() {
        val fatihah = BundledQuranSurahs.getBundledSurah(1)!!
        assertEquals(7, fatihah.size)
        fatihah.forEach { ayah ->
            assertTrue(ayah.arabicText.isNotBlank())
            assertTrue(ayah.englishTranslation.isNotBlank())
            assertTrue(ayah.banglaTranslation.isNotBlank())
            assertTrue(ayah.englishTransliteration.isNotBlank())
            assertTrue(ayah.banglaTransliteration.isNotBlank())
        }
        assertTrue(BanglaPhoneticConverter.toBanglaPhonetic("Bismillah").isNotBlank())
    }

    @Test
    fun prayerTimesAndQiblaBearingAreAstronomicallyValid() {
        val dhakaQibla = PrayerCalculator.calculateQiblaBearing(23.8103, 90.4125)
        assertTrue("Expected ~277 deg, got $dhakaQibla", dhakaQibla in 270.0..285.0)

        val londonQibla = PrayerCalculator.calculateQiblaBearing(51.5072, -0.1276)
        assertTrue("Expected ~119 deg, got $londonQibla", londonQibla in 112.0..126.0)

        val dhakaTz = java.util.TimeZone.getTimeZone("Asia/Dhaka")
        val cal = Calendar.getInstance(dhakaTz).apply { set(2026, Calendar.NOVEMBER, 16) }
        val schedule = PrayerCalculator.calculateForDate(23.8103, 90.4125, PrayerCalcMethod.KARACHI, cal, dhakaTz)
        assertTrue(schedule.fajrMinutes < schedule.sunriseMinutes)
        assertTrue(schedule.sunriseMinutes < schedule.dhuhrMinutes)
        assertTrue(schedule.dhuhrMinutes < schedule.asrMinutes)
        assertTrue(schedule.asrMinutes < schedule.maghribMinutes)
        assertTrue(schedule.maghribMinutes < schedule.ishaMinutes)

        val londonTz = java.util.TimeZone.getTimeZone("Europe/London")
        val londonCal = Calendar.getInstance(londonTz).apply { set(2026, Calendar.NOVEMBER, 16) }
        val londonSched = PrayerCalculator.calculateForDate(51.5072, -0.1276, PrayerCalcMethod.MWL, londonCal, londonTz)
        assertTrue(londonSched.fajrMinutes < londonSched.sunriseMinutes)
        assertTrue(londonSched.sunriseMinutes < londonSched.dhuhrMinutes)
        assertTrue(londonSched.dhuhrMinutes < londonSched.asrMinutes)
        assertTrue(londonSched.asrMinutes < londonSched.maghribMinutes)
        assertTrue(londonSched.maghribMinutes < londonSched.ishaMinutes)
    }

    @Test
    fun islamicCorpusAndVerifiedContentHaveStrictSourcesAndHumanAudioRefs() {
        assertEquals(27, IslamicKnowledgeCorpus.entries.size)
        assertTrue(IslamicKnowledgeCorpus.isGreeting("Assalamu Alaikum"))
        assertTrue(IslamicKnowledgeCorpus.isGreeting("hello"))
        assertFalse(IslamicKnowledgeCorpus.isGreeting("Importance of Salah"))

        val keywords = IslamicKnowledgeCorpus.extractSearchKeywords("What does Islam say about patience and anxiety?")
        assertTrue(keywords.contains("patience"))
        assertTrue(keywords.contains("anxiety"))
        assertFalse(keywords.contains("what"))

        val matches = IslamicKnowledgeCorpus.retrieveTopMatches("How to be consistent in Salah prayer")
        assertTrue(matches.isNotEmpty())
        assertTrue(matches.first().links.isNotEmpty())

        val unmatched = IslamicKnowledgeCorpus.retrieveTopMatches("quantum physics blockchain token")
        assertTrue(unmatched.isEmpty())

        IslamicContentData.adhkarList.forEach { dhikr ->
            assertTrue(dhikr.sourceRef.isNotBlank() && dhikr.sourceUrl.startsWith("https://"))
            assertTrue(dhikr.quranAudioRef != null || dhikr.hisnChapterId != null)
            assertTrue(dhikr.humanVoiceLabelEn.isNotBlank() && dhikr.humanVoiceLabelBn.isNotBlank())
        }
        IslamicContentData.duaList.forEach { dua ->
            assertTrue(dua.sourceRef.isNotBlank() && dua.sourceUrl.startsWith("https://"))
            assertTrue(dua.quranAudioRef != null || dua.hisnChapterId != null)
            assertTrue(dua.humanVoiceLabelEn.isNotBlank() && dua.humanVoiceLabelBn.isNotBlank())
        }
        IslamicContentData.lessonsList.forEach { assertTrue(it.sourceRef.isNotBlank() && it.sourceUrl.startsWith("https://")) }

        assertTrue("Expected at least 16 Tasbih presets, found ${IslamicContentData.tasbihPresets.size}", IslamicContentData.tasbihPresets.size >= 16)
        IslamicContentData.tasbihPresets.forEach { preset ->
            assertTrue("${preset.id} arabicText blank", preset.arabicText.isNotBlank())
            assertTrue("${preset.id} transliterationEn blank", preset.transliterationEn.isNotBlank())
            assertTrue("${preset.id} transliterationBn blank", preset.transliterationBn.isNotBlank())
            assertTrue("${preset.id} meaningEn blank", preset.meaningEn.isNotBlank())
            assertTrue("${preset.id} meaningBn blank", preset.meaningBn.isNotBlank())
            assertTrue("${preset.id} virtueEn blank", preset.virtueEn.isNotBlank())
            assertTrue("${preset.id} virtueBn blank", preset.virtueBn.isNotBlank())
            assertTrue("${preset.id} sourceRef blank", preset.sourceRef.isNotBlank())
            assertTrue("${preset.id} sourceUrl invalid", preset.sourceUrl.startsWith("https://"))
        }
    }

    @Test
    fun exerciseLibraryHas12ExercisesAnd6ValidWorkoutPrograms() {
        assertEquals(12, ExerciseLibrary.exercises.size)
        val validIds = ExerciseLibrary.exercises.map { it.id }.toSet()

        ExerciseLibrary.exercises.forEach { ex ->
            assertEquals(4, ex.phases.size)
            assertTrue(ex.nameEn.isNotBlank() && ex.nameBn.isNotBlank())
            assertTrue(ex.breathingEn.isNotBlank() && ex.breathingBn.isNotBlank())
            assertTrue(ex.postureEn.isNotEmpty() && ex.mistakesEn.isNotEmpty())
        }

        assertEquals(6, WorkoutProgramCatalog.programs.size)
        WorkoutProgramCatalog.programs.forEach { prog ->
            assertTrue(prog.titleEn.isNotBlank() && prog.titleBn.isNotBlank())
            assertTrue(prog.stations.isNotEmpty())
            prog.stations.forEach { st ->
                assertTrue("Unknown exercise id ${st.exerciseId}", validIds.contains(st.exerciseId))
                assertTrue(st.targetReps != null || st.durationSec != null)
            }
        }
    }
}
