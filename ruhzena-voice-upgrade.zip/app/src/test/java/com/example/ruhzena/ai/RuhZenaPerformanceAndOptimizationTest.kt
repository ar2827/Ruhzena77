package com.example.ruhzena.ai

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import com.example.ruhzena.ai.agent.AgentClock
import com.example.ruhzena.ai.agent.AgentRequestPayload
import com.example.ruhzena.ai.agent.AgentStreamEvent
import com.example.ruhzena.ai.agent.AiAgentMemoryStore
import com.example.ruhzena.ai.agent.AiFailureKind
import com.example.ruhzena.ai.agent.AiModelCatalog
import com.example.ruhzena.ai.agent.AiModelSpec
import com.example.ruhzena.ai.agent.AiPersonality
import com.example.ruhzena.ai.agent.AiProviderAdapter
import com.example.ruhzena.ai.agent.AiProviderId
import com.example.ruhzena.ai.agent.ChatTurn
import com.example.ruhzena.ai.agent.IntelligentModelRouter
import com.example.ruhzena.ai.agent.OpenAiCompatibleProviderAdapter
import com.example.ruhzena.ai.agent.ProviderHealthTracker
import com.example.ruhzena.ai.agent.QueryComplexity
import com.example.ruhzena.ai.agent.QueryDomain
import com.example.ruhzena.ai.agent.QueryProfile
import com.example.ruhzena.ai.agent.RuhZenaAgentEngine
import com.example.ruhzena.ai.agent.SecureAiCredentialStore
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.local.AiConversationSummaryEntity
import com.example.ruhzena.data.local.AiMemoryEntity
import com.example.ruhzena.data.local.AiMessageEntity
import com.example.ruhzena.data.local.AiProviderHealthEntity
import com.example.ruhzena.data.local.AiTaskStateEntity
import com.example.ruhzena.data.local.UserPreferences
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class RuhZenaPerformanceAndOptimizationTest {

    private class FakeClock(var now: Long = 1_760_000_000_000L) : AgentClock {
        override fun nowMillis(): Long = now
    }

    private class MemoryStore : AiAgentMemoryStore {
        val messages = mutableListOf<AiMessageEntity>()
        val memories = mutableListOf<AiMemoryEntity>()
        var summary: AiConversationSummaryEntity? = null
        var task: AiTaskStateEntity? = null
        val health = LinkedHashMap<String, AiProviderHealthEntity>()

        override suspend fun getAllMessages(): List<AiMessageEntity> = messages
        override suspend fun getActiveMemories(): List<AiMemoryEntity> = memories.filter { it.isActive && it.isApproved }
        override suspend fun getSummary(sessionId: String): AiConversationSummaryEntity? = summary
        override suspend fun saveSummary(summary: AiConversationSummaryEntity) { this.summary = summary }
        override suspend fun getActiveTask(): AiTaskStateEntity? = task
        override suspend fun saveTask(task: AiTaskStateEntity): Long { this.task = task; return 1L }
        override suspend fun loadAllHealth(): List<AiProviderHealthEntity> = health.values.toList()
        override suspend fun saveHealth(entity: AiProviderHealthEntity) { health[entity.modelKey] = entity }
    }

    private fun interceptingClient(handler: (Request) -> Response): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain -> handler(chain.request()) })
            .build()

    private fun okSseResponse(request: Request, body: String): Response = Response.Builder()
        .request(request)
        .protocol(Protocol.HTTP_1_1)
        .code(200)
        .message("OK")
        .header("Content-Type", "text/event-stream")
        .body(body.toResponseBody("text/event-stream".toMediaType()))
        .build()

    @Test
    fun allFourOriginalProvidersAndAllFourteenOriginalModelsAreIntactWithZeroExtraProviders() {
        assertEquals(
            setOf(
                AiProviderId.GROQ,
                AiProviderId.OPENROUTER,
                AiProviderId.CLOUDFLARE,
                AiProviderId.FIREBASE_GEMINI,
                AiProviderId.OFFLINE_CORPUS
            ),
            AiProviderId.entries.toSet()
        )

        val all = AiModelCatalog.defaultModels
        assertEquals(14, all.size)

        assertEquals(
            listOf(
                "openai/gpt-oss-120b",
                "llama-3.3-70b-versatile",
                "openai/gpt-oss-20b",
                "llama-3.1-8b-instant",
                "qwen/qwen3-8-27b"
            ),
            all.filter { it.provider == AiProviderId.GROQ }.map { it.modelId }
        )
        assertEquals(
            listOf(
                "openrouter/free",
                "google/gemma-4-31b-it:free",
                "nvidia/nemotron-3-ultra-550b-a55b:free",
                "nvidia/nemotron-3.5-super-vl:free",
                "google/gemma-4-26b-a4b-it:free"
            ),
            all.filter { it.provider == AiProviderId.OPENROUTER }.map { it.modelId }
        )
        assertEquals(
            listOf(
                "@cf/meta/llama-3.3-70b-instruct-fp8-fast",
                "@cf/google/gemma-4-26b-a4b-it"
            ),
            all.filter { it.provider == AiProviderId.CLOUDFLARE }.map { it.modelId }
        )
        assertEquals(
            listOf("gemini-3.8-flash", "gemini-3.5-flash-lite"),
            all.filter { it.provider == AiProviderId.FIREBASE_GEMINI }.map { it.modelId }
        )
    }

    @Test
    fun credentialSnapshotCachingEliminatesRepeatedDecryptionAndInvalidatesOnUpdate() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = SecureAiCredentialStore(context)
        store.clearUserOverrides()

        store.saveUserOverrides(
            groqKey = "gsk_test_123",
            openRouterKey = "sk-or-test-456",
            cloudflareAccountId = "cf_acct_789",
            cloudflareApiToken = "cf_tok_abc"
        )
        val snap1 = store.getSnapshot()
        val snap2 = store.getSnapshot()
        assertSame("Cached snapshot instance should be returned without re-decrypting", snap1, snap2)
        assertEquals("gsk_test_123", snap1.groqApiKey)
        assertEquals("sk-or-test-456", snap1.openRouterApiKey)
        assertTrue(snap1.hasCloudflare)

        store.saveUserOverrides(groqKey = "gsk_updated_999")
        val snap3 = store.getSnapshot()
        assertEquals("gsk_updated_999", snap3.groqApiKey)

        // Verify original endpoints & headers remain untouched
        val groqAdapter = OpenAiCompatibleProviderAdapter(AiProviderId.GROQ, store)
        val orAdapter = OpenAiCompatibleProviderAdapter(AiProviderId.OPENROUTER, store)
        val cfAdapter = OpenAiCompatibleProviderAdapter(AiProviderId.CLOUDFLARE, store)

        assertEquals("https://api.groq.com/openai/v1/chat/completions", groqAdapter.resolveEndpointAndHeaders().first)
        assertEquals("https://openrouter.ai/api/v1/chat/completions", orAdapter.resolveEndpointAndHeaders().first)
        assertEquals(
            "https://api.cloudflare.com/client/v4/accounts/cf_acct_789/ai/v1/chat/completions",
            cfAdapter.resolveEndpointAndHeaders().first
        )
    }

    @Test
    fun routerSelectsFastModelsForOrdinaryQuestionsAndHighReasoningForComplexIslamicAndCodingTasks() = runBlocking {
        val tracker = ProviderHealthTracker(FakeClock())
        val router = IntelligentModelRouter(tracker)

        // Ordinary everyday question -> ultra-fast model on Groq & Firebase
        val ordinaryProfile = router.classifyQuery("Quick tip to drink more water?")
        assertEquals(QueryComplexity.SIMPLE, ordinaryProfile.complexity)

        val groqOrdinary = router.rankCandidates(ordinaryProfile, setOf(AiProviderId.GROQ))
        assertTrue(
            "Ordinary question should pick an ultra-fast Groq model first",
            groqOrdinary.first().isUltraFast
        )

        val geminiOrdinary = router.rankCandidates(ordinaryProfile, setOf(AiProviderId.FIREBASE_GEMINI))
        assertEquals("gemini-3.5-flash-lite", geminiOrdinary.first().modelId)

        // Complex Islamic knowledge question -> high-reasoning model
        val islamicProfile = router.classifyQuery("Explain the difference between Fard and Wajib in Hanafi Fiqh with evidence")
        assertEquals(QueryDomain.ISLAMIC_KNOWLEDGE, islamicProfile.domain)
        assertEquals(QueryComplexity.COMPLEX, islamicProfile.complexity)

        val groqIslamic = router.rankCandidates(islamicProfile, setOf(AiProviderId.GROQ))
        assertTrue("Islamic knowledge query must route to high-reasoning model", groqIslamic.first().isHighReasoning)
        assertEquals("openai/gpt-oss-120b", groqIslamic.first().modelId)

        val geminiIslamic = router.rankCandidates(islamicProfile, setOf(AiProviderId.FIREBASE_GEMINI))
        assertEquals("gemini-3.8-flash", geminiIslamic.first().modelId)

        // Coding question -> high-reasoning model
        val codingProfile = router.classifyQuery("Debug this Kotlin coroutine flow cancellation bug")
        assertEquals(QueryDomain.CODING_TECHNICAL, codingProfile.domain)
        assertEquals(QueryComplexity.COMPLEX, codingProfile.complexity)
        val orCoding = router.rankCandidates(codingProfile, setOf(AiProviderId.OPENROUTER))
        assertTrue(orCoding.first().isHighReasoning)
    }

    @Test
    fun liveLatencyMonitoringPromotesFasterHealthyModelOverSluggishPeer() = runBlocking {
        val tracker = ProviderHealthTracker(FakeClock())
        val router = IntelligentModelRouter(tracker)

        val groqFast = AiModelCatalog.defaultModels.first { it.modelId == "llama-3.1-8b-instant" }
        val groqSlow = AiModelCatalog.defaultModels.first { it.modelId == "openai/gpt-oss-20b" }

        // Simulate gpt-oss-20b experiencing slow TTFT while llama-3.1-8b-instant responds in 190ms
        tracker.recordSuccess(groqSlow, latencyMs = 5_400L, firstTokenMs = 3_900L)
        tracker.recordSuccess(groqFast, latencyMs = 460L, firstTokenMs = 190L)

        val ranked = router.rankCandidates(
            profile = QueryProfile(QueryDomain.EVERYDAY_CHAT, QueryComplexity.SIMPLE),
            configuredProviders = setOf(AiProviderId.GROQ)
        )
        assertEquals("Faster healthy model must rank first", "llama-3.1-8b-instant", ranked.first().modelId)
    }

    @Test
    fun firstTokenStallAndMidStreamHangTriggerFastFailoverPreservingMemoryAndTask() = runBlocking {
        val store = MemoryStore().apply {
            memories.add(
                AiMemoryEntity(
                    id = 1L,
                    category = "GOAL",
                    content = "Training for 5km run while maintaining Fajr",
                    isApproved = true,
                    isActive = true
                )
            )
            task = AiTaskStateEntity(
                id = 1L,
                sessionId = "unified",
                title = "5km Morning Plan",
                objective = "Gradually reach 5km after Fajr",
                completedStepsJson = "[\"Week 1 brisk walk\"]",
                remainingStepsJson = "[\"Week 2 jog intervals\"]",
                status = "ACTIVE"
            )
        }

        // Adapter 1: stalls before emitting any token
        val stalledGroq = object : AiProviderAdapter {
            override val providerId = AiProviderId.GROQ
            override fun isConfigured() = true
            override fun streamCompletion(model: AiModelSpec, payload: AgentRequestPayload): Flow<String> = flow {
                delay(5_000L) // Exceeds test override 120ms first-token watchdog
                emit("Too late")
            }
            override suspend fun analyzeMealImage(model: AiModelSpec, bitmap: Bitmap, prefs: UserPreferences, mealType: String) =
                throw UnsupportedOperationException()
        }

        // Adapter 2: emits partial sentence then hangs mid-stream
        val hangingOpenRouter = object : AiProviderAdapter {
            override val providerId = AiProviderId.OPENROUTER
            override fun isConfigured() = true
            override fun streamCompletion(model: AiModelSpec, payload: AgentRequestPayload): Flow<String> = flow {
                emit("Start your Week 2 morning jog intervals right after Fajr with a gentle 5-minute warm-up. ")
                delay(5_000L) // Exceeds test override 150ms mid-stream stall watchdog
                emit("Never reached")
            }
            override suspend fun analyzeMealImage(model: AiModelSpec, bitmap: Bitmap, prefs: UserPreferences, mealType: String) =
                throw UnsupportedOperationException()
        }

        // Adapter 3: healthy Cloudflare backup finishes cleanly from partial continuation
        var capturedCloudflarePayload: AgentRequestPayload? = null
        val healthyCloudflare = object : AiProviderAdapter {
            override val providerId = AiProviderId.CLOUDFLARE
            override fun isConfigured() = true
            override fun streamCompletion(model: AiModelSpec, payload: AgentRequestPayload): Flow<String> = flow {
                capturedCloudflarePayload = payload
                emit("gentle 5-minute warm-up. Then alternate 2 minutes light jogging with 2 minutes walking.")
            }
            override suspend fun analyzeMealImage(model: AiModelSpec, bitmap: Bitmap, prefs: UserPreferences, mealType: String) =
                throw UnsupportedOperationException()
        }

        val models = listOf(
            AiModelCatalog.defaultModels.first { it.modelId == "openai/gpt-oss-120b" },
            AiModelCatalog.defaultModels.first { it.modelId == "openrouter/free" },
            AiModelCatalog.defaultModels.first { it.modelId == "@cf/meta/llama-3.3-70b-instruct-fp8-fast" }
        )
        val clock = FakeClock()
        val tracker = ProviderHealthTracker(clock, store)
        val router = IntelligentModelRouter(tracker) { models }
        val engine = RuhZenaAgentEngine(
            adapters = listOf(stalledGroq, hangingOpenRouter, healthyCloudflare),
            memoryStore = store,
            healthTracker = tracker,
            router = router,
            clock = clock,
            firstTokenStallMsOverride = 120L,
            interChunkStallMsOverride = 150L
        )

        val events = engine.streamAgentResponse(
            userPrompt = "Continue my detailed Week 2 running schedule",
            personality = AiPersonality.PRACTICAL_EXPERT,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences(characterGender = "MALE", userName = "Bilal")
        ).toList()

        val done = events.filterIsInstance<AgentStreamEvent.Completed>().single()
        assertEquals(AiProviderId.CLOUDFLARE, done.servedByProvider)
        assertTrue(done.usedFailover)
        assertEquals(3, done.attemptCount)

        // Verify partial continuation stitched seamlessly without repeating "gentle 5-minute warm-up."
        assertTrue(done.mainReply.contains("Start your Week 2 morning jog intervals"))
        assertTrue(done.mainReply.contains("alternate 2 minutes light jogging"))
        assertEquals(1, Regex("gentle 5-minute warm-up").findAll(done.mainReply).count())

        // Verify memory & active task were fully preserved across all switches
        val cfPayload = capturedCloudflarePayload
        assertNotNull(cfPayload)
        assertTrue(cfPayload!!.systemPrompt.contains("Training for 5km run while maintaining Fajr"))
        assertTrue(cfPayload.systemPrompt.contains("5km Morning Plan"))
        assertTrue(cfPayload.messages.last().content.contains("INTERNAL CONTINUATION"))

        // Verify stalled & mid-stream-hung models entered cooldown so they won't be retried immediately
        assertEquals(AiFailureKind.TIMEOUT_OR_STALL, tracker.getState(models[0]).lastErrorKind)
        assertEquals(AiFailureKind.MID_STREAM_INTERRUPT, tracker.getState(models[1]).lastErrorKind)
        assertFalse(tracker.isAvailableNow(models[0]))
        assertFalse(tracker.isAvailableNow(models[1]))
    }

    @Test
    fun salamOncePerSessionAndGreetingEtiquetteWorkAcrossCoreProviders() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = SecureAiCredentialStore(context)
        store.clearUserOverrides()
        store.saveUserOverrides(groqKey = "gsk_test_salam")

        val client = interceptingClient { req ->
            okSseResponse(
                req,
                "data: {\"choices\":[{\"delta\":{\"content\":\"Assalamu Alaikum brother! Start with 20 minutes of mobility today.\"}}]}\n\ndata: [DONE]\n\n"
            )
        }
        val groqAdapter = OpenAiCompatibleProviderAdapter(AiProviderId.GROQ, store, client)
        val groqModel = AiModelCatalog.defaultModels.first { it.modelId == "llama-3.1-8b-instant" }
        val memStore = MemoryStore()
        val tracker = ProviderHealthTracker(FakeClock(), memStore)
        val router = IntelligentModelRouter(tracker) { listOf(groqModel) }
        val engine = RuhZenaAgentEngine(listOf(groqAdapter), memStore, tracker, router)

        val turn1 = engine.streamAgentResponse(
            userPrompt = "Suggest a quick workout",
            personality = AiPersonality.PEACE_COMPANION,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences(characterGender = "MALE"),
            alreadyGreetedInSession = false
        ).toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertTrue("Turn 1 may include Salam", turn1.mainReply.startsWith("Assalamu Alaikum", ignoreCase = true))

        val turn2 = engine.streamAgentResponse(
            userPrompt = "What about protein after training?",
            personality = AiPersonality.PEACE_COMPANION,
            language = AppLanguage.ENGLISH,
            prefs = UserPreferences(characterGender = "MALE"),
            alreadyGreetedInSession = true
        ).toList().filterIsInstance<AgentStreamEvent.Completed>().single()
        assertFalse("Turn 2 must NOT repeat Salam", turn2.mainReply.startsWith("Assalamu Alaikum", ignoreCase = true))
        assertTrue("Turn 2 preserves guidance", turn2.mainReply.contains("20 minutes of mobility"))
    }
}
