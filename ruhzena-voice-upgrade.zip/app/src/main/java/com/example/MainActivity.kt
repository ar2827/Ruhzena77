package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.i18n.stringsFor
import com.example.ruhzena.data.cloud.FirebaseAuthHelper
import com.example.ruhzena.ui.RuhZenaApp
import com.example.ruhzena.ui.RuhZenaViewModel
import com.example.ruhzena.ui.screens.GoogleAuthGateScreen
import com.example.ui.theme.RuhZenaTheme
import com.example.ui.theme.RuhZenaThemeMode
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.recaptcha.RecaptchaAppCheckProviderFactory
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

private const val TAG = "AppCheckInit"
private const val AUTH_PREFS_NAME = "ruhzena_auth_prefs"
private const val KEY_GUEST_MODE_ENABLED = "guest_mode_enabled"
private const val DEBUG_TOKEN_EXTRA = "FIREBASE_APPCHECK_DEBUG_TOKEN"
private const val DEBUG_STORE_PREFIX = "com.google.firebase.appcheck.debug.store."
private const val DEBUG_SECRET_KEY = "com.google.firebase.appcheck.debug.DEBUG_SECRET"
private const val RECAPTCHA_SITE_KEY_RES = "recaptcha_site_key"

fun configureAppCheck(context: Context, intent: Intent?) {
    try {
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }

        if (BuildConfig.DEBUG) {
            val debugToken = intent?.getStringExtra(DEBUG_TOKEN_EXTRA)
            if (!debugToken.isNullOrEmpty()) {
                val persistenceKey = FirebaseApp.getInstance().persistenceKey
                val prefs = context.getSharedPreferences(
                    "$DEBUG_STORE_PREFIX$persistenceKey",
                    Context.MODE_PRIVATE
                )
                prefs.edit()
                    .putString(DEBUG_SECRET_KEY, debugToken)
                    .commit()
                Log.d(TAG, "App Check debug secret configured successfully.")
            } else {
                Log.w(TAG, "No debug token found in Intent extra.")
            }

            FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
                DebugAppCheckProviderFactory.getInstance()
            )
            Log.d(TAG, "DebugAppCheckProviderFactory installed.")
        } else {
            val resId = context.resources.getIdentifier(
                RECAPTCHA_SITE_KEY_RES,
                "string",
                context.packageName
            )
            if (resId != 0) {
                val siteKey = context.getString(resId)
                if (siteKey.isNotBlank()) {
                    FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
                        RecaptchaAppCheckProviderFactory.getInstance(siteKey)
                    )
                    Log.d(TAG, "RecaptchaAppCheckProviderFactory installed.")
                } else {
                    Log.e(TAG, "recaptcha_site_key resource string is blank.")
                }
            } else {
                Log.e(TAG, "recaptcha_site_key string resource not found in package.")
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "Failed to initialize Firebase App Check", e)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        val authPrefs = getSharedPreferences(AUTH_PREFS_NAME, Context.MODE_PRIVATE)
        setContent {
            val authFlow = remember { FirebaseAuthHelper.authStateFlow() }
            val currentUser by authFlow.collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)
            val activityScope = rememberCoroutineScope()
            var guestModeEnabled by remember {
                mutableStateOf(authPrefs.getBoolean(KEY_GUEST_MODE_ENABLED, false))
            }
            var suppressAutoSignIn by remember { mutableStateOf(false) }

            val activeUser = currentUser
            if (activeUser == null && !guestModeEnabled) {
                RuhZenaTheme(
                    themeMode = RuhZenaThemeMode.DARK_GLASS,
                    isBangla = false,
                    fontScale = 1.0f,
                    reducedMotion = false
                ) {
                    GoogleAuthGateScreen(
                        autoAttemptSignIn = !suppressAutoSignIn,
                        onContinueWithoutSignIn = {
                            authPrefs.edit().putBoolean(KEY_GUEST_MODE_ENABLED, true).apply()
                            guestModeEnabled = true
                        }
                    )
                }
            } else {
                val sessionKey = activeUser?.uid ?: "local_guest"
                key(sessionKey) {
                    val viewModel: RuhZenaViewModel = viewModel(key = sessionKey)
                    LaunchedEffect(activeUser?.uid) {
                        if (activeUser != null) {
                            suppressAutoSignIn = false
                            authPrefs.edit().putBoolean(KEY_GUEST_MODE_ENABLED, false).apply()
                            guestModeEnabled = false
                            viewModel.bindAuthenticatedUser(
                                uid = activeUser.uid,
                                displayName = activeUser.displayName,
                                email = activeUser.email
                            )
                        } else {
                            viewModel.clearAuthenticatedUser()
                        }
                    }

                    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
                    val activeLang = prefs.language
                    val localizedStrings = stringsFor(activeLang)
                    val themeMode = RuhZenaThemeMode.fromId(prefs.themeMode)
                    val layoutDirection = if (activeLang.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

                    CompositionLocalProvider(
                        LocalAppLanguage provides activeLang,
                        LocalStrings provides localizedStrings,
                        LocalLayoutDirection provides layoutDirection
                    ) {
                        RuhZenaTheme(
                            themeMode = themeMode,
                            isBangla = activeLang == AppLanguage.BANGLA,
                            fontScale = prefs.uiFontScale,
                            reducedMotion = prefs.reducedMotion
                        ) {
                            RuhZenaApp(
                                viewModel = viewModel,
                                initialOpenMutePicker = intent?.getBooleanExtra("open_mute_picker", false) == true,
                                initialOpenHydration = intent?.getBooleanExtra("open_hydration", false) == true,
                                isSignedIn = activeUser != null,
                                signedInUserName = activeUser?.displayName ?: prefs.userName,
                                signedInUserEmail = activeUser?.email.orEmpty(),
                                onSignOut = {
                                    activityScope.launch {
                                        suppressAutoSignIn = true
                                        authPrefs.edit().putBoolean(KEY_GUEST_MODE_ENABLED, false).apply()
                                        guestModeEnabled = false
                                        FirebaseAuthHelper.signOut(this@MainActivity)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
