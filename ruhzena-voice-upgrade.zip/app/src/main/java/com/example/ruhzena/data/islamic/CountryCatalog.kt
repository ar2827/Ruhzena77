package com.example.ruhzena.data.islamic

data class CountryPreset(
    val code: String,
    val nameEn: String,
    val defaultCity: String,
    val latitude: Double,
    val longitude: Double,
    val timeZoneId: String,
    val defaultMethodId: String,
    val defaultAsrSchool: String = "STANDARD",
    val cuisineRegion: String = "GLOBAL"
)

object CountryCatalog {
    val countries: List<CountryPreset> = listOf(
        CountryPreset("BD", "Bangladesh", "Dhaka, Bangladesh", 23.8103, 90.4125, "Asia/Dhaka", "KARACHI", "HANAFI", "SOUTH_ASIA"),
        CountryPreset("SA", "Saudi Arabia", "Makkah, Saudi Arabia", 21.4225, 39.8262, "Asia/Riyadh", "UMM_AL_QURA", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("AE", "United Arab Emirates", "Dubai, UAE", 25.2048, 55.2708, "Asia/Dubai", "DUBAI", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("EG", "Egypt", "Cairo, Egypt", 30.0444, 31.2357, "Africa/Cairo", "EGYPT", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("TR", "Turkey", "Istanbul, Turkey", 41.0082, 28.9784, "Europe/Istanbul", "MWL", "HANAFI", "MEDITERRANEAN"),
        CountryPreset("PK", "Pakistan", "Lahore, Pakistan", 31.5204, 74.3587, "Asia/Karachi", "KARACHI", "HANAFI", "SOUTH_ASIA"),
        CountryPreset("IN", "India", "New Delhi, India", 28.6139, 77.2090, "Asia/Kolkata", "KARACHI", "HANAFI", "SOUTH_ASIA"),
        CountryPreset("ID", "Indonesia", "Jakarta, Indonesia", -6.2088, 106.8456, "Asia/Jakarta", "MWL", "STANDARD", "SOUTHEAST_ASIA"),
        CountryPreset("MY", "Malaysia", "Kuala Lumpur, Malaysia", 3.1390, 101.6869, "Asia/Kuala_Lumpur", "MWL", "STANDARD", "SOUTHEAST_ASIA"),
        CountryPreset("SG", "Singapore", "Singapore", 1.3521, 103.8198, "Asia/Singapore", "MWL", "STANDARD", "SOUTHEAST_ASIA"),
        CountryPreset("GB", "United Kingdom", "London, UK", 51.5074, -0.1278, "Europe/London", "MWL", "STANDARD", "WESTERN"),
        CountryPreset("US", "United States", "New York, USA", 40.7128, -74.0060, "America/New_York", "ISNA", "STANDARD", "WESTERN"),
        CountryPreset("CA", "Canada", "Toronto, Canada", 43.6532, -79.3832, "America/Toronto", "ISNA", "STANDARD", "WESTERN"),
        CountryPreset("FR", "France", "Paris, France", 48.8566, 2.3522, "Europe/Paris", "MWL", "STANDARD", "WESTERN"),
        CountryPreset("DE", "Germany", "Berlin, Germany", 52.5200, 13.4050, "Europe/Berlin", "MWL", "STANDARD", "WESTERN"),
        CountryPreset("NL", "Netherlands", "Amsterdam, Netherlands", 52.3676, 4.9041, "Europe/Amsterdam", "MWL", "STANDARD", "WESTERN"),
        CountryPreset("ES", "Spain", "Madrid, Spain", 40.4168, -3.7038, "Europe/Madrid", "MWL", "STANDARD", "MEDITERRANEAN"),
        CountryPreset("IT", "Italy", "Rome, Italy", 41.9028, 12.4964, "Europe/Rome", "MWL", "STANDARD", "MEDITERRANEAN"),
        CountryPreset("SE", "Sweden", "Stockholm, Sweden", 59.3293, 18.0686, "Europe/Stockholm", "MWL", "STANDARD", "WESTERN"),
        CountryPreset("NO", "Norway", "Oslo, Norway", 59.9139, 10.7522, "Europe/Oslo", "MWL", "STANDARD", "WESTERN"),
        CountryPreset("MA", "Morocco", "Casablanca, Morocco", 33.5731, -7.5898, "Africa/Casablanca", "MWL", "STANDARD", "MEDITERRANEAN"),
        CountryPreset("DZ", "Algeria", "Algiers, Algeria", 36.7538, 3.0588, "Africa/Algiers", "MWL", "STANDARD", "MEDITERRANEAN"),
        CountryPreset("TN", "Tunisia", "Tunis, Tunisia", 36.8065, 10.1815, "Africa/Tunis", "MWL", "STANDARD", "MEDITERRANEAN"),
        CountryPreset("NG", "Nigeria", "Abuja, Nigeria", 9.0765, 7.3986, "Africa/Lagos", "MWL", "STANDARD", "AFRICA"),
        CountryPreset("KE", "Kenya", "Nairobi, Kenya", -1.2921, 36.8219, "Africa/Nairobi", "EGYPT", "STANDARD", "AFRICA"),
        CountryPreset("SD", "Sudan", "Khartoum, Sudan", 15.5007, 32.5599, "Africa/Khartoum", "EGYPT", "STANDARD", "AFRICA"),
        CountryPreset("SO", "Somalia", "Mogadishu, Somalia", 2.0469, 45.3182, "Africa/Mogadishu", "EGYPT", "STANDARD", "AFRICA"),
        CountryPreset("QA", "Qatar", "Doha, Qatar", 25.2854, 51.5310, "Asia/Qatar", "UMM_AL_QURA", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("KW", "Kuwait", "Kuwait City, Kuwait", 29.3759, 47.9774, "Asia/Kuwait", "UMM_AL_QURA", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("BH", "Bahrain", "Manama, Bahrain", 26.2285, 50.5860, "Asia/Bahrain", "UMM_AL_QURA", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("OM", "Oman", "Muscat, Oman", 23.5880, 58.3829, "Asia/Muscat", "UMM_AL_QURA", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("JO", "Jordan", "Amman, Jordan", 31.9454, 35.9284, "Asia/Amman", "EGYPT", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("PS", "Palestine", "Jerusalem, Palestine", 31.7683, 35.2137, "Asia/Hebron", "EGYPT", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("LB", "Lebanon", "Beirut, Lebanon", 33.8938, 35.5018, "Asia/Beirut", "EGYPT", "STANDARD", "MIDDLE_EAST"),
        CountryPreset("IQ", "Iraq", "Baghdad, Iraq", 33.3152, 44.3661, "Asia/Baghdad", "EGYPT", "HANAFI", "MIDDLE_EAST"),
        CountryPreset("UZ", "Uzbekistan", "Tashkent, Uzbekistan", 41.2995, 69.2401, "Asia/Tashkent", "KARACHI", "HANAFI", "SOUTH_ASIA"),
        CountryPreset("KZ", "Kazakhstan", "Almaty, Kazakhstan", 43.2220, 76.8512, "Asia/Almaty", "KARACHI", "HANAFI", "SOUTH_ASIA"),
        CountryPreset("AF", "Afghanistan", "Kabul, Afghanistan", 34.5553, 69.2075, "Asia/Kabul", "KARACHI", "HANAFI", "SOUTH_ASIA"),
        CountryPreset("LK", "Sri Lanka", "Colombo, Sri Lanka", 6.9271, 79.8612, "Asia/Colombo", "KARACHI", "STANDARD", "SOUTH_ASIA"),
        CountryPreset("MV", "Maldives", "Male, Maldives", 4.1755, 73.5093, "Indian/Maldives", "MWL", "STANDARD", "SOUTH_ASIA"),
        CountryPreset("BN", "Brunei", "Bandar Seri Begawan, Brunei", 4.9031, 114.9398, "Asia/Brunei", "MWL", "STANDARD", "SOUTHEAST_ASIA"),
        CountryPreset("PH", "Philippines", "Manila, Philippines", 14.5995, 120.9842, "Asia/Manila", "MWL", "STANDARD", "SOUTHEAST_ASIA"),
        CountryPreset("AU", "Australia", "Sydney, Australia", -33.8688, 151.2093, "Australia/Sydney", "MWL", "STANDARD", "WESTERN"),
        CountryPreset("NZ", "New Zealand", "Auckland, New Zealand", -36.8485, 174.7633, "Pacific/Auckland", "MWL", "STANDARD", "WESTERN"),
        CountryPreset("ZA", "South Africa", "Cape Town, South Africa", -33.9249, 18.4241, "Africa/Johannesburg", "MWL", "STANDARD", "AFRICA"),
        CountryPreset("JP", "Japan", "Tokyo, Japan", 35.6762, 139.6503, "Asia/Tokyo", "MWL", "STANDARD", "EAST_ASIA"),
        CountryPreset("KR", "South Korea", "Seoul, South Korea", 37.5665, 126.9780, "Asia/Seoul", "MWL", "STANDARD", "EAST_ASIA"),
        CountryPreset("BR", "Brazil", "Sao Paulo, Brazil", -23.5505, -46.6333, "America/Sao_Paulo", "MWL", "STANDARD", "WESTERN"),
        CountryPreset("BA", "Bosnia & Herzegovina", "Sarajevo, Bosnia", 43.8563, 18.4131, "Europe/Sarajevo", "MWL", "HANAFI", "MEDITERRANEAN"),
        CountryPreset("OTHER", "Other / Global", "Makkah, Saudi Arabia", 21.4225, 39.8262, "UTC", "MWL", "STANDARD", "GLOBAL")
    )

    fun findByCode(code: String?): CountryPreset? =
        countries.firstOrNull { it.code.equals(code, ignoreCase = true) }

    fun findByLocationLabel(label: String): CountryPreset? {
        val lower = label.lowercase()
        return countries.firstOrNull { c ->
            c.code != "OTHER" && (
                lower.contains(c.nameEn.lowercase()) ||
                    (c.code == "AE" && (lower.contains("uae") || lower.contains("dubai") || lower.contains("abu dhabi"))) ||
                    (c.code == "GB" && (lower.contains("uk") || lower.contains("england") || lower.contains("london"))) ||
                    (c.code == "US" && (lower.contains("usa") || lower.contains("united states")))
                )
        }
    }

    fun search(query: String): List<CountryPreset> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return countries
        return countries.filter {
            it.nameEn.lowercase().contains(q) ||
                it.defaultCity.lowercase().contains(q) ||
                it.code.lowercase() == q
        }
    }
}
