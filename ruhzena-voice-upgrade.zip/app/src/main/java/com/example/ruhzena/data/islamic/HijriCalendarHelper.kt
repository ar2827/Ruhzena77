package com.example.ruhzena.data.islamic

import java.util.Calendar
import kotlin.math.floor

data class HijriDate(
    val year: Int,
    val month: Int, // 1..12
    val day: Int,   // 1..30
    val monthNameEn: String,
    val monthNameAr: String,
    val monthNameBn: String
)

data class IslamicCalendarEvent(
    val month: Int,
    val day: Int,
    val titleEn: String,
    val titleBn: String,
    val noteEn: String,
    val noteBn: String
)

object HijriCalendarHelper {
    private val monthsEn = listOf(
        "Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani",
        "Jumada al-Ula", "Jumada al-Thani", "Rajab", "Sha'ban",
        "Ramadan", "Shawwal", "Dhul-Qa'dah", "Dhul-Hijjah"
    )

    private val monthsAr = listOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    private val monthsBn = listOf(
        "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি",
        "জমাদিউল আউয়াল", "জমাদিউস সানি", "রজব", "শাবান",
        "রমজান", "শাওয়াল", "জিলক্বদ", "জিলহজ্জ"
    )

    val notableEvents = listOf(
        IslamicCalendarEvent(1, 1, "Islamic New Year", "হিজরি নববর্ষ", "1 Muharram marks the Hijrah calendar milestone.", "১ মুহাররম হিজরি সনের প্রথম দিন।"),
        IslamicCalendarEvent(1, 10, "Day of Ashura", "আশুরা", "Fasting on 9th & 10th or 10th & 11th Muharram (Sahih Muslim 1134).", "৯-১০ অথবা ১০-১১ মুহাররম নফল রোজা রাখার সুন্নাহ (সহীহ মুসলিম ১১৩৪)।"),
        IslamicCalendarEvent(9, 1, "Start of Ramadan", "রমজান শুরু", "Blessed month of fasting, Quran, Qiyam, and generosity.", "সিয়াম, কুরআন ও তাকওয়ার বরকতময় মাস শুরু।"),
        IslamicCalendarEvent(9, 27, "Last 10 Nights (Odd Nights)", "শেষ দশকের বিজোড় রাত", "Seek Laylatul Qadr in all odd nights of the last 10 days (Bukhari 2017).", "রমজানের শেষ দশকের বিজোড় রাতগুলোতে লাইলাতুল ক্বদর অনুসন্ধান করুন (বুখারী ২০১৭)।"),
        IslamicCalendarEvent(10, 1, "Eid al-Fitr", "ঈদুল ফিতর", "Day of gratitude & charity after completing Ramadan.", "রমজান শেষে শুকরিয়া, ফিতরা ও আনন্দের দিন।"),
        IslamicCalendarEvent(12, 9, "Day of Arafah", "আরাফার দিন", "Fasting (for non-pilgrims) expiates sins of two years (Sahih Muslim 1162).", "হাজী ছাড়া অন্যদের জন্য আরাফার রোজা দুই বছরের গুনাহ মাফের মাধ্যম (মুসলিম ১১৬২)।"),
        IslamicCalendarEvent(12, 10, "Eid al-Adha", "ঈদুল আযহা", "Sacrifice & remembering Prophet Ibrahim's (AS) devotion.", "হযরত ইবরাহীম (আ.)-এর ত্যাগের আদর্শে কুরবানি ও ঈদ।")
    )

    /**
     * Converts Gregorian date to tabular Hijri date with user's moonsighting offset (-2..+2 days).
     * Note: Local moonsighting committees may differ by ±1 day, customizable via hijriOffsetDays.
     */
    fun toHijri(calendar: Calendar = Calendar.getInstance(), offsetDays: Int = 0): HijriDate {
        val cal = (calendar.clone() as Calendar).apply {
            add(Calendar.DAY_OF_MONTH, offsetDays.coerceIn(-2, 2))
        }
        val gYear = cal.get(Calendar.YEAR)
        val gMonth = cal.get(Calendar.MONTH) + 1
        val gDay = cal.get(Calendar.DAY_OF_MONTH)

        val jd = gregorianToJulianDayNumber(gYear, gMonth, gDay)
        val l0 = jd - 1948440 + 10632
        val n = floor((l0 - 1) / 10631.0).toInt()
        val l1 = l0 - 10631 * n + 354
        val j = (floor((10985 - l1) / 5316.0).toInt()) * (floor((50 * l1) / 17719.0).toInt()) +
            (floor(l1 / 5670.0).toInt()) * (floor((43 * l1) / 15238.0).toInt())
        val l2 = l1 - (floor((30 - j) / 15.0).toInt()) * (floor((17719 * j) / 50.0).toInt()) -
            (floor(j / 16.0).toInt()) * (floor((15238 * j) / 43.0).toInt()) + 29
        val hMonth = floor((24 * l2) / 709.0).toInt().coerceIn(1, 12)
        val hDay = (l2 - floor((709 * hMonth) / 24.0).toInt()).coerceIn(1, 30)
        val hYear = 30 * n + j - 30

        return HijriDate(
            year = hYear,
            month = hMonth,
            day = hDay,
            monthNameEn = monthsEn[hMonth - 1],
            monthNameAr = monthsAr[hMonth - 1],
            monthNameBn = monthsBn[hMonth - 1]
        )
    }

    fun daysInHijriMonth(year: Int, month: Int): Int {
        // Odd months have 30 days, even have 29; 12th month has 30 in leap year of 30-year cycle
        if (month % 2 == 1) return 30
        if (month < 12) return 29
        val leapYears = setOf(2, 5, 7, 10, 13, 16, 18, 21, 24, 26, 29)
        return if ((year % 30) in leapYears) 30 else 29
    }

    fun monthNameEn(month: Int): String = monthsEn[(month - 1).coerceIn(0, 11)]
    fun monthNameAr(month: Int): String = monthsAr[(month - 1).coerceIn(0, 11)]
    fun monthNameBn(month: Int): String = monthsBn[(month - 1).coerceIn(0, 11)]

    private fun gregorianToJulianDayNumber(year: Int, month: Int, day: Int): Int {
        val a = (14 - month) / 12
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        return day + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045
    }
}
