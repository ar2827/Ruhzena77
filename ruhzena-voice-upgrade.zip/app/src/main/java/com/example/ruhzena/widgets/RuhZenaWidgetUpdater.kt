package com.example.ruhzena.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.example.MainActivity
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.islamic.IslamicContentData
import com.example.ruhzena.data.islamic.PrayerCalcMethod
import com.example.ruhzena.data.islamic.PrayerCalculator
import com.example.ruhzena.data.local.RuhZenaDatabase
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.data.local.UserPreferencesRepository
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

object RuhZenaWidgetUpdater {
    fun launchAppPendingIntent(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    suspend fun loadSnapshot(context: Context): WidgetDataSnapshot {
        val prefs = UserPreferencesRepository(context).preferencesFlow.first()
        val db = RuhZenaDatabase.getInstance(context)
        val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val waterToday = db.waterLogDao().getTotalMlForDateSnapshot(todayKey)

        val tz = TimeZone.getTimeZone(prefs.locationTimeZoneId)
        val cal = Calendar.getInstance(tz)
        val method = PrayerCalcMethod.fromId(prefs.prayerCalcMethod)
        val asrShadow = if (prefs.asrJuristicMethod == "HANAFI") 2.0 else 1.0
        val schedule = PrayerCalculator.calculateForDate(
            latitude = prefs.latitude,
            longitude = prefs.longitude,
            method = method,
            calendar = cal,
            timeZone = tz,
            asrShadowFactorOverride = asrShadow
        )
        val nextPrayer = PrayerCalculator.getNextPrayer(schedule, cal)
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        val dailyLesson = IslamicContentData.lessonsList[dayOfYear % IslamicContentData.lessonsList.size]

        return WidgetDataSnapshot(
            prefs = prefs,
            waterTodayMl = waterToday,
            nextPrayerName = nextPrayer.prayerKey,
            nextPrayerTime = nextPrayer.timeFormatted,
            nextPrayerMinutesRemaining = nextPrayer.minutesRemaining,
            dailyArabic = dailyLesson.arabicText,
            dailyTranslation = if (prefs.language == AppLanguage.BANGLA) dailyLesson.bodyBn else dailyLesson.bodyEn,
            dailyRef = dailyLesson.sourceRef
        )
    }

    fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context) ?: return
        listOf(
            NextPrayerWidgetProvider::class.java,
            HydrationWidgetProvider::class.java,
            TasbihWidgetProvider::class.java,
            DailyAyahWidgetProvider::class.java
        ).forEach { cls ->
            val ids = manager.getAppWidgetIds(ComponentName(context, cls))
            if (ids.isNotEmpty()) {
                val intent = Intent(context, cls).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                context.sendBroadcast(intent)
            }
        }
    }
}

data class WidgetDataSnapshot(
    val prefs: UserPreferences,
    val waterTodayMl: Int,
    val nextPrayerName: String,
    val nextPrayerTime: String,
    val nextPrayerMinutesRemaining: Int,
    val dailyArabic: String,
    val dailyTranslation: String,
    val dailyRef: String
) {
    val hydrationPct: Int
        get() = ((waterTodayMl.toFloat() / prefs.hydrationGoalMl.coerceAtLeast(1)) * 100f)
            .roundToInt()
            .coerceIn(0, 999)
}
