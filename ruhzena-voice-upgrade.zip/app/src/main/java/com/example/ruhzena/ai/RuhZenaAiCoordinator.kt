package com.example.ruhzena.ai

import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.data.local.MealLogEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.ui.exercises.ExerciseLibrary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

data class OnlineKnowledgeSnippet(
    val title: String,
    val summary: String,
    val sourceUrl: String,
    val sourceName: String
)

class RuhZenaAiCoordinator {
    private val json = Json { ignoreUnknownKeys = true }
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val queryNoiseWords = setOf(
        "what", "is", "are", "was", "were", "who", "whom", "where", "when", "why", "how",
        "can", "could", "would", "should", "do", "does", "did", "the", "a", "an", "in",
        "on", "at", "of", "for", "to", "with", "about", "from", "tell", "me", "explain",
        "please", "islam", "islamic", "muslim", "meaning", "mean", "says", "say", "story",
        "history", "benefits", "benefit", "ruling", "rules", "many", "much", "give", "know"
    )

    suspend fun answerIslamicQuestion(
        query: String,
        language: AppLanguage,
        researchOnlineEnabled: Boolean,
        isOnline: Boolean,
        history: List<Pair<Boolean, String>> = emptyList(),
        alreadyGreetedInSession: Boolean = false
    ): AiEvidenceResponse = withContext(Dispatchers.IO) {
        val isBn = language == AppLanguage.BANGLA

        if (IslamicKnowledgeCorpus.isGreeting(query)) {
            val greetingLabel = "RuhZena AI • Verified Corpus"
            val qLower = query.lowercase().trim()
            val saidSalam = qLower.contains("salam") || qLower.contains("সালাম")
            val greetingReply = when {
                saidSalam -> if (isBn) {
                    "ওয়া আলাইকুমুস সালাম ওয়া রাহমাতুল্লাহি ওয়া বারাকাতুহু! আলহামদুলিল্লাহ, আমি আপনার সাহায্যের জন্য প্রস্তুত। কুরআনের যেকোনো সূরা, দৈনন্দিন দুআ, নামাজ বা ব্যক্তিগত সুস্থতা সম্পর্কে জিজ্ঞাসা করুন।"
                } else {
                    "Wa Alaikumus Salam wa Rahmatullahi wa Barakatuh! Alhamdulillah, I am honored to assist you. Ask about any Surah, daily Sunnah Dua, Salah/Wudu, or personal wellness — and I can guide you straight to it inside RuhZena."
                }
                else -> if (isBn) {
                    "আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহি ওয়া বারাকাতুহু! একটি সুন্দর সুন্নাহ আদব: সাধারণ 'হ্যালো/হাই'-এর বদলে একে অপরকে 'আসসালামু আলাইকুম' বলে সম্ভাষণ জানানো বরকতময়। আজ আপনাকে কীভাবে সাহায্য করতে পারি?"
                } else {
                    "Assalamu Alaikum wa Rahmatullahi wa Barakatuh! A gentle Sunnah reminder: greeting with 'Assalamu Alaikum' spreads peace and earns reward. How may I assist you today, In sha Allah?"
                }
            }
            return@withContext AiEvidenceResponse(
                topic = if (isBn) "আসসালামু আলাইকুম • ইসলামী সম্ভাষণ" else "Assalamu Alaikum • Islamic Greeting Etiquette",
                quranicEvidence = if (isBn) {
                    "সূরা আন-নিসা ৪:৮৬ — 'যখন তোমাদেরকে অভিবাদন করা হয়, তখন তোমরা তার চেয়ে উত্তম অভিবাদন জানাও অথবা অনুরূপ উত্তর দাও।'"
                } else {
                    "Surah An-Nisa 4:86 — 'And when you are greeted with a greeting, greet [in return] with one better than it or [at least] return it [in a like manner].'"
                },
                hadithEvidence = if (isBn) {
                    "সহীহ মুসলিম ৫৪ — রাসূলুল্লাহ (ﷺ) বলেছেন: 'তোমরা পরস্পরের মাঝে সালামের প্রসার ঘটাও।'"
                } else {
                    "Sahih Muslim 54 — The Prophet (ﷺ) said: 'Spread Salam (peace) amongst yourselves.'"
                },
                scholarlyExplanations = if (isBn) {
                    "কারো সাথে দেখা বা কথা শুরু করার সময় 'আসসালামু আলাইকুম' বলা সুন্নাহ (নেকি পাওয়া যায়), আর উত্তরদাতা বলেন 'ওয়া আলাইকুমুস সালাম ওয়া রাহমাতুল্লাহ'।"
                } else {
                    "Initiating with 'Assalamu Alaikum' earns reward and invokes peace, while 'Wa Alaikumus Salam' is specifically the response to someone who initiated Salam."
                },
                scholarlyDifferences = if (isBn) {
                    "সালাম শুরু করা সুন্নাহ এবং উত্তর দেওয়া ওয়াজিব—এই বিষয়ে সকল মাযহাব একমত।"
                } else {
                    "Scholars across all schools agree that initiating Salam is an emphasized Sunnah and returning it is an obligation."
                },
                aiSynthesis = greetingReply,
                sourceLinks = listOf("https://quran.com/4/86", "https://sunnah.com/muslim:54"),
                retrievalModeLabel = greetingLabel
            )
        }

        val effectiveQuery = enrichWithRecentContext(query, history)

        // 1. Direct Surah:Ayah or Named Surah detection (e.g. "2:255", "Ayat al-Kursi", "Surah Kahf 10")
        val directRef = parseDirectQuranReference(effectiveQuery)
        val directAyahText = if (directRef != null && researchOnlineEnabled && isOnline) {
            fetchDirectAyahOnline(directRef.first, directRef.second, isBn)
        } else {
            null
        }

        // 2. Scored local corpus retrieval
        val scoredLocal = IslamicKnowledgeCorpus.retrieveScoredMatches(effectiveQuery, limit = 2)
        val topLocalPair = scoredLocal.firstOrNull()
        val topLocal = topLocalPair?.first
        val topScore = topLocalPair?.second ?: 0

        // 3. Multi-source online knowledge lookup (AlQuran Cloud Search + Wikipedia Full-Text Search + DuckDuckGo)
        val shouldSearchWeb = researchOnlineEnabled && isOnline && directAyahText == null
        val onlineQuranMatches = if (shouldSearchWeb) {
            searchQuranOnline(effectiveQuery)
        } else {
            emptyList()
        }

        // Fetch open web encyclopedic summary whenever online research is enabled AND either local score isn't an unmistakable topical match (< 14) or the query asks about specific figures/history/details
        val looksSpecificQuestion = hasSpecificEntityOrQuestionPattern(effectiveQuery)
        val webSnippet = if (shouldSearchWeb && (topLocal == null || topScore < 14 || looksSpecificQuestion)) {
            fetchOpenWebKnowledge(effectiveQuery, preferBangla = isBn)
        } else {
            null
        }

        val sourceTags = buildList {
            add("RuhZena AI")
            if (directAyahText != null) add("Direct Ayah Lookup")
            if (onlineQuranMatches.isNotEmpty()) add("AlQuran Cloud")
            if (webSnippet != null) add(webSnippet.sourceName)
            if (topLocal != null) {
                add("Local Verified Corpus")
            } else if (size <= 1) {
                add(if (researchOnlineEnabled && !isOnline) "Offline Local Corpus" else "Local Verified Corpus")
            }
        }.distinct()
        val retrievalLabel = sourceTags.joinToString(" + ")

        if (topLocal == null && onlineQuranMatches.isEmpty() && directAyahText == null && webSnippet == null) {
            val fallbackGuidance = if (isBn) {
                if (!isOnline || !researchOnlineEnabled) {
                    "\"$query\" বিষয়ের ওপর অফলাইন সূচকে সরাসরি এন্ট্রি নেই এবং ইন্টারনেট গবেষণা নিষ্ক্রিয়/অফলাইন অবস্থায় আছে। উপরে 'অনলাইন গবেষণা মোড' চালু রেখে ইন্টারনেটে যুক্ত থাকলে আমি কুরআন সার্চ ও বিশ্বকোষ থেকে প্রাসঙ্গিক তথ্য নিয়ে উত্তর দিতে পারব। ব্যক্তিগত মাসআলার জন্য অভিজ্ঞ আলেমের পরামর্শ নিন।"
                } else {
                    "\"$query\" বিষয়ে নির্ভরযোগ্য উৎসে সরাসরি সুনির্দিষ্ট আয়াত/হাদিস পাওয়া যায়নি (কোনো বানানো রেফারেন্স দেওয়া হয়নি)। মূলনীতি অনুযায়ী: কল্যাণকর ও হালাল পথ বেছে নিন, সন্দেহজনক বিষয় পরিহার করুন এবং প্রয়োজনে কোনো বিশ্বস্ত মুফতি বা আলেমের পরামর্শ নিন।"
                }
            } else {
                if (!isOnline || !researchOnlineEnabled) {
                    "No exact offline corpus entry matched \"$query\" while offline/research-off, and RuhZena never invents verse or hadith citations. Connect to the internet with Online Research enabled for live Quran & Islamic retrieval, or consult a qualified scholar for personal rulings."
                } else {
                    "Live sources did not return an exact verified verse/article match for \"$query\", and RuhZena strictly avoids fabricating citations. Guided principle: clarify intention (niyyah), ensure no harm or violation of rights, avoid doubtful matters, and consult a qualified scholar for personal fatwa rulings."
                }
            }

            val fallbackSalam = if (!alreadyGreetedInSession) {
                if (isBn) "আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহি ওয়া বারাকাতুহু।\n\n"
                else "Assalamu Alaikum wa Rahmatullahi wa Barakatuh.\n\n"
            } else ""
            return@withContext AiEvidenceResponse(
                topic = query.take(64),
                quranicEvidence = if (isBn) {
                    "সূরা আল-নাহল ১৬:৪৩ — 'অতএব তোমরা যদি না জানো, তবে জ্ঞানীদের জিজ্ঞাসা করো।' (বানানো আয়াত এড়ানো হয়েছে)"
                } else {
                    "Surah An-Nahl 16:43 — 'So ask the people of the message (scholars) if you do not know.' (Zero-fabrication safeguard active)"
                },
                hadithEvidence = if (isBn) {
                    "সহীহ বুখারী ৫২ ও মুসলিম ১৫৯৯ — হালাল স্পষ্ট ও হারাম স্পষ্ট; সন্দেহজনক বিষয় পরিহার করে দ্বীন নিরাপদ রাখো।"
                } else {
                    "Sahih al-Bukhari 52 & Sahih Muslim 1599 — The lawful is clear and the unlawful is clear; leaving doubtful matters safeguards faith and honor."
                },
                scholarlyExplanations = if (isBn) {
                    "সুনির্দিষ্ট মাসআলার জন্য আপনার প্রশ্নটি একটু সহজ মূলশব্দে (বা সূরা:আয়াত নম্বরে, যেমন 2:255) লিখে আবার চেষ্টা করুন।"
                } else {
                    "Try rephrasing with key Islamic terms or a verse reference like 2:255, and consult a qualified scholar for personal rulings."
                },
                scholarlyDifferences = if (isBn) {
                    "স্থান, কাল ও প্রেক্ষাপট ভেদে আলেমদের ফিকহী মতামতে বৈচিত্র্য থাকতে পারে।"
                } else {
                    "Recognized scholarly opinions (Ikhtilaf) may vary across context and juristic schools."
                },
                aiSynthesis = fallbackSalam + fallbackGuidance,
                sourceLinks = listOf("https://quran.com/16/43", "https://sunnah.com/bukhari:52"),
                actionTags = RuhZenaInAppRouter.detectInAppActions(query, fallbackGuidance),
                retrievalModeLabel = retrievalLabel
            )
        }

        // If web snippet is much more specific than a weak local keyword overlap (e.g. score < 9), prioritize web topic!
        val preferWebPrimary = webSnippet != null && (topLocal == null || topScore < 9)

        val quranEvidence = buildString {
            if (directAyahText != null) {
                append(directAyahText).append("\n\n")
            }
            if (topLocal != null && (!preferWebPrimary || onlineQuranMatches.isEmpty())) {
                append(if (isBn) topLocal.quranBn else topLocal.quranEn)
            }
            if (onlineQuranMatches.isNotEmpty()) {
                if (isNotEmpty()) append("\n\n")
                append(if (isBn) "[অনলাইন কুরআন অনুসন্ধান]:\n" else "[Online Quran Search Results]:\n")
                onlineQuranMatches.forEach { append("• $it\n") }
            }
            if (isEmpty() && webSnippet != null) {
                append(
                    if (isBn) "এই নির্দিষ্ট ঐতিহাসিক/তথ্যভিত্তিক প্রশ্নে সরাসরি বিশ্বকোষীয় তথ্য নিচে সংযুক্ত হয়েছে।"
                    else "Live encyclopedia research returned specific factual context below for your question."
                )
            }
        }.trim()

        val hadithEvidence = if (topLocal != null && !preferWebPrimary) {
            if (isBn) topLocal.hadithBn else topLocal.hadithEn
        } else if (webSnippet != null) {
            if (isBn) "নিচের প্রামাণিক বিশ্বকোষীয় সারসংক্ষেপ দেখুন এবং হাদিস রেফারেন্সের জন্য Sunnah.com যাচাই করুন।"
            else "Review the verified reference summary below and cross-check primary Hadith collections on Sunnah.com."
        } else {
            if (isBn) "উপরের যাচাইকৃত কুরআনের আয়াত উল্লেখ করা হলো।"
            else "Verified Quran search/lookup passages above are cited directly from AlQuran Cloud."
        }

        val scholarly = buildString {
            if (webSnippet != null) {
                append("[${webSnippet.sourceName}: ${webSnippet.title}]\n${webSnippet.summary}")
            }
            if (topLocal != null && (!preferWebPrimary || webSnippet == null)) {
                if (isNotEmpty()) append("\n\n")
                append(if (isBn) topLocal.scholarlyBn else topLocal.scholarlyEn)
            }
            if (isEmpty()) {
                append(
                    if (isBn) "তাফসীর ইবনে কাসীর ও নির্ভরযোগ্য তাফসীরে আয়াতগুলোর প্রেক্ষাপট দেখা উচিত।"
                    else "Consult classical Tafsir (e.g., Tafsir Ibn Kathir) for full historical context of the retrieved verses."
                )
            }
        }.trim()

        val ikhtilaf = if (topLocal != null && !preferWebPrimary) {
            if (isBn) topLocal.ikhtilafBn else topLocal.ikhtilafEn
        } else {
            if (isBn) "আয়াত বা ঐতিহাসিক বিষয়ের ব্যবহারিক প্রয়োগে আলেমদের ব্যাখ্যায় বৈচিত্র্য থাকতে পারে।"
            else "Practical legal applications or historical nuances may carry recognized differences among scholars."
        }

        val fallbackSynthesis = buildString {
            if (webSnippet != null && (preferWebPrimary || looksSpecificQuestion)) {
                append(webSnippet.summary)
                if (topLocal != null && !preferWebPrimary) {
                    append("\n\n")
                    append(if (isBn) topLocal.synthesisBn else topLocal.synthesisEn)
                }
            } else if (topLocal != null) {
                append(if (isBn) topLocal.synthesisBn else topLocal.synthesisEn)
                if (scoredLocal.size > 1) {
                    val second = scoredLocal[1].first
                    append("\n\n")
                    append(if (isBn) "সম্পূরক দিক (${second.topicBn}): ${second.synthesisBn}" else "Related insight (${second.topicEn}): ${second.synthesisEn}")
                }
            } else if (directAyahText != null) {
                append(
                    if (isBn) "উল্লিখিত আয়াতটির অর্থ নিয়ে গভীরভাবে চিন্তা করুন এবং প্রতিদিনের আমলে প্রয়োগ করুন।"
                    else "Reflect deeply on the direct verse text above and its surrounding Surah theme."
                )
            } else {
                append(
                    if (isBn) "উপরের কুরআনের আয়াতগুলো নিয়ে গভীরভাবে চিন্তা করুন এবং আমলে প্রয়োগ করুন।"
                    else "Reflect on the verified verses retrieved above and apply them steadily in daily practice."
                )
            }
        }

        val finalSynthesis = fallbackSynthesis

        val links = buildList {
            if (webSnippet != null && webSnippet.sourceUrl.isNotBlank()) add(webSnippet.sourceUrl)
            topLocal?.links?.let { addAll(it) }
            if (directRef != null) add("https://quran.com/${directRef.first}/${directRef.second}")
            if (onlineQuranMatches.isNotEmpty()) add("https://alquran.cloud")
        }.distinct()

        val openingSalam = if (!alreadyGreetedInSession) {
            if (isBn) "আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহি ওয়া বারাকাতুহু।\n\n"
            else "Assalamu Alaikum wa Rahmatullahi wa Barakatuh.\n\n"
        } else ""

        AiEvidenceResponse(
            topic = if (preferWebPrimary && webSnippet != null) webSnippet.title
            else topLocal?.let { if (isBn) it.topicBn else it.topicEn }
                ?: webSnippet?.title
                ?: query.take(64),
            quranicEvidence = quranEvidence,
            hadithEvidence = hadithEvidence,
            scholarlyExplanations = scholarly,
            scholarlyDifferences = ikhtilaf,
            aiSynthesis = openingSalam + finalSynthesis,
            sourceLinks = links,
            actionTags = RuhZenaInAppRouter.detectInAppActions(query, finalSynthesis),
            retrievalModeLabel = retrievalLabel
        )
    }

    suspend fun answerWellnessQuestion(
        query: String,
        prefs: UserPreferences,
        waterTodayMl: Int,
        avgSleepMinutes: Int,
        workoutsThisWeek: Int,
        mealsToday: List<MealLogEntity> = emptyList(),
        habitsDoneCount: Int = 0,
        totalHabitsCount: Int = 0,
        researchOnlineEnabled: Boolean = true,
        isOnline: Boolean = false,
        history: List<Pair<Boolean, String>> = emptyList()
    ): String = withContext(Dispatchers.IO) {
        val isBn = prefs.language == AppLanguage.BANGLA
        val effectiveQuery = enrichWithRecentContext(query, history)
        val qLower = effectiveQuery.lowercase().trim()

        val totalCal = mealsToday.sumOf { it.calories }
        val totalProtein = mealsToday.sumOf { it.proteinGrams }
        val nameGreeting = prefs.userName.takeIf { it.isNotBlank() }?.let { "$it — " } ?: ""

        val bmr = ((10.0 * prefs.weightKg) + (6.25 * prefs.heightCm) - (5.0 * prefs.ageYears) + 5.0).roundToInt().coerceAtLeast(1100)
        val activityMult = when (prefs.fitnessLevel) {
            "Advanced" -> 1.55
            "Intermediate" -> 1.4
            else -> 1.3
        }
        val tdee = (bmr * activityMult).roundToInt()
        val proteinTargetG = (prefs.weightKg * 1.4).roundToInt().coerceIn(55, 190)

        val matchingExercises = ExerciseLibrary.exercises.filter { ex ->
            ex.nameEn.lowercase().contains(qLower) ||
                ex.nameBn.contains(effectiveQuery) ||
                ex.categoryEn.lowercase().contains(qLower) ||
                ex.musclesEn.lowercase().contains(qLower) ||
                qLower.contains(ex.id.replace("_", " ")) ||
                qLower.contains(ex.nameEn.lowercase().substringBefore(" "))
        }.take(3)

        val contextSummary = if (isBn) {
            "${nameGreeting}আপনার প্রোফাইল: বয়স ${prefs.ageYears}, ওজন ${prefs.weightKg} কেজি, উচ্চতা ${prefs.heightCm} সেমি (${prefs.fitnessLevel} • ${prefs.fitnessGoal}) • BMR ~$bmr / TDEE ~$tdee kcal • পানি: $waterTodayMl/${prefs.hydrationGoalMl} মি.লি. • আজকের খাবার: $totalCal kcal (${totalProtein}/${proteinTargetG}g প্রোটিন) • গড় ঘুম: ${avgSleepMinutes / 60}ঘ ${avgSleepMinutes % 60}মি।"
        } else {
            "${nameGreeting}Live Telemetry: Age ${prefs.ageYears}, ${prefs.weightKg}kg, ${prefs.heightCm}cm (${prefs.fitnessLevel} • ${prefs.fitnessGoal}) | Est. BMR ~$bmr / TDEE ~$tdee kcal | Water: $waterTodayMl/${prefs.hydrationGoalMl} ml | Fuel: $totalCal kcal (${totalProtein}/${proteinTargetG}g protein) | Avg Sleep: ${avgSleepMinutes / 60}h ${avgSleepMinutes % 60}m | Habits: $habitsDoneCount/$totalHabitsCount."
        }

        // Check if user is asking an open-ended informational health/nutrition/science question that benefits from live web context
        val isOpenInfoQuery = qLower.startsWith("what is") || qLower.startsWith("what are") ||
            qLower.startsWith("how does") || qLower.containsAny("creatine", "vitamin", "magnesium", "intermittent", "electrolyte", "hijama", "cupping", "caffeine", "bmi", "vo2", "metabolism", "stretch", "ভিটামিন", "ক্রিয়েটিন", "হিজামা", "মেটাবলিজম")
        val onlineWellnessSnippet = if (researchOnlineEnabled && isOnline && isOpenInfoQuery) {
            fetchOpenWebKnowledge(effectiveQuery, preferBangla = isBn)
        } else {
            null
        }

        val setsReps = when (prefs.fitnessLevel) {
            "Advanced" -> if (isBn) "৪ সেট × ১২–১৮ বার (৪০ সেকেন্ড বিশ্রাম)" else "4 sets × 12–18 reps (40s rest)"
            "Intermediate" -> if (isBn) "৩–৪ সেট × ১০–১৫ বার (৪৫ সেকেন্ড বিশ্রাম)" else "3–4 sets × 10–15 reps (45s rest)"
            else -> if (isBn) "২–৩ সেট × ৮–১০ বার (৬০ সেকেন্ড বিশ্রাম)" else "2–3 sets × 8–10 reps (60s rest)"
        }

        val coachingBody = when {
            onlineWellnessSnippet != null -> buildString {
                append(
                    if (isBn) "অনলাইন তথ্যসূত্র (${onlineWellnessSnippet.sourceName}: ${onlineWellnessSnippet.title}):\n"
                    else "Research Overview (${onlineWellnessSnippet.sourceName}: ${onlineWellnessSnippet.title}):\n"
                )
                append(onlineWellnessSnippet.summary).append("\n\n")
                append(
                    if (isBn) "আপনার প্রোফাইল অনুযায়ী প্রয়োগ: '${prefs.fitnessLevel}' স্তর ও '${prefs.fitnessGoal}' লক্ষ্য অনুযায়ী দৈনিক ~${tdee} kcal, ~${proteinTargetG}g প্রোটিন ও ${prefs.hydrationGoalMl} মি.লি. পানির সাথে সমন্বয় করুন।"
                    else "Personalized Application: Adapt this alongside your ${prefs.fitnessLevel} tier (~$tdee kcal TDEE, ~${proteinTargetG}g protein target, ${prefs.hydrationGoalMl} ml daily water)."
                )
            }

            IslamicKnowledgeCorpus.isGreeting(qLower) || qLower.containsAny("today", "status", "summary", "bmr", "tdee", "plan", "আজ", "অবস্থা", "পরিকল্পনা") -> {
                val waterGap = (prefs.hydrationGoalMl - waterTodayMl).coerceAtLeast(0)
                if (isBn) {
                    "আজকের ব্যক্তিগত স্বাস্থ্য পর্যালোচনা:\n" +
                        "১. ক্যালোরি ও প্রোটিন লক্ষ্য: আপনার ওজন ${prefs.weightKg} কেজি অনুযায়ী দৈনিক রক্ষণাবেক্ষণ ~${tdee} kcal এবং আদর্শ প্রোটিন লক্ষ্য ~${proteinTargetG}g। আজ লগ হয়েছে $totalCal kcal ও ${totalProtein}g।\n" +
                        "২. পানি পান: $waterTodayMl/${prefs.hydrationGoalMl} মি.লি. সম্পন্ন${if (waterGap > 0) " (আরও $waterGap মি.লি. বাকি — প্রতি নামাজের আগে ২৫০ মি.লি. পান করুন)" else " (লক্ষ্য পূর্ণ!)"}।\n" +
                        "৩. আজকের সেরা প্রশিক্ষণ: '${prefs.fitnessGoal}' লক্ষ্যের জন্য Workouts ট্যাব থেকে আপনার ব্যক্তিগতকৃত সেশন শুরু করুন।"
                } else {
                    "Personalized Daily Coaching Audit:\n" +
                        "1. Energy & Protein Calibration: At ${prefs.weightKg}kg / ${prefs.heightCm}cm, your estimated maintenance is ~$tdee kcal/day with a ~${proteinTargetG}g daily protein target. Today: $totalCal kcal and ${totalProtein}g logged.\n" +
                        "2. Hydration: $waterTodayMl / ${prefs.hydrationGoalMl} ml${if (waterGap > 0) " ($waterGap ml left — sip 250 ml around each prayer)" else " (Goal reached!)"}.\n" +
                        "3. Priority Training: Launch your personalized '${prefs.fitnessGoal}' plan in the Workouts tab (intensity adjusted for '${prefs.fitnessLimitation}')."
                }
            }

            qLower.containsAny("sleep", "tired", "fatigue", "energy", "insomnia", "bed", "ঘুম", "ক্লান্ত", "অবসাদ") -> if (isBn) {
                "ঘুম ও এনার্জি রিকভারি প্রোটোকল:\n" +
                    "• ফজরের সময় অনুযায়ী ৭–৮ ঘণ্টা আগে ঘুমানোর সময় ঠিক করুন (গড়: ${avgSleepMinutes / 60}ঘ ${avgSleepMinutes % 60}মি)।\n" +
                    "• ঘুমানোর ৪৫ মিনিট আগে স্ক্রিন বন্ধ রাখুন ও এশার পর ভারী খাবার এড়িয়ে চলুন।\n" +
                    "• শুতে যাওয়ার আগে ২ মিনিট 'Cat-Cow' ও 'Child's Pose' স্ট্রেচ করে বেডটাইম আযকার পাঠ করুন।"
            } else {
                "Restorative Sleep & Energy Protocol:\n" +
                    "• Count backward 7.5 hours from Fajr for your target lights-out time (current 7d avg: ${avgSleepMinutes / 60}h ${avgSleepMinutes % 60}m).\n" +
                    "• Cut caffeine 8 hours before bed and dim screens 45 minutes prior.\n" +
                    "• Wind down with 2 minutes of Cat-Cow + Child's Pose breathing (4s inhale / 6s exhale) paired with Bedtime Adhkar."
            }

            qLower.containsAny("water", "hydrat", "drink", "thirst", "পানি", "তৃষ্ণা") -> if (isBn) {
                "স্মার্ট হাইড্রেশন পরিকল্পনা:\n" +
                    "• আপনার ওজন (${prefs.weightKg} কেজি) অনুযায়ী লক্ষ্য: ${prefs.hydrationGoalMl} মি.লি./দিন (আজ: $waterTodayMl মি.লি.)।\n" +
                    "• ঘুম থেকে উঠে ৩০০ মি.লি., পাঁচ ওয়াক্ত নামাজের আগে ২৫০ মি.লি. ও ব্যায়ামের পর ২৫০ মি.লি. পান করলে সহজেই লক্ষ্য পূরণ হয়।"
            } else {
                "Smart Hydration Strategy:\n" +
                    "• Calibrated goal for ${prefs.weightKg}kg: ${prefs.hydrationGoalMl} ml/day ($waterTodayMl ml logged today).\n" +
                    "• Habit Anchor: Drink 300 ml on waking, 250 ml around each of the 5 prayers, and 250 ml post-workout."
            }

            qLower.containsAny("fat", "lose", "weight", "belly", "lean", "calorie", "cut", "ওজন", "মেদ", "চর্বি", "ক্যালোরি") -> {
                val deficitTarget = (tdee - 350).coerceAtLeast(1350)
                if (isBn) {
                    "টেকসই চর্বি কমানো ও ফিটনেস পরিকল্পনা:\n" +
                        "• লক্ষ্য ক্যালোরি: আপনার TDEE ~${tdee} kcal থেকে নিরাপদ ঘাটতি রাখলে ~${deficitTarget} kcal এবং দৈনিক ${proteinTargetG}g প্রোটিন উপযুক্ত।\n" +
                        "• ওয়ার্কআউট: সপ্তাহে ৩–৪ দিন 'HIIT Fat Burn & Conditioning' + প্রতিদিন ৭,৫০০+ কদম হাঁটা।\n" +
                        "• সুন্নাহ নিয়ম: পেটের ১/৩ খাবার, ১/৩ পানি ও ১/৩ শ্বাসের জন্য রাখুন।"
                } else {
                    "Sustainable Fat Loss & Conditioning Plan:\n" +
                        "• Smart Calorie & Protein Target: Aim for a gentle ~350 kcal deficit (~$deficitTarget kcal/day below your ~$tdee TDEE) while keeping protein near ${proteinTargetG}g/day to preserve lean muscle.\n" +
                        "• Training: 3–4 sessions/week of 'HIIT Fat Burn' or 'Full Body Foundation' ($setsReps) plus 7,500+ daily steps.\n" +
                        "• Prophetic Portion Rule: 1/3 whole food, 1/3 water, 1/3 easy breathing; replace liquid sugars with water."
                }
            }

            qLower.containsAny("suhoor", "iftar", "food", "eat", "meal", "diet", "nutrition", "protein", "কার্ব", "খাবার", "সেহরি", "ইফতার", "পুষ্টি", "প্রোটিন") -> {
                val gainTarget = tdee + 250
                if (isBn) {
                    "ব্যালেন্সড পুষ্টি, সেহরি ও ইফতার গাইড (আজ: $totalCal kcal | P:${totalProtein}/${proteinTargetG}g):\n" +
                        "• লক্ষ্য অনুযায়ী ক্যালোরি: মেইনটেন্যান্স ~${tdee} kcal (মাসল বিল্ডিং চাইলে ~${gainTarget} kcal)।\n" +
                        "• সেহরি: ওটস/লাল আটার রুটি + ২–৩টি ডিম/দই + সবজি ও বাদাম।\n" +
                        "• ইফতার: ১–৩টি খেজুর ও পানি → মাগরিব → গ্রিলড চিকেন/মাছ, ডাল ও সালাদ।"
                } else {
                    "Balanced Nutrition, Suhoor & Iftar Coach (Today: $totalCal kcal | P:${totalProtein}/${proteinTargetG}g):\n" +
                        "• Calibrated Targets: Maintenance ~$tdee kcal | Lean gain ~$gainTarget kcal | Protein ~${proteinTargetG}g/day.\n" +
                        "• Suhoor: Oats or whole-grain bread + 2–3 eggs or Greek yogurt + fruit/veg + 500 ml water.\n" +
                        "• Iftar: 1–3 dates & water → Maghrib → lean protein (chicken/fish/lentils) + complex carbs + greens."
                }
            }

            qLower.containsAny("knee", "pain", "hurt", "injury", "wrist", "back pain", "joint", "shoulder", "হাঁটু", "ব্যথা", "কব্জি", "আঘাত") -> if (isBn) {
                "নিরাপদ জয়েন্ট-ফ্রেন্ডলি বিকল্প নির্দেশিকা:\n" +
                    "• হাঁটুতে চাপ থাকলে: ডিপ স্কোয়াটের বদলে 'Glute Bridge', 'Step Jacks' ও চেয়ার-সাপোর্টেড হাফ-স্কোয়াট করুন।\n" +
                    "• কব্জিতে চাপ পড়লে: পুশ-আপের বদলে দেয়ালে/বেঞ্চে 'Incline Push-Up' বা 'Forearm Plank' করুন।\n" +
                    "• কোমর ব্যথায়: 'Cat-Cow', 'Child's Pose' এবং 'Glute Bridge' অত্যন্ত নিরাপদ ও উপকারী।"
            } else {
                "Joint-Safe Exercise Modifications:\n" +
                    "• Knee discomfort: Swap deep squats/jump jacks for Glute Bridges, Chair-Supported Box Squats, and Low-Impact Step Jacks.\n" +
                    "• Wrist discomfort: Replace floor push-ups with Wall/Bench Incline Push-Ups or Forearm Planks.\n" +
                    "• Lower-back tightness: Prioritize Cat-Cow Mobility, Child's Pose, Glute Bridges, and braced Forearm Planks. Stop any sharp pain and consult a clinician."
            }

            qLower.containsAny("muscle", "chest", "arm", "upper", "strength", "bulk", "gain", "পুশ", "বুক", "হাত", "পেশী") -> {
                val upperEx = ExerciseLibrary.exercises.filter { it.id in listOf("incline_push_up", "push_up", "pike_push_up", "forearm_plank", "superman_hold") }
                formatExercisePlan(isBn, if (isBn) "আপার-বডি ও মাসল স্ট্রেন্থ প্ল্যান" else "Upper Body & Lean Muscle Plan", setsReps, upperEx)
            }

            qLower.containsAny("leg", "glute", "squat", "lunge", "thigh", "calf", "পা", "উরু", "হিপ") -> {
                val legEx = ExerciseLibrary.exercises.filter { it.id in listOf("bodyweight_squat", "reverse_lunge", "glute_bridge", "calf_raise") }
                formatExercisePlan(isBn, if (isBn) "লোয়ার-বডি ও লেগ পাওয়ার প্ল্যান" else "Lower Body & Glute Strength Plan", setsReps, legEx)
            }

            qLower.containsAny("abs", "core", "plank", "posture", "spine", "stretch", "mobility", "কোর", "প্ল্যাঙ্ক", "মেরুদণ্ড", "স্ট্রেচ") -> {
                val coreEx = ExerciseLibrary.exercises.filter { it.id in listOf("forearm_plank", "bicycle_crunch", "cat_cow", "childs_pose_stretch") }
                formatExercisePlan(isBn, if (isBn) "কোর স্ট্যাবিলিটি ও ভঙ্গি উন্নয়ন প্ল্যান" else "Core Stability & Posture Mobility Plan", setsReps, coreEx)
            }

            qLower.containsAny("cardio", "stamina", "hiit", "warm", "conditioning", "burpee", "কার্ডিও", "স্ট্যামিনা") -> {
                val cardioEx = ExerciseLibrary.exercises.filter { it.id in listOf("jumping_jack", "mountain_climbers", "burpee_modified", "bodyweight_squat") }
                formatExercisePlan(isBn, if (isBn) "কার্ডিও, স্ট্যামিনা ও কন্ডিশনিং প্ল্যান" else "Cardio & Athletic Conditioning Plan", setsReps, cardioEx)
            }

            matchingExercises.isNotEmpty() -> {
                formatExercisePlan(
                    isBn,
                    if (isBn) "নির্বাচিত ব্যায়াম নির্দেশিকা" else "Targeted Exercise Form & Technique",
                    setsReps,
                    matchingExercises
                )
            }

            else -> {
                val webHealthInfo = if (researchOnlineEnabled && isOnline) {
                    fetchOpenWebKnowledge(effectiveQuery, preferBangla = isBn)
                } else {
                    null
                }
                if (webHealthInfo != null) {
                    buildString {
                        append(if (isBn) "অনলাইন তথ্যসূত্র (${webHealthInfo.sourceName}: ${webHealthInfo.title}):\n" else "Reference Summary (${webHealthInfo.sourceName}: ${webHealthInfo.title}):\n")
                        append(webHealthInfo.summary).append("\n\n")
                        append(if (isBn) "ব্যবহারিক প্রয়োগ: আপনার '${prefs.fitnessLevel}' স্তর ও '${prefs.fitnessGoal}' লক্ষ্য অনুযায়ী সুষম খাবার, পর্যাপ্ত পানি (${prefs.hydrationGoalMl} মি.লি.) এবং নিয়মিত ব্যায়ামের সাথে সমন্বয় করুন।" else "Practical Application: Align this with your ${prefs.fitnessLevel} training tier, ${proteinTargetG}g protein target, and ${prefs.hydrationGoalMl} ml hydration goal.")
                    }
                } else {
                    val recs = if (prefs.fitnessLimitation.contains("knee", ignoreCase = true)) {
                        ExerciseLibrary.exercises.filter { it.id in listOf("incline_push_up", "glute_bridge", "forearm_plank", "cat_cow") }
                    } else {
                        ExerciseLibrary.exercises.filter { it.id in listOf("jumping_jack", "push_up", "bodyweight_squat", "forearm_plank") }
                    }
                    formatExercisePlan(
                        isBn,
                        if (isBn) "আপনার প্রোফাইলভিত্তিক হোম ওয়ার্কআউট পরিকল্পনা (${prefs.fitnessLevel})" else "Personalized Home Workout Plan (${prefs.fitnessLevel})",
                        setsReps,
                        recs
                    )
                }
            }
        }

        val disclaimer = if (isBn) "\n\n[বিঃদ্রঃ: এটি ফিটনেস নির্দেশনা, কোনো চিকিৎসা পরামর্শ নয়।]" else "\n\n[Educational fitness guidance only — not medical advice.]"
        "$contextSummary\n\n$coachingBody$disclaimer"
    }

    private fun hasSpecificEntityOrQuestionPattern(query: String): Boolean {
        val lower = query.lowercase()
        return lower.containsAny(
            "who ", "when ", "where ", "how many", "what happened", "history of", "battle",
            "caliph", "companion", "sahabah", "kursi", "mulk", "kahf", "rahman", "yasin",
            "badr", "uhud", "khandaq", "abu bakr", "umar", "uthman", "ali", "khadijah", "aisha",
            "musa", "isa", "ibrahim", "yusuf", "maryam", "janazah", "eid", "qurbani",
            "বদর", "সাহাবা", "খলিফা", "কবে", "কোথায়", "কে ছিলেন", "ইতিহাস", "যুদ্ধ"
        )
    }

    private fun enrichWithRecentContext(query: String, history: List<Pair<Boolean, String>>): String {
        val trimmed = query.trim()
        val words = trimmed.split(Regex("\\s+"))
        val isShortFollowUp = words.size <= 5 ||
            trimmed.lowercase().startsWith("more") ||
            trimmed.lowercase().startsWith("why") ||
            trimmed.lowercase().startsWith("explain") ||
            trimmed.lowercase().startsWith("what about") ||
            trimmed.lowercase().startsWith("how about") ||
            trimmed.contains("বিস্তারিত") ||
            trimmed.contains("আরও")
        if (!isShortFollowUp || history.isEmpty()) return trimmed

        val lastUserMsg = history.lastOrNull { it.first && it.second.trim() != trimmed }?.second
            ?: return trimmed
        return "$lastUserMsg $trimmed"
    }

    private fun parseDirectQuranReference(query: String): Pair<Int, Int>? {
        val colonMatch = Regex("""\b(\d{1,3})\s*:\s*(\d{1,3})\b""").find(query)
        if (colonMatch != null) {
            val s = colonMatch.groupValues[1].toIntOrNull()
            val a = colonMatch.groupValues[2].toIntOrNull()
            if (s != null && a != null && s in 1..114 && a >= 1) return s to a
        }
        val lower = query.lowercase()
        if (lower.contains("kursi") || query.contains("কুরসি")) return 2 to 255
        if (lower.contains("fatiha") || query.contains("ফাতিহা")) return 1 to 1
        val matchedSurah = SurahCatalog.allSurahs.firstOrNull { meta ->
            lower.contains(meta.englishName.lowercase()) || lower.contains("surah ${meta.number}")
        }
        if (matchedSurah != null) {
            val ayahMatch = Regex("""\b(\d{1,3})\b""").findAll(query)
                .mapNotNull { it.groupValues[1].toIntOrNull() }
                .firstOrNull { it in 1..matchedSurah.ayahCount }
            return matchedSurah.number to (ayahMatch ?: 1)
        }
        return null
    }

    private fun fetchDirectAyahOnline(surahNum: Int, ayahNum: Int, isBn: Boolean): String? =
        runCatching {
            val editions = if (isBn) "quran-uthmani,bn.bengali,en.sahih" else "quran-uthmani,en.sahih"
            val url = "https://api.alquran.cloud/v1/ayah/$surahNum:$ayahNum/editions/$editions"
            val req = Request.Builder().url(url).header("User-Agent", "RuhZenaAndroid/1.0").build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val root = json.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject
                val arr = root["data"]?.jsonArray ?: return@use null
                if (arr.size < 2) return@use null
                val arText = arr[0].jsonObject["text"]?.jsonPrimitive?.content.orEmpty()
                val transText = arr[1].jsonObject["text"]?.jsonPrimitive?.content.orEmpty()
                val surahMeta = SurahCatalog.getMeta(surahNum)
                val title = "${surahMeta.englishName} $surahNum:$ayahNum"
                "$title\n$arText\n\"$transText\""
            }
        }.getOrNull()

    private fun searchQuranOnline(query: String): List<String> {
        val keywords = IslamicKnowledgeCorpus.translateBanglaTermsForOnlineSearch(query)
            .ifEmpty { IslamicKnowledgeCorpus.extractSearchKeywords(query) }
            .filter { it.length >= 4 && it !in queryNoiseWords }
            .take(2)
        if (keywords.isEmpty()) return emptyList()

        for (keyword in keywords) {
            val found = runCatching {
                val encoded = URLEncoder.encode(keyword, "UTF-8")
                val url = "https://api.alquran.cloud/v1/search/$encoded/all/en.sahih"
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", "RuhZenaAndroid/1.0")
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@use emptyList()
                    val body = resp.body?.string().orEmpty()
                    val root = json.parseToJsonElement(body).jsonObject
                    val matches = root["data"]?.jsonObject?.get("matches")?.jsonArray ?: return@use emptyList()
                    matches.take(3).mapNotNull { item ->
                        val obj = item.jsonObject
                        val text = obj["text"]?.jsonPrimitive?.content ?: return@mapNotNull null
                        val surah = obj["surah"]?.jsonObject
                        val surahNum = surah?.get("number")?.jsonPrimitive?.intOrNull ?: 0
                        val surahName = surah?.get("englishName")?.jsonPrimitive?.content ?: "Surah"
                        val ayahNum = obj["numberInSurah"]?.jsonPrimitive?.intOrNull ?: 0
                        "$surahName ($surahNum:$ayahNum): \"$text\""
                    }
                }
            }.getOrDefault(emptyList())
            if (found.isNotEmpty()) return found
        }
        return emptyList()
    }

    private fun buildCleanWebSearchQuery(query: String): String {
        val translated = IslamicKnowledgeCorpus.translateBanglaTermsForOnlineSearch(query)
        val cleaned = translated.filter { it.length >= 2 && it !in queryNoiseWords }
        if (cleaned.isNotEmpty()) return cleaned.take(6).joinToString(" ")
        return query.trim().take(80)
    }

    private fun fetchOpenWebKnowledge(query: String, preferBangla: Boolean = false): OnlineKnowledgeSnippet? {
        // 1. Try Bangla Wikipedia directly first when user wrote in Bangla script
        val hasBanglaChars = query.any { it.code in 0x0980..0x09FF }
        if (preferBangla && hasBanglaChars) {
            fetchWikipediaFullText(query = query.trim().take(80), langHost = "bn")?.let { return it }
        }

        // 2. Full-text Wikipedia Search + Intro Extract on English Wikipedia using cleaned natural-language keywords
        val cleanedSearch = buildCleanWebSearchQuery(query)
        fetchWikipediaFullText(query = cleanedSearch, langHost = "en")?.let { return it }

        // 3. Fallback: DuckDuckGo Instant Answer JSON API
        val encodedQuery = URLEncoder.encode(cleanedSearch, "UTF-8")
        return runCatching {
            val ddgUrl = "https://api.duckduckgo.com/?q=$encodedQuery&format=json&no_html=1&skip_disambig=1"
            val req = Request.Builder()
                .url(ddgUrl)
                .header("User-Agent", "RuhZenaAndroid/1.0")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val obj = JSONObject(resp.body?.string().orEmpty())
                val abs = obj.optString("AbstractText").trim()
                val heading = obj.optString("Heading").ifBlank { query.take(40) }
                val url = obj.optString("AbstractURL")
                if (abs.length >= 30) {
                    OnlineKnowledgeSnippet(
                        title = heading,
                        summary = abs.take(700),
                        sourceUrl = url,
                        sourceName = "DuckDuckGo Instant"
                    )
                } else null
            }
        }.getOrNull()
    }

    private fun fetchWikipediaFullText(query: String, langHost: String): OnlineKnowledgeSnippet? =
        runCatching {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val searchUrl = "https://$langHost.wikipedia.org/w/api.php?action=query&list=search&srsearch=$encoded&srlimit=3&utf8=1&format=json"
            val searchReq = Request.Builder()
                .url(searchUrl)
                .header("User-Agent", "RuhZenaAndroid/1.0 (https://github.com/ruhzena)")
                .build()
            val topPage = httpClient.newCall(searchReq).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val obj = JSONObject(resp.body?.string().orEmpty())
                val arr = obj.optJSONObject("query")?.optJSONArray("search") ?: return@use null
                if (arr.length() == 0) return@use null
                arr.optJSONObject(0)
            } ?: return null

            val pageId = topPage.optInt("pageid", -1)
            val title = topPage.optString("title")
            if (pageId <= 0 || title.isBlank()) return null

            val extractUrl = "https://$langHost.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=1&explaintext=1&pageids=$pageId&utf8=1&format=json"
            val extractReq = Request.Builder()
                .url(extractUrl)
                .header("User-Agent", "RuhZenaAndroid/1.0 (https://github.com/ruhzena)")
                .build()
            httpClient.newCall(extractReq).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val root = JSONObject(resp.body?.string().orEmpty())
                val pageObj = root.optJSONObject("query")?.optJSONObject("pages")?.optJSONObject(pageId.toString())
                    ?: return@use null
                val extract = pageObj.optString("extract").trim()
                val slug = URLEncoder.encode(title.replace(" ", "_"), "UTF-8")
                if (extract.length >= 40) {
                    OnlineKnowledgeSnippet(
                        title = title,
                        summary = extract.take(750),
                        sourceUrl = "https://$langHost.wikipedia.org/wiki/$slug",
                        sourceName = if (langHost == "bn") "Wikipedia (BN)" else "Wikipedia"
                    )
                } else null
            }
        }.getOrNull()

    private fun formatExercisePlan(
        isBn: Boolean,
        title: String,
        setsReps: String,
        items: List<com.example.ruhzena.ui.exercises.ExerciseItem>
    ): String = buildString {
        append("$title ($setsReps):\n")
        items.forEach { ex ->
            val name = if (isBn) ex.nameBn else ex.nameEn
            val breath = if (isBn) ex.breathingBn else ex.breathingEn
            val reg = if (isBn) ex.easierAltBn else ex.easierAltEn
            val prog = if (isBn) ex.progressionBn else ex.progressionEn
            append("\n• $name (${if (isBn) ex.setsRepsBn else ex.setsRepsEn})\n")
            append("  - ${if (isBn) "শ্বাস" else "Breathing"}: $breath\n")
            append("  - ${if (isBn) "সহজ বিকল্প" else "Easier"}: $reg\n")
            append("  - ${if (isBn) "উন্নত ধাপ" else "Progression"}: $prog\n")
        }
        append(
            if (isBn) "\n'সুস্থতা → ব্যায়াম ও ডেমো' ট্যাবে গিয়ে গাইডেড ওয়ার্কআউট প্লেয়ার চালু করুন।"
            else "\nOpen Wellness → Workouts to launch the guided workout player with live biomechanical form cues."
        )
    }

    private fun String.containsAny(vararg needles: String): Boolean = needles.any { this.contains(it) }
}
