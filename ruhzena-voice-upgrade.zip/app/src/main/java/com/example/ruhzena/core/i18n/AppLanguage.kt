package com.example.ruhzena.core.i18n

enum class AppLanguage(
    val code: String,
    val displayName: String,
    val nativeLabel: String,
    val isRtl: Boolean = false
) {
    ENGLISH("en", "English", "English", false),
    BANGLA("bn", "Bangla", "বাংলা", false),
    ARABIC("ar", "Arabic", "العربية", true),
    URDU("ur", "Urdu", "اردو", true),
    TURKISH("tr", "Turkish", "Türkçe", false),
    INDONESIAN("id", "Indonesian", "Bahasa Indonesia", false),
    MALAY("ms", "Malay", "Bahasa Melayu", false),
    FRENCH("fr", "French", "Français", false);

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: ENGLISH
    }
}
