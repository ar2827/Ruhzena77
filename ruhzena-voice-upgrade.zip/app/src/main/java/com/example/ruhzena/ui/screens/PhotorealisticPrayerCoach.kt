package com.example.ruhzena.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.GoldSourceTag
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.IslamicAcademyCurriculum
import com.example.ruhzena.ui.components.AnimeSalahWuduViewport
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.LocalRuhZenaPalette

@Composable
fun PhotorealisticPrayerCoachTab(
    isBn: Boolean,
    defaultGender: String,
    speakingItemId: String?,
    onSpeakArabic: (itemId: String, arabicText: String, fallbackSpeech: String) -> Unit,
    onSpeakLocalized: (itemId: String, text: String) -> Unit,
    onOpenUrl: (String) -> Unit,
    onAskRuhZenaAi: (String) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    var showWudu by rememberSaveable { mutableStateOf(false) }
    var gender by rememberSaveable(defaultGender) {
        mutableStateOf(if (defaultGender.equals("FEMALE", ignoreCase = true)) "FEMALE" else "MALE")
    }
    var salahIndex by rememberSaveable { mutableIntStateOf(0) }
    var wuduIndex by rememberSaveable { mutableIntStateOf(0) }

    val steps = if (showWudu) IslamicAcademyCurriculum.detailedWuduSteps else IslamicAcademyCurriculum.detailedSalahSteps
    val activeIdx = if (showWudu) wuduIndex.coerceIn(steps.indices) else salahIndex.coerceIn(steps.indices)
    val step = steps[activeIdx]

    val arabicSpeechId = "prayer_arabic_${step.id}"
    val guideSpeechId = "prayer_guide_${step.id}"
    val isArabicPlaying = speakingItemId == arabicSpeechId
    val isGuidePlaying = speakingItemId == guideSpeechId

    val livePostureCaption = when (step.id) {
        "salah_step_1" -> if (isBn) "তাকবীরে তাহরীমা • হাত উত্তোলন" else "Takbiratul Ihram • Raising Hands"
        "salah_step_2" -> if (isBn) "কিয়াম • দাঁড়ানো" else "Qiyam • Standing Upright"
        "salah_step_3" -> if (isBn) "রুকু • সমান্তরাল পিঠ" else "Ruku • 90° Level Bowing"
        "salah_step_4" -> if (isBn) "কাওমা • দুই হাত পাশে ছাড়া" else "Qawmah • Arms Released at Sides"
        "salah_step_5" -> if (isBn) "সিজদা • ৭ অঙ্গে সিজদা" else "Sujud • 7-Point Prostration"
        "salah_step_6" -> if (isBn) "জালসা • দুই সিজদার মাঝে বসা" else "Jalsa • Sitting Calmly"
        "salah_step_7" -> if (isBn) "তাশাহহুদ • শাহাদাত আঙুল ইশারা" else "Tashahhud • Index Finger Raised"
        "salah_step_8" -> if (isBn) "সালাম • ডানে ও বামে ফেরা" else "Taslim • Turning Right & Left"
        "wudu_step_1" -> if (isBn) "অজু • হাত ধোয়া" else "Wudu • Washing Hands (3×)"
        "wudu_step_2" -> if (isBn) "অজু • মুখমণ্ডল ধোয়া" else "Wudu • Rinsing & Face (3×)"
        "wudu_step_3" -> if (isBn) "অজু • হাত, মাথা ও পা" else "Wudu • Arms, Head & Feet"
        else -> if (isBn) "অজু • অজুর পরের দুআ" else "Wudu • Post-Wudu Dua"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("photorealistic_prayer_coach_list"),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 64.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Mode & Gender Selector Card
        item {
            GlassCard(accentBorder = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GlassFilterChip(
                        label = if (isBn) "সালাত (নামাজ)" else "Salah (Prayer)",
                        selected = !showWudu,
                        onClick = { showWudu = false },
                        modifier = Modifier.weight(1f).testTag("pray_mode_salah")
                    )
                    GlassFilterChip(
                        label = if (isBn) "অজু (পবিত্রতা)" else "Wudu (Ablution)",
                        selected = showWudu,
                        onClick = { showWudu = true },
                        modifier = Modifier.weight(1f).testTag("pray_mode_wudu")
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBn) "মডেল:" else "Guide:",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.textSecondary
                    )
                    GlassFilterChip(
                        label = if (isBn) "পুরুষ" else "Male",
                        selected = gender == "MALE",
                        onClick = { gender = "MALE" },
                        modifier = Modifier.testTag("pray_gender_male")
                    )
                    GlassFilterChip(
                        label = if (isBn) "নারী" else "Female",
                        selected = gender == "FEMALE",
                        onClick = { gender = "FEMALE" },
                        modifier = Modifier.testTag("pray_gender_female")
                    )
                }
            }
        }

        // Live Modern Anime-Style Salah & Wudu Posture Stage (step navigation handled cleanly at bottom)
        item {
            GlassCard(accentBorder = true, elevated = true, contentPadding = PaddingValues(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(
                        label = "${if (showWudu) "WUDU" else "SALAH"} • ${step.stepNumber}/${steps.size}",
                        accentColor = palette.accentSoft
                    )
                    StatusPillBadge(label = step.rulingBadge, accentColor = palette.gold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                AnimatedContent(
                    targetState = step.id,
                    transitionSpec = {
                        (fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                            slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { it / 10 } +
                            scaleIn(initialScale = 0.97f, animationSpec = tween(240))) togetherWith
                            (fadeOut(tween(150)) + slideOutHorizontally(tween(160)) { -it / 12 })
                    },
                    label = "prayerStepTransition"
                ) { _ ->
                    Column(modifier = Modifier.fillMaxWidth()) {
                AnimeSalahWuduViewport(
                    stepId = step.id,
                    isWudu = step.isWudu,
                    isFemale = gender == "FEMALE",
                    caption = livePostureCaption
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isBn) step.titleBn else step.titleEn,
                    style = MaterialTheme.typography.titleLarge,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Prominent "WHEN TO SAY WHAT" Timing Cue Banner
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.accentContainer.copy(alpha = 0.75f))
                        .border(0.9.dp, palette.borderAccent, RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = palette.gold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBn) "কখন ও কীভাবে বলবেন" else "WHEN TO SAY THIS",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.gold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isBn) step.whenToSayBn else step.whenToSayEn,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textPrimary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Exact Arabic Phrase + Transliteration + Translation + 1-Tap Listen Button
                // Only shown when an authentic Dua / Dhikr is actually prescribed to be spoken!
                if (step.arabicPhrase.isNotBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(palette.blockBg)
                            .border(0.8.dp, palette.borderNeutral, RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isBn) "যা পাঠ করবেন" else "WHAT TO SAY",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.accentSoft,
                                fontWeight = FontWeight.SemiBold
                            )
                            GlassFilterChip(
                                label = if (isArabicPlaying) {
                                    if (isBn) "থামান" else "Stop"
                                } else {
                                    if (isBn) "আরবি শুনুন" else "Listen Arabic"
                                },
                                selected = isArabicPlaying,
                                icon = if (isArabicPlaying) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                                onClick = {
                                    onSpeakArabic(arabicSpeechId, step.arabicPhrase, step.transliteration)
                                },
                                modifier = Modifier.testTag("pray_listen_arabic_button")
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = step.arabicPhrase,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontFamily = ArabicFontFamily,
                                fontSize = 24.sp,
                                lineHeight = 38.sp,
                                textDirection = TextDirection.Rtl
                            ),
                            color = palette.gold,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (step.transliteration.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = step.transliteration,
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.accentSoft,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        val meaning = if (isBn) step.meaningBn else step.meaningEn
                        if (meaning.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = meaning,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary
                            )
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(palette.blockBg)
                            .border(0.8.dp, palette.borderNeutral, RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Text(
                            text = if (isBn) "নীরবে সম্পন্ন করুন • কোনো নির্দিষ্ট দুআ নেই" else "SILENT ACTION • NO SPOKEN DUA PRESCRIBED",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.accentSoft,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isBn) {
                                "এই ধাপে আলাদা কোনো আরবি দুআ পড়ার বিধান নেই। মনোযোগ ও প্রশান্তির সাথে নিচের নির্দেশনা অনুযায়ী অজু সম্পন্ন করুন।"
                            } else {
                                "No specific Arabic Dua or verse is prescribed to be recited while washing in this step. Simply follow the action calmly with presence of heart."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Body Posture Note
                Text(
                    text = "${if (isBn) "ভঙ্গির নির্দেশনা:" else "Posture:"} ${if (isBn) step.postureCueBn else step.postureCueEn}",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )

                Spacer(modifier = Modifier.height(10.dp))

                GoldSourceTag(
                    sourceText = "${step.sourceRef} ↗",
                    modifier = Modifier.clickable { onOpenUrl(step.sourceUrl) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                GlassFilterChip(
                    label = if (isGuidePlaying) {
                        if (isBn) "থামান" else "Stop"
                    } else {
                        if (isBn) "ব্যাখ্যা শুনুন" else "Listen Guide"
                    },
                    selected = isGuidePlaying,
                    icon = if (isGuidePlaying) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                    onClick = {
                        val spoken = if (isBn) {
                            "${step.titleBn}. ${step.whenToSayBn}. ${step.postureCueBn}. অর্থ: ${step.meaningBn}"
                        } else {
                            "${step.titleEn}. ${step.whenToSayEn}. Posture: ${step.postureCueEn}. Meaning: ${step.meaningEn}"
                        }
                        onSpeakLocalized(guideSpeechId, spoken)
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Previous / Next Step Navigation Controls
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (showWudu && wuduIndex > 0) wuduIndex -= 1
                            else if (!showWudu && salahIndex > 0) salahIndex -= 1
                        },
                        enabled = activeIdx > 0,
                        modifier = Modifier
                            .size(48.dp)
                            .background(palette.blockBg, CircleShape)
                            .border(0.8.dp, palette.borderNeutral, CircleShape)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Previous step",
                            tint = if (activeIdx > 0) palette.textPrimary else palette.textMuted
                        )
                    }

                    EmeraldActionButton(
                        text = if (activeIdx < steps.lastIndex) {
                            if (isBn) "পরবর্তী ধাপ" else "Next Step"
                        } else {
                            if (isBn) "শুরু থেকে দেখুন" else "Restart Guide"
                        },
                        icon = Icons.AutoMirrored.Filled.ArrowForward,
                        onClick = {
                            if (activeIdx < steps.lastIndex) {
                                if (showWudu) wuduIndex += 1 else salahIndex += 1
                            } else {
                                if (showWudu) wuduIndex = 0 else salahIndex = 0
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("pray_next_step_button")
                    )

                    IconButton(
                        onClick = {
                            val q = if (isBn) {
                                "${step.titleBn} সম্পর্কে সাধারণ ভুল ও বিস্তারিত নিয়ম বলুন (${step.sourceRef})।"
                            } else {
                                "Explain '${step.titleEn}' in detail including common mistakes to avoid (${step.sourceRef})."
                            }
                            onAskRuhZenaAi(q)
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .background(palette.blockBg, CircleShape)
                            .border(0.8.dp, palette.borderAccent, CircleShape)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "Ask RuhZena AI", tint = palette.gold)
                    }
                }
            }
        }
    }
}
