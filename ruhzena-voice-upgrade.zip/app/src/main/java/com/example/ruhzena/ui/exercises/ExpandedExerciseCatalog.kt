package com.example.ruhzena.ui.exercises

import androidx.compose.ui.geometry.Offset

/**
 * Extended Hardcore Calisthenics, Push-Up Variations, Lower-Body Power & Flexible Spine Library.
 * Merged seamlessly into `ExerciseLibrary.exercises` and `WorkoutProgramCatalog.programs`.
 */
object ExpandedExerciseCatalog {

    private val defaultPose = SkeletalPose(
        head = Offset(0.50f, 0.25f),
        shoulder = Offset(0.50f, 0.35f),
        elbow = Offset(0.55f, 0.48f),
        wrist = Offset(0.58f, 0.60f),
        hip = Offset(0.50f, 0.56f),
        knee = Offset(0.52f, 0.72f),
        ankle = Offset(0.50f, 0.86f)
    )

    private fun phases(
        p1En: String, p1Bn: String, b1: BreathingCue,
        p2En: String, p2Bn: String, b2: BreathingCue,
        p3En: String, p3Bn: String, b3: BreathingCue,
        p4En: String, p4Bn: String, b4: BreathingCue
    ): List<ExercisePhaseInfo> = listOf(
        ExercisePhaseInfo(defaultPose, p1En, p1Bn, b1),
        ExercisePhaseInfo(defaultPose, p2En, p2Bn, b2),
        ExercisePhaseInfo(defaultPose, p3En, p3Bn, b3),
        ExercisePhaseInfo(defaultPose, p4En, p4Bn, b4)
    )

    val extraExercises: List<ExerciseItem> = listOf(
        // 1. Diamond Push-Up
        ExerciseItem(
            id = "diamond_push_up",
            nameEn = "Diamond Push-Up",
            nameBn = "ডায়মন্ড পুশ-আপ",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Advanced",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Triceps, Inner Chest (Pectorals), Anterior Deltoids, Core",
            musclesBn = "ট্রাইসেপস, বুকের ভেতরের পেশী, কাঁধ ও কোর",
            setsRepsEn = "3 sets × 8–12 reps",
            setsRepsBn = "৩ সেট × ৮–১২ বার",
            restSeconds = 60,
            breathingEn = "Inhale steadily as your chest lowers to your diamond hands; exhale forcefully to press up.",
            breathingBn = "নিচে নামার সময় শ্বাস নিন এবং উপরে ওঠার সময় জোরালোভাবে শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Touch thumbs and index fingers together directly under the center of your sternum",
                "Keep elbows tucked close to ribs—do not flare them outward",
                "Lock glutes and abs in a razor-straight military plank"
            ),
            postureBn = listOf(
                "বুকের ঠিক নিচে দুই হাতের বৃদ্ধাঙ্গুলি ও তর্জনী মিলিয়ে ডায়মন্ড আকৃতি করুন",
                "কনুই পাঁজরের কাছাকাছি রাখুন—বাইরে ছড়াবেন না",
                "কোমর ও কোর শক্ত করে সোজা প্ল্যাঙ্ক লাইন বজায় রাখুন"
            ),
            mistakesEn = listOf(
                "Placing hands too far forward near the face",
                "Letting hips sag as triceps fatigue"
            ),
            mistakesBn = listOf(
                "হাত বুকের নিচে না রেখে মুখের সামনে রাখা",
                "ক্লান্ত হলে কোমর নিচে ঝুলে পড়া"
            ),
            easierAltEn = "Perform Diamond Push-Ups with knees on a padded mat or hands on an elevated bench.",
            easierAltBn = "হাঁটু ম্যাটে রেখে অথবা উঁচু বেঞ্চে হাত রেখে ডায়মন্ড পুশ-আপ করুন।",
            progressionEn = "Elevate feet on a bench for Decline Diamond Push-Ups.",
            progressionBn = "বেঞ্চে পা তুলে ডিক্লাইন ডায়মন্ড পুশ-আপ করুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Diamond Lock — Thumbs & index fingers form a diamond under sternum",
                "১. ডায়মন্ড লক — বুকের নিচে দুই হাত মিলিয়ে স্থির হন", BreathingCue.STEADY,
                "2. Tucked Descent — Lower slowly with elbows grazing ribs",
                "২. নিয়ন্ত্রিত অবতরণ — কনুই শরীরের পাশে রেখে নিচে নামুন", BreathingCue.INHALE,
                "3. Sternum Tap — Chest hovers 2 cm above diamond hands",
                "৩. সর্বনিম্ন বিন্দু — বুক হাতের ঠিক ওপরে স্থির করুন", BreathingCue.INHALE,
                "4. Tricep Press — Drive explosively back to full elbow lockout",
                "৪. ট্রাইসেপস প্রেস — শক্তভাবে ঠেলে সোজা হয়ে উঠুন", BreathingCue.EXHALE
            )
        ),

        // 2. Army / Military Push-Up
        ExerciseItem(
            id = "military_push_up",
            nameEn = "Army (Military) Push-Up",
            nameBn = "আর্মি (মিলিটারি) পুশ-আপ",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Advanced",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Triceps, Pectorals, Front Deltoids, Core & Lower Back Stability",
            musclesBn = "ট্রাইসেপস, বুক, কাঁধ, কোর ও পিঠের স্থায়িত্ব",
            setsRepsEn = "4 sets × 12–15 reps",
            setsRepsBn = "৪ সেট × ১২–১৫ বার",
            restSeconds = 50,
            breathingEn = "Sharp rhythmic inhale on descent, crisp disciplined exhale on every rep up.",
            breathingBn = "নামার সময় গভীর শ্বাস নিন এবং ওঠার সময় ছন্দবদ্ধভাবে শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Hands strictly shoulder-width apart, feet together, heels locked upright",
                "Elbows track straight back alongside ribs at 0–15°",
                "Full chest-to-deck range of motion with zero hip sway"
            ),
            postureBn = listOf(
                "হাত ঠিক কাঁধ বরাবর এবং দুই পা একসাথে লাগানো রাখুন",
                "কনুই সম্পূর্ণ পেছন দিকে পাঁজরের সাথে মিশে নামবে",
                "কোমর না বাঁকিয়ে বুক মেঝের কাছাকাছি নামিয়ে পূর্ণ রেপ করুন"
            ),
            mistakesEn = listOf(
                "Half-reps that stop before upper arms break parallel",
                "Dropping the chin before the chest reaches the floor"
            ),
            mistakesBn = listOf(
                "অর্ধেক নেমেই উঠে পড়া",
                "বুকের আগে মাথা নিচে নামিয়ে দেওয়া"
            ),
            easierAltEn = "Standard shoulder-width Push-Up with wider foot stance for stability.",
            easierAltBn = "ভারসাম্যের জন্য পা সামান্য ফাঁকা রেখে সাধারণ পুশ-আপ করুন।",
            progressionEn = "Add a 2-second dead-stop pause at the bottom of every military rep.",
            progressionBn = "প্রতি রেপের নিচে ২ সেকেন্ড স্থির থেকে আবার ঠেলে উঠুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Attention Plank — Feet together, hands strictly under shoulders",
                "১. মিলিটারি প্ল্যাঙ্ক — দুই পা একসাথে, হাত কাঁধের নিচে", BreathingCue.STEADY,
                "2. Disciplined Lower — Elbows drive straight back along ribs",
                "২. সুশৃঙ্খল অবতরণ — কনুই সোজা পেছনে নিয়ে নিচে নামুন", BreathingCue.INHALE,
                "3. Chest to Deck — Rigid spine hovers cleanly over floor",
                "৩. চেস্ট টু ডেক — সোজা শরীর মেঝের খুব কাছে স্থির রাখুন", BreathingCue.INHALE,
                "4. Lockout Drive — Snap cleanly back to full military plank",
                "৪. শক্তিশালী উত্তোলন — সম্পূর্ণ সোজা অবস্থায় ফিরে আসুন", BreathingCue.EXHALE
            )
        ),

        // 3. Wide-Grip Push-Up
        ExerciseItem(
            id = "wide_push_up",
            nameEn = "Wide-Grip Push-Up",
            nameBn = "ওয়াইড-গ্রিপ পুশ-আপ",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Intermediate",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Outer Pectorals (Chest), Anterior Shoulders, Core",
            musclesBn = "বুকের বাইরের পেশী, কাঁধ ও কোর",
            setsRepsEn = "3 sets × 12–15 reps",
            setsRepsBn = "৩ সেট × ১২–১৫ বার",
            restSeconds = 45,
            breathingEn = "Inhale to stretch the chest wide at the bottom; exhale squeezing pecs together at top.",
            breathingBn = "নিচে বুক প্রসারিত করার সময় শ্বাস নিন; ওঠার সময় বুক সংকুচিত করে শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Place palms ~1.5× shoulder width with fingers turned slightly outward",
                "Keep shoulder blades retracted and core tight",
                "Lower smoothly until chest is just above the floor"
            ),
            postureBn = listOf(
                "দুই হাত কাঁধের চেয়ে দেড় গুণ প্রশস্ত করে রাখুন",
                "কাঁধ স্থির রেখে কোর শক্ত করে ধরুন",
                "ধীরে বুক মেঝের কাছাকাছি নামিয়ে আনুন"
            ),
            mistakesEn = listOf(
                "Shrugging shoulders up toward the ears",
                "Hyperextending the lower back"
            ),
            mistakesBn = listOf(
                "কাঁধ কানের দিকে তুলে রাখা",
                "কোমর নিচে বাঁকিয়ে ফেলা"
            ),
            easierAltEn = "Incline Push-Up with wide hand placement on a bench.",
            easierAltBn = "বেঞ্চে প্রশস্তভাবে হাত রেখে ইনক্লাইন পুশ-আপ করুন।",
            progressionEn = "Progress to Archer Push-Ups shifting weight side-to-side.",
            progressionBn = "আর্চার পুশ-আপে উন্নীত হোন।",
            floorY = 0.84f,
            phases = phases(
                "1. Wide Stance — Hands set 1.5× shoulder width, chest proud",
                "১. প্রশস্ত অবস্থান — কাঁধের দেড় গুণ প্রশস্ত করে হাত রাখুন", BreathingCue.STEADY,
                "2. Deep Pec Stretch — Lower torso smoothly between wide hands",
                "২. গভীর প্রসারণ — দুই হাতের মাঝে বুক ধীরে নিচে নামান", BreathingCue.INHALE,
                "3. Bottom Stretch — Brief pause with full chest engagement",
                "৩. সর্বনিম্ন প্রসারণ — বুকের পেশী টান অনুভব করুন", BreathingCue.INHALE,
                "4. Chest Squeeze — Press cleanly up squeezing pectorals",
                "৪. বুক সংকোচন — বুকের শক্তিতে ওপরে উঠে আসুন", BreathingCue.EXHALE
            )
        ),

        // 4. Decline Push-Up
        ExerciseItem(
            id = "decline_push_up",
            nameEn = "Decline Push-Up",
            nameBn = "ডিক্লাইন পুশ-আপ",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Advanced",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Upper Chest (Clavicular Pecs), Front Deltoids, Triceps, Core",
            musclesBn = "বুকের উপরের অংশ, কাঁধ, ট্রাইসেপস ও কোর",
            setsRepsEn = "3 sets × 10–12 reps",
            setsRepsBn = "৩ সেট × ১০–১২ বার",
            restSeconds = 60,
            breathingEn = "Inhale with control as your upper chest dips toward the mat; exhale driving strongly up.",
            breathingBn = "নিচে নামার সময় শ্বাস নিন এবং শক্তভাবে ওপরে ঠেলে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Plant toes securely atop a sturdy stationary box or bench behind you",
                "Keep palms planted firmly beneath shoulders on the floor",
                "Maintain a crisp straight line from elevated heels to crown of head"
            ),
            postureBn = listOf(
                "পিছনে একটি স্থির বেঞ্চ বা বক্সের ওপর দুই পায়ের আঙুল শক্তভাবে রাখুন",
                "দুই হাত কাঁধের নিচে মেঝেতে স্থির রাখুন",
                "উঁচু গোড়ালি থেকে মাথা পর্যন্ত সম্পূর্ণ সোজা রেখা বজায় রাখুন"
            ),
            mistakesEn = listOf(
                "Allowing the lower back to arch downward under gravity",
                "Dropping the forehead instead of lowering the chest"
            ),
            mistakesBn = listOf(
                "মাধ্যাকর্ষণে কোমর নিচে ঝুলে পড়া",
                "বুকের বদলে শুধু কপাল নিচে নামানো"
            ),
            easierAltEn = "Standard floor Push-Up until you can do 15 crisp reps.",
            easierAltBn = "আগে মেঝেতে ১৫টি সঠিক পুশ-আপ আয়ত্ত করুন।",
            progressionEn = "Transition into Pike Push-Ups for overhead shoulder strength.",
            progressionBn = "কাঁধের শক্তির জন্য পাইক পুশ-আপ শুরু করুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Elevated Plank — Toes planted firmly on stationary bench, hands locked on floor",
                "১. উঁচু প্ল্যাঙ্ক — পা স্থির বেঞ্চে এবং হাত মেঝেতে দৃঢ় রাখুন", BreathingCue.STEADY,
                "2. Angled Descent — Lower upper chest steadily toward the mat",
                "২. নিয়ন্ত্রিত অবতরণ — বুকের উপরের অংশ মেঝের দিকে নামান", BreathingCue.INHALE,
                "3. Deep Hover — Upper chest pauses cleanly above the mat",
                "৩. গভীর স্থিরতা — মেঝের ঠিক ওপরে বুক ধরে রাখুন", BreathingCue.INHALE,
                "4. Upper-Pec Press — Drive powerfully back to locked decline plank",
                "৪. শক্তিশালী উত্তোলন — দৃঢ়ভাবে ঠেলে সোজা অবস্থানে উঠুন", BreathingCue.EXHALE
            )
        ),

        // 5. Pike Push-Up
        ExerciseItem(
            id = "pike_push_up",
            nameEn = "Pike Push-Up",
            nameBn = "পাইক পুশ-আপ",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Advanced",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Deltoids (Shoulders), Upper Traps, Triceps, Upper Chest",
            musclesBn = "কাঁধ (ডেল্টয়েডস), আপার ট্র্যাপস ও ট্রাইসেপস",
            setsRepsEn = "3 sets × 8–10 reps",
            setsRepsBn = "৩ সেট × ৮–১০ বার",
            restSeconds = 60,
            breathingEn = "Inhale as the crown of your head tracks forward toward the mat; exhale pressing overhead.",
            breathingBn = "মাথা সামনে নিচে নামানোর সময় শ্বাস নিন; ওপরে ঠেলার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Hinge hips high into an inverted-V pike with straight spine",
                "Lower your head slightly in front of your hands (tripod triangle)",
                "Keep elbows angled back ~45°, never straight out sideways"
            ),
            postureBn = listOf(
                "কোমর উঁচুতে তুলে উল্টো-V (পাইক) আকৃতি তৈরি করুন",
                "দুই হাতের একটু সামনের দিকে মাথা নিচে নামান",
                "কনুই ৪৫° পেছনের দিকে রাখুন"
            ),
            mistakesEn = listOf(
                "Dropping head straight between hands instead of forward tripod",
                "Flaring elbows wide and straining shoulder capsules"
            ),
            mistakesBn = listOf(
                "হাতের সামনে না নামিয়ে মাঝখানে মাথা নামানো",
                "কনুই অতিরিক্ত বাইরে ছড়িয়ে দেওয়া"
            ),
            easierAltEn = "Bend knees slightly in Pike stance to reduce hamstring tightness.",
            easierAltBn = "হ্যামস্ট্রিংয়ে টান লাগলে হাঁটু সামান্য ভাঁজ করুন।",
            progressionEn = "Elevate feet on a sturdy box for Elevated Pike Push-Ups.",
            progressionBn = "বেঞ্চে পা তুলে এলিভেটেড পাইক পুশ-আপ করুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Inverted-V Pike — Hips driven high, heels light, spine tall",
                "১. উল্টো-V পাইক — কোমর উঁচু ও পিঠ সোজা রাখুন", BreathingCue.STEADY,
                "2. Tripod Dive — Bend elbows and shift crown slightly forward",
                "২. ট্রাইপড অবতরণ — কনুই ভাঁজ করে মাথা সামনের দিকে নামান", BreathingCue.INHALE,
                "3. Shoulder Load — Hover crown 3 cm ahead of fingertips",
                "৩. কাঁধে চাপ — মেঝের সামান্য ওপরে স্থির থাকুন", BreathingCue.INHALE,
                "4. Overhead Press — Drive back cleanly into tall inverted-V",
                "৪. ওভারহেড প্রেস — কাঁধের শক্তিতে পুনরায় উঁচুতে উঠুন", BreathingCue.EXHALE
            )
        ),

        // 6. Archer Push-Up
        ExerciseItem(
            id = "archer_push_up",
            nameEn = "Archer Push-Up",
            nameBn = "আর্চার পুশ-আপ",
            categoryEn = "Upper Body Strength",
            categoryBn = "উপরের অংশের শক্তি",
            difficulty = "Advanced",
            activeZone = MuscleZone.CHEST_ARMS,
            musclesEn = "Unilateral Chest, Triceps, Shoulders, Anti-Rotation Core",
            musclesBn = "একপার্শ্বীয় বুক, ট্রাইসেপস, কাঁধ ও কোর",
            setsRepsEn = "3 sets × 6–8 per side",
            setsRepsBn = "৩ সেট × প্রতি পাশে ৬–৮ বার",
            restSeconds = 60,
            breathingEn = "Inhale shifting weight onto your working arm; exhale exploding back to center.",
            breathingBn = "এক হাতে ভর দিয়ে নামার সময় শ্বাস নিন; মাঝে ফেরার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Start in a wide push-up stance with fingers angled 45° outward",
                "Keep the assisting arm straight while lowering chest toward the working hand",
                "Keep hips level without twisting the lower back"
            ),
            postureBn = listOf(
                "প্রশস্ত পুশ-আপ অবস্থানে হাত বাইরের দিকে ৪৫° ঘুরিয়ে রাখুন",
                "সহায়ক হাত সোজা রেখে মূল হাতের দিকে বুক নামান",
                "কোমর না ঘুরিয়ে সমান্তরাল রাখুন"
            ),
            mistakesEn = listOf(
                "Bending both elbows equally instead of loading one arm",
                "Letting hips twist sideways"
            ),
            mistakesBn = listOf(
                "দুই কনুই সমানভাবে ভাঁজ করা",
                "কোমর একপাশে ঘুরে যাওয়া"
            ),
            easierAltEn = "Wide-Grip Push-Up with slow 3-second eccentric lowering.",
            easierAltBn = "ধীরগতির ওয়াইড-গ্রিপ পুশ-আপ অনুশীলন করুন।",
            progressionEn = "Bridge directly toward strict One-Arm Push-Ups.",
            progressionBn = "ওয়ান-আর্ম পুশ-আপের জন্য প্রস্তুতি নিন।",
            floorY = 0.84f,
            phases = phases(
                "1. Wide Archer Setup — Wide palms anchored, core braced tight",
                "১. প্রশস্ত আর্চার অবস্থান — দুই হাত প্রশস্ত করে স্থির থাকুন", BreathingCue.STEADY,
                "2. Shift & Load — Lower toward working hand, opposite arm straight",
                "২. একপার্শ্বীয় অবতরণ — এক হাত সোজা রেখে অন্য দিকে বুক নামান", BreathingCue.INHALE,
                "3. Unilateral Peak — Pause low over loaded chest & tricep",
                "৩. পূর্ণ চাপ — নিচে এক মুহূর্ত স্থির থাকুন", BreathingCue.INHALE,
                "4. Center Drive — Push powerfully back to symmetric top lock",
                "৪. কেন্দ্রে প্রত্যাবর্তন — শক্তিশালী ধাক্কায় মাঝে ফিরে আসুন", BreathingCue.EXHALE
            )
        ),

        // 7. Full Athletic Burpee
        ExerciseItem(
            id = "burpee",
            nameEn = "Full Athletic Burpee",
            nameBn = "ফুল অ্যাথলেটিক বার্পি",
            categoryEn = "Cardio & Conditioning",
            categoryBn = "কার্ডিও ও কন্ডিশনিং",
            difficulty = "Advanced",
            activeZone = MuscleZone.FULL_BODY,
            musclesEn = "Full Body — Quads, Glutes, Chest, Shoulders, Core & Cardiovascular Engine",
            musclesBn = "সম্পূর্ণ শরীর — পা, গ্লুটস, বুক, কাঁধ, কোর ও হৃদযন্ত্র",
            setsRepsEn = "3 sets × 10–12 reps",
            setsRepsBn = "৩ সেট × ১০–১২ বার",
            restSeconds = 60,
            breathingEn = "Inhale dropping into plank, exhale driving up through the explosive vertical jump.",
            breathingBn = "প্ল্যাঙ্কে নামার সময় শ্বাস নিন এবং লাফিয়ে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Squat down placing palms solidly inside shoulder width",
                "Kick feet cleanly back into a tight horizontal plank without sagging hips",
                "Snap feet back under hips and explode tall with arms overhead"
            ),
            postureBn = listOf(
                "স্কোয়াট করে দুই হাত মেঝেতে দৃঢ়ভাবে রাখুন",
                "পা পেছনে ছুঁড়ে সোজা প্ল্যাঙ্ক করুন—কোমর ঝুলতে দেবেন না",
                "পা সামনে টেনে হাত ওপরে তুলে লাফিয়ে উঠুন"
            ),
            mistakesEn = listOf(
                "Slamming hips down into an arched back during the plank",
                "Landing stiff-legged after the vertical jump"
            ),
            mistakesBn = listOf(
                "প্ল্যাঙ্কে কোমর নিচে আছড়ে ফেলা",
                "লাফ থেকে নামার সময় হাঁটু শক্ত করে রাখা"
            ),
            easierAltEn = "Step-back Burpee: step feet back one at a time and skip the jump.",
            easierAltBn = "লাফ না দিয়ে এক পা করে পেছনে নিয়ে সহজ বার্পি করুন।",
            progressionEn = "Add a full chest-to-floor Push-Up at the bottom of every rep.",
            progressionBn = "প্রতি বার্পির নিচে একটি পূর্ণ পুশ-আপ যুক্ত করুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Squat Plant — Drop hips and plant palms solidly on the mat",
                "১. স্কোয়াট প্ল্যান্ট — নিচু হয়ে দুই হাত মেঝেতে স্থাপন করুন", BreathingCue.INHALE,
                "2. Snap to Plank — Kick feet back into a crisp rigid plank",
                "২. প্ল্যাঙ্ক কিক — পা পেছনে নিয়ে সোজা প্ল্যাঙ্কে আসুন", BreathingCue.STEADY,
                "3. Frog Tuck — Drive feet explosively forward under your chest",
                "৩. ফ্রগ টাক — দুই পা দ্রুত বুকের নিচে টেনে আনুন", BreathingCue.INHALE,
                "4. Vertical Explosion — Launch upward with arms reaching tall",
                "৪. ঊর্ধ্বমুখী লাফ — দুই হাত ওপরে তুলে লাফিয়ে উঠুন", BreathingCue.EXHALE
            )
        ),

        // 8. Hollow Body Hold
        ExerciseItem(
            id = "hollow_body_hold",
            nameEn = "Hollow Body Hold",
            nameBn = "হলো বডি হোল্ড",
            categoryEn = "Core Stability",
            categoryBn = "কোর স্থায়িত্ব",
            difficulty = "Advanced",
            activeZone = MuscleZone.CORE,
            musclesEn = "Deep Transverse Abdominis, Rectus Abdominis, Hip Flexors, Quads",
            musclesBn = "গভীর পেটের পেশী, অ্যাবস ও হিপ ফ্লেক্সর",
            setsRepsEn = "3 sets × 25–40 sec",
            setsRepsBn = "৩ সেট × ২৫–৪০ সেকেন্ড",
            restSeconds = 40,
            breathingEn = "Maintain steady shallow diaphragmatic breaths while keeping lower back glued down.",
            breathingBn = "কোমর মেঝেতে চেপে রেখে শান্ত ও নিয়মিত শ্বাস-প্রশ্বাস চালিয়ে যান।",
            postureEn = listOf(
                "Press lower back flush into the mat—zero gap under your lumbar spine",
                "Lift shoulder blades off the floor with arms extended past ears",
                "Point toes and squeeze straight legs together 15–20 cm above floor"
            ),
            postureBn = listOf(
                "কোমরের নিচের অংশ মেঝেতে সম্পূর্ণ চেপে ধরুন—কোনো ফাঁক রাখবেন না",
                "কাঁধ মেঝে থেকে তুলে দুই হাত কানের পাশ দিয়ে সোজা প্রসারিত করুন",
                "দুই পা একসাথে সোজা করে মেঝে থেকে কিছুটা ওপরে ধরে রাখুন"
            ),
            mistakesEn = listOf(
                "Allowing the lower back to peel off the mat",
                "Holding your breath and turning tense in the neck"
            ),
            mistakesBn = listOf(
                "কোমর মেঝে থেকে উঠে যাওয়া",
                "শ্বাস বন্ধ করে ঘাড়ে চাপ দেওয়া"
            ),
            easierAltEn = "Tuck one or both knees slightly toward chest while keeping lower back flat.",
            easierAltBn = "কোমর মেঝেতে রাখতে এক বা দুই হাঁটু সামান্য ভাঁজ করুন।",
            progressionEn = "Perform controlled Hollow Body Rocks maintaining the exact banana curve.",
            progressionBn = "একই বাঁকা ভঙ্গিতে ধীরে সামনে-পেছনে দুলুন (হলো রক)।",
            floorY = 0.84f,
            phases = phases(
                "1. Lumbar Imprint — Press lower back firmly into mat, brace abs",
                "১. কোমর লক — কোমর মেঝেতে চেপে ধরে পেট শক্ত করুন", BreathingCue.INHALE,
                "2. Scoop & Lift — Peel shoulders and straight legs into banana curve",
                "২. হলো কার্ভ — কাঁধ ও সোজা পা তুলে কলার মতো বাঁকা হন", BreathingCue.EXHALE,
                "3. Gymnastics Lock — Hold extended arms & pointed toes steadily",
                "৩. স্থির হোল্ড — হাত ও পা টানটান রেখে স্থির থাকুন", BreathingCue.STEADY,
                "4. Deep Core Breathe — Maintain lumbar seal through smooth breaths",
                "৪. নিয়ন্ত্রিত শ্বাস — কোমরের চাপ বজায় রেখে শ্বাস নিন", BreathingCue.STEADY
            )
        ),

        // 9. Lying Straight-Leg Raises
        ExerciseItem(
            id = "lying_leg_raises",
            nameEn = "Lying Leg Raises",
            nameBn = "লায়িং লেগ রেইজ",
            categoryEn = "Core Stability",
            categoryBn = "কোর স্থায়িত্ব",
            difficulty = "Intermediate",
            activeZone = MuscleZone.CORE,
            musclesEn = "Lower Abdominals, Hip Flexors, Deep Core",
            musclesBn = "নিম্ন পেটের পেশী (লোয়ার অ্যাবস) ও হিপ ফ্লেক্সর",
            setsRepsEn = "3 sets × 12–15 reps",
            setsRepsBn = "৩ সেট × ১২–১৫ বার",
            restSeconds = 40,
            breathingEn = "Exhale lifting both straight legs to 90°; inhale lowering slowly without touching heels.",
            breathingBn = "পা ওপরে তোলার সময় শ্বাস ছাড়ুন এবং ধীরে নিচে নামানোর সময় শ্বাস নিন।",
            postureEn = listOf(
                "Place palms flat beside hips for steady pelvic support",
                "Press lower back into the mat throughout the entire arc",
                "Lower legs smoothly to ~10 cm off the floor—do not drop heels"
            ),
            postureBn = listOf(
                "ভারসাম্যের জন্য দুই হাত কোমরের পাশে মেঝেতে রাখুন",
                "পুরো সময় কোমরের নিচের অংশ মেঝেতে লেগে থাকবে",
                "গোড়ালি মেঝেতে না ছুঁয়েই সামান্য ওপরে থামিয়ে আবার তুলুন"
            ),
            mistakesEn = listOf(
                "Swinging legs up using momentum instead of core control",
                "Arching the lower back when legs approach the floor"
            ),
            mistakesBn = listOf(
                "ঝাঁকুনি দিয়ে পা তোলা",
                "পা নামানোর সময় কোমর বাঁকিয়ে ফেলা"
            ),
            easierAltEn = "Bend knees to 90° (Bent-Knee Leg Raises) for lighter leverage.",
            easierAltBn = "সহজ করতে হাঁটু ৯০° ভাঁজ করে লেগ রেইজ করুন।",
            progressionEn = "Add a Dragon-Flag hip lift at the top of each rep.",
            progressionBn = "প্রতি রেপের শীর্ষে কোমর সামান্য ওপরে তুলুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Hover Start — Straight legs hover 10 cm off mat, back flat",
                "১. শুরু — সোজা পা মেঝে থেকে সামান্য ওপরে রাখুন", BreathingCue.INHALE,
                "2. Controlled Sweep — Raise locked legs steadily through 45°",
                "২. নিয়ন্ত্রিত উত্তোলন — সোজা পা ধীরে ৪৫° ওপরে তুলুন", BreathingCue.EXHALE,
                "3. Vertical Peak — Pause legs perpendicular at 90° over hips",
                "৩. ৯০° শীর্ষ — কোমরের ওপরে পা সোজা স্থির করুন", BreathingCue.EXHALE,
                "4. Slow Eccentric — Lower with brakes on without arching back",
                "৪. ধীর অবতরণ — কোমর সোজা রেখে ধীরে পা নামান", BreathingCue.INHALE
            )
        ),

        // 10. V-Up Jackknife
        ExerciseItem(
            id = "v_ups",
            nameEn = "V-Up Jackknife",
            nameBn = "ভি-আপ জ্যাকনাইফ",
            categoryEn = "Core Stability",
            categoryBn = "কোর স্থায়িত্ব",
            difficulty = "Advanced",
            activeZone = MuscleZone.CORE,
            musclesEn = "Upper & Lower Rectus Abdominis, Obliques, Hip Flexors",
            musclesBn = "সম্পূর্ণ পেটের পেশী, অব্লিকস ও হিপ ফ্লেক্সর",
            setsRepsEn = "3 sets × 10–12 reps",
            setsRepsBn = "৩ সেট × ১০–১২ বার",
            restSeconds = 50,
            breathingEn = "Exhale sharply folding into a crisp V; inhale uncurling back into hollow extension.",
            breathingBn = "ভি-আকৃতিতে ভাঁজ হওয়ার সময় শ্বাস ছাড়ুন; প্রসারিত হওয়ার সময় শ্বাস নিন।",
            postureEn = listOf(
                "Start fully extended supine with arms reaching overhead",
                "Simultaneously hinge torso and straight legs upward to meet at the top",
                "Reach fingertips toward ankles while balancing cleanly on sit bones"
            ),
            postureBn = listOf(
                "চিত হয়ে শুয়ে হাত মাথার পেছনে ও পা সোজা প্রসারিত করুন",
                "একসাথে বুক ও সোজা পা ওপরে তুলে V আকৃতি তৈরি করুন",
                "আঙুল পায়ের গোড়ালির দিকে বাড়িয়ে কোরে ভারসাম্য রাখুন"
            ),
            mistakesEn = listOf(
                "Yanking the neck forward instead of flexing from the ribcage",
                "Collapsing flat onto the floor between reps"
            ),
            mistakesBn = listOf(
                "পেটের বদলে ঘাড়ে টান দেওয়া",
                "প্রতি রেপের পর ধপাস করে মেঝেতে পড়ে যাওয়া"
            ),
            easierAltEn = "Tuck-Ups: bend knees into chest while reaching hands toward shins.",
            easierAltBn = "সহজ করতে হাঁটু ভাঁজ করে টাক-আপ করুন।",
            progressionEn = "Pause for 2 full seconds in the balanced V-peak on every rep.",
            progressionBn = "প্রতি রেপে V-শীর্ষে ২ সেকেন্ড স্থির হয়ে ভারসাম্য রাখুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Extended Hollow — Arms long overhead, legs hovering off mat",
                "১. প্রসারিত শুরু — হাত পেছনে ও পা সোজা রাখুন", BreathingCue.INHALE,
                "2. Explosive Fold — Hinge chest and legs upward simultaneously",
                "২. দ্রুত ভাঁজ — বুক ও পা একসাথে ওপরে তুলুন", BreathingCue.EXHALE,
                "3. Crisp V-Peak — Fingertips touch shins/toes balanced on sit bones",
                "৩. ভি-শীর্ষ — হাত পায়ের দিকে ছুঁয়ে V আকৃতি স্থির করুন", BreathingCue.EXHALE,
                "4. Controlled Uncurl — Roll vertebrae smoothly back to hollow hover",
                "৪. নিয়ন্ত্রিত প্রসারণ — ধীরে প্রসারিত অবস্থানে ফিরে যান", BreathingCue.INHALE
            )
        ),

        // 11. Side Plank Hip Lift
        ExerciseItem(
            id = "side_plank",
            nameEn = "Side Plank Hip Lift",
            nameBn = "সাইড প্ল্যাঙ্ক হিপ লিফট",
            categoryEn = "Core Stability",
            categoryBn = "কোর স্থায়িত্ব",
            difficulty = "Intermediate",
            activeZone = MuscleZone.CORE,
            musclesEn = "Obliques, Quadratus Lumborum, Glute Medius, Shoulder Stabilizers",
            musclesBn = "অব্লিকস (পার্শ্বীয় কোর), গ্লুটস ও কাঁধের স্থায়িত্ব",
            setsRepsEn = "3 sets × 12 reps / side",
            setsRepsBn = "৩ সেট × প্রতি পাশে ১২ বার",
            restSeconds = 40,
            breathingEn = "Inhale dipping hip lightly toward floor; exhale driving oblique skyward.",
            breathingBn = "কোমর নিচে নামানোর সময় শ্বাস নিন; ওপরে তোলার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Stack elbow directly beneath shoulder and keep forearm pressed flat",
                "Keep ears, shoulders, hips, and ankles aligned in one lateral plane",
                "Drive bottom oblique upward cleanly on every hip lift"
            ),
            postureBn = listOf(
                "কনুই ঠিক কাঁধের নিচে রেখে পুরো বাহু মেঝেতে স্থির করুন",
                "মাথা, কাঁধ, কোমর ও পা এক সরলরেখায় রাখুন",
                "পার্শ্বীয় কোরের শক্তিতে কোমর ছন্দবদ্ধভাবে ওপরে তুলুন"
            ),
            mistakesEn = listOf(
                "Rolling the top shoulder forward toward the mat",
                "Sinking into the supporting shoulder joint"
            ),
            mistakesBn = listOf(
                "উপরের কাঁধ সামনের দিকে ঝুঁকে পড়া",
                "নিচের কাঁধে ভার ছেড়ে দেওয়া"
            ),
            easierAltEn = "Bend bottom knee to 90° on the mat for shorter lever support.",
            easierAltBn = "নিচের হাঁটু ম্যাটে রেখে সহজ সাইড প্ল্যাঙ্ক করুন।",
            progressionEn = "Lift top leg into a Star Side Plank at the peak of every rep.",
            progressionBn = "প্রতি রেপের শীর্ষে উপরের পা তুলে স্টার সাইড প্ল্যাঙ্ক করুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Lateral Lock — Forearm planted under shoulder, body aligned straight",
                "১. সাইড লক — কাঁধের নিচে কনুই রেখে শরীর সোজা করুন", BreathingCue.STEADY,
                "2. Controlled Dip — Lower hip smoothly toward the mat",
                "২. নিয়ন্ত্রিত অবতরণ — কোমর ধীরে মেঝের দিকে নামান", BreathingCue.INHALE,
                "3. Oblique Drive — Squeeze side core and push hip high",
                "৩. অব্লিক লিফট — পার্শ্বীয় কোরের শক্তিতে কোমর ওপরে তুলুন", BreathingCue.EXHALE,
                "4. Tall Reach — Hold top alignment with open chest",
                "৪. স্থির শীর্ষ — বুক খোলা রেখে শীর্ষে এক মুহূর্ত স্থির থাকুন", BreathingCue.STEADY
            )
        ),

        // 12. Explosive Jump Squat
        ExerciseItem(
            id = "jump_squat",
            nameEn = "Explosive Jump Squat",
            nameBn = "এক্সপ্লোসিভ জাম্প স্কোয়াট",
            categoryEn = "Lower Body & Cardio",
            categoryBn = "নিম্ন অঙ্গ ও কার্ডিও",
            difficulty = "Advanced",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Quadriceps, Glutes, Hamstrings, Calves, Explosive Power",
            musclesBn = "উরু (কোয়াডস), গ্লুটস, হ্যামস্ট্রিং, কাফ ও বিস্ফোরক শক্তি",
            setsRepsEn = "3 sets × 10–12 reps",
            setsRepsBn = "৩ সেট × ১০–১২ বার",
            restSeconds = 60,
            breathingEn = "Inhale loading deep into squat; exhale exploding vertically off the floor.",
            breathingBn = "নিচে স্কোয়াটে নামার সময় শ্বাস নিন; লাফিয়ে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Sit hips back into a crisp athletic squat swinging arms behind",
                "Explode upward through triple extension (hips, knees, ankles)",
                "Land softly toe-to-heel directly back into an absorbing half-squat"
            ),
            postureBn = listOf(
                "কোমর পেছনে নিয়ে গভীর স্কোয়াটে নামুন এবং হাত পেছনে নিন",
                "কোমর, হাঁটু ও গোড়ালির সম্মিলিত শক্তিতে ওপরে লাফ দিন",
                "পায়ের সামনের অংশ থেকে নরমভাবে ল্যান্ড করে হাঁটু সামান্য ভাঁজ রাখুন"
            ),
            mistakesEn = listOf(
                "Landing heavily on straight locked knees",
                "Knees caving inward on takeoff or landing"
            ),
            mistakesBn = listOf(
                "হাঁটু সোজা রেখে জোরে মাটিতে নামা",
                "লাফ বা নামার সময় হাঁটু ভেতরে ঢুকে যাওয়া"
            ),
            easierAltEn = "Fast-tempo Bodyweight Squat rising onto tiptoes without leaving the floor.",
            easierAltBn = "লাফ না দিয়ে পায়ের আঙুলে ভর করে দ্রুত স্কোয়াট করুন।",
            progressionEn = "Perform 180° alternating Jump Squats with full soft-landing control.",
            progressionBn = "নিয়ন্ত্রিত ল্যান্ডিংসহ ১৮০° জাম্প স্কোয়াট করুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Athletic Load — Sit deep into squat, arms drawn back ready to spring",
                "১. শক্তি সঞ্চয় — গভীর স্কোয়াটে বসে হাত পেছনে নিন", BreathingCue.INHALE,
                "2. Explosive Launch — Drive hips & ankles upward into full airtime",
                "২. বিস্ফোরক লাফ — পায়ের পূর্ণ শক্তিতে শূন্যে লাফ দিন", BreathingCue.EXHALE,
                "3. Apex Extension — Body straight in mid-air with pointed toes",
                "৩. সর্বোচ্চ উচ্চতা — শূন্যে শরীর সম্পূর্ণ সোজা রাখুন", BreathingCue.EXHALE,
                "4. Soft Absorption — Land quietly toe-to-heel directly into cushioned squat",
                "৪. নরম ল্যান্ডিং — শব্দহীনভাবে হাঁটু ভাঁজ করে মাটিতে নামুন", BreathingCue.INHALE
            )
        ),

        // 13. Bulgarian Split Squat
        ExerciseItem(
            id = "bulgarian_split_squat",
            nameEn = "Bulgarian Split Squat",
            nameBn = "বুলগেরিয়ান স্প্লিট স্কোয়াট",
            categoryEn = "Lower Body Strength",
            categoryBn = "নিম্ন অঙ্গের শক্তি",
            difficulty = "Advanced",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Quadriceps, Glutes, Hamstrings, Single-Leg Balance & Core",
            musclesBn = "উরু (কোয়াডস), গ্লুটস, হ্যামস্ট্রিং ও এক পায়ের ভারসাম্য",
            setsRepsEn = "3 sets × 10 reps / leg",
            setsRepsBn = "৩ সেট × প্রতি পায়ে ১০ বার",
            restSeconds = 55,
            breathingEn = "Inhale sinking straight down toward the floor; exhale driving powerfully through front heel.",
            breathingBn = "নিচে নামার সময় শ্বাস নিন এবং সামনের পায়ের গোড়ালিতে চাপ দিয়ে ওঠার সময় শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Rest rear laces comfortably atop a sturdy stationary bench behind you",
                "Keep front foot planted solidly forward with slight athletic torso lean",
                "Drop rear knee cleanly toward the mat until front thigh is parallel"
            ),
            postureBn = listOf(
                "পেছনের পায়ের পাতা একটি স্থির বেঞ্চের ওপর আরামদায়কভাবে রাখুন",
                "সামনের পা দৃঢ়ভাবে মাটিতে রাখুন এবং বুক সামান্য সামনে ঝুঁকিয়ে রাখুন",
                "সামনের উরু সমান্তরাল হওয়া পর্যন্ত পেছনের হাঁটু নিচে নামান"
            ),
            mistakesEn = listOf(
                "Standing too close to the bench so the front heel lifts",
                "Pushing off the rear foot instead of loading the front leg"
            ),
            mistakesBn = listOf(
                "বেঞ্চের খুব কাছে দাঁড়ানো ফলে সামনের গোড়ালি উঠে যাওয়া",
                "সামনের পায়ের বদলে পেছনের পায়ে বেশি ভর দেওয়া"
            ),
            easierAltEn = "Reverse Lunge on flat ground to master single-leg balance.",
            easierAltBn = "আগে সমতল মেঝেতে রিভার্স লাঞ্জ অনুশীলন করুন।",
            progressionEn = "Add a 3-second slow descent and explosive jump switch at top.",
            progressionBn = "ধীরে ৩ সেকেন্ডে নেমে দ্রুতগতিতে ওপরে উঠুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Elevated Split — Rear foot resting solidly on stationary bench, torso tall",
                "১. স্প্লিট অবস্থান — পেছনের পা স্থির বেঞ্চে রেখে সোজা দাঁড়ান", BreathingCue.STEADY,
                "2. Controlled Drop — Sink hips vertically as front knee bends smoothly",
                "২. নিয়ন্ত্রিত অবতরণ — সোজা নিচে কোমর নামান", BreathingCue.INHALE,
                "3. Deep Single-Leg — Front thigh parallel, rear knee hovers above mat",
                "৩. গভীর স্প্লিট — সামনের উরু মেঝের সমান্তরাল রাখুন", BreathingCue.INHALE,
                "4. Front-Leg Drive — Push firmly through front midfoot to standing",
                "৪. শক্তিশালী উত্তোলন — সামনের পায়ের শক্তিতে ওপরে উঠুন", BreathingCue.EXHALE
            )
        ),

        // 14. Standing Calf Raises
        ExerciseItem(
            id = "calf_raises",
            nameEn = "Standing Calf Raises",
            nameBn = "স্ট্যান্ডিং কাফ রেইজ",
            categoryEn = "Lower Body Strength",
            categoryBn = "নিম্ন অঙ্গের শক্তি",
            difficulty = "Beginner",
            activeZone = MuscleZone.LEGS_GLUTES,
            musclesEn = "Gastrocnemius, Soleus (Calves), Ankle Stability",
            musclesBn = "পায়ের গোছা (কাফ পেশী) ও গোড়ালির স্থায়িত্ব",
            setsRepsEn = "3 sets × 18–20 reps",
            setsRepsBn = "৩ সেট × ১৮–২০ বার",
            restSeconds = 35,
            breathingEn = "Exhale driving heels high onto balls of feet; inhale lowering slowly with control.",
            breathingBn = "গোড়ালি ওপরে তোলার সময় শ্বাস ছাড়ুন এবং ধীরে নিচে নামানোর সময় শ্বাস নিন।",
            postureEn = listOf(
                "Stand tall with core engaged and weight balanced across big-toe mounds",
                "Rise as high as possible onto the balls of both feet",
                "Pause 1 full second at the peak before lowering gently"
            ),
            postureBn = listOf(
                "পিঠ সোজা ও কোর শক্ত করে দাঁড়ান",
                "পায়ের সামনের অংশে ভর করে গোড়ালি সর্বোচ্চ ওপরে তুলুন",
                "শীর্ষে ১ সেকেন্ড স্থির থেকে ধীরে নিচে নামান"
            ),
            mistakesEn = listOf(
                "Bouncing rapidly without squeezing at the top",
                "Rolling ankles outward onto the pinky toes"
            ),
            mistakesBn = listOf(
                "শীর্ষে না থেমে দ্রুত লাফানো",
                "গোড়ালি বাইরের দিকে হেলে পড়া"
            ),
            easierAltEn = "Hold the back of a chair lightly for extra balance.",
            easierAltBn = "ভারসাম্যের জন্য চেয়ারের পিঠ হালকা ধরে করুন।",
            progressionEn = "Perform Single-Leg Calf Raises for double intensity.",
            progressionBn = "দ্বিগুণ শক্তির জন্য এক পায়ে কাফ রেইজ করুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Grounded Stance — Stand tall with heels flat and weight centered",
                "১. সোজা অবস্থান — দুই পা সমতলে রেখে সোজা দাঁড়ান", BreathingCue.INHALE,
                "2. Plantar Drive — Press through balls of feet lifting heels upward",
                "২. গোড়ালি উত্তোলন — পায়ের আঙুলে ভর করে ওপরে উঠুন", BreathingCue.EXHALE,
                "3. Full Peak Squeeze — Hold maximum heel height with calves contracted",
                "৩. সর্বোচ্চ সংকোচন — শীর্ষে কাফ পেশী শক্ত করে ধরে রাখুন", BreathingCue.EXHALE,
                "4. Controlled Lower — Descend heels gently back to the mat",
                "৪. ধীর অবতরণ — ধীরে গোড়ালি মেঝেতে নামিয়ে আনুন", BreathingCue.INHALE
            )
        ),

        // 15. Cobra Spine Extension
        ExerciseItem(
            id = "cobra_stretch",
            nameEn = "Cobra Spine Extension",
            nameBn = "কোবরা স্পাইন স্ট্রেচ",
            categoryEn = "Mobility & Recovery",
            categoryBn = "সচলতা ও পুনরুদ্ধার",
            difficulty = "Beginner",
            activeZone = MuscleZone.SPINE_BACK,
            musclesEn = "Thoracic & Lumbar Spine Mobility, Abdominals, Chest Opener",
            musclesBn = "মেরুদণ্ডের নমনীয়তা, বুক প্রসারণ ও পেটের স্ট্রেচ",
            setsRepsEn = "3 sets × 20–30 sec",
            setsRepsBn = "৩ সেট × ২০–৩০ সেকেন্ড",
            restSeconds = 20,
            breathingEn = "Inhale lifting chest gracefully upward; exhale softening shoulders down away from ears.",
            breathingBn = "বুক ওপরে তোলার সময় গভীর শ্বাস নিন; কাঁধ শিথিল রেখে শ্বাস ছাড়ুন।",
            postureEn = listOf(
                "Place palms firmly beneath shoulders with elbows close to ribs",
                "Press pelvis and tops of feet gently into the mat",
                "Unfurl spine vertebra by vertebra—keep neck long and shoulders down"
            ),
            postureBn = listOf(
                "দুই হাত কাঁধের নিচে রেখে কনুই শরীরের কাছে রাখুন",
                "কোমর ও পায়ের পাতা আলতোভাবে মেঝেতে চেপে রাখুন",
                "মেরুদণ্ড ধীরে ধীরে বাঁকিয়ে বুক ওপরে তুলুন—কাঁধ নিচু রাখুন"
            ),
            mistakesEn = listOf(
                "Shrugging shoulders up around the ears",
                "Jamming the lower back instead of lengthening through the chest"
            ),
            mistakesBn = listOf(
                "কাঁধ কানের দিকে তুলে রাখা",
                "বুক না খুলে শুধু কোমরে চাপ দেওয়া"
            ),
            easierAltEn = "Sphinx Pose resting comfortably on forearms instead of extended palms.",
            easierAltBn = "হাতের তালুর বদলে কনুই মেঝেতে রেখে সহজ স্ফিংক্স ভঙ্গি করুন।",
            progressionEn = "Lift thighs gently into Upward-Facing Dog for deeper thoracic opening.",
            progressionBn = "উরু সামান্য ওপরে তুলে গভীর স্পাইন স্ট্রেচ করুন।",
            floorY = 0.84f,
            phases = phases(
                "1. Prone Alignment — Palms under shoulders, forehead calm on mat",
                "১. প্রারম্ভিক অবস্থান — উপুড় হয়ে শুয়ে হাত কাঁধের নিচে রাখুন", BreathingCue.INHALE,
                "2. Baby Cobra — Peel chest smoothly off mat using upper-back muscles",
                "২. বেবি কোবরা — পিঠের শক্তিতে ধীরে বুক ওপরে তুলুন", BreathingCue.INHALE,
                "3. Full Spine Arch — Open sternum gracefully with shoulders relaxed down",
                "৩. পূর্ণ কোবরা আর্চ — কাঁধ নিচু রেখে বুক ও মেরুদণ্ড প্রসারিত করুন", BreathingCue.STEADY,
                "4. Gentle Unfurl — Lower vertebrae calmly back to mat on exhale",
                "৪. শান্ত অবতরণ — শ্বাস ছাড়তে ছাড়তে ধীরে মেঝেতে ফিরে আসুন", BreathingCue.EXHALE
            )
        )
    )

    val extraPrograms: List<WorkoutProgram> = listOf(
        WorkoutProgram(
            id = "military_pushup_gauntlet",
            titleEn = "Military Push-Up Gauntlet",
            titleBn = "মিলিটারি পুশ-আপ চ্যালেঞ্জ",
            subtitleEn = "Complete upper-body mastery: Military, Diamond, Wide, Decline, Pike & Archer Push-Ups",
            subtitleBn = "আর্মি, ডায়মন্ড, ওয়াইড, ডিক্লাইন, পাইক ও আর্চার পুশ-আপের পূর্ণাঙ্গ শক্তিশালী সেশন",
            focusAreaEn = "Hardcore Upper",
            focusAreaBn = "হার্ডকোর আপার বডি",
            level = "Advanced",
            durationMinutes = 18,
            estimatedKcal = 195,
            accentTag = "HARDCORE",
            stations = listOf(
                WorkoutStation("military_push_up", targetReps = 12, restAfterSec = 30),
                WorkoutStation("wide_push_up", targetReps = 12, restAfterSec = 30),
                WorkoutStation("diamond_push_up", targetReps = 10, restAfterSec = 35),
                WorkoutStation("decline_push_up", targetReps = 10, restAfterSec = 35),
                WorkoutStation("pike_push_up", targetReps = 8, restAfterSec = 35),
                WorkoutStation("archer_push_up", targetReps = 8, restAfterSec = 30),
                WorkoutStation("cobra_stretch", durationSec = 30, restAfterSec = 0)
            )
        ),
        WorkoutProgram(
            id = "calisthenics_warrior_split",
            titleEn = "Calisthenics Warrior Split",
            titleBn = "ক্যালিসথেনিকস ওয়ারিয়র সেশন",
            subtitleEn = "Explosive full-body strength: Burpees, Bulgarian Split Squats, Jump Squats, V-Ups & Hollow Lock",
            subtitleBn = "বার্পি, বুলগেরিয়ান স্প্লিট স্কোয়াট, জাম্প স্কোয়াট, ভি-আপ ও হলো বডি লক",
            focusAreaEn = "Full Calisthenics",
            focusAreaBn = "পূর্ণ ক্যালিসথেনিকস",
            level = "Advanced",
            durationMinutes = 20,
            estimatedKcal = 245,
            accentTag = "WARRIOR",
            stations = listOf(
                WorkoutStation("burpee", targetReps = 10, restAfterSec = 30),
                WorkoutStation("military_push_up", targetReps = 12, restAfterSec = 30),
                WorkoutStation("bulgarian_split_squat", targetReps = 10, restAfterSec = 30),
                WorkoutStation("jump_squat", targetReps = 12, restAfterSec = 30),
                WorkoutStation("v_ups", targetReps = 12, restAfterSec = 25),
                WorkoutStation("hollow_body_hold", durationSec = 30, restAfterSec = 25),
                WorkoutStation("side_plank", durationSec = 30, restAfterSec = 20),
                WorkoutStation("cobra_stretch", durationSec = 30, restAfterSec = 0)
            )
        )
    )
}
