package com.example.ruhzena

import android.app.Application
import com.example.ruhzena.ai.RuhZenaAiCoordinator
import com.example.ruhzena.ai.agent.AiProviderId
import com.example.ruhzena.ai.agent.FirebaseAiLogicProviderAdapter
import com.example.ruhzena.ai.agent.OpenAiCompatibleProviderAdapter
import com.example.ruhzena.ai.agent.RoomAiAgentMemoryStore
import com.example.ruhzena.ai.agent.RuhZenaAgentEngine
import com.example.ruhzena.ai.agent.SecureAiCredentialStore
import com.example.ruhzena.core.network.ConnectivityMonitor
import com.example.ruhzena.data.cloud.RuhZenaCloudRepository
import com.example.ruhzena.data.islamic.QuranRepository
import com.example.ruhzena.data.local.RuhZenaDataRepository
import com.example.ruhzena.data.local.RuhZenaDatabase
import com.example.ruhzena.data.local.UserPreferencesRepository
import com.example.ruhzena.media.QuranAudioController
import com.example.ruhzena.media.RuhZenaSoundEngine
import com.example.ruhzena.media.RuhZenaSpeechPlayer
import com.example.ruhzena.notifications.RuhZenaNotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class RuhZenaApplication : Application() {
    private val appInitScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database by lazy { RuhZenaDatabase.getInstance(this) }
    val preferencesRepository by lazy { UserPreferencesRepository(this) }
    val dataRepository by lazy { RuhZenaDataRepository(database) }
    val cloudRepository by lazy { RuhZenaCloudRepository(this) }
    val quranRepository by lazy {
        QuranRepository(
            cachedSurahDao = database.cachedSurahDao(),
            aiAyahExplainer = { ayah, lang -> agentEngine.explainAyahWithFailover(ayah, lang) }
        )
    }
    val connectivityMonitor by lazy { ConnectivityMonitor(this) }
    val aiCoordinator by lazy { RuhZenaAiCoordinator() }
    val speechPlayer by lazy { RuhZenaSpeechPlayer(this) }
    val soundEngine by lazy { RuhZenaSoundEngine(this) }
    val audioController by lazy { QuranAudioController(this, speechPlayer) }

    val aiCredentialStore by lazy { SecureAiCredentialStore(this) }
    private val aiHttpClient by lazy { OpenAiCompatibleProviderAdapter.defaultHttpClient() }

    val agentEngine by lazy {
        val memoryStore = RoomAiAgentMemoryStore(dataRepository)
        val adapters = listOf(
            OpenAiCompatibleProviderAdapter(AiProviderId.GROQ, aiCredentialStore, aiHttpClient),
            OpenAiCompatibleProviderAdapter(AiProviderId.OPENROUTER, aiCredentialStore, aiHttpClient),
            OpenAiCompatibleProviderAdapter(AiProviderId.CLOUDFLARE, aiCredentialStore, aiHttpClient),
            FirebaseAiLogicProviderAdapter()
        )
        RuhZenaAgentEngine(
            adapters = adapters,
            memoryStore = memoryStore,
            discoveryHttpClient = aiHttpClient
        )
    }

    override fun onCreate() {
        super.onCreate()
        RuhZenaNotificationHelper.createChannels(this)
        // Warm up credential cache, HTTP client, and persisted model health off the main thread
        // so the very first RuhZena AI reply starts without cold-start Keystore/Room/TLS overhead.
        appInitScope.launch {
            runCatching {
                aiCredentialStore.getSnapshot()
                agentEngine.healthTracker.ensureLoaded()
            }
        }
    }
}
