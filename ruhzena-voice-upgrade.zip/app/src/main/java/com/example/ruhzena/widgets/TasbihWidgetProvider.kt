package com.example.ruhzena.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.R
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.notifications.NotificationActionReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TasbihWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val snap = RuhZenaWidgetUpdater.loadSnapshot(context)
                val isBn = snap.prefs.language == AppLanguage.BANGLA

                val tapIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                    action = NotificationActionReceiver.ACTION_WIDGET_TASBIH_TAP
                }
                val tapPending = PendingIntent.getBroadcast(
                    context,
                    4302,
                    tapIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                for (appWidgetId in appWidgetIds) {
                    val views = RemoteViews(context.packageName, R.layout.widget_tasbih).apply {
                        setTextViewText(R.id.widget_tasbih_title, if (isBn) "রূহজেনা • তাসবীহ" else "RuhZena • TASBIH")
                        setTextViewText(
                            R.id.widget_tasbih_count,
                            if (isBn) "মোট: ${snap.prefs.tasbihTotalCount}" else "Total: ${snap.prefs.tasbihTotalCount}"
                        )
                        setOnClickPendingIntent(
                            R.id.widget_tasbih_root,
                            RuhZenaWidgetUpdater.launchAppPendingIntent(context, 4301)
                        )
                        setOnClickPendingIntent(R.id.widget_tasbih_tap_btn, tapPending)
                    }
                    appWidgetManager.updateAppWidget(appWidgetId, views)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
