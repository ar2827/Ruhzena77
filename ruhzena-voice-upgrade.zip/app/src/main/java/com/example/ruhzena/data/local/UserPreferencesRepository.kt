package com.example.ruhzena.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.islamic.CountryPreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable

private val Context.ruhZenaDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "ruhzena_prefs"
)

@Serializable
data class UserPreferences(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val themeMode: String = "DARK_GLASS",
    val countryCode: String = "",
    val countryName: String = "",
    val onboardingCompleted: Boolean = false,
    val userName: String = "",
    val ageYears: Int = 25,
    val weightKg: Int = 68,
    val heightCm: Int = 170,
    val characterGender: String = "", // "MALE" or "FEMALE"
    val uiFontScale: Float = 1.0f,
    val reducedMotion: Boolean = false,
    val selectedReciterId: String = "ar.alafasy",
    val quranFontSizeSp: Int = 26,
    val showPronunciation: Boolean = true,
    val lastReadSurah: Int = 1,
    val lastReadAyah: Int = 1,
    val locationName: String = "Dhaka, Bangladesh",
    val latitude: Double = 23.8103,
    val longitude: Double = 90.4125,
    val locationTimeZoneId: String = "Asia/Dhaka",
    val prayerCalcMethod: String = "KARACHI",
    val asrJuristicMethod: String = "HANAFI",
    val hijriOffsetDays: Int = 0,
    val ramadanModeEnabled: Boolean = false,
    val learningMode: String = "AUTO", // AUTO, NEW_MUSLIM, REFERENCE
    val kidsModeEnabled: Boolean = false,
    val hydrationGoalMl: Int = 2500,
    val fitnessLevel: String = "Beginner",
    val fitnessGoal: String = "Consistency & Mobility",
    val availableEquipment: String = "Bodyweight Only",
    val fitnessLimitation: String = "None",
    val quietHoursEnabled: Boolean = true,
    val quietStartHour: Int = 22,
    val quietEndHour: Int = 5,
    val prayerRemindersEnabled: Boolean = true,
    val waterRemindersEnabled: Boolean = true,
    val adhkarRemindersEnabled: Boolean = true,
    val workoutRemindersEnabled: Boolean = false,
    val bedtimeRemindersEnabled: Boolean = false,
    val lessonRemindersEnabled: Boolean = true,
    val hourlyMotivationEnabled: Boolean = true,
    val notificationToneUri: String = "",
    val notificationVibrationEnabled: Boolean = true,
    val motivationBannerDismissed: Boolean = false,
    val aiTierOverride: String = "AUTO",
    val activeAiModelFile: String = "",
    val tasbihTotalCount: Int = 0,
    val tasbihSessionsCompleted: Int = 0,
    val hifzRevisionStreak: Int = 0,
    val hifzTargetSurah: Int = 1,
    val ramadanFastedDaysCsv: String = "",
    val ramadanCompletedJuzCsv: String = "",
    val ramadanTarawihDays: Int = 0,
    val ramadanSadaqahCount: Int = 0,
    val aiPersonalityMode: String = "COMPANION", // COMPANION (Peace & Life) or EXPERT (Practical & Knowledge)
    val learningTrackChosen: Boolean = false,
    val arabicMasteredLettersCsv: String = "",
    val quranSleepTimerMinutes: Int = 0,
    val completedLearningStepsCsv: String = "",
    val learningAllAccess: Boolean = false,
    val mutedUntilEpochMs: Long = 0L,
    val quickJumpSlotsCsv: String = "CONTINUE_QURAN,PRAYER_QIBLA,DAILY_DUAS,TASBIH_3D,URGE_RESET,QUICK_WATER",
    val tutorialCompleted: Boolean = false,
    val completedTutorialPagesCsv: String = "",
    val adhanMuezzinId: String = "MAKKAH",
    val speechVoiceStyle: String = "WARM_HUMAN"
)

class UserPreferencesRepository(private val context: Context) {
    private val fastBootPrefs by lazy {
        context.applicationContext.getSharedPreferences("ruhzena_fast_boot", Context.MODE_PRIVATE)
    }

    fun initialFastBootPreferences(): UserPreferences = UserPreferences(
        language = AppLanguage.fromCode(fastBootPrefs.getString("language", null)),
        themeMode = fastBootPrefs.getString("theme_mode", "DARK_GLASS") ?: "DARK_GLASS",
        onboardingCompleted = fastBootPrefs.getBoolean("onboarding_done", false),
        tutorialCompleted = fastBootPrefs.getBoolean("tutorial_completed", false),
        completedTutorialPagesCsv = fastBootPrefs.getString("completed_tutorial_pages_csv", "") ?: "",
        userName = fastBootPrefs.getString("user_name", "") ?: ""
    )

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val COUNTRY_CODE = stringPreferencesKey("country_code")
        val COUNTRY_NAME = stringPreferencesKey("country_name")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val USER_NAME = stringPreferencesKey("user_name")
        val AGE_YEARS = intPreferencesKey("age_years")
        val WEIGHT_KG = intPreferencesKey("weight_kg")
        val HEIGHT_CM = intPreferencesKey("height_cm")
        val CHARACTER_GENDER = stringPreferencesKey("character_gender")
        val UI_FONT_SCALE = floatPreferencesKey("ui_font_scale")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val RECITER_ID = stringPreferencesKey("reciter_id")
        val QURAN_FONT_SIZE = intPreferencesKey("quran_font_size")
        val SHOW_PRONUNCIATION = booleanPreferencesKey("show_pronunciation")
        val LAST_SURAH = intPreferencesKey("last_surah")
        val LAST_AYAH = intPreferencesKey("last_ayah")
        val LOCATION_NAME = stringPreferencesKey("location_name")
        val LATITUDE = doublePreferencesKey("latitude")
        val LONGITUDE = doublePreferencesKey("longitude")
        val LOCATION_TZ = stringPreferencesKey("location_tz")
        val CALC_METHOD = stringPreferencesKey("calc_method")
        val ASR_METHOD = stringPreferencesKey("asr_method")
        val HIJRI_OFFSET = intPreferencesKey("hijri_offset")
        val RAMADAN_MODE = booleanPreferencesKey("ramadan_mode")
        val LEARNING_MODE = stringPreferencesKey("learning_mode")
        val KIDS_MODE = booleanPreferencesKey("kids_mode")
        val HYDRATION_GOAL = intPreferencesKey("hydration_goal_ml")
        val FITNESS_LEVEL = stringPreferencesKey("fitness_level")
        val FITNESS_GOAL = stringPreferencesKey("fitness_goal")
        val EQUIPMENT = stringPreferencesKey("equipment")
        val LIMITATION = stringPreferencesKey("fitness_limitation")
        val QUIET_ENABLED = booleanPreferencesKey("quiet_hours_enabled")
        val QUIET_START = intPreferencesKey("quiet_start_hour")
        val QUIET_END = intPreferencesKey("quiet_end_hour")
        val REMIND_PRAYER = booleanPreferencesKey("remind_prayer")
        val REMIND_WATER = booleanPreferencesKey("remind_water")
        val REMIND_ADHKAR = booleanPreferencesKey("remind_adhkar")
        val REMIND_WORKOUT = booleanPreferencesKey("remind_workout")
        val REMIND_BEDTIME = booleanPreferencesKey("remind_bedtime")
        val REMIND_LESSON = booleanPreferencesKey("remind_lesson")
        val REMIND_HOURLY_MOTIVATION = booleanPreferencesKey("remind_hourly_motivation")
        val NOTIF_TONE_URI = stringPreferencesKey("notif_tone_uri")
        val NOTIF_VIBRATION = booleanPreferencesKey("notif_vibration")
        val MOTIVATION_BANNER_DISMISSED = booleanPreferencesKey("motivation_banner_dismissed")
        val AI_TIER = stringPreferencesKey("ai_tier_override")
        val ACTIVE_MODEL_FILE = stringPreferencesKey("active_ai_model_file")
        val TASBIH_TOTAL = intPreferencesKey("tasbih_total")
        val TASBIH_SESSIONS = intPreferencesKey("tasbih_sessions")
        val HIFZ_STREAK = intPreferencesKey("hifz_revision_streak")
        val HIFZ_TARGET_SURAH = intPreferencesKey("hifz_target_surah")
        val RAMADAN_FASTED_CSV = stringPreferencesKey("ramadan_fasted_csv")
        val RAMADAN_JUZ_CSV = stringPreferencesKey("ramadan_juz_csv")
        val RAMADAN_TARAWIH = intPreferencesKey("ramadan_tarawih_days")
        val RAMADAN_SADAQAH = intPreferencesKey("ramadan_sadaqah_count")
        val AI_PERSONALITY = stringPreferencesKey("ai_personality_mode")
        val LEARNING_TRACK_CHOSEN = booleanPreferencesKey("learning_track_chosen")
        val ARABIC_MASTERED_CSV = stringPreferencesKey("arabic_mastered_letters_csv")
        val QURAN_SLEEP_TIMER = intPreferencesKey("quran_sleep_timer_min")
        val COMPLETED_LEARNING_STEPS_CSV = stringPreferencesKey("completed_learning_steps_csv")
        val LEARNING_ALL_ACCESS = booleanPreferencesKey("learning_all_access")
        val MUTED_UNTIL_EPOCH_MS = longPreferencesKey("muted_until_epoch_ms")
        val QUICK_JUMP_SLOTS_CSV = stringPreferencesKey("quick_jump_slots_csv")
        val TUTORIAL_COMPLETED = booleanPreferencesKey("tutorial_completed")
        val COMPLETED_TUTORIAL_PAGES_CSV = stringPreferencesKey("completed_tutorial_pages_csv")
        val ADHAN_MUEZZIN_ID = stringPreferencesKey("adhan_muezzin_id")
        val SPEECH_VOICE_STYLE = stringPreferencesKey("speech_voice_style")
    }

    val preferencesFlow: Flow<UserPreferences> = context.ruhZenaDataStore.data.map { prefs ->
        UserPreferences(
            language = AppLanguage.fromCode(prefs[Keys.LANGUAGE]),
            themeMode = prefs[Keys.THEME_MODE] ?: "DARK_GLASS",
            countryCode = prefs[Keys.COUNTRY_CODE] ?: "",
            countryName = prefs[Keys.COUNTRY_NAME] ?: "",
            onboardingCompleted = prefs[Keys.ONBOARDING_DONE] ?: false,
            userName = prefs[Keys.USER_NAME] ?: "",
            ageYears = prefs[Keys.AGE_YEARS] ?: 25,
            weightKg = prefs[Keys.WEIGHT_KG] ?: 68,
            heightCm = prefs[Keys.HEIGHT_CM] ?: 170,
            characterGender = prefs[Keys.CHARACTER_GENDER] ?: "",
            uiFontScale = prefs[Keys.UI_FONT_SCALE] ?: 1.0f,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            selectedReciterId = prefs[Keys.RECITER_ID] ?: "ar.alafasy",
            quranFontSizeSp = prefs[Keys.QURAN_FONT_SIZE] ?: 26,
            showPronunciation = prefs[Keys.SHOW_PRONUNCIATION] ?: true,
            lastReadSurah = prefs[Keys.LAST_SURAH] ?: 1,
            lastReadAyah = prefs[Keys.LAST_AYAH] ?: 1,
            locationName = prefs[Keys.LOCATION_NAME] ?: "Dhaka, Bangladesh",
            latitude = prefs[Keys.LATITUDE] ?: 23.8103,
            longitude = prefs[Keys.LONGITUDE] ?: 90.4125,
            locationTimeZoneId = prefs[Keys.LOCATION_TZ] ?: "Asia/Dhaka",
            prayerCalcMethod = prefs[Keys.CALC_METHOD] ?: "KARACHI",
            asrJuristicMethod = prefs[Keys.ASR_METHOD] ?: "HANAFI",
            hijriOffsetDays = prefs[Keys.HIJRI_OFFSET] ?: 0,
            ramadanModeEnabled = prefs[Keys.RAMADAN_MODE] ?: false,
            learningMode = prefs[Keys.LEARNING_MODE] ?: "AUTO",
            kidsModeEnabled = prefs[Keys.KIDS_MODE] ?: false,
            hydrationGoalMl = prefs[Keys.HYDRATION_GOAL] ?: 2500,
            fitnessLevel = prefs[Keys.FITNESS_LEVEL] ?: "Beginner",
            fitnessGoal = prefs[Keys.FITNESS_GOAL] ?: "Consistency & Mobility",
            availableEquipment = prefs[Keys.EQUIPMENT] ?: "Bodyweight Only",
            fitnessLimitation = prefs[Keys.LIMITATION] ?: "None",
            quietHoursEnabled = prefs[Keys.QUIET_ENABLED] ?: true,
            quietStartHour = prefs[Keys.QUIET_START] ?: 22,
            quietEndHour = prefs[Keys.QUIET_END] ?: 5,
            prayerRemindersEnabled = prefs[Keys.REMIND_PRAYER] ?: true,
            waterRemindersEnabled = prefs[Keys.REMIND_WATER] ?: true,
            adhkarRemindersEnabled = prefs[Keys.REMIND_ADHKAR] ?: true,
            workoutRemindersEnabled = prefs[Keys.REMIND_WORKOUT] ?: false,
            bedtimeRemindersEnabled = prefs[Keys.REMIND_BEDTIME] ?: false,
            lessonRemindersEnabled = prefs[Keys.REMIND_LESSON] ?: true,
            hourlyMotivationEnabled = prefs[Keys.REMIND_HOURLY_MOTIVATION] ?: true,
            notificationToneUri = prefs[Keys.NOTIF_TONE_URI] ?: "",
            notificationVibrationEnabled = prefs[Keys.NOTIF_VIBRATION] ?: true,
            motivationBannerDismissed = prefs[Keys.MOTIVATION_BANNER_DISMISSED] ?: false,
            aiTierOverride = prefs[Keys.AI_TIER] ?: "AUTO",
            activeAiModelFile = prefs[Keys.ACTIVE_MODEL_FILE] ?: "",
            tasbihTotalCount = prefs[Keys.TASBIH_TOTAL] ?: 0,
            tasbihSessionsCompleted = prefs[Keys.TASBIH_SESSIONS] ?: 0,
            hifzRevisionStreak = prefs[Keys.HIFZ_STREAK] ?: 0,
            hifzTargetSurah = prefs[Keys.HIFZ_TARGET_SURAH] ?: 1,
            ramadanFastedDaysCsv = prefs[Keys.RAMADAN_FASTED_CSV] ?: "",
            ramadanCompletedJuzCsv = prefs[Keys.RAMADAN_JUZ_CSV] ?: "",
            ramadanTarawihDays = prefs[Keys.RAMADAN_TARAWIH] ?: 0,
            ramadanSadaqahCount = prefs[Keys.RAMADAN_SADAQAH] ?: 0,
            aiPersonalityMode = prefs[Keys.AI_PERSONALITY] ?: "COMPANION",
            learningTrackChosen = prefs[Keys.LEARNING_TRACK_CHOSEN] ?: false,
            arabicMasteredLettersCsv = prefs[Keys.ARABIC_MASTERED_CSV] ?: "",
            quranSleepTimerMinutes = prefs[Keys.QURAN_SLEEP_TIMER] ?: 0,
            completedLearningStepsCsv = prefs[Keys.COMPLETED_LEARNING_STEPS_CSV] ?: "",
            learningAllAccess = prefs[Keys.LEARNING_ALL_ACCESS] ?: false,
            mutedUntilEpochMs = prefs[Keys.MUTED_UNTIL_EPOCH_MS] ?: 0L,
            quickJumpSlotsCsv = prefs[Keys.QUICK_JUMP_SLOTS_CSV]
                ?: "CONTINUE_QURAN,PRAYER_QIBLA,DAILY_DUAS,TASBIH_3D,URGE_RESET,QUICK_WATER",
            tutorialCompleted = prefs[Keys.TUTORIAL_COMPLETED] ?: false,
            completedTutorialPagesCsv = prefs[Keys.COMPLETED_TUTORIAL_PAGES_CSV] ?: "",
            adhanMuezzinId = prefs[Keys.ADHAN_MUEZZIN_ID] ?: "MAKKAH",
            speechVoiceStyle = prefs[Keys.SPEECH_VOICE_STYLE] ?: "WARM_HUMAN"
        ).also { loaded ->
            // Keep fast-boot mirror synchronized so subsequent cold launches never flash OnboardingScreen
            fastBootPrefs.edit()
                .putBoolean("onboarding_done", loaded.onboardingCompleted)
                .putBoolean("tutorial_completed", loaded.tutorialCompleted)
                .putString("completed_tutorial_pages_csv", loaded.completedTutorialPagesCsv)
                .putString("theme_mode", loaded.themeMode)
                .putString("language", loaded.language.code)
                .putString("user_name", loaded.userName)
                .apply()
        }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.ruhZenaDataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setThemeMode(themeMode: String) {
        context.ruhZenaDataStore.edit { it[Keys.THEME_MODE] = themeMode }
    }

    suspend fun setCountry(country: CountryPreset, updateLocationDefaults: Boolean = true) {
        context.ruhZenaDataStore.edit {
            it[Keys.COUNTRY_CODE] = country.code
            it[Keys.COUNTRY_NAME] = country.nameEn
            if (updateLocationDefaults) {
                it[Keys.LOCATION_NAME] = country.defaultCity
                it[Keys.LATITUDE] = country.latitude
                it[Keys.LONGITUDE] = country.longitude
                it[Keys.LOCATION_TZ] = country.timeZoneId
                it[Keys.CALC_METHOD] = country.defaultMethodId
                it[Keys.ASR_METHOD] = country.defaultAsrSchool
            }
        }
    }

    suspend fun setUiFontScale(scale: Float) {
        context.ruhZenaDataStore.edit { it[Keys.UI_FONT_SCALE] = scale.coerceIn(0.85f, 1.30f) }
    }

    suspend fun setReducedMotion(enabled: Boolean) {
        context.ruhZenaDataStore.edit { it[Keys.REDUCED_MOTION] = enabled }
    }

    suspend fun setAsrJuristicMethod(method: String) {
        context.ruhZenaDataStore.edit { it[Keys.ASR_METHOD] = method }
    }

    suspend fun setHijriOffsetDays(offset: Int) {
        context.ruhZenaDataStore.edit { it[Keys.HIJRI_OFFSET] = offset.coerceIn(-2, 2) }
    }

    suspend fun setRamadanModeEnabled(enabled: Boolean) {
        context.ruhZenaDataStore.edit { it[Keys.RAMADAN_MODE] = enabled }
    }

    suspend fun setLearningMode(mode: String) {
        context.ruhZenaDataStore.edit { it[Keys.LEARNING_MODE] = mode }
    }

    suspend fun setKidsModeEnabled(enabled: Boolean) {
        context.ruhZenaDataStore.edit { it[Keys.KIDS_MODE] = enabled }
    }

    suspend fun setNotificationTone(uriString: String) {
        context.ruhZenaDataStore.edit { it[Keys.NOTIF_TONE_URI] = uriString }
    }

    suspend fun setNotificationVibration(enabled: Boolean) {
        context.ruhZenaDataStore.edit { it[Keys.NOTIF_VIBRATION] = enabled }
    }

    suspend fun setMotivationBannerDismissed(dismissed: Boolean) {
        context.ruhZenaDataStore.edit { it[Keys.MOTIVATION_BANNER_DISMISSED] = dismissed }
    }

    suspend fun completeOnboarding() {
        fastBootPrefs.edit().putBoolean("onboarding_done", true).apply()
        context.ruhZenaDataStore.edit { it[Keys.ONBOARDING_DONE] = true }
    }

    suspend fun saveOnboardingProfile(
        name: String,
        ageYears: Int,
        weightKg: Int,
        heightCm: Int,
        characterGender: String,
        level: String,
        goal: String,
        equipment: String,
        limitation: String
    ) {
        val recommendedWater = (weightKg.coerceIn(25, 220) * 35).coerceIn(1400, 4500)
        fastBootPrefs.edit()
            .putBoolean("onboarding_done", true)
            .putString("user_name", name.trim())
            .apply()
        context.ruhZenaDataStore.edit {
            it[Keys.USER_NAME] = name.trim()
            it[Keys.AGE_YEARS] = ageYears.coerceIn(8, 100)
            it[Keys.WEIGHT_KG] = weightKg.coerceIn(25, 250)
            it[Keys.HEIGHT_CM] = heightCm.coerceIn(100, 230)
            it[Keys.CHARACTER_GENDER] = characterGender
            it[Keys.FITNESS_LEVEL] = level
            it[Keys.FITNESS_GOAL] = goal
            it[Keys.EQUIPMENT] = equipment
            it[Keys.LIMITATION] = limitation
            it[Keys.HYDRATION_GOAL] = recommendedWater
            it[Keys.ONBOARDING_DONE] = true
        }
    }

    suspend fun setSelectedReciter(reciterId: String) {
        context.ruhZenaDataStore.edit { it[Keys.RECITER_ID] = reciterId }
    }

    suspend fun setQuranFontSize(sizeSp: Int) {
        context.ruhZenaDataStore.edit { it[Keys.QURAN_FONT_SIZE] = sizeSp.coerceIn(18, 42) }
    }

    suspend fun setShowPronunciation(show: Boolean) {
        context.ruhZenaDataStore.edit { it[Keys.SHOW_PRONUNCIATION] = show }
    }

    suspend fun setLastRead(surah: Int, ayah: Int) {
        context.ruhZenaDataStore.edit {
            it[Keys.LAST_SURAH] = surah
            it[Keys.LAST_AYAH] = ayah
        }
    }

    suspend fun setLocation(name: String, lat: Double, lon: Double, timeZoneId: String) {
        context.ruhZenaDataStore.edit {
            it[Keys.LOCATION_NAME] = name
            it[Keys.LATITUDE] = lat
            it[Keys.LONGITUDE] = lon
            it[Keys.LOCATION_TZ] = timeZoneId
        }
    }

    suspend fun setPrayerCalcMethod(method: String) {
        context.ruhZenaDataStore.edit { it[Keys.CALC_METHOD] = method }
    }

    suspend fun setHydrationGoal(goalMl: Int) {
        context.ruhZenaDataStore.edit { it[Keys.HYDRATION_GOAL] = goalMl.coerceIn(1000, 6000) }
    }

    suspend fun updateFitnessProfile(
        name: String? = null,
        ageYears: Int? = null,
        weightKg: Int? = null,
        heightCm: Int? = null,
        characterGender: String? = null,
        level: String,
        goal: String,
        equipment: String,
        limitation: String
    ) {
        context.ruhZenaDataStore.edit {
            name?.let { n -> it[Keys.USER_NAME] = n.trim() }
            ageYears?.let { a -> it[Keys.AGE_YEARS] = a.coerceIn(8, 100) }
            weightKg?.let { w -> it[Keys.WEIGHT_KG] = w.coerceIn(25, 250) }
            heightCm?.let { h -> it[Keys.HEIGHT_CM] = h.coerceIn(100, 230) }
            characterGender?.let { g -> it[Keys.CHARACTER_GENDER] = g }
            it[Keys.FITNESS_LEVEL] = level
            it[Keys.FITNESS_GOAL] = goal
            it[Keys.EQUIPMENT] = equipment
            it[Keys.LIMITATION] = limitation
        }
    }

    suspend fun updateReminderSettings(
        prayer: Boolean? = null,
        water: Boolean? = null,
        adhkar: Boolean? = null,
        workout: Boolean? = null,
        bedtime: Boolean? = null,
        lesson: Boolean? = null,
        hourlyMotivation: Boolean? = null,
        quietEnabled: Boolean? = null,
        quietStart: Int? = null,
        quietEnd: Int? = null
    ) {
        context.ruhZenaDataStore.edit { prefs ->
            prayer?.let { prefs[Keys.REMIND_PRAYER] = it }
            water?.let { prefs[Keys.REMIND_WATER] = it }
            adhkar?.let { prefs[Keys.REMIND_ADHKAR] = it }
            workout?.let { prefs[Keys.REMIND_WORKOUT] = it }
            bedtime?.let { prefs[Keys.REMIND_BEDTIME] = it }
            lesson?.let { prefs[Keys.REMIND_LESSON] = it }
            hourlyMotivation?.let { prefs[Keys.REMIND_HOURLY_MOTIVATION] = it }
            quietEnabled?.let { prefs[Keys.QUIET_ENABLED] = it }
            quietStart?.let { prefs[Keys.QUIET_START] = it }
            quietEnd?.let { prefs[Keys.QUIET_END] = it }
        }
    }

    suspend fun restoreFromBackup(restored: UserPreferences) {
        context.ruhZenaDataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = restored.language.code
            prefs[Keys.THEME_MODE] = restored.themeMode
            prefs[Keys.COUNTRY_CODE] = restored.countryCode
            prefs[Keys.COUNTRY_NAME] = restored.countryName
            prefs[Keys.ONBOARDING_DONE] = restored.onboardingCompleted
            prefs[Keys.USER_NAME] = restored.userName
            prefs[Keys.AGE_YEARS] = restored.ageYears
            prefs[Keys.WEIGHT_KG] = restored.weightKg
            prefs[Keys.HEIGHT_CM] = restored.heightCm
            prefs[Keys.CHARACTER_GENDER] = restored.characterGender
            prefs[Keys.UI_FONT_SCALE] = restored.uiFontScale
            prefs[Keys.REDUCED_MOTION] = restored.reducedMotion
            prefs[Keys.RECITER_ID] = restored.selectedReciterId
            prefs[Keys.QURAN_FONT_SIZE] = restored.quranFontSizeSp
            prefs[Keys.SHOW_PRONUNCIATION] = restored.showPronunciation
            prefs[Keys.LAST_SURAH] = restored.lastReadSurah
            prefs[Keys.LAST_AYAH] = restored.lastReadAyah
            prefs[Keys.LOCATION_NAME] = restored.locationName
            prefs[Keys.LATITUDE] = restored.latitude
            prefs[Keys.LONGITUDE] = restored.longitude
            prefs[Keys.LOCATION_TZ] = restored.locationTimeZoneId
            prefs[Keys.CALC_METHOD] = restored.prayerCalcMethod
            prefs[Keys.ASR_METHOD] = restored.asrJuristicMethod
            prefs[Keys.HIJRI_OFFSET] = restored.hijriOffsetDays
            prefs[Keys.RAMADAN_MODE] = restored.ramadanModeEnabled
            prefs[Keys.LEARNING_MODE] = restored.learningMode
            prefs[Keys.KIDS_MODE] = restored.kidsModeEnabled
            prefs[Keys.HYDRATION_GOAL] = restored.hydrationGoalMl
            prefs[Keys.FITNESS_LEVEL] = restored.fitnessLevel
            prefs[Keys.FITNESS_GOAL] = restored.fitnessGoal
            prefs[Keys.EQUIPMENT] = restored.availableEquipment
            prefs[Keys.LIMITATION] = restored.fitnessLimitation
            prefs[Keys.QUIET_ENABLED] = restored.quietHoursEnabled
            prefs[Keys.QUIET_START] = restored.quietStartHour
            prefs[Keys.QUIET_END] = restored.quietEndHour
            prefs[Keys.REMIND_PRAYER] = restored.prayerRemindersEnabled
            prefs[Keys.REMIND_WATER] = restored.waterRemindersEnabled
            prefs[Keys.REMIND_ADHKAR] = restored.adhkarRemindersEnabled
            prefs[Keys.REMIND_WORKOUT] = restored.workoutRemindersEnabled
            prefs[Keys.REMIND_BEDTIME] = restored.bedtimeRemindersEnabled
            prefs[Keys.REMIND_LESSON] = restored.lessonRemindersEnabled
            prefs[Keys.REMIND_HOURLY_MOTIVATION] = restored.hourlyMotivationEnabled
            prefs[Keys.NOTIF_TONE_URI] = restored.notificationToneUri
            prefs[Keys.NOTIF_VIBRATION] = restored.notificationVibrationEnabled
            prefs[Keys.MOTIVATION_BANNER_DISMISSED] = restored.motivationBannerDismissed
            prefs[Keys.TASBIH_TOTAL] = restored.tasbihTotalCount
            prefs[Keys.TASBIH_SESSIONS] = restored.tasbihSessionsCompleted
            prefs[Keys.HIFZ_STREAK] = restored.hifzRevisionStreak
            prefs[Keys.HIFZ_TARGET_SURAH] = restored.hifzTargetSurah
            prefs[Keys.RAMADAN_FASTED_CSV] = restored.ramadanFastedDaysCsv
            prefs[Keys.RAMADAN_JUZ_CSV] = restored.ramadanCompletedJuzCsv
            prefs[Keys.RAMADAN_TARAWIH] = restored.ramadanTarawihDays
            prefs[Keys.RAMADAN_SADAQAH] = restored.ramadanSadaqahCount
            prefs[Keys.AI_PERSONALITY] = restored.aiPersonalityMode
            prefs[Keys.LEARNING_TRACK_CHOSEN] = restored.learningTrackChosen
            prefs[Keys.ARABIC_MASTERED_CSV] = restored.arabicMasteredLettersCsv
            prefs[Keys.QURAN_SLEEP_TIMER] = restored.quranSleepTimerMinutes
            prefs[Keys.COMPLETED_LEARNING_STEPS_CSV] = restored.completedLearningStepsCsv
            prefs[Keys.LEARNING_ALL_ACCESS] = restored.learningAllAccess
            prefs[Keys.MUTED_UNTIL_EPOCH_MS] = restored.mutedUntilEpochMs
        }
    }

    suspend fun clearAllPreferences() {
        context.ruhZenaDataStore.edit { it.clear() }
    }

    suspend fun setAiTierOverride(tier: String) {
        context.ruhZenaDataStore.edit { it[Keys.AI_TIER] = tier }
    }

    suspend fun setActiveAiModelFile(fileName: String) {
        context.ruhZenaDataStore.edit { it[Keys.ACTIVE_MODEL_FILE] = fileName }
    }

    suspend fun recordTasbihTap(completedSession: Boolean) {
        context.ruhZenaDataStore.edit { prefs ->
            prefs[Keys.TASBIH_TOTAL] = (prefs[Keys.TASBIH_TOTAL] ?: 0) + 1
            if (completedSession) {
                prefs[Keys.TASBIH_SESSIONS] = (prefs[Keys.TASBIH_SESSIONS] ?: 0) + 1
            }
        }
    }

    suspend fun undoTasbihTap() {
        context.ruhZenaDataStore.edit { prefs ->
            prefs[Keys.TASBIH_TOTAL] = ((prefs[Keys.TASBIH_TOTAL] ?: 0) - 1).coerceAtLeast(0)
        }
    }

    suspend fun recordHifzSession(surahNumber: Int) {
        context.ruhZenaDataStore.edit { prefs ->
            prefs[Keys.HIFZ_TARGET_SURAH] = surahNumber.coerceIn(1, 114)
            prefs[Keys.HIFZ_STREAK] = (prefs[Keys.HIFZ_STREAK] ?: 0) + 1
        }
    }

    suspend fun toggleRamadanFastDay(dayNumber: Int) {
        if (dayNumber !in 1..30) return
        context.ruhZenaDataStore.edit { prefs ->
            val current = prefs[Keys.RAMADAN_FASTED_CSV].orEmpty()
                .split(',')
                .mapNotNull { it.trim().toIntOrNull() }
                .toMutableSet()
            if (!current.add(dayNumber)) current.remove(dayNumber)
            prefs[Keys.RAMADAN_FASTED_CSV] = current.sorted().joinToString(",")
        }
    }

    suspend fun toggleRamadanJuz(juzNumber: Int) {
        if (juzNumber !in 1..30) return
        context.ruhZenaDataStore.edit { prefs ->
            val current = prefs[Keys.RAMADAN_JUZ_CSV].orEmpty()
                .split(',')
                .mapNotNull { it.trim().toIntOrNull() }
                .toMutableSet()
            if (!current.add(juzNumber)) current.remove(juzNumber)
            prefs[Keys.RAMADAN_JUZ_CSV] = current.sorted().joinToString(",")
        }
    }

    suspend fun incrementRamadanTarawih() {
        context.ruhZenaDataStore.edit { prefs ->
            prefs[Keys.RAMADAN_TARAWIH] = ((prefs[Keys.RAMADAN_TARAWIH] ?: 0) + 1).coerceAtMost(30)
        }
    }

    suspend fun incrementRamadanSadaqah() {
        context.ruhZenaDataStore.edit { prefs ->
            prefs[Keys.RAMADAN_SADAQAH] = (prefs[Keys.RAMADAN_SADAQAH] ?: 0) + 1
        }
    }

    suspend fun setAiPersonalityMode(mode: String) {
        context.ruhZenaDataStore.edit { it[Keys.AI_PERSONALITY] = mode }
    }

    suspend fun selectLearningTrack(mode: String) {
        context.ruhZenaDataStore.edit {
            it[Keys.LEARNING_MODE] = mode
            it[Keys.LEARNING_TRACK_CHOSEN] = true
        }
    }

    suspend fun toggleArabicLetterMastered(letterKey: String) {
        if (letterKey.isBlank()) return
        context.ruhZenaDataStore.edit { prefs ->
            val current = prefs[Keys.ARABIC_MASTERED_CSV].orEmpty()
                .split(',')
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toMutableSet()
            if (!current.add(letterKey)) current.remove(letterKey)
            prefs[Keys.ARABIC_MASTERED_CSV] = current.sorted().joinToString(",")
        }
    }

    suspend fun setQuranSleepTimerMinutes(minutes: Int) {
        context.ruhZenaDataStore.edit { it[Keys.QURAN_SLEEP_TIMER] = minutes.coerceIn(0, 180) }
    }

    suspend fun completeLearningStep(stepNumber: Int) {
        if (stepNumber !in 1..20) return
        context.ruhZenaDataStore.edit { prefs ->
            val current = prefs[Keys.COMPLETED_LEARNING_STEPS_CSV].orEmpty()
                .split(',')
                .mapNotNull { it.trim().toIntOrNull() }
                .toMutableSet()
            current.add(stepNumber)
            prefs[Keys.COMPLETED_LEARNING_STEPS_CSV] = current.sorted().joinToString(",")
        }
    }

    suspend fun setLearningAllAccess(enabled: Boolean) {
        context.ruhZenaDataStore.edit { it[Keys.LEARNING_ALL_ACCESS] = enabled }
    }

    suspend fun setMutedUntil(epochMs: Long) {
        context.ruhZenaDataStore.edit { it[Keys.MUTED_UNTIL_EPOCH_MS] = epochMs.coerceAtLeast(0L) }
    }

    suspend fun setQuickJumpSlotsCsv(csv: String) {
        context.ruhZenaDataStore.edit { it[Keys.QUICK_JUMP_SLOTS_CSV] = csv }
    }

    suspend fun setTutorialCompleted(completed: Boolean) {
        fastBootPrefs.edit().putBoolean("tutorial_completed", completed).apply()
        context.ruhZenaDataStore.edit { it[Keys.TUTORIAL_COMPLETED] = completed }
    }

    suspend fun markTutorialPageCompleted(pageId: String) {
        if (pageId.isBlank()) return
        context.ruhZenaDataStore.edit { prefs ->
            val current = prefs[Keys.COMPLETED_TUTORIAL_PAGES_CSV].orEmpty()
                .split(',')
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toMutableSet()
            current.add(pageId)
            val updated = current.sorted().joinToString(",")
            prefs[Keys.COMPLETED_TUTORIAL_PAGES_CSV] = updated
            if (pageId == "HOME") {
                prefs[Keys.TUTORIAL_COMPLETED] = true
                fastBootPrefs.edit()
                    .putBoolean("tutorial_completed", true)
                    .putString("completed_tutorial_pages_csv", updated)
                    .apply()
            } else {
                fastBootPrefs.edit()
                    .putString("completed_tutorial_pages_csv", updated)
                    .apply()
            }
        }
    }

    suspend fun resetAllTutorials() {
        fastBootPrefs.edit()
            .putBoolean("tutorial_completed", false)
            .putString("completed_tutorial_pages_csv", "")
            .apply()
        context.ruhZenaDataStore.edit { prefs ->
            prefs[Keys.TUTORIAL_COMPLETED] = false
            prefs[Keys.COMPLETED_TUTORIAL_PAGES_CSV] = ""
        }
    }

    suspend fun setAdhanMuezzinId(muezzinId: String) {
        context.ruhZenaDataStore.edit { it[Keys.ADHAN_MUEZZIN_ID] = muezzinId }
    }

    /** Restores/sets the profile gender only when it is a valid value ("MALE"/"FEMALE"). */
    suspend fun setCharacterGender(gender: String) {
        val g = gender.trim().uppercase()
        if (g != "MALE" && g != "FEMALE") return
        context.ruhZenaDataStore.edit { it[Keys.CHARACTER_GENDER] = g }
    }

    suspend fun setSpeechVoiceStyle(style: String) {
        context.ruhZenaDataStore.edit { it[Keys.SPEECH_VOICE_STYLE] = style }
    }
}
