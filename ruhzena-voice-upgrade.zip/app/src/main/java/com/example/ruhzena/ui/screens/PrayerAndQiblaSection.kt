package com.example.ruhzena.ui.screens

import android.Manifest
import android.content.Intent
import android.hardware.SensorManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.sensors.CompassSensorManager
import com.example.ruhzena.core.sensors.LocationFetchResult
import com.example.ruhzena.core.sensors.LocationHelper
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.CityPreset
import com.example.ruhzena.data.islamic.DailyPrayerSchedule
import com.example.ruhzena.data.islamic.HijriCalendarHelper
import com.example.ruhzena.data.islamic.NextPrayerInfo
import com.example.ruhzena.data.islamic.PrayerCalcMethod
import com.example.ruhzena.data.islamic.PrayerCalculator
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun PrayerAndQiblaSection(
    prefs: UserPreferences,
    schedule: DailyPrayerSchedule,
    nextPrayer: NextPrayerInfo,
    citySearchResults: List<CityPreset> = emptyList(),
    isSearchingCity: Boolean = false,
    onSearchCity: (String) -> Unit = {},
    onSelectCity: (CityPreset) -> Unit,
    onSelectMethod: (PrayerCalcMethod) -> Unit,
    onSelectAsrMethod: (String) -> Unit = {},
    onAdjustHijriOffset: (Int) -> Unit = {},
    onRefreshGpsLocation: ((LocationFetchResult) -> Unit) -> Unit
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val context = LocalContext.current

    val compassManager = remember { CompassSensorManager(context) }
    val compassState by compassManager.state.collectAsStateWithLifecycle()

    LaunchedEffect(prefs.latitude, prefs.longitude) {
        compassManager.setCoordinates(prefs.latitude, prefs.longitude)
    }

    DisposableEffect(compassManager) {
        compassManager.start()
        onDispose { compassManager.stop() }
    }

    var isLocating by remember { mutableStateOf(false) }
    var showOpenLocationSettings by remember { mutableStateOf(false) }
    var locationFeedback by remember { mutableStateOf<String?>(null) }
    var manualDialHeading by remember { mutableFloatStateOf(0f) }
    var cityQuery by remember { mutableStateOf("") }
    var showHijriCalendarDialog by remember { mutableStateOf(false) }
    var showCalibrationDialog by remember { mutableStateOf(false) }

    val tz = remember(prefs.locationTimeZoneId) { TimeZone.getTimeZone(prefs.locationTimeZoneId) }
    val todayHijri = remember(prefs.hijriOffsetDays, prefs.locationTimeZoneId) {
        HijriCalendarHelper.toHijri(Calendar.getInstance(tz), prefs.hijriOffsetDays)
    }

    val handleLocationResult: (LocationFetchResult) -> Unit = { result ->
        isLocating = false
        when (result) {
            is LocationFetchResult.Success -> {
                showOpenLocationSettings = false
                locationFeedback = if (result.location.isApproximateNetwork) {
                    if (isBn) "নেটওয়ার্ক অবস্থান আপডেট: ${result.location.name}" else "Network city detected: ${result.location.name}"
                } else {
                    if (isBn) "GPS অবস্থান আপডেট: ${result.location.name}" else "GPS updated: ${result.location.name}"
                }
            }
            LocationFetchResult.LocationServicesDisabled -> {
                showOpenLocationSettings = true
                locationFeedback = if (isBn) {
                    "ফোনের লোকেশন (GPS) বন্ধ আছে। সেটিংস থেকে চালু করুন অথবা নিচে শহর খুঁজুন।"
                } else {
                    "Device Location (GPS) is turned off. Enable it in Settings or search a city below."
                }
            }
            LocationFetchResult.PermissionMissing -> {
                showOpenLocationSettings = false
                locationFeedback = if (isBn) {
                    "অবস্থানের অনুমতি দেওয়া হয়নি — নিচে শহর নির্বাচন করুন।"
                } else {
                    "Location permission not granted — search or choose a city below."
                }
            }
            LocationFetchResult.Unavailable -> {
                showOpenLocationSettings = false
                locationFeedback = if (isBn) {
                    "তাৎক্ষণিক GPS সিগন্যাল পাওয়া যায়নি; নিচে যেকোনো শহর লিখে খুঁজুন।"
                } else {
                    "No GPS fix returned right now; search any city worldwide below."
                }
            }
        }
    }

    val locationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            isLocating = true
            onRefreshGpsLocation(handleLocationResult)
        } else {
            locationFeedback = if (isBn) "অবস্থানের অনুমতি দেওয়া হয়নি — শহর নির্বাচন করুন" else "Permission denied — choose a city manually"
        }
    }

    val qiblaBearing = remember(prefs.latitude, prefs.longitude) {
        PrayerCalculator.calculateQiblaBearing(prefs.latitude, prefs.longitude)
    }

    val effectiveAzimuth = if (compassState.hasLiveReading) compassState.azimuthDegrees else manualDialHeading
    var cumulativeTargetDeg by remember { mutableFloatStateOf(-effectiveAzimuth) }
    LaunchedEffect(effectiveAzimuth) {
        val currentMod = ((cumulativeTargetDeg % 360f) + 360f) % 360f
        val desiredMod = ((-effectiveAzimuth % 360f) + 360f) % 360f
        val shortestDelta = ((desiredMod - currentMod + 540f) % 360f) - 180f
        cumulativeTargetDeg += shortestDelta
    }
    val smoothDialRotation by animateFloatAsState(
        targetValue = cumulativeTargetDeg,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "qiblaDialRot"
    )

    val deltaToQibla = ((qiblaBearing.toFloat() - effectiveAzimuth + 540f) % 360f) - 180f
    val isAlignedWithQibla = abs(deltaToQibla) <= 5f
    val haptics = LocalHapticFeedback.current
    var wasAligned by remember { mutableStateOf(false) }
    LaunchedEffect(isAlignedWithQibla) {
        if (isAlignedWithQibla && !wasAligned) {
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        }
        wasAligned = isAlignedWithQibla
    }

    val textMeasurer = rememberTextMeasurer()

    if (showHijriCalendarDialog) {
        MonthlyHijriCalendarDialog(
            todayHijri = todayHijri,
            offsetDays = prefs.hijriOffsetDays,
            isBn = isBn,
            onAdjustOffset = onAdjustHijriOffset,
            onDismiss = { showHijriCalendarDialog = false }
        )
    }

    if (showCalibrationDialog) {
        QiblaCalibrationDialog(
            accuracy = compassState.accuracy,
            hasLiveReading = compassState.hasLiveReading,
            magneticFieldMicroTesla = compassState.magneticFieldMicroTesla,
            magneticInterference = compassState.magneticInterference,
            sensorSource = compassState.sensorSource,
            isBn = isBn,
            onRestartSensor = { compassManager.restart() },
            onDismiss = { showCalibrationDialog = false }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Hijri Date Banner Card
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.PRAYER_HIJRI_CARD)
                    .testTag("hijri_calendar_button"),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                onClick = { showHijriCalendarDialog = true }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = palette.gold, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "${todayHijri.day} ${if (isBn) todayHijri.monthNameBn else todayHijri.monthNameEn} ${todayHijri.year} AH",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary
                            )
                            Text(
                                text = "${todayHijri.monthNameAr} • ${if (isBn) "হিজরি ক্যালেন্ডার ও চাঁদ দেখা সমন্বয়" else "Tap for Monthly Hijri Calendar & Events"}",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    StatusPillBadge(
                        label = if (prefs.hijriOffsetDays == 0) "0d" else "${if (prefs.hijriOffsetDays > 0) "+" else ""}${prefs.hijriOffsetDays}d",
                        accentColor = palette.accentSoft
                    )
                }
            }
        }

        // True-North Qibla Cockpit
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                elevated = true,
                accentBorder = isAlignedWithQibla,
                contentPadding = PaddingValues(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.qiblaCompassTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    GlassFilterChip(
                        label = if (isBn) "ক্যালিব্রেট" else "Calibrate",
                        selected = compassState.hasLiveReading && compassState.accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE,
                        onClick = { showCalibrationDialog = true },
                        modifier = Modifier
                            .tutorialTarget(TutorialTargetKeys.PRAYER_CALIBRATE_BTN)
                            .testTag("qibla_calibration_button")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(204.dp)
                            .then(
                                if (!compassState.hasLiveReading) {
                                    Modifier.pointerInput(Unit) {
                                        detectDragGestures { change, dragAmount ->
                                            change.consume()
                                            manualDialHeading = ((manualDialHeading + dragAmount.x * 0.7f) % 360f + 360f) % 360f
                                        }
                                    }
                                } else Modifier
                            )
                            .tutorialTarget(TutorialTargetKeys.PRAYER_QIBLA_COMPASS)
                            .testTag("qibla_compass_dial"),
                        contentAlignment = Alignment.Center
                    ) {
                        QiblaCompassDial(
                            dialRotationDeg = smoothDialRotation,
                            qiblaBearingDeg = qiblaBearing.toFloat(),
                            pitchDeg = compassState.pitchDegrees,
                            rollDeg = compassState.rollDegrees,
                            isAligned = isAlignedWithQibla,
                            accentSoft = palette.success,
                            gold = palette.gold,
                            amber = palette.amber,
                            textPrimary = palette.textPrimary,
                            textMuted = palette.textMuted,
                            centerDotColor = palette.voidBg,
                            textMeasurer = textMeasurer
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${qiblaBearing.roundToInt()}°",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = if (isAlignedWithQibla) palette.accentSoft else palette.gold
                            )
                            Text(
                                text = strings.qiblaBearingLabel,
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.textSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            val turnHint = when {
                                isAlignedWithQibla -> if (isBn) "কিবলার দিকে সঠিকভাবে মুখ করেছেন!" else "Aligned with Qibla!"
                                deltaToQibla > 0f -> if (isBn) "ডানে ${deltaToQibla.roundToInt()}° ঘুরুন" else "Turn right ${deltaToQibla.roundToInt()}°"
                                else -> if (isBn) "বামে ${abs(deltaToQibla).roundToInt()}° ঘুরুন" else "Turn left ${abs(deltaToQibla).roundToInt()}°"
                            }
                            Text(
                                text = turnHint,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isAlignedWithQibla) palette.accentSoft else palette.gold,
                                textAlign = TextAlign.End
                            )
                            Text(
                                text = "${if (isBn) "বর্তমান দিক" else "Heading"}: ${effectiveAzimuth.roundToInt()}°",
                                style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = palette.textSecondary
                            )
                        }
                    }

                    if (compassState.hasLiveReading && compassState.accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = strings.compassCalibrationTip,
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.amber,
                            textAlign = TextAlign.Center
                        )
                    } else if (!compassState.hasLiveReading) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = strings.manualQiblaFallback,
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textMuted,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                if (!compassState.hasLiveReading) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isBn) "উত্তর দিক (True North) ম্যানুয়াল ডায়াল: ${manualDialHeading.roundToInt()}°"
                        else "Manual North Alignment Dial: ${manualDialHeading.roundToInt()}°",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textSecondary
                    )
                    Slider(
                        value = manualDialHeading,
                        onValueChange = { manualDialHeading = it },
                        valueRange = 0f..359f,
                        colors = SliderDefaults.colors(
                            thumbColor = palette.gold,
                            activeTrackColor = palette.accentSoft
                        ),
                        modifier = Modifier.testTag("manual_compass_slider")
                    )
                }
            }
        }

        // Daily Prayer Times Bento Card + Independent Asr School Quick Toggle
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.prayerTimesTitle, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                    StatusPillBadge(
                        label = if (prefs.asrJuristicMethod == "HANAFI") "Asr: Hanafi" else "Asr: Standard",
                        accentColor = palette.gold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                val rows = listOf(
                    Triple("FAJR", strings.fajr, schedule.fajrMinutes),
                    Triple("SUNRISE", strings.sunrise, schedule.sunriseMinutes),
                    Triple("DHUHR", strings.dhuhr, schedule.dhuhrMinutes),
                    Triple("ASR", strings.asr, schedule.asrMinutes),
                    Triple("MAGHRIB", strings.maghrib, schedule.maghribMinutes),
                    Triple("ISHA", strings.isha, schedule.ishaMinutes)
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    rows.chunked(2).forEach { pair ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { (key, label, mins) ->
                                val isNext = nextPrayer.prayerKey == key
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            if (isNext) palette.accentContainer else palette.blockBg,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .border(
                                            0.7.dp,
                                            if (isNext) palette.borderAccent else palette.borderNeutral.copy(alpha = 0.45f),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (isNext) palette.accentSoft else palette.textSecondary
                                    )
                                    Text(
                                        text = PrayerCalculator.formatMinutes(mins),
                                        style = MaterialTheme.typography.labelLarge.copy(
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = FontWeight.SemiBold
                                        ),
                                        color = if (isNext) palette.gold else palette.textPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = if (isBn) "আসরের মাজহাব (জুরিস্টিক পদ্ধতি)" else "Asr Juristic School",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassFilterChip(
                        label = if (isBn) "স্ট্যান্ডার্ড (শাফেয়ী/মালিকি/হাম্বলী)" else "Standard (Shafi'i / Maliki)",
                        selected = prefs.asrJuristicMethod != "HANAFI",
                        onClick = { onSelectAsrMethod("STANDARD") },
                        modifier = Modifier.testTag("asr_method_standard")
                    )
                    GlassFilterChip(
                        label = if (isBn) "হানাফি" else "Hanafi",
                        selected = prefs.asrJuristicMethod == "HANAFI",
                        onClick = { onSelectAsrMethod("HANAFI") },
                        modifier = Modifier.testTag("asr_method_hanafi")
                    )
                }
            }
        }

        // Location, GPS & Worldwide City Search Controls
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${strings.locationLabel}: ${prefs.locationName}",
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary
                    )
                }
                Text(
                    text = "%.4f, %.4f • ${prefs.locationTimeZoneId}".format(prefs.latitude, prefs.longitude),
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = palette.textMuted
                )

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EmeraldActionButton(
                        text = if (isLocating) (if (isBn) "অবস্থান খোঁজা হচ্ছে..." else "Locating GPS...") else strings.detectLocation,
                        icon = Icons.Default.MyLocation,
                        onClick = {
                            if (LocationHelper.hasCoarseLocationPermission(context)) {
                                isLocating = true
                                onRefreshGpsLocation(handleLocationResult)
                            } else {
                                locationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                            }
                        },
                        modifier = Modifier.weight(1f).testTag("detect_gps_button")
                    )
                    if (isLocating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                            color = palette.accentSoft
                        )
                    }
                }

                if (locationFeedback != null) {
                    Text(
                        text = locationFeedback!!,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (showOpenLocationSettings) palette.amber else palette.accentSoft,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                if (showOpenLocationSettings) {
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                        },
                        modifier = Modifier.testTag("open_location_settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isBn) "লোকেশন সেটিংস খুলুন" else "Open Location Settings")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = if (isBn) "বিশ্বের যেকোনো শহর খুঁজুন" else "Search Any City Worldwide",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = cityQuery,
                        onValueChange = { cityQuery = it },
                        placeholder = {
                            Text(
                                if (isBn) "এখানে লিখুন" else "Type here",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textMuted
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { onSearchCity(cityQuery) }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.accentSoft,
                            unfocusedBorderColor = palette.borderNeutral,
                            focusedTextColor = palette.textPrimary,
                            unfocusedTextColor = palette.textPrimary
                        ),
                        modifier = Modifier.weight(1f).testTag("city_search_input")
                    )
                    IconButton(
                        onClick = { onSearchCity(cityQuery) },
                        modifier = Modifier
                            .size(48.dp)
                            .background(palette.accentContainer, RoundedCornerShape(12.dp))
                            .testTag("city_search_button")
                    ) {
                        if (isSearchingCity) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = palette.accentSoft)
                        } else {
                            Icon(Icons.Default.Search, contentDescription = "Search City", tint = palette.accentSoft)
                        }
                    }
                }

                if (citySearchResults.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(citySearchResults) { city ->
                            GlassFilterChip(
                                label = city.name,
                                selected = prefs.locationName == city.name,
                                onClick = {
                                    onSelectCity(city)
                                    locationFeedback = if (isBn) "শহর নির্বাচিত: ${city.name}" else "Selected: ${city.name}"
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(strings.manualCity, style = MaterialTheme.typography.labelMedium, color = palette.textSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(PrayerCalculator.cityPresets) { city ->
                        GlassFilterChip(
                            label = city.name,
                            selected = prefs.locationName == city.name,
                            onClick = {
                                onSelectCity(city)
                                locationFeedback = null
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(strings.calculationMethod, style = MaterialTheme.typography.labelMedium, color = palette.textSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                val activeMethod = PrayerCalcMethod.fromId(prefs.prayerCalcMethod)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(PrayerCalcMethod.entries) { method ->
                        GlassFilterChip(
                            label = if (isBn) method.labelBn else method.labelEn,
                            selected = activeMethod == method,
                            onClick = { onSelectMethod(method) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MonthlyHijriCalendarDialog(
    todayHijri: com.example.ruhzena.data.islamic.HijriDate,
    offsetDays: Int,
    isBn: Boolean,
    onAdjustOffset: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    var viewYear by remember { mutableIntStateOf(todayHijri.year) }
    var viewMonth by remember { mutableIntStateOf(todayHijri.month) }

    val totalDays = HijriCalendarHelper.daysInHijriMonth(viewYear, viewMonth)
    val monthEvents = HijriCalendarHelper.notableEvents.filter { it.month == viewMonth }
    val monthTitle = if (isBn) {
        "${HijriCalendarHelper.monthNameBn(viewMonth)} $viewYear হি."
    } else {
        "${HijriCalendarHelper.monthNameEn(viewMonth)} $viewYear AH"
    }

    SafeFullScreenDialog(onDismissRequest = onDismiss, centerContent = true) {
        BackHandler(onBack = onDismiss)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 460.dp)
                .padding(16.dp)
                .testTag("hijri_calendar_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = palette.surfaceBg,
            border = BorderStroke(1.dp, palette.borderAccent)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBn) "হিজরি ক্যালেন্ডার" else "Hijri Calendar",
                        style = MaterialTheme.typography.titleLarge,
                        color = palette.gold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = palette.textPrimary)
                    }
                }

                // Month switcher
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        if (viewMonth == 1) {
                            viewMonth = 12
                            viewYear -= 1
                        } else {
                            viewMonth -= 1
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Prev", tint = palette.textPrimary)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(monthTitle, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                        Text(HijriCalendarHelper.monthNameAr(viewMonth), style = MaterialTheme.typography.bodySmall, color = palette.accentSoft)
                    }
                    IconButton(onClick = {
                        if (viewMonth == 12) {
                            viewMonth = 1
                            viewYear += 1
                        } else {
                            viewMonth += 1
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next", tint = palette.textPrimary)
                    }
                }

                // Days Grid (7 columns)
                val rows = (1..totalDays).chunked(7)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    rows.forEach { week ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            week.forEach { day ->
                                val isToday = viewYear == todayHijri.year && viewMonth == todayHijri.month && day == todayHijri.day
                                val hasEvent = monthEvents.any { it.day == day }
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(38.dp)
                                        .background(
                                            when {
                                                isToday -> palette.accentPrimary
                                                hasEvent -> palette.gold.copy(alpha = 0.22f)
                                                else -> palette.blockBg
                                            },
                                            RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            0.7.dp,
                                            if (hasEvent && !isToday) palette.gold else palette.borderNeutral.copy(alpha = 0.4f),
                                            RoundedCornerShape(8.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = day.toString(),
                                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                        color = if (isToday) palette.onAccent else palette.textPrimary
                                    )
                                }
                            }
                            repeat(7 - week.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }

                // Moonsighting Adjustment Stepper
                GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                    Text(
                        text = if (isBn) "চাঁদ দেখা সমন্বয় (-২ থেকে +২ দিন)" else "Moonsighting Day Offset (-2 to +2 days)",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.textSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        (-2..2).forEach { opt ->
                            GlassFilterChip(
                                label = if (opt > 0) "+$opt" else opt.toString(),
                                selected = offsetDays == opt,
                                onClick = { onAdjustOffset(opt) }
                            )
                        }
                    }
                }

                // Events this month
                val eventsToShow = if (monthEvents.isNotEmpty()) monthEvents else HijriCalendarHelper.notableEvents.take(3)
                Text(
                    text = if (monthEvents.isNotEmpty()) {
                        if (isBn) "এই মাসের উল্লেখযোগ্য ইসলামিক দিন" else "Notable Islamic Dates This Month"
                    } else {
                        if (isBn) "বার্ষিক উল্লেখযোগ্য ইসলামিক দিন" else "Upcoming Notable Hijri Milestones"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = palette.accentSoft
                )
                eventsToShow.forEach { ev ->
                    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(10.dp)) {
                        Text(
                            text = "${ev.day} ${if (isBn) HijriCalendarHelper.monthNameBn(ev.month) else HijriCalendarHelper.monthNameEn(ev.month)} — ${if (isBn) ev.titleBn else ev.titleEn}",
                            style = MaterialTheme.typography.titleSmall,
                            color = palette.gold
                        )
                        Text(
                            text = if (isBn) ev.noteBn else ev.noteEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QiblaCalibrationDialog(
    accuracy: Int,
    hasLiveReading: Boolean,
    magneticFieldMicroTesla: Float,
    magneticInterference: Boolean,
    sensorSource: String,
    isBn: Boolean,
    onRestartSensor: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val accuracyLabel = when {
        !hasLiveReading -> if (isBn) "সেন্সর সক্রিয় নেই (ডায়াল ঘুরিয়ে ব্যবহার করুন)" else "No Magnetometer Signal (Touch Dial Active)"
        magneticInterference -> if (isBn) "চৌম্বকীয় বাধা শনাক্ত হয়েছে" else "Magnetic Interference Detected"
        accuracy == SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> if (isBn) "উচ্চ নির্ভুলতা (High)" else "High Precision"
        accuracy == SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> if (isBn) "মাঝারি নির্ভুলতা (Medium)" else "Medium Accuracy"
        else -> if (isBn) "ফিগার-৮ ক্যালিব্রেশন প্রয়োজন" else "Needs Figure-8 Calibration"
    }
    val statusColor = when {
        !hasLiveReading -> palette.amber
        magneticInterference -> palette.coral
        accuracy == SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> palette.success
        else -> palette.gold
    }

    val infiniteTransition = rememberInfiniteTransition(label = "figure8_cal")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * kotlin.math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "figure8_phase"
    )

    SafeFullScreenDialog(onDismissRequest = onDismiss, centerContent = true) {
        BackHandler(onBack = onDismiss)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 460.dp)
                .padding(16.dp)
                .testTag("qibla_calibration_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = palette.surfaceBg,
            border = BorderStroke(1.dp, palette.borderAccent)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Explore, contentDescription = null, tint = palette.accentSoft)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBn) "কম্পাস ক্যালিব্রেশন" else "Compass Calibration",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = palette.textPrimary)
                    }
                }

                StatusPillBadge(label = accuracyLabel, accentColor = statusColor)

                // Animated Continuous Infinity / Figure-8 (Lissajous) Motion Guide
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(126.dp)
                        .background(palette.blockBg, RoundedCornerShape(16.dp))
                        .border(0.8.dp, palette.borderNeutral, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 14.dp)) {
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val rx = size.width * 0.42f
                        val ry = size.height * 0.36f

                        // Smooth continuous parametric infinity curve: x = rx*sin(t), y = ry*sin(2t)/1.35
                        val figure8Path = Path()
                        val samples = 120
                        for (i in 0..samples) {
                            val t = (i.toFloat() / samples) * (2.0 * kotlin.math.PI)
                            val x = cx + (rx * kotlin.math.sin(t)).toFloat()
                            val y = cy + (ry * kotlin.math.sin(2.0 * t)).toFloat()
                            if (i == 0) figure8Path.moveTo(x, y) else figure8Path.lineTo(x, y)
                        }
                        figure8Path.close()

                        // Subtle glow track
                        drawPath(
                            path = figure8Path,
                            color = palette.accentSoft.copy(alpha = 0.20f),
                            style = Stroke(width = 14f, cap = StrokeCap.Round)
                        )
                        // Crisp figure-8 trace
                        drawPath(
                            path = figure8Path,
                            brush = Brush.horizontalGradient(listOf(palette.accentSoft, palette.gold, palette.accentSoft)),
                            style = Stroke(width = 4.5f, cap = StrokeCap.Round)
                        )

                        // Animated trailing tail + phone beacon moving smoothly along the infinity path
                        for (trailIdx in 5 downTo 1) {
                            val trailT = phase - trailIdx * 0.14f
                            val tx = cx + (rx * kotlin.math.sin(trailT.toDouble())).toFloat()
                            val ty = cy + (ry * kotlin.math.sin(2.0 * trailT.toDouble())).toFloat()
                            drawCircle(
                                color = palette.gold.copy(alpha = (0.55f - trailIdx * 0.09f).coerceAtLeast(0.08f)),
                                radius = (11f - trailIdx * 1.4f).coerceAtLeast(3f),
                                center = Offset(tx, ty)
                            )
                        }
                        val phoneX = cx + (rx * kotlin.math.sin(phase.toDouble())).toFloat()
                        val phoneY = cy + (ry * kotlin.math.sin(2.0 * phase.toDouble())).toFloat()
                        drawCircle(
                            color = palette.gold.copy(alpha = 0.32f),
                            radius = 18f,
                            center = Offset(phoneX, phoneY)
                        )
                        drawRoundRect(
                            color = palette.textPrimary,
                            topLeft = Offset(phoneX - 7f, phoneY - 11f),
                            size = Size(14f, 22f),
                            cornerRadius = CornerRadius(3.5f, 3.5f)
                        )
                        drawRoundRect(
                            color = palette.accentPrimary,
                            topLeft = Offset(phoneX - 5f, phoneY - 8f),
                            size = Size(10f, 15f),
                            cornerRadius = CornerRadius(2f, 2f)
                        )
                    }
                }

                // Live Magnetometer Telemetry Readout
                GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isBn) "চৌম্বক ক্ষেত্র (Magnetic Field)" else "Magnetic Field",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.textSecondary
                            )
                            Text(
                                text = if (magneticFieldMicroTesla > 0.5f) {
                                    "${magneticFieldMicroTesla.roundToInt()} µT • ${if (magneticInterference) (if (isBn) "হস্তক্ষেপ" else "Interference") else (if (isBn) "স্বাভাবিক (25–65 µT)" else "Normal (25–65 µT)")}"
                                } else {
                                    if (isBn) "রিডিং পাওয়া যায়নি ($sensorSource)" else "No live µT reading ($sensorSource)"
                                },
                                style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = if (magneticInterference) palette.coral else palette.textPrimary
                            )
                        }
                        OutlinedButton(
                            onClick = onRestartSensor,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("restart_compass_sensor_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isBn) "রিসেট" else "Reset", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }

                val steps = if (isBn) {
                    listOf(
                        "১. চৌম্বকীয় কেস, স্পিকার বা ধাতব টেবিল থেকে দূরে সরুন।",
                        "২. উপরের অ্যানিমেশন অনুসরণ করে বাতাসে মসৃণভাবে ৩–৪ বার '∞' (Figure-8) আঁকুন।",
                        "৩. ফোনটি সমতল রেখে মাঝের লেভেল বাবলটি কেন্দ্রে আনুন। সেন্সর না থাকলে কম্পাস ডায়াল আঙুল দিয়ে ঘুরিয়ে উত্তর দিক মিলিয়ে নিন।"
                    )
                } else {
                    listOf(
                        "1. Remove magnetic cases and step away from metal desks or electronics.",
                        "2. Slowly move your phone along the continuous ∞ Figure-8 path shown above 3–4 times.",
                        "3. Hold the phone flat until the center bubble aligns. If your device has no magnetometer, drag the compass dial directly to align North."
                    )
                }

                GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        steps.forEach { step ->
                            Text(step, style = MaterialTheme.typography.bodySmall, color = palette.textPrimary)
                        }
                    }
                }

                EmeraldActionButton(
                    text = if (isBn) "সম্পন্ন" else "Done",
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun QiblaCompassDial(
    dialRotationDeg: Float,
    qiblaBearingDeg: Float,
    pitchDeg: Float,
    rollDeg: Float,
    isAligned: Boolean,
    accentSoft: Color,
    gold: Color,
    amber: Color,
    textPrimary: Color,
    textMuted: Color,
    centerDotColor: Color,
    textMeasurer: TextMeasurer
) {
    Canvas(modifier = Modifier.size(200.dp)) {
        val radius = size.minDimension / 2f
        val center = Offset(size.width / 2f, size.height / 2f)

        // 1. Brushed dark-metallic outer casing & bevel
        drawCircle(
            brush = Brush.sweepGradient(
                colors = listOf(
                    Color(0xFF3E444D),
                    Color(0xFF1A1E24),
                    Color(0xFF4B525D),
                    Color(0xFF191D22),
                    Color(0xFF3E444D)
                ),
                center = center
            ),
            radius = radius - 1f,
            center = center
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFF13191E),
                    Color(0xFF0A0D10)
                ),
                center = center,
                radius = radius - 9f
            ),
            radius = radius - 9f,
            center = center
        )

        drawCircle(
            color = if (isAligned) accentSoft.copy(alpha = 0.85f) else gold.copy(alpha = 0.45f),
            radius = radius - 8f,
            center = center,
            style = Stroke(width = if (isAligned) 3.5f else 1.8f)
        )

        drawCircle(
            color = textMuted.copy(alpha = 0.16f),
            radius = radius * 0.66f,
            center = center,
            style = Stroke(width = 1.2f)
        )
        drawCircle(
            color = textMuted.copy(alpha = 0.2f),
            radius = radius * 0.22f,
            center = center,
            style = Stroke(width = 1.2f)
        )

        rotate(degrees = dialRotationDeg, pivot = center) {
            for (deg in 0 until 360 step 5) {
                val rad = (deg - 90) * (PI / 180.0)
                val isCardinal = deg % 90 == 0
                val isMajor = deg % 30 == 0
                val isMid = deg % 15 == 0
                val inner = when {
                    isCardinal -> radius - 22f
                    isMajor -> radius - 19f
                    isMid -> radius - 15f
                    else -> radius - 12f
                }
                val outer = radius - 9.5f
                drawLine(
                    color = when {
                        deg == 0 -> Color(0xFFFF5252)
                        isCardinal -> gold.copy(alpha = 0.9f)
                        isMajor -> Color(0xFFE5EAE8).copy(alpha = 0.78f)
                        else -> Color(0xFF9CA8A4).copy(alpha = 0.4f)
                    },
                    start = Offset(center.x + (inner * cos(rad)).toFloat(), center.y + (inner * sin(rad)).toFloat()),
                    end = Offset(center.x + (outer * cos(rad)).toFloat(), center.y + (outer * sin(rad)).toFloat()),
                    strokeWidth = when {
                        isCardinal -> 3f
                        isMajor -> 2f
                        else -> 1.1f
                    },
                    cap = StrokeCap.Round
                )
            }

            val rosePoints = listOf(
                "N" to 0f, "NE" to 45f, "E" to 90f, "SE" to 135f,
                "S" to 180f, "SW" to 225f, "W" to 270f, "NW" to 315f
            )
            rosePoints.forEach { (label, angle) ->
                val isPrimary = label.length == 1
                val rad = (angle - 90f) * (PI / 180.0)
                val dist = radius - (if (isPrimary) 33f else 31f)
                val measured = textMeasurer.measure(
                    text = label,
                    style = TextStyle(
                        fontSize = if (isPrimary) 12.sp else 9.sp,
                        fontWeight = if (isPrimary) FontWeight.Bold else FontWeight.Medium,
                        color = when (label) {
                            "N" -> Color(0xFFFF5252)
                            "E", "S", "W" -> Color(0xFFF3F6F5)
                            else -> Color(0xFF9DA7A4)
                        }
                    )
                )
                val tx = center.x + (dist * cos(rad)).toFloat() - measured.size.width / 2f
                val ty = center.y + (dist * sin(rad)).toFloat() - measured.size.height / 2f
                drawText(measured, topLeft = Offset(tx, ty))
            }

            val northNeedle = Path().apply {
                moveTo(center.x, center.y - radius * 0.56f)
                lineTo(center.x - 8.5f, center.y)
                lineTo(center.x, center.y - 6f)
                close()
            }
            val northNeedleShadow = Path().apply {
                moveTo(center.x, center.y - radius * 0.56f)
                lineTo(center.x + 8.5f, center.y)
                lineTo(center.x, center.y - 6f)
                close()
            }
            val southNeedle = Path().apply {
                moveTo(center.x, center.y + radius * 0.52f)
                lineTo(center.x - 8.5f, center.y)
                lineTo(center.x, center.y + 6f)
                close()
            }
            val southNeedleShadow = Path().apply {
                moveTo(center.x, center.y + radius * 0.52f)
                lineTo(center.x + 8.5f, center.y)
                lineTo(center.x, center.y + 6f)
                close()
            }
            drawPath(northNeedle, color = Color(0xFFFF5252))
            drawPath(northNeedleShadow, color = Color(0xFFB71C1C))
            drawPath(southNeedle, color = Color(0xFFE7ECEA).copy(alpha = 0.9f))
            drawPath(southNeedleShadow, color = Color(0xFF6B7280))

            rotate(degrees = qiblaBearingDeg, pivot = center) {
                val tipY = center.y - radius + 24f
                drawLine(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            if (isAligned) accentSoft else gold,
                            if (isAligned) accentSoft.copy(alpha = 0.15f) else gold.copy(alpha = 0.12f)
                        ),
                        startY = tipY,
                        endY = center.y
                    ),
                    start = Offset(center.x, tipY),
                    end = Offset(center.x, center.y),
                    strokeWidth = 5f,
                    cap = StrokeCap.Round
                )

                val kaabaSize = 16f
                val kaabaTopLeft = Offset(center.x - kaabaSize / 2f, tipY - kaabaSize / 2f)
                drawRoundRect(
                    color = Color(0xFF0E1012),
                    topLeft = kaabaTopLeft,
                    size = Size(kaabaSize, kaabaSize),
                    cornerRadius = CornerRadius(3f, 3f)
                )
                drawRoundRect(
                    color = if (isAligned) accentSoft else gold,
                    topLeft = kaabaTopLeft,
                    size = Size(kaabaSize, kaabaSize),
                    cornerRadius = CornerRadius(3f, 3f),
                    style = Stroke(width = 2.2f)
                )
                drawLine(
                    color = gold,
                    start = Offset(kaabaTopLeft.x + 2f, kaabaTopLeft.y + 5f),
                    end = Offset(kaabaTopLeft.x + kaabaSize - 2f, kaabaTopLeft.y + 5f),
                    strokeWidth = 2f
                )
            }
        }

        val maxBubbleShift = radius * 0.13f
        val bubbleX = (center.x + (rollDeg / 35f).coerceIn(-1f, 1f) * maxBubbleShift)
        val bubbleY = (center.y + (pitchDeg / 35f).coerceIn(-1f, 1f) * maxBubbleShift)
        val isFlatEnough = abs(pitchDeg) < 15f && abs(rollDeg) < 15f
        drawCircle(
            color = (if (isFlatEnough) accentSoft else amber).copy(alpha = 0.45f),
            radius = 9f,
            center = Offset(bubbleX, bubbleY)
        )

        val pointer = Path().apply {
            moveTo(center.x, 12f)
            lineTo(center.x - 7f, 0f)
            lineTo(center.x + 7f, 0f)
            close()
        }
        drawPath(pointer, color = if (isAligned) accentSoft else gold)

        drawArc(
            brush = Brush.linearGradient(
                colors = listOf(Color.White.copy(alpha = 0.16f), Color.Transparent)
            ),
            startAngle = 195f,
            sweepAngle = 125f,
            useCenter = false,
            topLeft = Offset(14f, 14f),
            size = Size(size.width - 28f, size.height - 28f),
            style = Stroke(width = 7f, cap = StrokeCap.Round)
        )

        drawCircle(gold, radius = 6.5f, center = center)
        drawCircle(centerDotColor, radius = 2.5f, center = center)
    }
}
