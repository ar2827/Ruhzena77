package com.example.ruhzena.ai

import kotlinx.serialization.Serializable

@Serializable
data class AiEvidenceResponse(
    val topic: String,
    val quranicEvidence: String,
    val hadithEvidence: String,
    val scholarlyExplanations: String,
    val scholarlyDifferences: String,
    val aiSynthesis: String,
    val sourceLinks: List<String> = emptyList(),
    val retrievalModeLabel: String = "Local Verified Corpus",
    val actionTags: List<String> = emptyList()
)

data class KnowledgeEntry(
    val id: String,
    val keywords: List<String>,
    val topicEn: String,
    val topicBn: String,
    val quranEn: String,
    val quranBn: String,
    val hadithEn: String,
    val hadithBn: String,
    val scholarlyEn: String,
    val scholarlyBn: String,
    val ikhtilafEn: String,
    val ikhtilafBn: String,
    val synthesisEn: String,
    val synthesisBn: String,
    val links: List<String>
)

object IslamicKnowledgeCorpus {
    private val stopwords = setOf(
        "what", "how", "when", "where", "why", "who", "whom", "whose", "which", "does", "do", "did",
        "is", "are", "was", "were", "be", "been", "being", "the", "a", "an", "in", "on", "at", "to",
        "for", "of", "with", "about", "from", "and", "or", "can", "could", "would", "should", "will",
        "you", "me", "my", "mine", "your", "our", "tell", "give", "make", "explain", "mean", "meaning",
        "please", "islam", "islamic", "say", "says", "said", "does", "know", "want", "need", "help",
        "কি", "কী", "কিভাবে", "কীভাবে", "কেন", "কখন", "কোথায়", "কে", "সম্পর্কে", "বিষয়ে", "বলুন",
        "জানতে", "চাই", "ইসলাম", "ইসলামে", "ইসলামের", "আমাদের", "আমার", "আপনার", "করব", "করা", "হয়", "হয়েছে"
    )

    private val banglaToEnglishConcepts = mapOf(
        "নামাজ" to "prayer salah", "সালাত" to "prayer salah", "ফজর" to "fajr prayer", "যোহর" to "dhuhr",
        "আসর" to "asr", "মাগরিব" to "maghrib", "এশা" to "isha", "তাহাজ্জুদ" to "tahajjud night prayer",
        "বিতর" to "witr prayer", "তারাবীহ" to "tarawih", "জানাজা" to "janazah funeral prayer",
        "অজু" to "wudu ablution", "গোসল" to "ghusl purification", "তায়াম্মুম" to "tayammum",
        "দুশ্চিন্তা" to "anxiety peace", "হতাশা" to "despair hope", "মন" to "heart peace",
        "তওবা" to "repentance tawbah forgiveness", "ক্ষমা" to "forgiveness mercy", "গুনাহ" to "sin repentance",
        "রোজা" to "fasting sawm", "সিয়াম" to "fasting", "রমজান" to "ramadan", "লাইলাতুল" to "laylatul qadr",
        "যাকাত" to "zakat charity", "সদকা" to "sadaqah charity", "কুরবানি" to "qurbani udhiyah sacrifice",
        "রাগ" to "anger patience", "দুআ" to "dua supplication", "ইস্তিখারা" to "istikhara",
        "মা" to "mother parents", "বাবা" to "father parents", "পরিবার" to "family marriage",
        "বিয়ে" to "marriage nikah", "বিবাহ" to "marriage nikah", "তালাক" to "divorce",
        "কুরআন" to "quran recitation", "হাদিস" to "hadith sunnah", "তাফসীর" to "tafsir",
        "ধৈর্য" to "patience sabr", "সবর" to "patience sabr", "কৃতজ্ঞতা" to "gratitude shukr",
        "স্বাস্থ্য" to "health fitness", "ব্যায়াম" to "exercise workout", "ঘুম" to "sleep rest",
        "খাবার" to "nutrition food", "পানি" to "water hydration", "পুষ্টি" to "nutrition",
        "রিজিক" to "provision rizq", "হালাল" to "halal lawful", "হারাম" to "haram forbidden", "সুদ" to "riba interest",
        "জুমআ" to "friday jumuah", "হজ" to "hajj pilgrimage", "উমরাহ" to "umrah",
        "বদর" to "battle of badr", "উহুদ" to "battle of uhud", "খন্দক" to "battle of trench",
        "হিংসা" to "envy hasad", "বদ-নজর" to "evil eye protection", "রুকইয়াহ" to "ruqyah",
        "মৃত্যু" to "death hereafter", "আখিরাত" to "hereafter", "জান্নাত" to "paradise jannah",
        "জাহান্নাম" to "hellfire", "সততা" to "truthfulness honesty", "নবী" to "prophet muhammad",
        "সাহাবা" to "sahabah companions", "আবু" to "abu bakr", "উমর" to "umar ibn khattab",
        "আলী" to "ali ibn abi talib", "খাদিজা" to "khadijah", "আয়েশা" to "aisha",
        "মুসা" to "moses musa", "ইব্রাহিম" to "abraham ibrahim", "ইউসুফ" to "joseph yusuf",
        "ঈসা" to "jesus isa", "ভালোবাসা" to "love mercy", "অহংকার" to "arrogance humility"
    )

    val entries: List<KnowledgeEntry> = listOf(
        KnowledgeEntry(
            id = "salah_prayer",
            keywords = listOf("prayer", "pray", "salah", "salat", "namaz", "fajr", "dhuhr", "asr", "maghrib", "isha", "khushu", "focus", "namaj", "নামাজ", "সালাত", "ফজর", "যোহর", "আসর", "মাগরিব", "এশা", "খুশু"),
            topicEn = "Significance & Khushu' (Focus) in Salah",
            topicBn = "নামাজের গুরুত্ব ও মনোযোগ (খুশু)",
            quranEn = "Surah Al-Baqarah 2:238 — 'Maintain with care the [obligatory] prayers and [in particular] the middle prayer and stand before Allah, devoutly obedient.' Surah Al-Mu'minun 23:1–2 — 'Certainly will the believers have succeeded: They who are during their prayer humbly submissive.'",
            quranBn = "সূরা আল-বাকারা ২:২৩৮ — 'তোমরা নামাজসমূহের এবং বিশেষত মধ্যবর্তী নামাজের প্রতি যত্নবান হও।' সূরা মুমিনূন ২৩:১-২ — 'নিশ্চয়ই মুমিনগণ সফলকাম হয়েছে, যারা তাদের নামাজে বিনীত থাকে।'",
            hadithEn = "Sahih al-Bukhari 528 (Grade: Sahih): The five daily prayers wash away sins like bathing in a flowing river five times a day. Sahih Muslim 82: Preserving Salah distinguishes faith from neglect.",
            hadithBn = "সহীহ বুখারী ৫২৮ (মান: সহীহ): পাঁচ ওয়াক্ত নামাজ প্রতিদিন প্রবাহিত নদীতে গোসল করার মতো গুনাহের ময়লা ধুয়ে দেয়।",
            scholarlyEn = "Imam al-Nawawi (al-Majmu') and Ibn Rajab affirmed that Salah anchors the believer's day, while slowing down recitation and understanding Al-Fatihah awakens khushu'.",
            scholarlyBn = "ইমাম নববী (রহ.) উল্লেখ করেছেন, ধীরস্থিরভাবে তিলাওয়াত ও সূরা ফাতিহার অর্থ বোঝা নামাজে মনোযোগ (খুশু) বাড়ায়।",
            ikhtilafEn = "Hanafi and Shafi'i/Maliki/Hanbali schools differ on whether Asr begins at 1x or 2x object shadow length, and on audible vs silent recitation of Bismillah before Al-Fatihah.",
            ikhtilafBn = "আসর নামাজের ওয়াক্ত (১ গুণ বনাম ২ গুণ ছায়া) এবং সূরা ফাতিহার আগে বিসমিল্লাহ উচ্চস্বরে না অনুচ্চস্বরে পড়া—এসব বিষয়ে মাযহাবসমূহের স্বীকৃত মতভেদ রয়েছে।",
            synthesisEn = "Perform calm wudu, silence distractions two minutes before adhan, and pause at each rukn (bowing and prostration) while reflecting on what you recite.",
            synthesisBn = "আযানের আগেই অজু সেরে মন স্থির করুন এবং রুকু-সিজদায় তাড়াহুড়ো না করে ধীরস্থিরভাবে তাসবিহ পাঠ করুন।",
            links = listOf("https://quran.com/2/238", "https://sunnah.com/bukhari:528")
        ),
        KnowledgeEntry(
            id = "tahajjud_night",
            keywords = listOf("tahajjud", "qiyam", "night", "witr", "তাহাজ্জুদ", "কিয়াম", "রাতের", "বিতর"),
            topicEn = "Tahajjud & Qiyam al-Layl (Night Prayer)",
            topicBn = "তাহাজ্জুদ ও রাতের নামাজ",
            quranEn = "Surah Al-Isra 17:79 — 'And from [part of] the night, pray with it as additional [worship] for you; it is expected that your Lord will resurrect you to a praised station.' Surah As-Sajdah 32:16 praises those whose sides forsake their beds to invoke their Lord in fear and hope.",
            quranBn = "সূরা বনি ইসরাঈল ১৭:৭৯ — 'রাতের কিছু অংশে তাহাজ্জুদ পড়ুন, এটি আপনার জন্য অতিরিক্ত ইবাদত; আশা করা যায় আপনার রব আপনাকে প্রশংসিত স্থানে অধিষ্ঠিত করবেন।'",
            hadithEn = "Sahih Muslim 1163 (Grade: Sahih): 'The best prayer after the obligatory prayers is the night prayer (Qiyam al-Layl).' Sahih al-Bukhari 1145: In the last third of every night, Allah asks who is calling upon Him so He may answer.",
            hadithBn = "সহীহ মুসলিম ১১৬৩ (মান: সহীহ): 'ফরজ নামাজের পর সর্বোত্তম নামাজ হলো রাতের নামাজ।' সহীহ বুখারী ১১৪৫: রাতের শেষ তৃতীয়াংশে আল্লাহর বিশেষ রহমত অবতীর্ণ হয়।",
            scholarlyEn = "Scholars teach that Tahajjud can be prayed as two, four, or eight rak'ahs followed by Witr, and waking even 15 minutes before Fajr qualifies as reviving the night.",
            scholarlyBn = "আলেমদের মতে ফজরের ১৫-২০ মিনিট আগে উঠে মাত্র ২ রাকাত তাহাজ্জুদ ও বিতর আদায় করলেও রাত জাগার ফজিলত লাভ হয়।",
            ikhtilafEn = "Schools differ slightly on whether Witr is obligatory (Wajib in Hanafi fiqh) or emphasized Sunnah (Sunnah Mu'akkadah in the majority of the three other schools), and whether Tahajjud requires sleeping first.",
            ikhtilafBn = "বিতর নামাজ ওয়াজিব (হানাফি) নাকি সুন্নাতে মুয়াক্কাদাহ (অধিকাংশ ইমাম)—এ বিষয়ে স্বীকৃত ফিকহি মতভেদ রয়েছে।",
            synthesisEn = "Sleep shortly after Isha and wake 15–20 minutes before Fajr for 2 gentle rak'ahs plus heartfelt Dua during Sujood.",
            synthesisBn = "এশার পর তাড়াতাড়ি ঘুমিয়ে ফজরের ২০ মিনিট আগে উঠে ২ রাকাত তাহাজ্জুদ ও সিজদায় মন খুলে দুআ করুন।",
            links = listOf("https://quran.com/17/79", "https://sunnah.com/muslim:1163a")
        ),
        KnowledgeEntry(
            id = "wudu_purification",
            keywords = listOf("wudu", "ablution", "ghusl", "tayammum", "clean", "pure", "taharah", "অজু", "গোসল", "পবিত্রতা"),
            topicEn = "Wudu (Ablution) & Spiritual Purification",
            topicBn = "অজু ও পবিত্রতার বিধান",
            quranEn = "Surah Al-Ma'idah 5:6 — 'O you who have believed, when you rise to [perform] prayer, wash your faces and your forearms to the elbows and wipe over your heads and wash your feet to the ankles.'",
            quranBn = "সূরা মায়িদা ৫:৬ — 'হে মুমিনগণ, যখন তোমরা নামাজের জন্য দাঁড়াবে, তখন তোমাদের মুখমণ্ডল ও হাত কনুই পর্যন্ত ধুয়ে নাও, মাথা মাসেহ করো এবং পা টাখনু পর্যন্ত ধুয়ে নাও।'",
            hadithEn = "Sahih Muslim 223 (Grade: Sahih): 'Purity is half of faith (At-tuhuru shatrul-iman).' Sahih Muslim 244: With every drop of wudu water, minor sins fall away.",
            hadithBn = "সহীহ মুসলিম ২২৩ (মান: সহীহ): 'পবিত্রতা ঈমানের অর্ধেক।' এবং অজুর পানির প্রতিটি ফোঁটার সাথে ছোট গুনাহসমূহ ঝরে যায়।",
            scholarlyEn = "Jurists emphasize conserving water even beside a flowing river and fulfilling the four Quranic pillars (face, arms to elbows, head wipe, feet to ankles) attentively.",
            scholarlyBn = "ফকিহগণ অজুতে পানি অপচয় না করে চার ফরজ যথাযথভাবে আদায়ের প্রতি গুরুত্ব দিয়েছেন।",
            ikhtilafEn = "Schools differ on whether wiping the entire head or a quarter/portion suffices, and whether intention (niyyah) and sequential order (tartib) are obligatory pillars.",
            ikhtilafBn = "মাথা কতটুকু মাসেহ করা ফরজ এবং অজুতে নিয়ত ও ধারাবাহিকতা ফরজ কি না—এ নিয়ে মাযহাবগুলোতে ফিকহি মতভেদ রয়েছে।",
            synthesisEn = "Maintain wudu throughout the day when possible; refreshing wudu also calms anger and prepares the heart for Salah.",
            synthesisBn = "সম্ভব হলে দিনের বেশিরভাগ সময় অজু অবস্থায় থাকুন; এটি রাগ প্রশমন করে ও মনকে সতেজ রাখে।",
            links = listOf("https://quran.com/5/6", "https://sunnah.com/muslim:223")
        ),
        KnowledgeEntry(
            id = "anxiety_depression_tawakkul",
            keywords = listOf("anxiety", "anxious", "stress", "stressed", "sad", "sadness", "depress", "depressed", "depression", "worry", "worried", "fear", "overwhelm", "overwhelmed", "peace", "calm", "tawakkul", "heart", "hardship", "দুশ্চিন্তা", "হতাশা", "অস্থিরতা", "ভয়", "শান্তি", "তাওয়াক্কুল", "মন"),
            topicEn = "Overcoming Anxiety, Sadness & Finding Peace (Tawakkul)",
            topicBn = "দুশ্চিন্তা, হতাশা দূর করা ও মানসিক প্রশান্তি",
            quranEn = "Surah Ar-Ra'd 13:28 — 'Unquestionably, by the remembrance of Allah hearts are assured.' Surah Ash-Sharh 94:5–6 — 'For indeed, with hardship [will be] ease.' Surah At-Talaq 65:3 — 'And whoever relies upon Allah — then He is sufficient for him.'",
            quranBn = "সূরা রা'দ ১৩:২৮ — 'জেনে রাখো, আল্লাহর যিকিরেই অন্তরসমূহ প্রশান্ত হয়।' সূরা ইনশিরাহ ৯৪:৫-৬ — 'নিশ্চয় কষ্টের সাথেই রয়েছে স্বস্তি।' সূরা তালাক ৬৫:৩ — 'যে আল্লাহর ওপর ভরসা করে, আল্লাহ তার জন্য যথেষ্ট।'",
            hadithEn = "Sahih al-Bukhari 6369 (Grade: Sahih): The Prophet (ﷺ) regularly sought refuge from anxiety (hamm) and grief (hazan). Sahih Muslim 2999: Everything for a believer is good—gratitude in ease and patience in hardship.",
            hadithBn = "সহীহ বুখারী ৬৩৬৯ (মান: সহীহ): নবীজী (ﷺ) নিয়মিত দুশ্চিন্তা ও দুঃখ থেকে আল্লাহর আশ্রয় চাইতেন।",
            scholarlyEn = "Ibn al-Qayyim explained in Zad al-Ma'ad that remembrance of Allah, seeking beneficial companionship, and taking practical worldly means together dispel spiritual and emotional distress; Islamic ethics also affirm seeking qualified medical care when needed.",
            scholarlyBn = "ইবনুল কাইয়্যিম (রহ.) উল্লেখ করেছেন যে আল্লাহর যিকির, দুআ এবং বাস্তব পদক্ষেপ একসাথে গ্রহণ করলে অন্তরের উদ্বেগ দূর হয়; প্রয়োজনে চিকিৎসকের পরামর্শ নেওয়াও ইসলামসম্মত।",
            ikhtilafEn = "Scholars distinguish spiritual trials from clinical conditions and unanimously encourage combining spiritual remedies (Salah, Dua, Dhikr) with professional health support.",
            ikhtilafBn = "আধ্যাত্মিক অস্থিরতা ও শারীরিক/মানসিক অসুস্থতার ক্ষেত্রে আলেমগণ ইবাদতের পাশাপাশি অভিজ্ঞ চিকিৎসকের পরামর্শ নেওয়ার প্রতি উৎসাহ দেন।",
            synthesisEn = "Take a slow breath, pray two calm rak'ahs, recite 'Hasbunallahu wa ni'mal-Wakil' and the Prophetic Dua against anxiety (Bukhari 6369), and take one small constructive action today.",
            synthesisBn = "ধীর শ্বাস নিয়ে দুই রাকাত নামাজ পড়ুন, দুশ্চিন্তা মুক্তির দুআ (বুখারী ৬৩৬৯) পাঠ করুন এবং আজকের ছোট একটি বাস্তব কাজ সম্পন্ন করুন।",
            links = listOf("https://quran.com/13/28", "https://sunnah.com/bukhari:6369")
        ),
        KnowledgeEntry(
            id = "tawbah_repentance",
            keywords = listOf("repent", "repentance", "tawbah", "forgive", "forgiveness", "istighfar", "guilt", "sin", "sins", "relapse", "mercy", "তওবা", "ক্ষমা", "ইস্তিগফার", "গুনাহ"),
            topicEn = "Tawbah (Repentance), Istighfar & Never Despairing",
            topicBn = "তওবা, ইস্তিগফার ও হতাশ না হওয়া",
            quranEn = "Surah Az-Zumar 39:53 — 'Say, O My servants who have transgressed against themselves, do not despair of the mercy of Allah. Indeed, Allah forgives all sins.' Surah Al-Furqan 25:70 promises Allah replaces sincere repenters' evil deeds with good deeds.",
            quranBn = "সূরা যুমার ৩৯:৫৩ — 'হে আমার বান্দারা, যারা নিজেদের ওপর জুলুম করেছ, আল্লাহর রহমত থেকে নিরাশ হয়ো না। নিশ্চয় আল্লাহ সকল গুনাহ ক্ষমা করেন।'",
            hadithEn = "Sahih Muslim 2749 (Grade: Sahih): Allah rejoices at the repentance of His servant more than a lost traveler finding his provision. Sunan Ibn Majah 4250 (Hasan): 'Every son of Adam sins, and the best of those who sin are those who repent.'",
            hadithBn = "সহীহ মুসলিম ২৭৪৯ (মান: সহীহ): বান্দার তওবায় আল্লাহ অত্যন্ত আনন্দিত হন। ইবনে মাজাহ ৪২৫০: প্রত্যেক মানুষই ভুল করে, আর উত্তম হলো যারা তওবা করে।",
            scholarlyEn = "Imam al-Nawawi (Riyad as-Salihin) listed three conditions of sincere Tawbah: ceasing the sin immediately, feeling genuine remorse, and resolving firmly not to return—plus restoring any human rights if others were wronged.",
            scholarlyBn = "ইমাম নববী (রহ.) তওবার শর্ত হিসেবে গুনাহ ত্যাগ, অনুতপ্ত হওয়া, পুনরায় না করার দৃঢ় সংকল্প এবং কারো হক নষ্ট হলে তা ফিরিয়ে দেওয়ার কথা বলেছেন।",
            ikhtilafEn = "Jurists emphasize that repeating a sin after sincere past repentance does not invalidate prior Tawbah; each sincere return renews mercy.",
            ikhtilafBn = "আলেমগণ বলেন, তওবা করার পর দুর্বলতাবশত আবার ভুল হয়ে গেলেও হতাশ না হয়ে সাথে সাথে পুনরায় তওবা করতে হবে।",
            synthesisEn = "Never let shame keep you away from Salah or Dua. Make fresh wudu, pray two rak'ahs of Tawbah, recite Sayyidul Istighfar, and replace the triggering environment.",
            synthesisBn = "লজ্জা বা অপরাধবোধের কারণে নামাজ ছাড়বেন না; সাথে সাথে অজু করে দুই রাকাত নফল পড়ে তওবা করুন ও ক্ষমা চান।",
            links = listOf("https://quran.com/39/53", "https://sunnah.com/muslim:2747a")
        ),
        KnowledgeEntry(
            id = "ramadan_fasting",
            keywords = listOf("fast", "fasting", "ramadan", "sawm", "roza", "suhoor", "iftar", "sehri", "রোজা", "রমজান", "সিয়াম", "সেহরি", "ইফতার"),
            topicEn = "Fasting (Sawm), Ramadan & Mindful Suhoor/Iftar",
            topicBn = "রোজা, রমজান এবং সেহরি ও ইফতারের সুন্নাহ",
            quranEn = "Surah Al-Baqarah 2:183 — 'O you who have believed, decreed upon you is fasting as it was decreed upon those before you that you may become mindful of Allah (taqwa).'",
            quranBn = "সূরা আল-বাকারা ২:১৮৩ — 'হে মুমিনগণ, তোমাদের ওপর সিয়াম ফরজ করা হয়েছে যেভাবে পূর্ববর্তীদের ওপর করা হয়েছিল, যাতে তোমরা তাকওয়া অর্জন করতে পারো।'",
            hadithEn = "Sahih al-Bukhari 1923 (Grade: Sahih): 'Eat Suhoor, for indeed in Suhoor there is blessing (barakah).' Sahih al-Bukhari 1903: Fasting is a shield against harsh speech and impulse.",
            hadithBn = "সহীহ বুখারী ১৯২৩ (মান: সহীহ): 'তোমরা সেহরি খাও, কারণ সেহরিতে বরকত রয়েছে।' সহীহ বুখারী ১৯০৩: রোজা হলো ঢালস্বরূপ।",
            scholarlyEn = "Fasting trains physical self-restraint, empathy for the hungry, and restraint of speech and anger; scholars also permit breaking the fast when illness or hardship makes fasting harmful.",
            scholarlyBn = "রোজা কেবল পানাহার থেকে বিরত থাকা নয়, বরং জিহ্বা, দৃষ্টি ও আচরণের সংযম অনুশীলন। অসুস্থ বা সফরে থাকলে শরীয়তের ছাড় রয়েছে।",
            ikhtilafEn = "Schools discuss details of voluntary Mon/Thu fasting, intention timing (before Fajr for Ramadan vs during morning for voluntary fasts), and compensation (fidyah vs qada).",
            ikhtilafBn = "নফল রোজার নিয়তের সময় ও কাজা/ফিদইয়ার সূক্ষ্ম মাসআলায় ফিকহি মাযহাবগুলোতে আলোচনা রয়েছে।",
            synthesisEn = "Pair fasting with balanced hydration between Iftar and Suhoor, start Iftar with dates and water, and guard speech from negativity.",
            synthesisBn = "ইফতারে খেজুর ও পানি দিয়ে শুরু করুন, ইফতার থেকে সেহরি পর্যন্ত পর্যাপ্ত পানি পান করুন এবং কথাবার্তায় সংযম রাখুন।",
            links = listOf("https://quran.com/2/183", "https://sunnah.com/bukhari:1923")
        ),
        KnowledgeEntry(
            id = "zakat_sadaqah",
            keywords = listOf("zakat", "charity", "sadaqah", "donate", "poor", "wealth", "দান", "যাকাত", "সদকা", "সম্পদ"),
            topicEn = "Zakat, Sadaqah & Purifying Wealth",
            topicBn = "যাকাত, সদকা ও সম্পদের পবিত্রতা",
            quranEn = "Surah At-Tawbah 9:103 — 'Take, [O, Muhammad], from their wealth a charity by which you purify them and cause them increase.' Surah Al-Baqarah 2:261 likens charity spent for Allah to a grain producing seven hundredfold.",
            quranBn = "সূরা তাওবা ৯:১০৩ — 'তাদের সম্পদ থেকে সদকা গ্রহণ করুন, যা দ্বারা আপনি তাদের পবিত্র ও পরিশুদ্ধ করবেন।' সূরা বাকারা ২:২৬১: আল্লাহর পথে ব্যয়ের সওয়াব সাতশত গুণ বা ততোধিক বৃদ্ধি পায়।",
            hadithEn = "Sahih Muslim 2588 (Grade: Sahih): 'Charity never decreases wealth.' Sahih al-Bukhari 2989: Every limb owes daily sadaqah—even a kind word or removing harm from a path.",
            hadithBn = "সহীহ মুসলিম ২৫৮৮ (মান: সহীহ): 'সদকা করলে সম্পদ কখনো কমে না।' সহীহ বুখারী ২৯৮৯: সুন্দর কথা বলা ও পথের কষ্টদায়ক বস্তু সরানোও সদকা।",
            scholarlyEn = "Zakat (typically 2.5% annually above Nisab held for one lunar year) is a binding right of the poor, while voluntary Sadaqah can be financial or service-based every single day.",
            scholarlyBn = "নিসাব পরিমাণ সম্পদ এক বছর পূর্ণ হলে ২.৫% যাকাত ফরজ, আর নফল সদকা যেকোনো দিন অর্থ বা ভালো আচরণের মাধ্যমে করা যায়।",
            ikhtilafEn = "Jurists differ on whether Nisab should benchmark gold or silver for cash savings, and whether Zakat applies to women's worn gold jewelry (Hanafi view requires it; majority of the other three schools exempt personal worn jewelry).",
            ikhtilafBn = "ব্যবহৃত স্বর্ণের অলংকারে যাকাত ফরজ কি না এবং নগদ টাকার নিসাব স্বর্ণ নাকি রুপার হিসেবে ধরা হবে—এ বিষয়ে মাযহাবসমূহের মতভেদ রয়েছে।",
            synthesisEn = "Automate a small regular Sadaqah—even daily or weekly—and smile or speak gently to family today, as kindness itself is counted as charity.",
            synthesisBn = "নিয়মিত সামান্য হলেও দান করার অভ্যাস গড়ে তুলুন এবং পরিবার ও মানুষের সাথে হাসিমুখে উত্তম আচরণ করুন।",
            links = listOf("https://quran.com/2/261", "https://sunnah.com/muslim:2588")
        ),
        KnowledgeEntry(
            id = "anger_control",
            keywords = listOf("anger", "angry", "mad", "temper", "conflict", "fight", "irritated", "রাগ", "ক্রোধ", "মেজাজ"),
            topicEn = "Controlling Anger & Emotional Discipline (Hilm)",
            topicBn = "রাগ নিয়ন্ত্রণ ও সহনশীলতা",
            quranEn = "Surah Ali 'Imran 3:134 — '...who restrain anger and pardon the people — and Allah loves the doers of good.' Surah Fussilat 41:34 — 'Repel [evil] by that [deed] which is better.'",
            quranBn = "সূরা আলে ইমরান ৩:১৩৪ — '...যারা ক্রোধ সংবরণ করে এবং মানুষকে ক্ষমা করে দেয়; আল্লাহ সৎকর্মশীলদের ভালোবাসেন।'",
            hadithEn = "Sahih al-Bukhari 6116 (Grade: Sahih): 'Do not get angry' (repeated three times to a questioner seeking life advice). Sahih al-Bukhari 6114: True strength is self-control during anger. Sunan Abi Dawud 4782: Change posture (sit or lie down) when angry.",
            hadithBn = "সহীহ বুখারী ৬১১৬ (মান: সহীহ): 'রাগ করো না।' বুখারী ৬১১৪: প্রকৃত শক্তিশালী সে-ই যে রাগের সময় নিজেকে নিয়ন্ত্রণ করে। আবু দাউদ ৪৭৮২: রাগ এলে দাঁড়িয়ে থাকলে বসে পড়ুন।",
            scholarlyEn = "Ibn Rajab (Jami' al-'Ulum wal-Hikam) taught that the Prophet's command 'do not get angry' means both avoiding triggers and restraining harmful words/actions when anger rises.",
            scholarlyBn = "ইবনে রজব হাম্বলী (রহ.) বলেন, 'রাগ করো না' হাদিসের অর্থ হলো রাগের অনুভূতি এলে অন্যায় কথা বা কাজ থেকে নিজেকে বিরত রাখা।",
            ikhtilafEn = "Scholars agree anger in defense of justice must still stay bounded by prophetic mercy and never justify cruelty or breaking ties.",
            ikhtilafBn = "ন্যায়ের পক্ষে দৃঢ়তা বজায় রাখলেও ব্যক্তিগত আক্রোশ বা সীমালঙ্ঘন সব আলেমের মতে নিষিদ্ধ।",
            synthesisEn = "When provoked: stay silent, recite 'A'udhu billahi minash-shaytanir-rajim', sit down, or perform cool wudu before replying.",
            synthesisBn = "রাগ উঠলে চুপ থাকুন, 'আউযুবিল্লাহি মিনাশ-শাইতানির রাজীম' পড়ুন, বসে পড়ুন বা ঠান্ডা পানি দিয়ে অজু করুন।",
            links = listOf("https://quran.com/3/134", "https://sunnah.com/bukhari:6116")
        ),
        KnowledgeEntry(
            id = "dua_istikhara",
            keywords = listOf("dua", "supplication", "istikhara", "decision", "choice", "answer", "দুআ", "ইস্তিখারা", "সিদ্ধান্ত"),
            topicEn = "Etiquette of Dua & Salat al-Istikhara (Seeking Guidance)",
            topicBn = "দুআ কবুলের আদব ও ইস্তিখারা",
            quranEn = "Surah Al-Baqarah 2:186 — 'And when My servants ask you concerning Me — indeed I am near. I respond to the invocation of the supplicant when he calls upon Me.' Surah Ghafir 40:60 — 'Call upon Me; I will respond to you.'",
            quranBn = "সূরা বাকারা ২:১৮৬ — 'যখন আমার বান্দারা আমার সম্পর্কে জিজ্ঞাসা করে, নিশ্চয় আমি নিকটে। আহ্বানকারী যখন আমাকে ডাকে আমি তার ডাকে সাড়া দিই।'",
            hadithEn = "Sahih al-Bukhari 1162 (Grade: Sahih): Taught Salat al-Istikhara—two non-obligatory rak'ahs followed by asking Allah to grant or turn away a decision based on what is best. Jami' at-Tirmidhi 3476: Begin Dua by praising Allah and sending Salawat on the Prophet (ﷺ).",
            hadithBn = "সহীহ বুখারী ১১৬২ (মান: সহীহ): যেকোনো গুরুত্বপূর্ণ সিদ্ধান্তে ২ রাকাত নফল নামাজ পড়ে ইস্তিখারার দুআ পড়তে শেখানো হয়েছে।",
            scholarlyEn = "Imam al-Nawawi explained Istikhara is NOT waiting for a magical dream—rather, you consult wise people (istisharah), pray Istikhara, and move forward with whichever lawful path eases and brings clarity.",
            scholarlyBn = "ইমাম নববী (রহ.) স্পষ্ট করেছেন যে ইস্তিখারা মানেই স্বপ্ন দেখা বাধ্যতামূলক নয়; বরং পরামর্শ ও ইস্তিখারার পর যেদিকে মন প্রশান্ত হয় ও পরিস্থিতি সহজ হয় সেটি গ্রহণ করা।",
            ikhtilafEn = "Scholars note Istikhara is performed for permissible (mubah) life decisions—never to decide whether to perform an obligatory duty or commit a sin.",
            ikhtilafBn = "ইস্তিখারা কেবল বৈধ বিষয়ে সিদ্ধান্ত নেওয়ার জন্য; ফরজ কাজ করা বা হারাম বর্জনের ক্ষেত্রে ইস্তিখারা নয়।",
            synthesisEn = "Start Dua with 'Alhamdulillah' and Salawat, ask with certainty during Sujood or the last third of night, and combine Istikhara with practical consultation.",
            synthesisBn = "আল্লাহর প্রশংসা ও দরূদ শরীফ দিয়ে দুআ শুরু করুন, সিজদায় বা রাতের শেষ ভাগে মন খুলে চান এবং অভিজ্ঞদের পরামর্শ নিন।",
            links = listOf("https://quran.com/2/186", "https://sunnah.com/bukhari:1162")
        ),
        KnowledgeEntry(
            id = "parents_family",
            keywords = listOf("parents", "mother", "father", "mom", "dad", "family", "marriage", "wife", "husband", "children", "kids", "মা", "বাবা", "পিতা", "মাতা", "পরিবার", "বিবাহ", "স্বামী", "স্ত্রী"),
            topicEn = "Honoring Parents, Family Kindness & Household Mercy",
            topicBn = "পিতা-মাতার সম্মান ও পারিবারিক সম্প্রীতি",
            quranEn = "Surah Al-Isra 17:23–24 — '...and to parents good treatment... say not to them [so much as] uff, and do not repel them but speak to them a noble word.' Surah Ar-Rum 30:21 highlights tranquility, affection, and mercy in marriage.",
            quranBn = "সূরা বনি ইসরাঈল ১৭:২৩-২৪ — 'পিতা-মাতার সাথে সদ্ব্যবহার করো... তাদেরকে উফ্ পর্যন্ত বলো না এবং তাদের সাথে সম্মানজনক কথা বলো।' সূরা রূম ৩০:২১: দাম্পত্য জীবনে প্রশান্তি, ভালোবাসা ও দয়া।",
            hadithEn = "Sahih al-Bukhari 5971 (Grade: Sahih): 'Your mother, your mother, your mother, then your father' deserve highest companionship. Jami' at-Tirmidhi 3895 (Sahih): 'The best of you are those best to their families.'",
            hadithBn = "সহীহ বুখারী ৫৯৭১ (মান: সহীহ): সদ্ব্যবহারের ক্ষেত্রে মা তিনবার অগ্রাধিকার পান, এরপর বাবা। তিরমিযী ৩৮৯৫: 'তোমাদের মধ্যে সর্বোত্তম সেই ব্যক্তি, যে তার পরিবারের কাছে উত্তম।'",
            scholarlyEn = "Islamic jurisprudence considers dutifulness to parents (birr al-walidayn) and keeping kinship ties (silatur-rahim) major causes of blessing in life and provision.",
            scholarlyBn = "ইসলামিক শিক্ষায় মাতা-পিতার সেবা ও আত্মীয়তার সম্পর্ক বজায় রাখাকে জীবন ও রিজিকে বরকতের অন্যতম মাধ্যম বলা হয়েছে।",
            ikhtilafEn = "Jurists explain that obedience to parents ceases only if they command something sinful—even then, respectful kindness and gentle speech remain mandatory (Quran 31:15).",
            ikhtilafBn = "কোনো অন্যায় কাজের নির্দেশ না দিলে পিতা-মাতার আনুগত্য জরুরি; আর মতভিন্নতা থাকলেও ভদ্র ও সম্মানজনক আচরণ অপরিহার্য (সূরা লুকমান ৩১:১৫)।",
            synthesisEn = "Check on your parents or family gently today, speak softly even under stress, and make the Quranic Dua 17:24 for them.",
            synthesisBn = "আজই পিতা-মাতার খোঁজ নিন, ব্যস্ততার মাঝেও নম্রভাবে কথা বলুন এবং তাদের জন্য সূরা বনি ইসরাঈলের ১৭:২৪ দুআটি পাঠ করুন।",
            links = listOf("https://quran.com/17/23-24", "https://sunnah.com/bukhari:5971")
        ),
        KnowledgeEntry(
            id = "quran_recitation",
            keywords = listOf("quran", "tajweed", "read", "recite", "memorize", "hifz", "surah", "ayah", "কুরআন", "তিলাওয়াত", "তাজউইদ", "সূরা", "আয়াত"),
            topicEn = "Reading, Memorizing & Reflecting on the Quran",
            topicBn = "কুরআন তিলাওয়াত, মুখস্থ ও অনুধাবন",
            quranEn = "Surah Sad 38:29 — '[This is] a blessed Book which We have revealed to you, that they might reflect upon its verses.' Surah Al-Muzzammil 73:4 — 'And recite the Qur'an with measured recitation (tartil).'",
            quranBn = "সূরা সোয়াদ ৩৮:২৯ — 'এটি এক বরকতময় কিতাব... যাতে মানুষ এর আয়াতসমূহ নিয়ে গভীরভাবে চিন্তা করে।' সূরা মুযযাম্মিল ৭৩:৪ — 'ধীরে ধীরে স্পষ্টভাবে কুরআন তিলাওয়াত করুন।'",
            hadithEn = "Sahih al-Bukhari 5027 (Grade: Sahih): 'The best among you are those who learn the Qur'an and teach it.' Sahih Muslim 798: One who struggles yet perseveres in reciting receives a double reward.",
            hadithBn = "সহীহ বুখারী ৫০২৭ (মান: সহীহ): 'তোমাদের মধ্যে সর্বোত্তম সেই ব্যক্তি, যে কুরআন শেখে ও শেখায়।' সহীহ মুসলিম ৭৯৮: কষ্ট করে পড়লে দ্বিগুণ সওয়াব।",
            scholarlyEn = "Imam al-Ghazali emphasized pairing clear pronunciation (tajweed) with pondering meaning (tadabbur) and acting upon a verse daily.",
            scholarlyBn = "ইমাম গাজ্জালী (রহ.) তিলাওয়াতের সাথে অর্থ বুঝে আমল করার (তাদাব্বুর) ওপর বিশেষ গুরুত্ব দিয়েছেন।",
            ikhtilafEn = "Early scholars noted slow, deeply reflected recitation is generally more transformative than rushing through pages without comprehension.",
            ikhtilafBn = "অর্থ না বুঝে দ্রুত খতম করার চেয়ে ধীরে বুঝে তিলাওয়াত করাকে অধিকাংশ সালাফ বেশি প্রভাবশালী বলেছেন।",
            synthesisEn = "Open the Quran tab in RuhZena for even 5–10 ayahs daily with human reciter audio and translation.",
            synthesisBn = "রূহযেনার কুরআন সেকশনে প্রতিদিন ক্বারীর তিলাওয়াত শুনে অর্থসহ অন্তত ৫-১০টি আয়াত পাঠ করুন।",
            links = listOf("https://quran.com/38/29", "https://sunnah.com/bukhari:5027")
        ),
        KnowledgeEntry(
            id = "patience_discipline",
            keywords = listOf("patience", "patient", "sabr", "habit", "habits", "discipline", "consistency", "addiction", "screen", "procrastinat", "lazy", "ধৈর্য", "সবর", "অভ্যাস", "শৃঙ্খলা", "অলসতা"),
            topicEn = "Sabr (Patience), Consistency & Overcoming Bad Habits",
            topicBn = "সবর, শৃঙ্খলা ও খারাপ অভ্যাস ত্যাগ",
            quranEn = "Surah Al-Baqarah 2:153 — 'Seek help through patience and prayer. Indeed, Allah is with the patient.' Surah Ash-Shams 91:9 — 'He has succeeded who purifies it [the soul].'",
            quranBn = "সূরা আল-বাকারা ২:১৫৩ — 'ধৈর্য ও নামাজের মাধ্যমে সাহায্য প্রার্থনা করো। নিশ্চয় আল্লাহ ধৈর্যশীলদের সাথে আছেন।'",
            hadithEn = "Sahih al-Bukhari 6464 (Grade: Sahih): 'The deeds most beloved to Allah are those done regularly, even if small.' Sahih al-Bukhari 6470: Whoever seeks self-restraint, Allah grants them restraint.",
            hadithBn = "সহীহ বুখারী ৬৪৬৪ (মান: সহীহ): 'আল্লাহর কাছে সবচেয়ে প্রিয় আমল হলো যা নিয়মিত করা হয়, যদিও তা অল্প হয়।'",
            scholarlyEn = "Ibn al-Qayyim categorized patience into patience in obedience, patience in avoiding harm/sin, and patience in hardship—noting that structuring daily environment beats willpower alone.",
            scholarlyBn = "ইবনুল কাইয়্যিম (রহ.) সবরকে তিন ভাগে ভাগ করেছেন এবং খারাপ অভ্যাস ছাড়তে পরিবেশ ও রুটিন পরিবর্তনের পরামর্শ দিয়েছেন।",
            ikhtilafEn = "Scholars discuss gratitude vs patience as twin stations, concluding neither matures without the other.",
            ikhtilafBn = "শোকর ও সবর উভয়ই মুমিনের অপরিহার্য গুণ হিসেবে সর্বজনস্বীকৃত।",
            synthesisEn = "Set tiny realistic daily minimums in the Discipline tab, remove triggers (like late-night phone scrolling), and bounce back calmly if you slip.",
            synthesisBn = "শৃঙ্খলা ট্যাবে ছোট ও বাস্তবসম্মত দৈনিক লক্ষ্য ঠিক করুন, ট্রিগার দূর করুন এবং কোনো দিন মিস হলে শান্তভাবে ফিরে আসুন।",
            links = listOf("https://quran.com/2/153", "https://sunnah.com/bukhari:6464")
        ),
        KnowledgeEntry(
            id = "gratitude_shukr",
            keywords = listOf("gratitude", "thankful", "shukr", "blessing", "content", "happy", "happiness", "কৃতজ্ঞতা", "শোকর", "সন্তুষ্টি", "সুখ"),
            topicEn = "Gratitude (Shukr) & Contentment",
            topicBn = "কৃতজ্ঞতা (শোকর) ও অল্পে তুষ্টি",
            quranEn = "Surah Ibrahim 14:7 — 'If you are grateful, I will surely increase you [in favor].' Surah Al-Baqarah 2:152 — 'So remember Me; I will remember you. And be grateful to Me and do not deny Me.'",
            quranBn = "সূরা ইব্রাহিম ১৪:৭ — 'যদি তোমরা কৃতজ্ঞতা প্রকাশ করো, আমি অবশ্যই তোমাদের নিয়ামত বাড়িয়ে দেবো।'",
            hadithEn = "Sahih Muslim 2963 (Grade: Sahih): Look to those who have less materially so you do not belittle Allah's favors upon you. Sunan Abi Dawud 4811: Whoever does not thank people has not thanked Allah.",
            hadithBn = "সহীহ মুসলিম ২৯৬৩ (মান: সহীহ): পার্থিব বিষয়ে নিজের চেয়ে নিচের অবস্থানের মানুষের দিকে তাকাও, তাহলে আল্লাহর নিয়ামত তুচ্ছ মনে হবে না।",
            scholarlyEn = "Scholars define complete Shukr as recognition in the heart, praise on the tongue ('Alhamdulillah'), and using blessings in obedience rather than harm.",
            scholarlyBn = "আলেমদের মতে শোকর তিনটি বিষয় নিয়ে গঠিত: অন্তরে স্বীকৃতি, মুখে 'আলহামদুলিল্লাহ' বলা এবং নিয়ামতকে ভালো কাজে ব্যয় করা।",
            ikhtilafEn = "Classical works examine whether wealth with gratitude or simplicity with patience tests a person more deeply; the standard depends on each person's integrity.",
            ikhtilafBn = "সচ্ছল অবস্থায় শোকর নাকি অভাবের সময় সবর বেশি পরীক্ষামূলক—এ বিষয়ে আলেমগণ ব্যক্তির নিয়ত ও আমলের ওপর গুরুত্ব দিয়েছেন।",
            synthesisEn = "Record one specific blessing and achievement in your private Journal tonight and say Alhamdulillah deliberately.",
            synthesisBn = "আজ রাতে আপনার প্রাইভেট জার্নালে অন্তত একটি নিয়ামত ও কৃতজ্ঞতার কথা লিখে রাখুন।",
            links = listOf("https://quran.com/14/7", "https://sunnah.com/muslim:2963c")
        ),
        KnowledgeEntry(
            id = "health_amanah",
            keywords = listOf("health", "body", "fitness", "sleep", "food", "water", "workout", "exercise", "diet", "স্বাস্থ্য", "ব্যায়াম", "ঘুম", "খাবার", "পানি"),
            topicEn = "Physical Health, Hydration & Rest as an Amanah",
            topicBn = "শারীরিক সুস্থতা, পরিমিত খাবার ও ঘুমের ইসলামিক গুরুত্ব",
            quranEn = "Surah Al-A'raf 7:31 — 'Eat and drink, but be not excessive.' Surah Al-Furqan 25:47 — 'He made the night for you as clothing and sleep as rest.'",
            quranBn = "সূরা আরাফ ৭:৩১ — 'খাও এবং পান করো, কিন্তু অপচয় ও অতিরঞ্জন করো না।' সূরা ফুরকান ২৫:৪৭ — 'ঘুমকে বিশ্রামের উপায় করেছেন।'",
            hadithEn = "Sahih Muslim 2664 (Grade: Sahih): 'The strong believer is better and more beloved to Allah than the weak believer, while there is good in both.' Sahih al-Bukhari 5199: 'Indeed, your body has a right over you.'",
            hadithBn = "সহীহ মুসলিম ২৬৬৪ (মান: সহীহ): 'শক্তিশালী মুমিন দুর্বল মুমিনের চেয়ে উত্তম।' বুখারী ৫১৯৯: 'আপনার শরীরেরও আপনার ওপর অধিকার রয়েছে।'",
            scholarlyEn = "Ibn al-Qayyim's Tibb al-Nabawi emphasized balanced movement, hydration, moderate portions, and restorative early sleep.",
            scholarlyBn = "ইবনুল কাইয়্যিম (রহ.) পরিমিত আহার, নিয়মিত ব্যায়াম এবং রাতের প্রথম ভাগে ঘুমানোকে সুস্বাস্থ্যের চাবিকাঠি বলেছেন।",
            ikhtilafEn = "Scholars differentiate revealed ethical duties (moderation, avoiding harm) from historical remedies noted as experience.",
            ikhtilafBn = "আলেমগণ শরয়ী বিধান ও ঐতিহাসিক চিকিৎসা অভিজ্ঞতার মধ্যে স্পষ্ট পার্থক্য করেন।",
            synthesisEn = "Pair RuhZena's Guided Workouts, Hydration ring, and Sleep log to steward your body responsibly.",
            synthesisBn = "রূহযেনার ওয়ার্কআউট, পানি পান ও ঘুমের রুটিন ব্যবহার করে শরীরের আমানত রক্ষা করুন।",
            links = listOf("https://quran.com/7/31", "https://sunnah.com/muslim:2664")
        ),
        KnowledgeEntry(
            id = "rizq_work_honesty",
            keywords = listOf("work", "job", "business", "money", "rizq", "halal", "riba", "interest", "honest", "career", "income", "রিজিক", "কাজ", "চাকরি", "হালাল", "ব্যবসা", "সুদ"),
            topicEn = "Halal Provision (Rizq), Integrity & Work Ethic",
            topicBn = "হালাল রিজিক, সততা ও কর্মনিষ্ঠা",
            quranEn = "Surah Al-Mulk 67:15 — 'Walk among its slopes and eat of His provision.' Surah Al-Baqarah 2:275 distinguishes lawful trade from forbidden interest (riba).",
            quranBn = "সূরা মুলক ৬৭:১৫ — 'পৃথিবীর বুকে বিচরণ করো এবং তাঁর দেওয়া রিজিক থেকে আহার করো।' সূরা বাকারা ২:২৭৫: আল্লাহ ব্যবসাকে হালাল ও সুদকে হারাম করেছেন।",
            hadithEn = "Sahih al-Bukhari 2072 (Grade: Sahih): 'No one ever eats better food than that earned by the work of their own hands.' Sahih Muslim 1015: 'Allah is Pure and accepts only what is pure.'",
            hadithBn = "সহীহ বুখারী ২০৭২ (মান: সহীহ): 'নিজ হাতে উপার্জিত খাদ্যের চেয়ে উত্তম খাদ্য কেউ গ্রহণ করেনি।' সহীহ মুসলিম ১০১৫: আল্লাহ পবিত্র এবং পবিত্র (হালাল) ছাড়া গ্রহণ করেন না।",
            scholarlyEn = "Islamic commercial ethics demand truthfulness, clear contracts, prompt payment of wages, and avoidance of fraud or interest.",
            scholarlyBn = "ইসলামিক অর্থনীতিতে সত্যবাদিতা, স্বচ্ছ চুক্তি এবং প্রতারণা ও সুদ বর্জন অপরিহার্য।",
            ikhtilafEn = "Contemporary scholars debate specific modern financial structures and contracts while unanimously prohibiting clear interest and deception.",
            ikhtilafBn = "সুদ ও প্রতারণা হারাম হওয়ার বিষয়ে সকল আলেম একমত, যদিও আধুনিক কিছু লেনদেনের খুঁটিনাটি বিষয়ে সমকালীন ফকিহদের গবেষণা চলমান।",
            synthesisEn = "Seek excellence (ihsan) in your daily study or profession while ensuring transparent, lawful earnings and making Dua for rizqan tayyiban.",
            synthesisBn = "আপনার পেশা বা পড়াশোনায় সর্বোচ্চ নিষ্ঠা বজায় রাখুন, হালাল উপার্জন নিশ্চিত করুন এবং উপকারী রিজিকের দুআ পড়ুন।",
            links = listOf("https://quran.com/67/15", "https://sunnah.com/bukhari:2072")
        ),
        KnowledgeEntry(
            id = "jumuah_friday",
            keywords = listOf("friday", "jumuah", "jumma", "kahf", "salawat", "জুমআ", "শুক্রবার", "কাহফ", "দরুদ"),
            topicEn = "Virtues & Sunnahs of Friday (Jumu'ah)",
            topicBn = "জুমআর দিনের ফজিলত ও সুন্নাহ",
            quranEn = "Surah Al-Jumu'ah 62:9 — 'O you who have believed, when [the adhan] is called for the prayer on the day of Jumu'ah, then proceed to the remembrance of Allah and leave trade.'",
            quranBn = "সূরা জুমআ ৬২:৯ — 'হে মুমিনগণ, জুমআর দিনে যখন নামাজের জন্য আহ্বান করা হয়, তখন আল্লাহর স্মরণের দিকে ধাবিত হও এবং ক্রয়-বিক্রয় ত্যাগ করো।'",
            hadithEn = "Sahih al-Bukhari 935 (Grade: Sahih): There is an hour on Friday when a Muslim's Dua is answered. Al-Mustadrak / Sunan al-Kubra (authenticated by scholars): Reciting Surah Al-Kahf on Friday brings light between the two Fridays.",
            hadithBn = "সহীহ বুখারী ৯৩৫ (মান: সহীহ): জুমআর দিনে একটি বিশেষ মুহূর্ত আছে যখন দুআ কবুল হয়।",
            scholarlyEn = "Recommended Friday practices include ghusl, clean attire, miswak/oral hygiene, arriving early, abundant Salawat on the Prophet (ﷺ), and Surah Al-Kahf.",
            scholarlyBn = "জুমআর দিনে গোসল, পরিচ্ছন্ন পোশাক, আগে মসজিদে যাওয়া, বেশি করে দরূদ পাঠ ও সূরা কাহফ তিলাওয়াত মুস্তাহাব।",
            ikhtilafEn = "Scholars discuss whether the special hour of Dua on Friday is during the Imam's sitting/sermon or the final hour before Maghrib.",
            ikhtilafBn = "জুমআর দিনে দুআ কবুলের বিশেষ সময় খুতবার সময় নাকি আসরের পর থেকে মাগরিবের আগ পর্যন্ত—এ বিষয়ে আলেমদের দুটি প্রসিদ্ধ মত রয়েছে।",
            synthesisEn = "Prepare early for Jumu'ah, read Surah Al-Kahf, send abundant Salawat, and set aside focused minutes for Dua before Maghrib.",
            synthesisBn = "জুমআর দিনে সময়মতো মসজিদে যান, সূরা কাহফ পড়ুন এবং আসর থেকে মাগরিবের মধ্যে বেশি করে দুআ করুন।",
            links = listOf("https://quran.com/62/9", "https://sunnah.com/bukhari:935")
        ),
        KnowledgeEntry(
            id = "aqeedah_tawhid",
            keywords = listOf("allah", "tawhid", "aqeedah", "faith", "iman", "creed", "god", "তাওহীদ", "আকীদা", "ঈমান", "আল্লাহ"),
            topicEn = "Tawhid, Iman & Knowing Allah's Mercy",
            topicBn = "তাওহীদ, ঈমান ও আল্লাহর রহমত",
            quranEn = "Surah Al-Ikhlas 112:1–4 — 'Say, He is Allah, [who is] One, Allah, the Eternal Refuge.' Surah Al-A'raf 7:156 — 'My mercy encompasses all things.'",
            quranBn = "সূরা ইখলাস ১১২:১-৪ — 'বলুন, তিনি আল্লাহ, এক ও অদ্বিতীয়।' সূরা আরাফ ৭:১৫৬ — 'আমার রহমত সবকিছুকে পরিবেষ্টন করে আছে।'",
            hadithEn = "Sahih Muslim 8 (Hadith Jibril, Grade: Sahih): Defines Islam (five pillars), Iman (six articles of faith), and Ihsan (worshipping Allah with awareness that He sees you).",
            hadithBn = "সহীহ মুসলিম ৮ (হাদিসে জিবরীল, মান: সহীহ): ইসলাম, ঈমান ও ইহসানের মূল ভিত্তি বর্ণনা করা হয়েছে।",
            scholarlyEn = "Mainstream Sunni creed affirms Allah's absolute oneness in Lordship, Worship, and Names & Attributes without likening Him to creation.",
            scholarlyBn = "আহলুস সুন্নাহর আকীদা অনুযায়ী আল্লাহ রুবুবিয়্যাত, উলুহিয়্যাত ও নাম-গুণাবলিতে একক ও অতুলনীয়।",
            ikhtilafEn = "Recognized Sunni theological methodologies agree completely on Tawhid while differing slightly in semantic interpretation of certain descriptive verses.",
            ikhtilafBn = "মূল তাওহীদে আহলুস সুন্নাহর সকল ধারা একমত, কেবল কিছু আয়াতের ব্যাখ্যা পদ্ধতিতে সূক্ষ্ম পার্থক্য রয়েছে।",
            synthesisEn = "Balance hope in Allah's vast mercy with reverence, and anchor your heart daily with Morning & Evening Adhkar.",
            synthesisBn = "আল্লাহর রহমতের আশা ও ভয়ের ভারসাম্যে চলুন এবং সকাল-সন্ধ্যার যিকিরে হৃদয়কে সজীব রাখুন।",
            links = listOf("https://quran.com/112", "https://sunnah.com/muslim:8a")
        ),
        KnowledgeEntry(
            id = "speech_character",
            keywords = listOf("speech", "talk", "gossip", "backbit", "backbiting", "gheebah", "friend", "kindness", "character", "adab", "আদব", "গীবত", "চরিত্র", "কথা"),
            topicEn = "Guarding Speech, Character (Akhlaq) & Avoiding Backbiting",
            topicBn = "সুন্দর চরিত্র, জিহ্বার হেফাজত ও গীবত বর্জন",
            quranEn = "Surah Al-Hujurat 49:12 — 'And do not spy or backbite each other.' Surah Al-Qalam 68:4 — 'And indeed, you are of a great moral character.'",
            quranBn = "সূরা হুজুরাত ৪৯:১২ — 'একে অপরের গোপনীয়তা সন্ধান করো না এবং গীবত করো না।' সূরা কলম ৬৮:৪ — 'নিশ্চয় আপনি মহান চরিত্রের অধিকারী।'",
            hadithEn = "Sahih al-Bukhari 6018 (Grade: Sahih): 'Whoever believes in Allah and the Last Day should speak good or remain silent.' Sahih al-Bukhari 6035: 'The best among you are those best in character.'",
            hadithBn = "সহীহ বুখারী ৬০১৮ (মান: সহীহ): 'যে আল্লাহ ও আখিরাতে বিশ্বাস করে, সে যেন ভালো কথা বলে অথবা চুপ থাকে।'",
            scholarlyEn = "Imam al-Nawawi listed guarding the tongue from gossip, mockery, and harshness as central to preserving one's deeds.",
            scholarlyBn = "ইমাম নববী (রহ.) গীবত, কটূক্তি ও অপ্রয়োজনীয় কথা থেকে জিহ্বা রক্ষা করাকে নেক আমল রক্ষার মূল উপায় বলেছেন।",
            ikhtilafEn = "Scholars note limited exceptions where speaking about harm is allowed solely for legitimate protection, legal witness, or sincere warnings without malice.",
            ikhtilafBn = "আলেমগণ বলেন, শুধু ন্যায়বিচার, সতর্কীকরণ বা বৈধ প্রয়োজনে কারো দোষ বলা জায়েয—তাও বিদ্বেষ ছাড়া।",
            synthesisEn = "Before speaking or posting online, pause and ask: Is this truthful, kind, and beneficial?",
            synthesisBn = "কথা বলার বা অনলাইনে মন্তব্য করার আগে ভাবুন—এটি কি সত্য, কল্যাণকর এবং সুন্দর?",
            links = listOf("https://quran.com/49/12", "https://sunnah.com/bukhari:6018")
        ),
        KnowledgeEntry(
            id = "knowledge_growth",
            keywords = listOf("knowledge", "learn", "study", "wisdom", "ilm", "growth", "purpose", "life", "জ্ঞান", "শিক্ষা", "পড়াশোনা", "উদ্দেশ্য"),
            topicEn = "Seeking Beneficial Knowledge & Personal Growth",
            topicBn = "উপকারী জ্ঞান অর্জন ও আত্মউন্নয়ন",
            quranEn = "Surah Ta-Ha 20:114 — 'My Lord, increase me in knowledge.' Surah Al-Mujadila 58:11 — 'Allah will raise those who have believed among you and those who were given knowledge, by degrees.'",
            quranBn = "সূরা ত্বহা ২০:১১৪ — 'হে আমার রব, আমার জ্ঞান বৃদ্ধি করে দিন।' সূরা মুজাদালা ৫৮:১১ — 'আল্লাহ ঈমানদার ও জ্ঞানীদের মর্যাদা বহুগুণে উন্নীত করেন।'",
            hadithEn = "Sahih Muslim 2699 (Grade: Sahih): 'Whoever follows a path in pursuit of knowledge, Allah makes easy for them a path to Paradise.' Sunan Ibn Majah 925: Ask Allah daily for 'ilman nafi'an (beneficial knowledge).",
            hadithBn = "সহীহ মুসলিম ২৬৯৯ (মান: সহীহ): 'যে ব্যক্তি জ্ঞান অন্বেষণের পথে চলে, আল্লাহ তার জন্য জান্নাতের পথ সহজ করে দেন।'",
            scholarlyEn = "Islamic tradition unites sacred knowledge with beneficial worldly science, craftsmanship, and self-reflection—requiring humility and putting learning into practice.",
            scholarlyBn = "ইসলামিক ঐতিহ্যে দ্বীনি ও উপকারী দুনিয়াবি জ্ঞান—উভয়কেই বিনয় ও আমলের সাথে অর্জনের তাগিদ দেওয়া হয়েছে।",
            ikhtilafEn = "Scholars classify essential religious obligations (fard 'ayn) as mandatory for every individual, while specialized fields are communal duties (fard kifayah).",
            ikhtilafBn = "প্রত্যেক মুসলিমের জন্য আবশ্যিক জ্ঞান (ফরজে আইন) ও সমাজের সম্মিলিত প্রয়োজনের জ্ঞান (ফরজে কিফায়া)—উভয়ের গুরুত্বই আলেমগণ বর্ণনা করেছেন।",
            synthesisEn = "Start mornings with the Prophetic Dua for beneficial knowledge (Ibn Majah 925) and dedicate 15 focused minutes daily to intentional learning.",
            synthesisBn = "সকালে 'আল্লাহুম্মা ইন্নী আসআলুকা ইলমান নাফি'আন' দুআটি পাঠ করুন এবং প্রতিদিন অন্তত ১৫ মিনিট মনোযোগ দিয়ে কিছু শিখুন।",
            links = listOf("https://quran.com/20/114", "https://sunnah.com/muslim:2699a")
        ),
        KnowledgeEntry(
            id = "hajj_umrah",
            keywords = listOf("hajj", "umrah", "kaaba", "makkah", "tawaf", "pilgrimage", "madinah", "হজ", "উমরাহ", "কাবা", "মক্কা", "তাওয়াফ"),
            topicEn = "Hajj, Umrah & Spiritual Journey to Makkah",
            topicBn = "হজ, উমরাহ ও বাইতুল্লাহর আধ্যাত্মিক শিক্ষা",
            quranEn = "Surah Ali 'Imran 3:97 — 'And [due] to Allah from the people is a pilgrimage to the House — for whoever is able to find thereto a way.'",
            quranBn = "সূরা আলে ইমরান ৩:৯৭ — 'মানুষের মধ্যে যার সামর্থ্য আছে, তার ওপর আল্লাহর উদ্দেশ্যে বাইতুল্লাহর হজ করা ফরজ।'",
            hadithEn = "Sahih al-Bukhari 1521 (Grade: Sahih): 'Whoever performs Hajj for Allah and avoids obscenity and transgression returns pure like the day their mother bore them.' Sahih al-Bukhari 1773: Umrah to Umrah expiates sins between them.",
            hadithBn = "সহীহ বুখারী ১৫২১ (মান: সহীহ): 'যে ব্যক্তি নিষ্ঠার সাথে হজ করে এবং অশ্লীলতা ও পাপাচার থেকে বিরত থাকে, সে নবজাতক শিশুর মতো নিষ্পাপ হয়ে ফিরে আসে।'",
            scholarlyEn = "Hajj is obligatory once in a lifetime for financially and physically capable adults (istita'ah), symbolizing unity, equality in Ihram, and devotion.",
            scholarlyBn = "সামর্থ্যবান প্রাপ্তবয়স্ক মুসলিমের ওপর জীবনে একবার হজ ফরজ, যা মানবসমতার ও তাওহীদের প্রতীক।",
            ikhtilafEn = "Schools discuss the timing and types of Ihram (Tamattu', Qiran, Ifrad) and whether Umrah once in a lifetime is Fard (Shafi'i/Hanbali) or emphasized Sunnah (Hanafi/Maliki).",
            ikhtilafBn = "উমরাহ একবার করা ফরজ নাকি সুন্নাতে মুয়াক্কাদাহ এবং তামাত্তু/কিরান/ইফরাদ হজের সূক্ষ্ম বিধান নিয়ে মাযহাবগুলোতে আলোচনা রয়েছে।",
            synthesisEn = "Prepare intention, lawful wealth, and study the rites before travel; even from home, cherish Qibla orientation and make sincere Dua for an invited journey.",
            synthesisBn = "সফরের আগে হালাল অর্থ, নিয়ত ও হজের নিয়ম জেনে নিন এবং অন্তরে বাইতুল্লাহ জিয়ারতের আগ্রহ রাখুন।",
            links = listOf("https://quran.com/3/97", "https://sunnah.com/bukhari:1521")
        ),
        KnowledgeEntry(
            id = "seerah_prophet",
            keywords = listOf("prophet", "muhammad", "rasul", "sunnah", "seerah", "mercy", "messenger", "নবী", "রাসূল", "মুহাম্মদ", "সীরাত", "সুন্নাহ"),
            topicEn = "Following the Prophet Muhammad (ﷺ) & His Mercy",
            topicBn = "মহানবী হযরত মুহাম্মদ (ﷺ)-এর সীরাত ও আদর্শ",
            quranEn = "Surah Al-Anbiya 21:107 — 'And We have not sent you, [O Muhammad], except as a mercy to the worlds.' Surah Al-Ahzab 33:21 — 'There has certainly been for you in the Messenger of Allah an excellent pattern.'",
            quranBn = "সূরা আম্বিয়া ২১:১০৭ — 'আমি আপনাকে সমগ্র বিশ্বজগতের জন্য রহমতস্বরূপই প্রেরণ করেছি।' সূরা আহযাব ৩৩:২১ — 'আল্লাহর রাসূলের মধ্যে তোমাদের জন্য রয়েছে সর্বোত্তম আদর্শ।'",
            hadithEn = "Sahih al-Bukhari 7280 (Grade: Sahih): 'All of my Ummah will enter Paradise except those who refuse... Whoever obeys me enters Paradise.' Sahih Muslim 2328: He was gentle, smiling, and never took revenge for himself.",
            hadithBn = "সহীহ বুখারী ৭২৮০ (মান: সহীহ): 'যে আমার আনুগত্য করবে সে জান্নাতে প্রবেশ করবে।' সহীহ মুসলিম ২৩২৮: তিনি ছিলেন অত্যন্ত কোমল ও ক্ষমাশীল।",
            scholarlyEn = "Loving the Prophet (ﷺ) manifests through sending Salawat, learning his authentic Sunnah, practicing gentle character, and serving family and neighbors.",
            scholarlyBn = "নবীজী (ﷺ)-এর ভালোবাসার প্রকৃত প্রকাশ হলো দরূদ পাঠ, সহীহ সুন্নাহ অনুসরণ এবং মানুষের প্রতি দয়াশীল আচরণ।",
            ikhtilafEn = "Scholars clearly distinguish binding legislative Sunnah (acts of worship) from customary habits (local clothing/food preferences).",
            ikhtilafBn = "আলেমগণ ইবাদতসংক্রান্ত সুন্নাহ এবং ব্যক্তিগত/আঞ্চলিক অভ্যাসের মধ্যে স্পষ্ট পার্থক্য নির্ণয় করেছেন।",
            synthesisEn = "Revive one gentle Sunnah today: greet others with warm Salam, smile kindly, eat in moderation, and send 10 Salawat.",
            synthesisBn = "আজই একটি সুন্দর সুন্নাহ পালন করুন: আগে সালাম দিন, হাসিমুখে কথা বলুন এবং ১০ বার দরূদ শরীফ পাঠ করুন।",
            links = listOf("https://quran.com/21/107", "https://sunnah.com/bukhari:7280")
        ),
        KnowledgeEntry(
            id = "envy_pride_heart",
            keywords = listOf("envy", "jealous", "jealousy", "hasad", "pride", "arrogance", "ego", "kibr", "humble", "humility", "tazkiyah", "হিংসা", "অহংকার", "নম্রতা", "অন্তর"),
            topicEn = "Curing Envy (Hasad), Pride & Purifying the Heart",
            topicBn = "হিংসা, অহংকার বর্জন ও আত্মশুদ্ধি (তাযকিয়াহ)",
            quranEn = "Surah An-Nisa 4:54 warns against envying others for what Allah gave them of His bounty. Surah Luqman 31:18 — 'Indeed, Allah does not like everyone self-deluded and boastful.'",
            quranBn = "সূরা নিসা ৪:৫৪: আল্লাহ অনুগ্রহ করে মানুষকে যা দিয়েছেন সে বিষয়ে হিংসা করতে নিষেধ করা হয়েছে। সূরা লুকমান ৩১:১৮: আল্লাহ কোনো অহংকারী দাম্ভিককে পছন্দ করেন না।",
            hadithEn = "Sahih Muslim 91 (Grade: Sahih): 'No one with an atom's weight of arrogance (kibr) in their heart will enter Paradise'—meaning rejecting truth and looking down on people. Sahih al-Bukhari 6065: 'Do not envy one another, do not hate one another.'",
            hadithBn = "সহীহ মুসলিম ৯১ (মান: সহীহ): 'যার অন্তরে অণু পরিমাণ অহংকার (সত্য অস্বীকার ও মানুষকে তুচ্ছ করা) থাকবে সে জান্নাতে প্রবেশ করবে না।'",
            scholarlyEn = "Imam al-Ghazali taught the antidote to envy is actively praying for the other person's blessing (BarakAllahu lahu) and serving others humbly.",
            scholarlyBn = "ইমাম গাজ্জালী (রহ.) বলেছেন, হিংসার চিকিৎসা হলো যার প্রতি হিংসা আসে তার কল্যাণ ও বরকতের জন্য দুআ করা।",
            ikhtilafEn = "Scholars distinguish destructive Hasad (wishing another loses a blessing) from praiseworthy Ghibtah (wishing Allah grants you a similar good deed, such as Quran mastery or charity).",
            ikhtilafBn = "অন্যের ক্ষতি চাওয়া (হাসাদ) হারাম; তবে ভালো কাজে অন্যের মতো যোগ্যতা কামনা করা (গিবতা) প্রশংসনীয়।",
            synthesisEn = "Whenever you notice comparison or jealousy rising, say 'MashaAllah, Allahumma barik lahum' and practice humility by initiating greeting first.",
            synthesisBn = "কারও উন্নতি দেখে মনে অস্বস্তি হলে সাথে সাথে বলুন 'মাশাআল্লাহ, আল্লাহুম্মা বারিক লাহুম' এবং বিনয়ের সাথে আগে সালাম দিন।",
            links = listOf("https://quran.com/31/18", "https://sunnah.com/muslim:91a")
        ),
        KnowledgeEntry(
            id = "ruqyah_protection",
            keywords = listOf("evil eye", "nazar", "magic", "sihr", "jinn", "ruqyah", "protect", "protection", "nightmare", "বদ-নজর", "জাদু", "জিন", "রুকইয়াহ", "আশ্রয়"),
            topicEn = "Authentic Ruqyah & Spiritual Protection",
            topicBn = "কুরআন-সুন্নাহ সম্মত রুকইয়াহ ও নিরাপত্তা",
            quranEn = "Surah Al-Falaq (113) & Surah An-Nas (114) — The Mu'awwidhat revealed specifically for seeking Allah's shelter against visible and unseen harm, envy, and whispers.",
            quranBn = "সূরা ফালাক (১১৩) ও সূরা নাস (১১৪) — দৃশ্য-অদৃশ্য ক্ষতি, হিংসা ও কুমন্ত্রণা থেকে আল্লাহর আশ্রয় লাভের জন্য নাযিলকৃত।",
            hadithEn = "Sahih al-Bukhari 5017 (Grade: Sahih): The Prophet (ﷺ) recited Surahs Al-Ikhlas, Al-Falaq, and An-Nas three times every night before sleeping and wiped over his body. Sahih al-Bukhari 2311: Reciting Ayat al-Kursi (2:255) before bed guards the believer all night.",
            hadithBn = "সহীহ বুখারী ৫০১৭ (মান: সহীহ): নবীজী (ﷺ) প্রতি রাতে সূরা ইখলাস, ফালাক ও নাস ৩ বার পড়ে শরীরে ফুঁ দিতেন। বুখারী ২৩১১: আয়াতুল কুরসি রাতভর নিরাপত্তা দেয়।",
            scholarlyEn = "Authentic Ruqyah relies strictly on Quranic verses, Prophetic supplications in understood Arabic/language, and firm reliance on Allah—rejecting amulets with shirk, sorcery, or superstition.",
            scholarlyBn = "সহীহ রুকইয়াহ কেবল কুরআনের আয়াত, সুন্নাহর দুআ ও আল্লাহর ওপর তাওয়াক্কুলের মাধ্যমে করতে হয়; তাবিজ-কবজ বা শিরকি পদ্ধতি সম্পূর্ণ নিষিদ্ধ।",
            ikhtilafEn = "Scholars unanimously forbid fortune-tellers and harmful magic; lawful self-Ruqyah is strongly preferred for every believer to recite themselves.",
            ikhtilafBn = "গণক বা জাদুকরের কাছে যাওয়া সর্বসম্মতভাবে হারাম; নিজের ওপর নিজে রুকইয়াহ করাই সুন্নাহসম্মত ও উত্তম।",
            synthesisEn = "Recite Ayat al-Kursi and the 3 Quls morning, evening, and before sleep, and stay consistent with daily Salah.",
            synthesisBn = "সকাল-সন্ধ্যায় ও ঘুমানোর আগে আয়াতুল কুরসি ও ৩ কুল নিয়মিত পাঠ করুন।",
            links = listOf("https://quran.com/113", "https://sunnah.com/bukhari:5017")
        ),
        KnowledgeEntry(
            id = "death_hereafter_grief",
            keywords = listOf("death", "die", "grave", "janazah", "hereafter", "akhirah", "jannah", "paradise", "hell", "loss", "grief", "bereavement", "মৃত্যু", "কবর", "জানাযা", "আখিরাত", "জান্নাত", "শোক"),
            topicEn = "Remembering Akhirah, Jannah & Comfort in Grief",
            topicBn = "আখিরাত, জান্নাত ও প্রিয়জন হারানোর শোকে সান্ত্বনা",
            quranEn = "Surah Al-Baqarah 2:156 — 'Indeed we belong to Allah, and indeed to Him we will return.' Surah Al-Mulk 67:2 — 'He who created death and life to test which of you is best in deed.'",
            quranBn = "সূরা বাকারা ২:১৫৬ — 'নিশ্চয় আমরা আল্লাহরই জন্য এবং নিশ্চয় তাঁরই দিকে প্রত্যাবর্তনকারী।' সূরা মুলক ৬৭:২: তিনি মৃত্যু ও জীবন সৃষ্টি করেছেন আমলের পরীক্ষার জন্য।",
            hadithEn = "Sahih Muslim 918 (Grade: Sahih): Saying 'Inna lillahi wa inna ilayhi raji'un, Allahumma'jurni fi musibati...' during loss earns Allah's replacement with something better. Sahih Muslim 1631: Ongoing charity, beneficial knowledge, and righteous children praying benefit the deceased continuously.",
            hadithBn = "সহীহ মুসলিম ৯১৮ (মান: সহীহ): বিপদে 'ইন্না লিল্লাহি ওয়া ইন্না ইলাইহি রাজিউন' ও দুআ পাঠ করলে আল্লাহ উত্তম প্রতিদান দেন। মুসলিম ১৬৩১: সদকায়ে জারিয়া ও সন্তানের দুআ মৃত ব্যক্তির উপকারে আসে।",
            scholarlyEn = "Crying with tenderness out of grief is natural and prophetic (Sahih al-Bukhari 1303), while wailing or despairing of Allah's wisdom is avoided.",
            scholarlyBn = "শোকে নীরবে অশ্রু ফেলা নবীজীর সুন্নাহ (বুখারী ১৩০৩), তবে বিলাপ বা আল্লাহর সিদ্ধান্তের প্রতি অসন্তুষ্টি নিষিদ্ধ।",
            ikhtilafEn = "All schools encourage making Dua for deceased Muslims, giving Sadaqah on their behalf, and settling their unpaid debts promptly.",
            ikhtilafBn = "মৃত ব্যক্তির জন্য মাগফিরাতের দুআ, তার নামে সদকা ও ঋণ পরিশোধ করা সব আলেমের মতে অত্যন্ত উত্তম ও উপকারী।",
            synthesisEn = "Send regular Dua ('Rabbighfir li wa liwalidayya') and give even small quiet charity on behalf of departed loved ones.",
            synthesisBn = "মৃত আত্মীয়-স্বজন ও পিতা-মাতার জন্য প্রতিদিন ক্ষমার দুআ করুন এবং সামান্য হলেও তাদের নামে সদকা দিন।",
            links = listOf("https://quran.com/2/156", "https://sunnah.com/muslim:1631")
        ),
        KnowledgeEntry(
            id = "modesty_haya_gaze",
            keywords = listOf("modesty", "haya", "hijab", "gaze", "lust", "temptation", "social media", "phone", "eyes", "পর্দা", "হিজাব", "হায়া", "দৃষ্টি", "লজ্জা"),
            topicEn = "Modesty (Haya), Guarding the Gaze & Digital Chastity",
            topicBn = "শালীনতা (হায়া), দৃষ্টি সংযম ও ডিজিটাল পবিত্রতা",
            quranEn = "Surah An-Nur 24:30–31 — 'Tell the believing men to lower their gaze and guard their modesty... And tell the believing women to lower their gaze and guard their modesty.'",
            quranBn = "সূরা নূর ২৪:৩০-৩১ — 'মুমিন পুরুষ ও নারীদের বলুন, তারা যেন তাদের দৃষ্টি সংযত রাখে এবং লজ্জাস্থানের হেফাজত করে।'",
            hadithEn = "Sahih al-Bukhari 6118 (Grade: Sahih): 'Haya (modesty/moral restraint) does not bring anything except good.' Sahih Muslim 2159: Turning away from an unintended glance earns sweetness of faith in the heart.",
            hadithBn = "সহীহ বুখারী ৬১১৮ (মান: সহীহ): 'লজ্জাশীলতা (হায়া) কেবল কল্যাণই বয়ে আনে।' মুসলিম ২১৫৯: প্রথম অনিচ্ছাকৃত দৃষ্টি সরিয়ে নেওয়া সুন্নাহ।",
            scholarlyEn = "Contemporary scholars emphasize guarding one's digital gaze—avoiding harmful feeds, algorithms, and late-night solitude on screens.",
            scholarlyBn = "সমকালীন আলেমগণ স্মার্টফোন ও সোশ্যাল মিডিয়াতেও চোখের হেফাজত বজায় রাখাকে অন্তরের প্রশান্তির জন্য জরুরি বলেছেন।",
            ikhtilafEn = "Jurists discuss specific outer dress details (e.g., whether face covering is recommended vs obligatory) while unanimously agreeing on dignity, modesty, and lowering the gaze for both men and women.",
            ikhtilafBn = "পর্দার পূর্ণাঙ্গ কাঠামোতে কিছু ফিকহি মতভেদ থাকলেও নারী-পুরুষ উভয়ের শালীনতা ও দৃষ্টি সংযমের ওপর সব আলেম একমত।",
            synthesisEn = "Unfollow triggering accounts, enable screen downtime before sleep, and replace idle scrolling with Quran, exercise, or Dhikr.",
            synthesisBn = "ক্ষতিকর কনটেন্ট আনফলো করুন, রাতে স্ক্রিন টাইম সীমিত করুন এবং অবসর সময় যিকির বা ভালো কাজে লাগান।",
            links = listOf("https://quran.com/24/30", "https://sunnah.com/bukhari:6118")
        ),
        KnowledgeEntry(
            id = "neighbors_brotherhood",
            keywords = listOf("neighbor", "neighbour", "community", "brotherhood", "sisterhood", "mercy", "help", "kind", "প্রতিবেশী", "সমাজ", "ভ্রাতৃত্ব", "সাহায্য"),
            topicEn = "Rights of Neighbors, Brotherhood & Community Service",
            topicBn = "প্রতিবেশীর হক, ভ্রাতৃত্ব ও সমাজসেবা",
            quranEn = "Surah An-Nisa 4:36 — '...do good to parents, relatives, orphans, the needy, the near neighbor, the neighbor farther away, and the companion at your side.'",
            quranBn = "সূরা নিসা ৪:৩৬ — '...পিতা-মাতা, আত্মীয়, এতিম, অভাবগ্রস্ত, নিকট প্রতিবেশী ও দূর প্রতিবেশীর সাথে সদ্ব্যবহার করো।'",
            hadithEn = "Sahih al-Bukhari 6014 (Grade: Sahih): 'Whoever believes in Allah and the Last Day should honor their neighbor.' Sahih Muslim 45: None truly believes until loving for their neighbor what they love for themselves.",
            hadithBn = "সহীহ বুখারী ৬০১৪ (মান: সহীহ): 'যে আল্লাহ ও আখিরাতে বিশ্বাস করে, সে যেন তার প্রতিবেশীকে সম্মান করে।' মুসলিম ৪৫: নিজের জন্য যা পছন্দ করো প্রতিবেশীর জন্যও তা পছন্দ করো।",
            scholarlyEn = "The rights of a neighbor apply regardless of faith or background—starting with never causing noise, harm, or isolation, and offering warmth or food when able.",
            scholarlyBn = "প্রতিবেশী মুসলিম বা অমুসলিম যেই হোক, তার নিরাপত্তা ও সম্মান রক্ষা করা এবং প্রয়োজনে পাশে দাঁড়ানো ইসলামের অন্যতম সৌন্দর্য।",
            ikhtilafEn = "Scholars note 'neighbor' classically encompasses roughly forty homes around one's residence as well as roommates, coworkers, and classmates.",
            ikhtilafBn = "আলেমদের মতে আশেপাশের বাড়ি ছাড়াও সহকর্মী ও সহপাঠীরাও নিকট সঙ্গী হিসেবে সদ্ব্যবহারের হকদার।",
            synthesisEn = "Check respectfully on a neighbor, roommate, or colleague this week and keep shared spaces clean and peaceful.",
            synthesisBn = "এই সপ্তাহে আপনার প্রতিবেশী বা সহকর্মীর খোঁজ নিন এবং সবার জন্য শান্তিপূর্ণ পরিবেশ বজায় রাখুন।",
            links = listOf("https://quran.com/4/36", "https://sunnah.com/bukhari:6014")
        ),
        KnowledgeEntry(
            id = "honesty_trust_promises",
            keywords = listOf("honesty", "lie", "lying", "truth", "trust", "promise", "amanah", "cheat", "সত্য", "মিথ্যা", "আমানত", "প্রতিশ্রুতি", "ওয়াদা"),
            topicEn = "Truthfulness, Honesty & Fulfilling Promises (Amanah)",
            topicBn = "সত্যবাদিতা, আমানত ও ওয়াদা রক্ষা",
            quranEn = "Surah Al-Ma'idah 5:1 — 'O you who have believed, fulfill [all] contracts.' Surah At-Tawbah 9:119 — 'Be with those who are true.'",
            quranBn = "সূরা মায়িদা ৫:১ — 'হে মুমিনগণ, তোমরা অঙ্গীকারসমূহ পূর্ণ করো।' সূরা তাওবা ৯:১১৯ — 'সত্যবাদীদের সাথে থাকো।'",
            hadithEn = "Sahih al-Bukhari 6094 (Grade: Sahih): 'Truthfulness leads to righteousness, and righteousness leads to Paradise.' Sahih al-Bukhari 33: Breaking promises, lying, and betraying trust are traits to fiercely guard against.",
            hadithBn = "সহীহ বুখারী ৬০৯৪ (মান: সহীহ): 'সত্যবাদিতা পুণ্যের দিকে এবং পুণ্য জান্নাতের দিকে নিয়ে যায়।' বুখারী ৩৩: মিথ্যা, ওয়াদা ভঙ্গ ও খেয়ানত বর্জনীয়।",
            scholarlyEn = "Amanah covers entrusted secrets, borrowed items, public/work responsibilities, time commitments, and accuracy in reporting.",
            scholarlyBn = "আমানত কেবল টাকাপয়সা নয়; বরং কারও গোপন কথা, অফিসের সময় এবং দায়িত্ব সঠিকভাবে পালন করাও আমানতের অন্তর্ভুক্ত।",
            ikhtilafEn = "Scholars strictly prohibit deception in daily speech and trade; only emergency lifesaving or reconciling estranged spouses allows tactful phrasing without malice.",
            ikhtilafBn = "দৈনন্দিন জীবনে ও ব্যবসায় প্রতারণা বা মিথ্যা সর্বসম্মতভাবে হারাম।",
            synthesisEn = "Keep every small commitment you make today—arrive on time, tell the truth gently, and protect what others entrust to you.",
            synthesisBn = "আজকের প্রতিটি ছোট ওয়াদা রক্ষা করুন, সময়নিষ্ঠ থাকুন এবং মানুষের আস্থা অটুট রাখুন।",
            links = listOf("https://quran.com/5/1", "https://sunnah.com/bukhari:6094")
        )
    )

    fun extractSearchKeywords(query: String): List<String> {
        val rawTokens = query.lowercase()
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .split(Regex("\\s+"))
            .map { it.trim() }
            .filter { it.length >= 2 && it !in stopwords }

        return rawTokens.flatMap { token ->
            val stemmed = normalizeToken(token)
            val mapped = banglaToEnglishConcepts[token]?.split(" ") ?: emptyList()
            listOf(token, stemmed) + mapped
        }.filter { it.length >= 2 && it !in stopwords }.distinct()
    }

    fun translateBanglaTermsForOnlineSearch(query: String): List<String> {
        val tokens = query.lowercase()
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .split(Regex("\\s+"))
            .map { it.trim() }
            .filter { it.length >= 2 }
        val translated = tokens.flatMap { tok ->
            banglaToEnglishConcepts[tok]?.split(" ")
                ?: banglaToEnglishConcepts.entries.firstOrNull { tok.startsWith(it.key) }?.value?.split(" ")
                ?: emptyList()
        }
        val asciiTokens = tokens.filter { tok -> tok.all { it.code < 128 } && tok !in stopwords }
        return (asciiTokens + translated).distinct()
    }

    private fun normalizeToken(token: String): String {
        if (token.any { it.code >= 0x0980 && it.code <= 0x09FF }) {
            // Basic Bangla inflection stripping
            val suffixes = listOf("গুলো", "সমূহ", "ের", "কে", "তে", "য়ে", "রা", "টা", "টি")
            for (s in suffixes) {
                if (token.length > s.length + 2 && token.endsWith(s)) {
                    return token.removeSuffix(s)
                }
            }
            return token
        }
        return when {
            token.length > 5 && token.endsWith("ies") -> token.dropLast(3) + "y"
            token.length > 5 && token.endsWith("ing") -> token.dropLast(3)
            token.length > 4 && token.endsWith("ed") -> token.dropLast(2)
            token.length > 5 && token.endsWith("ness") -> token.dropLast(4)
            token.length > 4 && token.endsWith("s") && !token.endsWith("ss") -> token.dropLast(1)
            else -> token
        }
    }

    fun isGreeting(query: String): Boolean {
        val q = query.lowercase().trim()
        return q in setOf("hi", "hello", "hey", "salam", "assalamu alaikum", "as-salamu alaykum", "সালাম", "আসসালামু আলাইকুম", "হ্যালো") ||
            q.startsWith("assalam") || q.startsWith("salam")
    }

    fun retrieveScoredMatches(query: String, limit: Int = 2): List<Pair<KnowledgeEntry, Int>> {
        val tokens = extractSearchKeywords(query)
        if (tokens.isEmpty()) return emptyList()
        return entries.map { entry ->
            var score = 0
            var matchedAnchor = false
            val topicWords = entry.topicEn.lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotBlank() }
            for (token in tokens) {
                if (entry.keywords.any { it == token }) {
                    score += 9
                    matchedAnchor = true
                } else if (entry.keywords.any { it.startsWith(token) || (token.length >= 4 && it.contains(token)) || (it.length >= 4 && token.contains(it)) }) {
                    score += 6
                    matchedAnchor = true
                }
                if (topicWords.contains(token) || entry.topicBn.contains(token)) {
                    score += 4
                    matchedAnchor = true
                }
                if (entry.quranEn.lowercase().contains(token) || entry.hadithEn.lowercase().contains(token)) {
                    score += 2
                }
            }
            entry to if (matchedAnchor) score else 0
        }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(limit)
    }

    fun retrieveTopMatches(query: String, limit: Int = 2): List<KnowledgeEntry> =
        retrieveScoredMatches(query, limit).map { it.first }
}
