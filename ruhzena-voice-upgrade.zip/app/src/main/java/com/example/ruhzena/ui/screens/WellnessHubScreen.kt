package com.example.ruhzena.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.FoldedDropdownOption
import com.example.ruhzena.core.ui.FoldedPageDropdown
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.SegmentedGlassTabRow
import com.example.ruhzena.core.ui.SegmentedTabItem
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.local.MealLogEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.data.local.WaterLogEntity
import com.example.ruhzena.data.local.WorkoutLogEntity
import com.example.ruhzena.ui.MealScanUiState
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ruhzena.ui.exercises.ExerciseDemonstrationPlayer
import com.example.ruhzena.ui.exercises.ExerciseLibrary
import com.example.ruhzena.ui.exercises.MuscleZone
import com.example.ruhzena.ui.exercises.WorkoutEquipmentCatalog
import com.example.ruhzena.ui.exercises.WorkoutProgram
import com.example.ruhzena.ui.exercises.WorkoutProgramCatalog
import com.example.ruhzena.ui.exercises.WorkoutStation
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

enum class WellnessSubTab { WORKOUTS, HYDRATION, NUTRITION }

@Composable
private fun wellnessFieldColors(focusColor: Color = LocalRuhZenaPalette.current.accentPrimary) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = focusColor,
    unfocusedBorderColor = LocalRuhZenaPalette.current.borderNeutral,
    focusedTextColor = LocalRuhZenaPalette.current.textPrimary,
    unfocusedTextColor = LocalRuhZenaPalette.current.textPrimary,
    focusedLabelColor = focusColor,
    unfocusedLabelColor = LocalRuhZenaPalette.current.textMuted,
    focusedPlaceholderColor = LocalRuhZenaPalette.current.textMuted,
    unfocusedPlaceholderColor = LocalRuhZenaPalette.current.textMuted
)

@Composable
fun WellnessHubScreen(
    selectedTab: WellnessSubTab,
    onSelectTab: (WellnessSubTab) -> Unit,
    prefs: UserPreferences,
    waterMlToday: Int,
    waterLogs: List<WaterLogEntity>,
    weeklyWaterLogs: List<WaterLogEntity> = emptyList(),
    mealsToday: List<MealLogEntity>,
    mealScanState: MealScanUiState,
    hasPreviousMealScan: Boolean = false,
    recentWorkouts: List<WorkoutLogEntity>,
    onAddWater: (Int) -> Unit,
    onDeleteWater: (Long) -> Unit,
    onSetWaterGoal: (Int) -> Unit,
    onAddMeal: (String, String, Int, Int, Int, Int, Boolean, String) -> Unit,
    onDeleteMeal: (Long) -> Unit,
    onAnalyzeMealPhoto: (Bitmap, String) -> Unit,
    onReanalyzeMealPhoto: (String) -> Unit = {},
    onRestorePreviousMealScan: () -> Unit = {},
    onClearMealScan: () -> Unit,
    onLogWorkout: (String, Int, Int, Int) -> Unit,
    onUpdateBiometricProfile: (
        name: String,
        ageYears: Int,
        weightKg: Int,
        heightCm: Int,
        level: String,
        goal: String,
        equipment: String,
        limitation: String
    ) -> Unit,
    formatTime: (Long) -> String,
    onSelectCharacterGender: (String) -> Unit = {},
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> }
) {
    val strings = LocalStrings.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val wellnessOptions = remember(strings, isBn) {
        listOf(
            FoldedDropdownOption(
                value = WellnessSubTab.WORKOUTS,
                label = strings.tabWorkouts,
                subtitle = if (isBn) "৩ডি ব্যায়াম প্রদর্শনী ও প্রোগ্রাম" else "Articulated workout demos & programs",
                testTag = "wellness_tab_workouts"
            ),
            FoldedDropdownOption(
                value = WellnessSubTab.HYDRATION,
                label = strings.tabHydration,
                subtitle = if (isBn) "দৈনিক পানি পান ও লক্ষ্য" else "Daily water tracker & hydration goal",
                testTag = "wellness_tab_hydration"
            ),
            FoldedDropdownOption(
                value = WellnessSubTab.NUTRITION,
                label = strings.tabNutrition,
                subtitle = if (isBn) "খাবার স্ক্যানার ও ক্যালোরি হিসাব" else "Meal scanner & calorie balance",
                testTag = "wellness_tab_nutrition"
            )
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .tutorialTarget(TutorialTargetKeys.WORKOUT_SECTION_DROPDOWN)
        ) {
            FoldedPageDropdown(
                options = wellnessOptions,
                selected = selectedTab,
                onSelect = onSelectTab,
                sectionLabel = if (isBn) "স্বাস্থ্য বিভাগ" else "Wellness Section",
                triggerTestTag = "wellness_section_dropdown"
            )
        }

        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = {
                val forward = targetState.ordinal >= initialState.ordinal
                (fadeIn(tween(220, easing = FastOutSlowInEasing)) +
                    slideInHorizontally(tween(240, easing = FastOutSlowInEasing)) { if (forward) it / 14 else -it / 14 } +
                    scaleIn(initialScale = 0.98f, animationSpec = tween(220))) togetherWith
                    (fadeOut(tween(150)) + slideOutHorizontally(tween(160)) { if (forward) -it / 16 else it / 16 })
            },
            modifier = Modifier.weight(1f),
            label = "wellnessTabTransition"
        ) { activeWellnessTab ->
        when (activeWellnessTab) {
            WellnessSubTab.WORKOUTS -> WorkoutsAndDemosTab(
                prefs = prefs,
                recentWorkouts = recentWorkouts,
                onLogWorkout = onLogWorkout,
                onUpdateBiometricProfile = onUpdateBiometricProfile,
                formatTime = formatTime,
                onSelectCharacterGender = onSelectCharacterGender,
                onAskRuhZebaAi = onAskRuhZebaAi
            )
            WellnessSubTab.HYDRATION -> HydrationTab(
                goalMl = prefs.hydrationGoalMl,
                waterMlToday = waterMlToday,
                logs = waterLogs,
                weeklyLogs = weeklyWaterLogs,
                prefs = prefs,
                onAddWater = onAddWater,
                onDeleteWater = onDeleteWater,
                onSetGoal = onSetWaterGoal,
                formatTime = formatTime,
                onAskRuhZebaAi = onAskRuhZebaAi
            )
            WellnessSubTab.NUTRITION -> NutritionTab(
                meals = mealsToday,
                mealScanState = mealScanState,
                hasPreviousScan = hasPreviousMealScan,
                prefs = prefs,
                onAddMeal = onAddMeal,
                onDeleteMeal = onDeleteMeal,
                onAnalyzeMealPhoto = onAnalyzeMealPhoto,
                onReanalyzeMealPhoto = onReanalyzeMealPhoto,
                onRestorePreviousScan = onRestorePreviousMealScan,
                onClearMealScan = onClearMealScan,
                onAskRuhZebaAi = onAskRuhZebaAi
            )
        }
        }
    }
}

@Composable
private fun WorkoutsAndDemosTab(
    prefs: UserPreferences,
    recentWorkouts: List<WorkoutLogEntity>,
    onLogWorkout: (String, Int, Int, Int) -> Unit,
    onUpdateBiometricProfile: (
        name: String,
        ageYears: Int,
        weightKg: Int,
        heightCm: Int,
        level: String,
        goal: String,
        equipment: String,
        limitation: String
    ) -> Unit,
    formatTime: (Long) -> String,
    onSelectCharacterGender: (String) -> Unit = {},
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> }
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val haptics = LocalHapticFeedback.current

    var selectedEquipmentFilter by remember { mutableStateOf("All") }
    var selectedCategory by remember { mutableStateOf("All") }
    var exerciseSearchQuery by rememberSaveable { mutableStateOf("") }
    var selectedExercise by remember { mutableStateOf(ExerciseLibrary.exercises.first()) }
    var restSecondsRemaining by remember { mutableIntStateOf(0) }
    var restActive by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showCustomBuilder by remember { mutableStateOf(false) }
    var workoutSavedFeedback by remember { mutableStateOf(false) }

    var previewProgram by remember { mutableStateOf<WorkoutProgram?>(null) }
    var activeGuidedProgram by remember { mutableStateOf<WorkoutProgram?>(null) }

    val weekDaysActive = remember(recentWorkouts) {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val loggedKeys = recentWorkouts.map { it.dateKey }.toSet()
        val cal = Calendar.getInstance()
        cal.firstDayOfWeek = Calendar.MONDAY
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val dayLabelsEn = listOf("M", "T", "W", "T", "F", "S", "S")
        val dayLabelsBn = listOf("সো", "ম", "বু", "বৃ", "শু", "শ", "র")
        (0..6).map { idx ->
            val key = fmt.format(cal.time)
            cal.add(Calendar.DAY_OF_YEAR, 1)
            Triple(if (isBn) dayLabelsBn[idx] else dayLabelsEn[idx], loggedKeys.contains(key), key)
        }
    }
    val weeklyStats = remember(recentWorkouts) {
        val weekAgo = System.currentTimeMillis() - 7L * 24L * 3600L * 1000L
        val weekLogs = recentWorkouts.filter { it.timestamp >= weekAgo }
        Triple(weekLogs.size, weekLogs.sumOf { it.durationMinutes }, weekLogs.sumOf { it.estimatedCalories })
    }

    val filteredPrograms = remember(selectedEquipmentFilter, prefs.availableEquipment) {
        when (selectedEquipmentFilter) {
            "My Gear" -> WorkoutProgramCatalog.programs.filter {
                WorkoutEquipmentCatalog.matchesUserEquipment(it.equipmentTag, prefs.availableEquipment)
            }
            "Bodyweight" -> WorkoutProgramCatalog.programs.filter { it.equipmentTag == "Bodyweight" }
            WorkoutEquipmentCatalog.DUMBBELLS -> WorkoutProgramCatalog.programs.filter { it.equipmentTag == WorkoutEquipmentCatalog.DUMBBELLS }
            WorkoutEquipmentCatalog.RESISTANCE_BANDS -> WorkoutProgramCatalog.programs.filter { it.equipmentTag == WorkoutEquipmentCatalog.RESISTANCE_BANDS }
            WorkoutEquipmentCatalog.PULL_UP_BAR -> WorkoutProgramCatalog.programs.filter { it.equipmentTag == WorkoutEquipmentCatalog.PULL_UP_BAR }
            WorkoutEquipmentCatalog.KETTLEBELL -> WorkoutProgramCatalog.programs.filter { it.equipmentTag == WorkoutEquipmentCatalog.KETTLEBELL }
            WorkoutEquipmentCatalog.BARBELL_BENCH -> WorkoutProgramCatalog.programs.filter { it.equipmentTag == WorkoutEquipmentCatalog.BARBELL_BENCH }
            else -> WorkoutProgramCatalog.programs
        }
    }

    val filteredExercises = remember(selectedEquipmentFilter, selectedCategory, exerciseSearchQuery, prefs.availableEquipment) {
        val byEquip = when (selectedEquipmentFilter) {
            "My Gear" -> ExerciseLibrary.exercises.filter {
                WorkoutEquipmentCatalog.matchesUserEquipment(it.equipmentRequired, prefs.availableEquipment)
            }
            "Bodyweight" -> ExerciseLibrary.exercises.filter { it.equipmentRequired == "Bodyweight" }
            WorkoutEquipmentCatalog.DUMBBELLS -> ExerciseLibrary.exercises.filter { it.equipmentRequired == WorkoutEquipmentCatalog.DUMBBELLS }
            WorkoutEquipmentCatalog.RESISTANCE_BANDS -> ExerciseLibrary.exercises.filter { it.equipmentRequired == WorkoutEquipmentCatalog.RESISTANCE_BANDS }
            WorkoutEquipmentCatalog.PULL_UP_BAR -> ExerciseLibrary.exercises.filter { it.equipmentRequired == WorkoutEquipmentCatalog.PULL_UP_BAR }
            WorkoutEquipmentCatalog.KETTLEBELL -> ExerciseLibrary.exercises.filter { it.equipmentRequired == WorkoutEquipmentCatalog.KETTLEBELL }
            WorkoutEquipmentCatalog.BARBELL_BENCH -> ExerciseLibrary.exercises.filter { it.equipmentRequired == WorkoutEquipmentCatalog.BARBELL_BENCH }
            else -> ExerciseLibrary.exercises
        }
        val byCat = when (selectedCategory) {
            "Push-Ups" -> byEquip.filter { it.id.contains("push_up") }
            "Back" -> byEquip.filter { it.categoryEn.contains("Back") || it.activeZone == MuscleZone.SPINE_BACK }
            "Hardcore" -> byEquip.filter { it.difficulty.equals("Advanced", ignoreCase = true) }
            "Upper" -> byEquip.filter { it.categoryEn.contains("Upper") }
            "Lower" -> byEquip.filter { it.categoryEn.contains("Lower") }
            "Core" -> byEquip.filter { it.categoryEn.contains("Core") }
            "Mobility" -> byEquip.filter { it.categoryEn.contains("Mobility") }
            "Cardio" -> byEquip.filter { it.categoryEn.contains("Cardio") }
            else -> byEquip
        }
        val q = exerciseSearchQuery.trim().lowercase()
        if (q.isEmpty()) byCat
        else byCat.filter {
            it.nameEn.lowercase().contains(q) ||
                it.nameBn.contains(q) ||
                it.musclesEn.lowercase().contains(q) ||
                it.categoryEn.lowercase().contains(q) ||
                it.equipmentRequired.lowercase().contains(q) ||
                it.movementPattern.lowercase().contains(q)
        }
    }

    LaunchedEffect(restActive) {
        while (restActive && restSecondsRemaining > 0) {
            delay(1000L)
            restSecondsRemaining -= 1
            if (restSecondsRemaining == 0) {
                restActive = false
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("workouts_list"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 52.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Weekly Consistency & Personalized Profile Cockpit
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "সাপ্তাহিক প্রশিক্ষণ ছন্দ" else "Weekly Training Pulse",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary
                        )
                        Text(
                            text = buildString {
                                if (prefs.userName.isNotBlank()) append("${prefs.userName} • ")
                                append("${prefs.ageYears}y • ${prefs.weightKg}kg • ${prefs.heightCm}cm • ${prefs.fitnessLevel}")
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.accentSoft,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    GlassFilterChip(
                        label = strings.generatePersonalizedPlan,
                        selected = false,
                        onClick = { showProfileDialog = true },
                        icon = Icons.Default.Tune,
                        modifier = Modifier
                            .tutorialTarget(TutorialTargetKeys.WORKOUT_PROFILE_BTN)
                            .testTag("wellness_edit_profile_button")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TrainingMetricTile("${weeklyStats.first}", if (isBn) "ওয়ার্কআউট" else "Workouts")
                    TrainingMetricTile("${weeklyStats.second} min", if (isBn) "মোট সময়" else "Minutes")
                    TrainingMetricTile("~${weeklyStats.third}", if (isBn) "ক্যালোরি" else "Kcal")
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    weekDaysActive.forEach { (label, active, _) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(
                                        color = if (active) palette.accentPrimary else palette.blockBg,
                                        shape = CircleShape
                                    )
                                    .border(
                                        width = 0.8.dp,
                                        color = if (active) palette.accentSoft else palette.borderNeutral,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (active) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = palette.onAccent, modifier = Modifier.size(14.dp))
                                } else {
                                    Text(label, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                                }
                            }
                            if (active) {
                                Text(label, style = MaterialTheme.typography.labelSmall, color = palette.accentSoft)
                            }
                        }
                    }
                }
            }
        }

        // 1b. Personalized Daily Plan Card based on User Biometrics, Goal & Limitations
        item {
            val recommendedProgram = remember(prefs.fitnessLevel, prefs.fitnessGoal, prefs.fitnessLimitation) {
                pickRecommendedProgram(prefs)
            }
            val heightM = (prefs.heightCm.coerceIn(110, 230) / 100f)
            val bmi = (prefs.weightKg.toFloat() / (heightM * heightM))
            val bmiFormatted = String.format(Locale.US, "%.1f", bmi)
            val dailyHydrationTarget = (prefs.weightKg.coerceIn(35, 180) * 35).coerceIn(1800, 4500)
            val hasJointCaution = !prefs.fitnessLimitation.equals("None", ignoreCase = true) && prefs.fitnessLimitation.isNotBlank()

            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.WORKOUT_RECOMMENDED_CARD)
                    .testTag("recommended_program_card"),
                accentBorder = true,
                onClick = { previewProgram = recommendedProgram }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(
                        label = strings.recommendedTodayLabel,
                        accentColor = palette.gold,
                        icon = Icons.Default.AutoAwesome
                    )
                    Text(
                        text = "BMI $bmiFormatted • ${dailyHydrationTarget}ml H₂O",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = palette.sky
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isBn) recommendedProgram.titleBn else recommendedProgram.titleEn,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                Text(
                    text = if (isBn) recommendedProgram.subtitleBn else recommendedProgram.subtitleEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
                if (hasJointCaution) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isBn) {
                            "নিরাপদ নির্দেশনা (${prefs.fitnessLimitation}): লাফের পরিবর্তে সহজ/হাঁটু-বান্ধব ভঙ্গি ব্যবহার করুন।"
                        } else {
                            "Adapted for ${prefs.fitnessLimitation}: use controlled tempo & easier low-impact options."
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.gold
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    EmeraldActionButton(
                        text = if (isBn) "প্রস্তাবিত সেশন (${recommendedProgram.durationMinutes}মি)" else "Start Recommended (${recommendedProgram.durationMinutes}m)",
                        icon = Icons.Default.PlayArrow,
                        onClick = { activeGuidedProgram = recommendedProgram },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("start_recommended_workout_button")
                    )
                    GlassFilterChip(
                        label = if (isBn) "কাস্টম তৈরি" else "Build Custom",
                        selected = false,
                        icon = Icons.Default.Add,
                        onClick = { showCustomBuilder = true },
                        modifier = Modifier.testTag("custom_workout_builder_button")
                    )
                }
            }
        }

        // 2. Equipment Filter & Curated Guided Workout Programs
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBn) "গাইডেড ওয়ার্কআউট প্রোগ্রাম" else "Guided Workout Programs",
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary
                    )
                    Text(
                        text = if (isBn) "${filteredPrograms.size} প্রোগ্রাম" else "${filteredPrograms.size} Programs",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.gold
                    )
                }

                // Equipment filter strip (Bodyweight, My Gear, Dumbbells, Bands, Pull-Up Bar, Kettlebell, Barbell)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val equipFilters = listOf(
                        "All" to (if (isBn) "সব সরঞ্জাম" else "All Gear"),
                        "My Gear" to (if (isBn) "আমার সরঞ্জাম" else "My Equipment"),
                        "Bodyweight" to (if (isBn) "বডিওয়েট" else "No Equipment"),
                        WorkoutEquipmentCatalog.DUMBBELLS to (if (isBn) "ডাম্বেল" else "Dumbbells"),
                        WorkoutEquipmentCatalog.RESISTANCE_BANDS to (if (isBn) "ব্যান্ড" else "Bands"),
                        WorkoutEquipmentCatalog.PULL_UP_BAR to (if (isBn) "পুল-আপ বার" else "Pull-Up Bar"),
                        WorkoutEquipmentCatalog.KETTLEBELL to (if (isBn) "কেটলবেল" else "Kettlebell"),
                        WorkoutEquipmentCatalog.BARBELL_BENCH to (if (isBn) "বারবেল/জিম" else "Barbell & Gym")
                    )
                    items(equipFilters) { (key, label) ->
                        GlassFilterChip(
                            label = label,
                            selected = selectedEquipmentFilter == key,
                            onClick = { selectedEquipmentFilter = key },
                            modifier = Modifier.testTag("workout_equip_filter_${key.lowercase().replace(" ", "_")}")
                        )
                    }
                }

                filteredPrograms.forEach { program ->
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("program_card_${program.id}"),
                        onClick = { previewProgram = program }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    StatusPillBadge(label = program.accentTag, accentColor = palette.gold)
                                    Text(
                                        text = "${program.level} • ${if (isBn) program.focusAreaBn else program.focusAreaEn}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.accentSoft,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isBn) program.titleBn else program.titleEn,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = if (isBn) program.subtitleBn else program.subtitleEn,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Timer, contentDescription = null, tint = palette.sky, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("${program.durationMinutes} min", style = MaterialTheme.typography.labelSmall, color = palette.textPrimary)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = palette.gold, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("~${program.estimatedKcal} kcal", style = MaterialTheme.typography.labelSmall, color = palette.textPrimary)
                                    }
                                    Text("${program.stations.size} ${if (isBn) "ধাপ" else "exercises"}", style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(palette.accentPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Preview workout", tint = palette.onAccent)
                            }
                        }
                    }
                }
            }
        }

        // 3. Exercise Form Library, Search & Live Movement Studio
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (isBn) "ব্যায়ামের সঠিক ভঙ্গি ও ফর্ম স্টুডিও" else "Exercise Form Library & Demo Studio",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                OutlinedTextField(
                    value = exerciseSearchQuery,
                    onValueChange = { exerciseSearchQuery = it },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.accentSoft) },
                    placeholder = {
                        Text(
                            text = if (isBn) "এখানে লিখুন" else "Type here",
                            color = palette.textMuted
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = wellnessFieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .tutorialTarget(TutorialTargetKeys.WORKOUT_SEARCH_INPUT)
                        .testTag("workout_search_input")
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("All", "Upper", "Lower", "Back", "Core", "Push-Ups", "Hardcore", "Mobility", "Cardio")) { cat ->
                        GlassFilterChip(
                            label = cat,
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat }
                        )
                    }
                }
                if (filteredExercises.isEmpty()) {
                    Text(
                        text = if (isBn) "এই ফিল্টারে কোনো ব্যায়াম নেই—সব সরঞ্জাম বা অন্য বিভাগ বেছে নিন।" else "No matching exercises for this equipment/category filter.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textMuted
                    )
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filteredExercises, key = { it.id }) { ex ->
                            val equipShort = if (ex.equipmentRequired != "Bodyweight") {
                                " (${if (isBn) WorkoutEquipmentCatalog.equipmentBadgeBn(ex.equipmentRequired) else ex.equipmentRequired})"
                            } else ""
                            GlassFilterChip(
                                label = (if (isBn) ex.nameBn else ex.nameEn) + equipShort,
                                selected = selectedExercise.id == ex.id,
                                onClick = { selectedExercise = ex },
                                modifier = Modifier.testTag("exercise_chip_${ex.id}")
                            )
                        }
                    }
                }
            }
        }

        item {
            ExerciseDemonstrationPlayer(
                exercise = selectedExercise,
                characterGender = prefs.characterGender,
                onSelectGender = onSelectCharacterGender
            )
        }

        // 4. Compact Biomechanics & Coaching Details Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBn) selectedExercise.nameBn else selectedExercise.nameEn,
                        style = MaterialTheme.typography.titleLarge,
                        color = palette.textPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    StatusPillBadge(
                        label = if (isBn) selectedExercise.setsRepsBn else selectedExercise.setsRepsEn,
                        accentColor = palette.gold
                    )
                }

                DetailBulletBlock(strings.musclesInvolved, if (isBn) selectedExercise.musclesBn else selectedExercise.musclesEn, palette.accentSoft)
                DetailBulletBlock(strings.breathingCue, if (isBn) selectedExercise.breathingBn else selectedExercise.breathingEn, palette.sky)

                Spacer(modifier = Modifier.height(8.dp))
                Text(strings.postureCheckpoints, style = MaterialTheme.typography.labelLarge, color = palette.textPrimary)
                (if (isBn) selectedExercise.postureBn else selectedExercise.postureEn).forEach { cp ->
                    Text("• $cp", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(strings.commonMistakes, style = MaterialTheme.typography.labelLarge, color = palette.coral)
                (if (isBn) selectedExercise.mistakesBn else selectedExercise.mistakesEn).forEach { m ->
                    Text("• $m", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                }

                DetailBulletBlock(strings.easierAlternative, if (isBn) selectedExercise.easierAltBn else selectedExercise.easierAltEn, palette.gold)
                DetailBulletBlock(strings.progressionOption, if (isBn) selectedExercise.progressionBn else selectedExercise.progressionEn, palette.accentSoft)
                Spacer(modifier = Modifier.height(10.dp))
                GlassFilterChip(
                    label = if (isBn) "রূহযেবা AI কোচিং" else "Ask RuhZeba AI",
                    selected = false,
                    icon = Icons.Default.AutoAwesome,
                    onClick = {
                        val exTitle = if (isBn) selectedExercise.nameBn else selectedExercise.nameEn
                        val q = if (isBn) {
                            "'$exTitle' ব্যায়ামটি আমার ${prefs.fitnessLevel} স্তর ও লক্ষ্য (${prefs.fitnessGoal}) অনুযায়ী কীভাবে নিরাপদভাবে করব?"
                        } else {
                            "How can I customize '$exTitle' safely for my ${prefs.fitnessLevel} level and ${prefs.fitnessGoal} goal?"
                        }
                        onAskRuhZebaAi("WELLNESS", q)
                    },
                    modifier = Modifier.testTag("workout_ask_ai_button")
                )
            }
        }

        // 5. Rest Timer & Quick Exercise Log
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = restActive) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = palette.accentSoft)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(strings.restTimerTitle, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text(
                                text = if (restActive) "${restSecondsRemaining}s" else "${selectedExercise.restSeconds}s recommended",
                                style = MaterialTheme.typography.titleLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = palette.gold
                            )
                        }
                    }
                    GlassFilterChip(
                        label = if (restActive) "Stop" else strings.startRest,
                        selected = restActive,
                        onClick = {
                            if (restActive) {
                                restActive = false
                                restSecondsRemaining = 0
                            } else {
                                restSecondsRemaining = selectedExercise.restSeconds
                                restActive = true
                            }
                        }
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                EmeraldActionButton(
                    text = strings.logWorkout,
                    icon = Icons.Default.CheckCircle,
                    onClick = {
                        onLogWorkout(
                            if (isBn) selectedExercise.nameBn else selectedExercise.nameEn,
                            3,
                            15,
                            95
                        )
                        workoutSavedFeedback = true
                    },
                    modifier = Modifier.fillMaxWidth().testTag("log_workout_button")
                )
                if (workoutSavedFeedback) {
                    Text(strings.workoutLoggedMsg, style = MaterialTheme.typography.labelSmall, color = palette.accentSoft, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }

        if (recentWorkouts.isNotEmpty()) {
            item {
                Text(
                    text = if (isBn) "সাম্প্রতিক ব্যায়াম ইতিহাস" else "Recent Workout History",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
            }
            items(recentWorkouts.take(8), key = { it.id }) { log ->
                GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(log.routineTitle, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary)
                            Text(formatTime(log.timestamp), style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        }
                        StatusPillBadge(label = "${log.durationMinutes} min • ~${log.estimatedCalories} kcal", accentColor = palette.accentSoft)
                    }
                }
            }
        }
    }

    if (showProfileDialog) {
        FitnessProfileDialog(
            prefs = prefs,
            onDismiss = { showProfileDialog = false },
            onSave = { name, age, weight, height, lvl, goal, eq, lim ->
                onUpdateBiometricProfile(name, age, weight, height, lvl, goal, eq, lim)
                showProfileDialog = false
            }
        )
    }

    if (showCustomBuilder) {
        CustomWorkoutBuilderDialog(
            isBn = isBn,
            userLevel = prefs.fitnessLevel,
            onDismiss = { showCustomBuilder = false },
            onStartCustomProgram = { customProg ->
                showCustomBuilder = false
                activeGuidedProgram = customProg
            }
        )
    }

    previewProgram?.let { program ->
        GuidedWorkoutPreviewDialog(
            program = program,
            isBn = isBn,
            onDismiss = { previewProgram = null },
            onStartWorkout = {
                previewProgram = null
                activeGuidedProgram = program
            }
        )
    }

    activeGuidedProgram?.let { program ->
        GuidedWorkoutSessionDialog(
            program = program,
            isBn = isBn,
            characterGender = prefs.characterGender,
            onDismiss = { activeGuidedProgram = null },
            onCompleteWorkout = { title, count, duration, kcal ->
                onLogWorkout(title, count, duration, kcal)
            }
        )
    }
}

@Composable
private fun CustomWorkoutBuilderDialog(
    isBn: Boolean,
    userLevel: String,
    onDismiss: () -> Unit,
    onStartCustomProgram: (WorkoutProgram) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    var routineTitle by remember { mutableStateOf(if (isBn) "আমার কাস্টম ওয়ার্কআউট" else "My Custom Routine") }
    var selectedIds by remember { mutableStateOf(setOf("push_up", "bodyweight_squat", "forearm_plank")) }
    var workDurationSec by remember { mutableIntStateOf(40) }
    var restAfterSec by remember { mutableIntStateOf(20) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.surfaceBg,
        title = {
            Text(
                text = if (isBn) "কাস্টম ওয়ার্কআউট নির্মাতা" else "Custom Workout Builder",
                color = palette.textPrimary
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = routineTitle,
                    onValueChange = { routineTitle = it },
                    label = { Text(if (isBn) "রুটিনের নাম" else "Routine Title") },
                    singleLine = true,
                    colors = wellnessFieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = if (isBn) "প্রতি ব্যায়ামের সময় ও বিশ্রাম" else "Station Duration & Rest",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.accentSoft
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(30, 40, 50).forEach { sec ->
                        GlassFilterChip(
                            label = "${sec}s work",
                            selected = workDurationSec == sec,
                            onClick = { workDurationSec = sec },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(15, 20, 30).forEach { rest ->
                        GlassFilterChip(
                            label = "${rest}s rest",
                            selected = restAfterSec == rest,
                            onClick = { restAfterSec = rest },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Text(
                    text = if (isBn) "ব্যায়াম নির্বাচন করুন (${selectedIds.size})" else "Select Exercises (${selectedIds.size} chosen)",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.gold
                )
                ExerciseLibrary.exercises.forEach { ex ->
                    val checked = selectedIds.contains(ex.id)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (checked) palette.accentContainer else palette.blockBg,
                                RoundedCornerShape(10.dp)
                            )
                            .border(
                                0.7.dp,
                                if (checked) palette.borderAccent else palette.borderNeutral.copy(alpha = 0.4f),
                                RoundedCornerShape(10.dp)
                            )
                            .clickable {
                                selectedIds = if (checked && selectedIds.size > 1) {
                                    selectedIds - ex.id
                                } else {
                                    selectedIds + ex.id
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = checked,
                            onCheckedChange = null,
                            colors = CheckboxDefaults.colors(
                                checkedColor = palette.accentPrimary,
                                checkmarkColor = palette.onAccent,
                                uncheckedColor = palette.textMuted
                            )
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (isBn) ex.nameBn else ex.nameEn, style = MaterialTheme.typography.labelLarge, color = palette.textPrimary)
                            Text(if (isBn) ex.categoryBn else ex.categoryEn, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val ordered = ExerciseLibrary.exercises.filter { selectedIds.contains(it.id) }
                    if (ordered.isNotEmpty()) {
                        val stations = ordered.map { ex ->
                            WorkoutStation(exerciseId = ex.id, durationSec = workDurationSec, restAfterSec = restAfterSec)
                        }
                        val totalMinutes = (((workDurationSec + restAfterSec) * stations.size) / 60).coerceAtLeast(3)
                        val program = WorkoutProgram(
                            id = "custom_${System.currentTimeMillis()}",
                            titleEn = routineTitle.ifBlank { "My Custom Routine" },
                            titleBn = routineTitle.ifBlank { "আমার কাস্টম ওয়ার্কআউট" },
                            subtitleEn = "${stations.size} stations • ${workDurationSec}s work / ${restAfterSec}s rest",
                            subtitleBn = "${stations.size} ধাপ • ${workDurationSec}সে ব্যায়াম / ${restAfterSec}সে বিশ্রাম",
                            focusAreaEn = "Custom Mix",
                            focusAreaBn = "কাস্টম মিশ্রণ",
                            level = userLevel,
                            durationMinutes = totalMinutes,
                            estimatedKcal = totalMinutes * 7,
                            accentTag = "CUSTOM",
                            stations = stations
                        )
                        onStartCustomProgram(program)
                    }
                },
                modifier = Modifier.testTag("start_custom_workout_button")
            ) {
                Text(if (isBn) "শুরু করুন" else "Start Session", color = palette.accentSoft)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isBn) "বাতিল" else "Cancel", color = palette.textSecondary)
            }
        }
    )
}

@Composable
private fun TrainingMetricTile(value: String, label: String) {
    val palette = LocalRuhZenaPalette.current
    Column(
        modifier = Modifier
            .background(palette.blockBg, RoundedCornerShape(12.dp))
            .border(0.6.dp, palette.borderNeutral.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
            color = palette.textPrimary
        )
        Text(label, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
    }
}

@Composable
private fun DetailBulletBlock(label: String, value: String, color: Color) {
    val palette = LocalRuhZenaPalette.current
    Spacer(modifier = Modifier.height(6.dp))
    Text(label, style = MaterialTheme.typography.labelLarge, color = color)
    Text(value, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
}

private fun pickRecommendedProgram(prefs: UserPreferences): WorkoutProgram {
    val lim = prefs.fitnessLimitation.lowercase()
    val goal = prefs.fitnessGoal.lowercase()
    val lvl = prefs.fitnessLevel.lowercase()
    val selectedGear = WorkoutEquipmentCatalog.parseSelected(prefs.availableEquipment)
    val hasKnee = lim.contains("knee") || lim.contains("joint")
    val hasBack = lim.contains("back")

    // Prioritize matching equipment-based programs when the user owns workout equipment!
    if (selectedGear.any { it != WorkoutEquipmentCatalog.NONE }) {
        val equipmentPick = when {
            hasBack && selectedGear.contains(WorkoutEquipmentCatalog.RESISTANCE_BANDS) ->
                WorkoutProgramCatalog.programs.firstOrNull { it.id == "resistance_band_sculpt" }
            selectedGear.contains(WorkoutEquipmentCatalog.BARBELL_BENCH) || selectedGear.contains(WorkoutEquipmentCatalog.FULL_GYM) ->
                WorkoutProgramCatalog.programs.firstOrNull { it.id == "barbell_gym_foundations" }
            selectedGear.contains(WorkoutEquipmentCatalog.DUMBBELLS) ->
                if (goal.contains("leg") || goal.contains("lower")) {
                    WorkoutProgramCatalog.programs.firstOrNull { it.id == "dumbbell_lower_athletic" }
                } else {
                    WorkoutProgramCatalog.programs.firstOrNull { it.id == "dumbbell_total_strength" }
                }
            selectedGear.contains(WorkoutEquipmentCatalog.KETTLEBELL) ->
                WorkoutProgramCatalog.programs.firstOrNull { it.id == "kettlebell_conditioning" }
            selectedGear.contains(WorkoutEquipmentCatalog.PULL_UP_BAR) ->
                WorkoutProgramCatalog.programs.firstOrNull { it.id == "pullup_bar_calisthenics" }
            selectedGear.contains(WorkoutEquipmentCatalog.RESISTANCE_BANDS) ->
                WorkoutProgramCatalog.programs.firstOrNull { it.id == "resistance_band_sculpt" }
            else -> null
        }
        if (equipmentPick != null) return equipmentPick
    }

    return when {
        hasKnee && (goal.contains("posture") || goal.contains("flexibility")) ->
            WorkoutProgramCatalog.programs.firstOrNull { it.id == "core_posture_reset" }
        hasKnee ->
            WorkoutProgramCatalog.programs.firstOrNull { it.id == "upper_body_sculpt" }
        hasBack ->
            WorkoutProgramCatalog.programs.firstOrNull { it.id == "fajr_mobility_flow" }
        goal.contains("fat") || goal.contains("stamina") ->
            if (lvl == "beginner") WorkoutProgramCatalog.programs.firstOrNull { it.id == "full_body_foundation" }
            else WorkoutProgramCatalog.programs.firstOrNull { it.id == "hiit_fat_burn" }
        goal.contains("flexibility") || goal.contains("posture") || goal.contains("mobility") ->
            WorkoutProgramCatalog.programs.firstOrNull { it.id == "fajr_mobility_flow" }
        goal.contains("strength") ->
            if (lvl == "beginner") WorkoutProgramCatalog.programs.firstOrNull { it.id == "full_body_foundation" }
            else WorkoutProgramCatalog.programs.firstOrNull { it.id == "upper_body_sculpt" }
        else -> WorkoutProgramCatalog.programs.firstOrNull { it.level.equals(prefs.fitnessLevel, ignoreCase = true) }
    } ?: WorkoutProgramCatalog.programs.first()
}

@Composable
private fun FitnessProfileDialog(
    prefs: UserPreferences,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        ageYears: Int,
        weightKg: Int,
        heightCm: Int,
        level: String,
        goal: String,
        equip: String,
        limitation: String
    ) -> Unit
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    var name by remember { mutableStateOf(prefs.userName) }
    var ageText by remember { mutableStateOf(prefs.ageYears.toString()) }
    var weightText by remember { mutableStateOf(prefs.weightKg.toString()) }
    var heightText by remember { mutableStateOf(prefs.heightCm.toString()) }
    var level by remember { mutableStateOf(prefs.fitnessLevel) }
    var goal by remember { mutableStateOf(prefs.fitnessGoal) }
    var equip by remember { mutableStateOf(prefs.availableEquipment) }
    var limitation by remember { mutableStateOf(prefs.fitnessLimitation) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.surfaceBg,
        title = { Text(strings.profileSetupTitle, color = palette.textPrimary) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(strings.fullNameLabel) },
                    singleLine = true,
                    colors = wellnessFieldColors()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = ageText,
                        onValueChange = { ageText = it.filter(Char::isDigit).take(3) },
                        label = { Text(strings.ageLabel) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = wellnessFieldColors(),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = weightText,
                        onValueChange = { weightText = it.filter(Char::isDigit).take(3) },
                        label = { Text(strings.weightKgLabel) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = wellnessFieldColors(),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = heightText,
                        onValueChange = { heightText = it.filter(Char::isDigit).take(3) },
                        label = { Text(strings.heightCmLabel) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = wellnessFieldColors(),
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Beginner", "Intermediate", "Advanced").forEach { lvl ->
                        GlassFilterChip(label = lvl, selected = level == lvl, onClick = { level = lvl })
                    }
                }
                OutlinedTextField(
                    value = goal,
                    onValueChange = { goal = it },
                    label = { Text(strings.primaryGoalLabel) },
                    singleLine = true,
                    colors = wellnessFieldColors()
                )
                val isBnDialog = LocalAppLanguage.current == AppLanguage.BANGLA
                val selectedEquipSet = WorkoutEquipmentCatalog.parseSelected(equip)
                Text(
                    text = if (isBnDialog) "আপনার কাছে কোন ওয়ার্কআউট সরঞ্জাম আছে?" else "Workout Equipment Available",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.accentSoft
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    WorkoutEquipmentCatalog.selectableOptions.chunked(2).forEach { rowPair ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            rowPair.forEach { opt ->
                                GlassFilterChip(
                                    label = if (isBnDialog) opt.labelBn else opt.labelEn,
                                    selected = selectedEquipSet.contains(opt.id),
                                    onClick = { equip = WorkoutEquipmentCatalog.toggleOption(equip, opt.id) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (rowPair.size == 1) Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
                OutlinedTextField(
                    value = limitation,
                    onValueChange = { limitation = it },
                    label = { Text(strings.limitationsLabel) },
                    singleLine = true,
                    colors = wellnessFieldColors()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        name.trim(),
                        (ageText.toIntOrNull() ?: prefs.ageYears).coerceIn(13, 100),
                        (weightText.toIntOrNull() ?: prefs.weightKg).coerceIn(30, 220),
                        (heightText.toIntOrNull() ?: prefs.heightCm).coerceIn(120, 230),
                        level,
                        goal,
                        equip,
                        limitation
                    )
                }
            ) {
                Text(strings.saveSettings, color = palette.accentSoft)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.closeAction, color = palette.textSecondary)
            }
        }
    )
}
