package com.example.ruhzena.core.i18n

import androidx.compose.runtime.staticCompositionLocalOf

interface CoreNavStrings {
    val appName: String
    val tagline: String
    val navHome: String
    val navSpirituality: String
    val navAi: String
    val navWellness: String
    val navDiscipline: String
}

data class CoreNavStringsData(
    override val appName: String,
    override val tagline: String,
    override val navHome: String,
    override val navSpirituality: String,
    override val navAi: String,
    override val navWellness: String,
    override val navDiscipline: String
) : CoreNavStrings

interface OnboardingStrings {
    val welcomeTitle: String
    val welcomeSubtitle: String
    val chooseLanguage: String
    val pillarSpirituality: String
    val pillarSpiritualityDesc: String
    val pillarPhysical: String
    val pillarPhysicalDesc: String
    val pillarDiscipline: String
    val pillarDisciplineDesc: String
    val pillarGrowth: String
    val pillarGrowthDesc: String
    val localPrivacyBadge: String
    val continueAction: String
    val startCompanion: String
    val welcomeQuote: String
    val profileSetupTitle: String
    val profileSetupSubtitle: String
    val fullNameLabel: String
    val ageLabel: String
    val weightKgLabel: String
    val heightCmLabel: String
    val fitnessLevelLabel: String
    val primaryGoalLabel: String
    val equipmentLabel: String
    val limitationsLabel: String
    val startMyJourney: String
    val under13Notice: String
}

data class OnboardingStringsData(
    override val welcomeTitle: String,
    override val welcomeSubtitle: String,
    override val chooseLanguage: String,
    override val pillarSpirituality: String,
    override val pillarSpiritualityDesc: String,
    override val pillarPhysical: String,
    override val pillarPhysicalDesc: String,
    override val pillarDiscipline: String,
    override val pillarDisciplineDesc: String,
    override val pillarGrowth: String,
    override val pillarGrowthDesc: String,
    override val localPrivacyBadge: String,
    override val continueAction: String,
    override val startCompanion: String,
    override val welcomeQuote: String,
    override val profileSetupTitle: String,
    override val profileSetupSubtitle: String,
    override val fullNameLabel: String,
    override val ageLabel: String,
    override val weightKgLabel: String,
    override val heightCmLabel: String,
    override val fitnessLevelLabel: String,
    override val primaryGoalLabel: String,
    override val equipmentLabel: String,
    override val limitationsLabel: String,
    override val startMyJourney: String,
    override val under13Notice: String
) : OnboardingStrings

interface HomeStrings {
    val salamGreeting: String
    val nextPrayerLabel: String
    val prayerInPrefix: String
    val dailyOverviewTitle: String
    val hydrationLabel: String
    val workoutLabel: String
    val habitsLabel: String
    val sleepLabel: String
    val nutritionLabel: String
    val continueReadingQuran: String
    val dailyIslamicLesson: String
    val quickActionsTitle: String
    val qiblaAction: String
    val tasbihAction: String
    val adhkarAction: String
    val duaAction: String
    val journalAction: String
    val aiCoachAction: String
    val offlineBadge: String
    val onlineBadge: String
}

data class HomeStringsData(
    override val salamGreeting: String,
    override val nextPrayerLabel: String,
    override val prayerInPrefix: String,
    override val dailyOverviewTitle: String,
    override val hydrationLabel: String,
    override val workoutLabel: String,
    override val habitsLabel: String,
    override val sleepLabel: String,
    override val nutritionLabel: String,
    override val continueReadingQuran: String,
    override val dailyIslamicLesson: String,
    override val quickActionsTitle: String,
    override val qiblaAction: String,
    override val tasbihAction: String,
    override val adhkarAction: String,
    override val duaAction: String,
    override val journalAction: String,
    override val aiCoachAction: String,
    override val offlineBadge: String,
    override val onlineBadge: String
) : HomeStrings

interface QuranStrings {
    val tabQuran: String
    val tabPrayerQibla: String
    val tabAdhkarDua: String
    val tabTasbih: String
    val tabLessons: String
    val searchSurahHint: String
    val surahsCountLabel: String
    val ayahsLabel: String
    val reciterLabel: String
    val selectReciter: String
    val playSurah: String
    val pauseAudio: String
    val resumeAudio: String
    val nextAyah: String
    val prevAyah: String
    val repeatAyah: String
    val repeatSurah: String
    val playbackSpeed: String
    val showPronunciation: String
    val hidePronunciation: String
    val pronunciationNote: String
    val pronunciationDisclaimer: String
    val textSizeLabel: String
    val downloadAllSurahs: String
    val downloadingSurahs: String
    val offlineReadyLabel: String
    val cachedOffline: String
    val requiresOnlineOnce: String
    val audioLoading: String
    val audioError: String
    val bookmarkSaved: String
    val bookmarkRemoved: String
    val bookmarksFilter: String
    val deeperContextTitle: String
}

data class QuranStringsData(
    override val tabQuran: String,
    override val tabPrayerQibla: String,
    override val tabAdhkarDua: String,
    override val tabTasbih: String,
    override val tabLessons: String,
    override val searchSurahHint: String,
    override val surahsCountLabel: String,
    override val ayahsLabel: String,
    override val reciterLabel: String,
    override val selectReciter: String,
    override val playSurah: String,
    override val pauseAudio: String,
    override val resumeAudio: String,
    override val nextAyah: String,
    override val prevAyah: String,
    override val repeatAyah: String,
    override val repeatSurah: String,
    override val playbackSpeed: String,
    override val showPronunciation: String,
    override val hidePronunciation: String,
    override val pronunciationNote: String,
    override val pronunciationDisclaimer: String,
    override val textSizeLabel: String,
    override val downloadAllSurahs: String,
    override val downloadingSurahs: String,
    override val offlineReadyLabel: String,
    override val cachedOffline: String,
    override val requiresOnlineOnce: String,
    override val audioLoading: String,
    override val audioError: String,
    override val bookmarkSaved: String,
    override val bookmarkRemoved: String,
    override val bookmarksFilter: String,
    override val deeperContextTitle: String
) : QuranStrings

interface PrayerAndDeenStrings {
    val prayerTimesTitle: String
    val qiblaCompassTitle: String
    val calculationMethod: String
    val locationLabel: String
    val detectLocation: String
    val manualCity: String
    val qiblaBearingLabel: String
    val compassStatusActive: String
    val compassStatusNoSensor: String
    val compassCalibrationTip: String
    val manualQiblaFallback: String
    val fajr: String
    val sunrise: String
    val dhuhr: String
    val asr: String
    val maghrib: String
    val isha: String
    val morningAdhkar: String
    val eveningAdhkar: String
    val bedtimeAdhkar: String
    val afterPrayerAdhkar: String
    val adhkarSection: String
    val duaSection: String
    val tasbihTitle: String
    val tapToCount: String
    val resetCounter: String
    val customDhikrHint: String
    val targetLabel: String
    val sessionsCompleted: String
    val referenceSource: String
    val listenPronunciation: String
    val explanationTitle: String
    val lifeLessonTitle: String
    val openFullGuide: String
    val explanationAction: String
    val meaningTitle: String
    val tasbihVirtuesTitle: String
    val tapForTasbihVirtues: String
}

data class PrayerAndDeenStringsData(
    override val prayerTimesTitle: String,
    override val qiblaCompassTitle: String,
    override val calculationMethod: String,
    override val locationLabel: String,
    override val detectLocation: String,
    override val manualCity: String,
    override val qiblaBearingLabel: String,
    override val compassStatusActive: String,
    override val compassStatusNoSensor: String,
    override val compassCalibrationTip: String,
    override val manualQiblaFallback: String,
    override val fajr: String,
    override val sunrise: String,
    override val dhuhr: String,
    override val asr: String,
    override val maghrib: String,
    override val isha: String,
    override val morningAdhkar: String,
    override val eveningAdhkar: String,
    override val bedtimeAdhkar: String,
    override val afterPrayerAdhkar: String,
    override val adhkarSection: String,
    override val duaSection: String,
    override val tasbihTitle: String,
    override val tapToCount: String,
    override val resetCounter: String,
    override val customDhikrHint: String,
    override val targetLabel: String,
    override val sessionsCompleted: String,
    override val referenceSource: String,
    override val listenPronunciation: String,
    override val explanationTitle: String,
    override val lifeLessonTitle: String,
    override val openFullGuide: String,
    override val explanationAction: String,
    override val meaningTitle: String,
    override val tasbihVirtuesTitle: String,
    override val tapForTasbihVirtues: String
) : PrayerAndDeenStrings

interface AiStrings {
    val aiTitle: String
    val aiModeIslamic: String
    val aiModeWellness: String
    val aiAskHintIslamic: String
    val aiAskHintWellness: String
    val aiSend: String
    val aiNewChat: String
    val aiClearHistory: String
    val aiModelManager: String
    val aiResearchMode: String
    val aiResearchOnlineDesc: String
    val aiResearchOfflineDesc: String
    val aiDeviceTierLightweight: String
    val aiDeviceTierBalanced: String
    val aiDeviceTierAdvanced: String
    val aiStatusReadyOnDevice: String
    val aiStatusGroundedLocal: String
    val aiStatusDownloading: String
    val aiStatusInitializing: String
    val evidenceQuran: String
    val evidenceHadith: String
    val evidenceScholarly: String
    val evidenceIkhtilaf: String
    val evidenceAiSynthesis: String
    val medicalDisclaimer: String
    val downloadModel: String
    val deleteModel: String
    val loadModel: String
    val unloadModel: String
    val aiCitedSourcesTitle: String
    val aiExplanationSectionTitle: String
}

data class AiStringsData(
    override val aiTitle: String,
    override val aiModeIslamic: String,
    override val aiModeWellness: String,
    override val aiAskHintIslamic: String,
    override val aiAskHintWellness: String,
    override val aiSend: String,
    override val aiNewChat: String,
    override val aiClearHistory: String,
    override val aiModelManager: String,
    override val aiResearchMode: String,
    override val aiResearchOnlineDesc: String,
    override val aiResearchOfflineDesc: String,
    override val aiDeviceTierLightweight: String,
    override val aiDeviceTierBalanced: String,
    override val aiDeviceTierAdvanced: String,
    override val aiStatusReadyOnDevice: String,
    override val aiStatusGroundedLocal: String,
    override val aiStatusDownloading: String,
    override val aiStatusInitializing: String,
    override val evidenceQuran: String,
    override val evidenceHadith: String,
    override val evidenceScholarly: String,
    override val evidenceIkhtilaf: String,
    override val evidenceAiSynthesis: String,
    override val medicalDisclaimer: String,
    override val downloadModel: String,
    override val deleteModel: String,
    override val loadModel: String,
    override val unloadModel: String,
    override val aiCitedSourcesTitle: String,
    override val aiExplanationSectionTitle: String
) : AiStrings

interface WellnessStrings {
    val tabWorkouts: String
    val tabHydration: String
    val tabNutrition: String
    val tabSleep: String
    val animatedDemoTitle: String
    val playDemo: String
    val pauseDemo: String
    val replayDemo: String
    val slowMotion: String
    val repeatLoop: String
    val captionsToggle: String
    val movementStepLabel: String
    val musclesInvolved: String
    val breathingCue: String
    val postureCheckpoints: String
    val commonMistakes: String
    val easierAlternative: String
    val progressionOption: String
    val restTimerTitle: String
    val startRest: String
    val logWorkout: String
    val workoutLoggedMsg: String
    val generatePersonalizedPlan: String
    val hydrationGoalTitle: String
    val addWaterCustom: String
    val logMealTitle: String
    val mealNameHint: String
    val caloriesHint: String
    val proteinHint: String
    val carbsHint: String
    val fatHint: String
    val estimatedDataTag: String
    val verifiedDataTag: String
    val logSleepTitle: String
    val sleepDurationLabel: String
    val bedtimeLabel: String
    val wakeTimeLabel: String
    val sleepQualityLabel: String
    val sleepRoutineTip: String
    val recommendedTodayLabel: String
    val intensityLabel: String
    val formGuideMode: String
    val studioPhotoMode: String
    val whyHydrationMatters: String
    val scanMealPhotoTitle: String
    val takeMealPhoto: String
    val chooseMealPhoto: String
    val analyzingMealPhoto: String
    val logAnalyzedMeal: String
    val searchMealsHint: String
}

data class WellnessStringsData(
    override val tabWorkouts: String,
    override val tabHydration: String,
    override val tabNutrition: String,
    override val tabSleep: String,
    override val animatedDemoTitle: String,
    override val playDemo: String,
    override val pauseDemo: String,
    override val replayDemo: String,
    override val slowMotion: String,
    override val repeatLoop: String,
    override val captionsToggle: String,
    override val movementStepLabel: String,
    override val musclesInvolved: String,
    override val breathingCue: String,
    override val postureCheckpoints: String,
    override val commonMistakes: String,
    override val easierAlternative: String,
    override val progressionOption: String,
    override val restTimerTitle: String,
    override val startRest: String,
    override val logWorkout: String,
    override val workoutLoggedMsg: String,
    override val generatePersonalizedPlan: String,
    override val hydrationGoalTitle: String,
    override val addWaterCustom: String,
    override val logMealTitle: String,
    override val mealNameHint: String,
    override val caloriesHint: String,
    override val proteinHint: String,
    override val carbsHint: String,
    override val fatHint: String,
    override val estimatedDataTag: String,
    override val verifiedDataTag: String,
    override val logSleepTitle: String,
    override val sleepDurationLabel: String,
    override val bedtimeLabel: String,
    override val wakeTimeLabel: String,
    override val sleepQualityLabel: String,
    override val sleepRoutineTip: String,
    override val recommendedTodayLabel: String,
    override val intensityLabel: String,
    override val formGuideMode: String,
    override val studioPhotoMode: String,
    override val whyHydrationMatters: String,
    override val scanMealPhotoTitle: String,
    override val takeMealPhoto: String,
    override val chooseMealPhoto: String,
    override val analyzingMealPhoto: String,
    override val logAnalyzedMeal: String,
    override val searchMealsHint: String
) : WellnessStrings

interface DisciplineStrings {
    val tabHabits: String
    val tabJournal: String
    val addHabit: String
    val habitNameHint: String
    val streakLabel: String
    val bestStreakLabel: String
    val recoveryBanner: String
    val recoverMissedDay: String
    val addJournalEntry: String
    val journalTitleHint: String
    val journalContentHint: String
    val achievementHint: String
    val moodLabel: String
    val exportJournal: String
    val deleteAction: String
    val privateLocalNotice: String
}

data class DisciplineStringsData(
    override val tabHabits: String,
    override val tabJournal: String,
    override val addHabit: String,
    override val habitNameHint: String,
    override val streakLabel: String,
    override val bestStreakLabel: String,
    override val recoveryBanner: String,
    override val recoverMissedDay: String,
    override val addJournalEntry: String,
    override val journalTitleHint: String,
    override val journalContentHint: String,
    override val achievementHint: String,
    override val moodLabel: String,
    override val exportJournal: String,
    override val deleteAction: String,
    override val privateLocalNotice: String
) : DisciplineStrings

interface SettingsStrings {
    val settingsTitle: String
    val languageSetting: String
    val notificationsTitle: String
    val notificationPermissionGranted: String
    val notificationPermissionMissing: String
    val grantPermission: String
    val quietHoursTitle: String
    val prayerReminders: String
    val waterReminders: String
    val adhkarReminders: String
    val workoutReminders: String
    val bedtimeReminders: String
    val lessonReminders: String
    val hourlyMotivationReminders: String
    val motivationWindowTitle: String
    val openMotivationWindow: String
    val sendPreviewNotification: String
    val backupRestoreTitle: String
    val exportBackupBtn: String
    val importBackupBtn: String
    val saveSettings: String
    val sourcesAndIntegrityTitle: String
    val closeAction: String
    val themeModeLabel: String
    val darkGlassTheme: String
    val lightGlassTheme: String
    val countrySetting: String
    val selectCountryHint: String
    val characterGenderLabel: String
    val maleCharacter: String
    val femaleCharacter: String
    val safetyPrivacyTitle: String
    val safetyPrivacySummary: String
    val selectiveClearTitle: String
    val fullResetAction: String
    val asrSchoolLabel: String
    val hijriOffsetLabel: String
    val ramadanModeLabel: String
    val kidsModeLabel: String
    val learningModeLabel: String
    val uiTextSizeLabel: String
    val reducedMotionLabel: String
    val reminderToneLabel: String
    val previewToneAction: String
    val vibrationLabel: String
}

data class SettingsStringsData(
    override val settingsTitle: String,
    override val languageSetting: String,
    override val notificationsTitle: String,
    override val notificationPermissionGranted: String,
    override val notificationPermissionMissing: String,
    override val grantPermission: String,
    override val quietHoursTitle: String,
    override val prayerReminders: String,
    override val waterReminders: String,
    override val adhkarReminders: String,
    override val workoutReminders: String,
    override val bedtimeReminders: String,
    override val lessonReminders: String,
    override val hourlyMotivationReminders: String,
    override val motivationWindowTitle: String,
    override val openMotivationWindow: String,
    override val sendPreviewNotification: String,
    override val backupRestoreTitle: String,
    override val exportBackupBtn: String,
    override val importBackupBtn: String,
    override val saveSettings: String,
    override val sourcesAndIntegrityTitle: String,
    override val closeAction: String,
    override val themeModeLabel: String,
    override val darkGlassTheme: String,
    override val lightGlassTheme: String,
    override val countrySetting: String,
    override val selectCountryHint: String,
    override val characterGenderLabel: String,
    override val maleCharacter: String,
    override val femaleCharacter: String,
    override val safetyPrivacyTitle: String,
    override val safetyPrivacySummary: String,
    override val selectiveClearTitle: String,
    override val fullResetAction: String,
    override val asrSchoolLabel: String,
    override val hijriOffsetLabel: String,
    override val ramadanModeLabel: String,
    override val kidsModeLabel: String,
    override val learningModeLabel: String,
    override val uiTextSizeLabel: String,
    override val reducedMotionLabel: String,
    override val reminderToneLabel: String,
    override val previewToneAction: String,
    override val vibrationLabel: String
) : SettingsStrings

/**
 * Modular composite i18n container that keeps JVM constructor argument counts small
 * (well under JVM's 255-parameter signature limit) while preserving flat property access
 * across the UI via Kotlin interface delegation.
 */
data class AppStrings(
    val core: CoreNavStringsData,
    val onboarding: OnboardingStringsData,
    val home: HomeStringsData,
    val quran: QuranStringsData,
    val prayerAndDeen: PrayerAndDeenStringsData,
    val ai: AiStringsData,
    val wellness: WellnessStringsData,
    val discipline: DisciplineStringsData,
    val settings: SettingsStringsData
) : CoreNavStrings by core,
    OnboardingStrings by onboarding,
    HomeStrings by home,
    QuranStrings by quran,
    PrayerAndDeenStrings by prayerAndDeen,
    AiStrings by ai,
    WellnessStrings by wellness,
    DisciplineStrings by discipline,
    SettingsStrings by settings

val EnglishStrings = AppStrings(
    core = CoreNavStringsData(
        appName = "RuhZena",
        tagline = "Intelligent Islamic Lifestyle & Wellness Companion",
        navHome = "Home",
        navSpirituality = "Quran & Deen",
        navAi = "RuhZena AI",
        navWellness = "Wellness",
        navDiscipline = "Discipline"
    ),
    onboarding = OnboardingStringsData(
        welcomeTitle = "Welcome to RuhZena",
        welcomeSubtitle = "A privacy-first, offline-capable companion uniting faith, physical vitality, self-discipline, and knowledge.",
        chooseLanguage = "Choose Interface Language",
        pillarSpirituality = "Spirituality",
        pillarSpiritualityDesc = "Complete Quran, verified Adhkar, prayer times, Qibla & evidence-based learning.",
        pillarPhysical = "Physical Wellness",
        pillarPhysicalDesc = "Animated exercise coach, hydration, sleep routines & realistic nutrition.",
        pillarDiscipline = "Discipline",
        pillarDisciplineDesc = "Compassionate habit building, missed-goal recovery & daily consistency.",
        pillarGrowth = "Personal Growth",
        pillarGrowthDesc = "Intelligent AI guidance & private local reflection journal.",
        localPrivacyBadge = "100% Local-First • No Mandatory Account or Paywall",
        continueAction = "Continue",
        startCompanion = "Enter RuhZena",
        welcomeQuote = "Small sincere steps, guided by faith and discipline, transform an ordinary day into a life of purpose. We are here to walk that lasting change with you.",
        profileSetupTitle = "Personalize Your Companion",
        profileSetupSubtitle = "Share a few details so workouts, hydration targets, and coaching adapt precisely to you.",
        fullNameLabel = "Your Name",
        ageLabel = "Age (years)",
        weightKgLabel = "Weight (kg)",
        heightCmLabel = "Height (cm)",
        fitnessLevelLabel = "Fitness Level",
        primaryGoalLabel = "Primary Goal",
        equipmentLabel = "Available Equipment",
        limitationsLabel = "Joint / Injury Notes (optional)",
        startMyJourney = "Start My Journey",
        under13Notice = "Ages under 13 should use RuhZena with a parent or guardian's guidance."
    ),
    home = HomeStringsData(
        salamGreeting = "Assalamu Alaikum",
        nextPrayerLabel = "Next Prayer",
        prayerInPrefix = "in",
        dailyOverviewTitle = "Today's Overview",
        hydrationLabel = "Hydration",
        workoutLabel = "Workouts",
        habitsLabel = "Habits",
        sleepLabel = "Sleep",
        nutritionLabel = "Nutrition",
        continueReadingQuran = "Continue Reading",
        dailyIslamicLesson = "Daily Reflection",
        quickActionsTitle = "Quick Access",
        qiblaAction = "Qibla",
        tasbihAction = "Tasbih",
        adhkarAction = "Adhkar",
        duaAction = "Dua",
        journalAction = "Journal",
        aiCoachAction = "Ask AI",
        offlineBadge = "Offline Ready",
        onlineBadge = "Online"
    ),
    quran = QuranStringsData(
        tabQuran = "Quran",
        tabPrayerQibla = "Prayer & Qibla",
        tabAdhkarDua = "Adhkar & Dua",
        tabTasbih = "Tasbih",
        tabLessons = "Daily Hikmah",
        searchSurahHint = "Search all 114 Surahs...",
        surahsCountLabel = "114 Surahs",
        ayahsLabel = "Ayahs",
        reciterLabel = "Reciter",
        selectReciter = "Select Verified Reciter",
        playSurah = "Play Surah",
        pauseAudio = "Pause",
        resumeAudio = "Resume",
        nextAyah = "Next Ayah",
        prevAyah = "Prev Ayah",
        repeatAyah = "Repeat Ayah",
        repeatSurah = "Repeat Surah",
        playbackSpeed = "Speed",
        showPronunciation = "Show Pronunciation",
        hidePronunciation = "Hide Pronunciation",
        pronunciationNote = "Phonetic Guide (English)",
        pronunciationDisclaimer = "Phonetic transliteration aids reading; listen to the verified reciter audio for authentic Tajweed.",
        textSizeLabel = "Arabic Size",
        downloadAllSurahs = "Download All 114 Surahs for Offline",
        downloadingSurahs = "Downloading verified Quran dataset...",
        offlineReadyLabel = "Saved Offline",
        cachedOffline = "Available Offline",
        requiresOnlineOnce = "Tap to fetch & cache once when online",
        audioLoading = "Buffering recitation...",
        audioError = "Unable to stream recitation. Check connection.",
        bookmarkSaved = "Bookmark saved",
        bookmarkRemoved = "Bookmark removed",
        bookmarksFilter = "Bookmarks",
        deeperContextTitle = "Historical & Surah Context"
    ),
    prayerAndDeen = PrayerAndDeenStringsData(
        prayerTimesTitle = "Prayer Schedule",
        qiblaCompassTitle = "Qibla Compass",
        calculationMethod = "Calculation Method",
        locationLabel = "Location",
        detectLocation = "Use GPS Location",
        manualCity = "Select City",
        qiblaBearingLabel = "Qibla Bearing",
        compassStatusActive = "Live Magnetometer Active",
        compassStatusNoSensor = "Compass sensor unavailable — using manual bearing fallback",
        compassCalibrationTip = "Move your phone in a figure-8 motion away from metal to calibrate.",
        manualQiblaFallback = "Face the exact degree shown relative to True North.",
        fajr = "Fajr",
        sunrise = "Sunrise",
        dhuhr = "Dhuhr",
        asr = "Asr",
        maghrib = "Maghrib",
        isha = "Isha",
        morningAdhkar = "Morning",
        eveningAdhkar = "Evening",
        bedtimeAdhkar = "Bedtime",
        afterPrayerAdhkar = "After Prayer",
        adhkarSection = "Adhkar",
        duaSection = "Dua Collection",
        tasbihTitle = "Digital Tasbih",
        tapToCount = "Tap to Count Dhikr",
        resetCounter = "Reset",
        customDhikrHint = "Custom Dhikr phrase...",
        targetLabel = "Target",
        sessionsCompleted = "Sessions",
        referenceSource = "Source",
        listenPronunciation = "Listen (Human Voice)",
        explanationTitle = "Explanation & Spiritual Wisdom",
        lifeLessonTitle = "Practical Life Lesson",
        openFullGuide = "Open Full Guide & Explanation",
        explanationAction = "Explanation",
        meaningTitle = "Full Meaning",
        tasbihVirtuesTitle = "Virtues, Rewards & Sources",
        tapForTasbihVirtues = "Tap to read virtues & Hadith sources"
    ),
    ai = AiStringsData(
        aiTitle = "RuhZena AI",
        aiModeIslamic = "Scholar & Coach",
        aiModeWellness = "Heart Companion",
        aiAskHintIslamic = "Ask about Quran, Hadith, Fiqh, Seerah, or everyday guidance...",
        aiAskHintWellness = "Talk about life, workouts, hydration, habits, or emotional calm...",
        aiSend = "Send",
        aiNewChat = "New Session",
        aiClearHistory = "Delete History",
        aiModelManager = "RuhZeba AI Controls",
        aiResearchMode = "Online Research Retrieval",
        aiResearchOnlineDesc = "RuhZeba AI combines verified Quran & Hadith knowledge with structured sources.",
        aiResearchOfflineDesc = "Offline verified corpus active. Unverified claims are never invented.",
        aiDeviceTierLightweight = "Life & Companion Mode",
        aiDeviceTierBalanced = "Knowledge & Solver Mode",
        aiDeviceTierAdvanced = "Comprehensive Guidance",
        aiStatusReadyOnDevice = "RuhZeba AI Active",
        aiStatusGroundedLocal = "RuhZeba AI • Offline Corpus",
        aiStatusDownloading = "Preparing...",
        aiStatusInitializing = "Connecting...",
        evidenceQuran = "1. Quranic Evidence",
        evidenceHadith = "2. Hadith Evidence",
        evidenceScholarly = "3. Scholarly Explanations",
        evidenceIkhtilaf = "4. Scholarly Differences",
        evidenceAiSynthesis = "5. Explanation & Practical Guidance",
        medicalDisclaimer = "Wellness coaching provides lifestyle education only and is not medical advice.",
        downloadModel = "Download Model",
        deleteModel = "Delete Model",
        loadModel = "Load Into Memory",
        unloadModel = "Unload",
        aiCitedSourcesTitle = "Cited Sources",
        aiExplanationSectionTitle = "Explanation & Context"
    ),
    wellness = WellnessStringsData(
        tabWorkouts = "Workouts & Demos",
        tabHydration = "Hydration",
        tabNutrition = "Nutrition",
        tabSleep = "Sleep",
        animatedDemoTitle = "Animated Movement Demonstration",
        playDemo = "Play",
        pauseDemo = "Pause",
        replayDemo = "Replay",
        slowMotion = "Slow",
        repeatLoop = "Loop",
        captionsToggle = "Captions",
        movementStepLabel = "Movement Phase",
        musclesInvolved = "Target Areas",
        breathingCue = "Breathing Guidance",
        postureCheckpoints = "Posture Checkpoints",
        commonMistakes = "Common Mistakes to Avoid",
        easierAlternative = "Easier Regression",
        progressionOption = "Advanced Progression",
        restTimerTitle = "Rest Timer",
        startRest = "Start Rest",
        logWorkout = "Complete & Log Workout",
        workoutLoggedMsg = "Workout saved locally",
        generatePersonalizedPlan = "Personalize Plan",
        hydrationGoalTitle = "Daily Hydration",
        addWaterCustom = "Custom ml",
        logMealTitle = "Log Meal",
        mealNameHint = "Meal or food name",
        caloriesHint = "Calories (kcal)",
        proteinHint = "Protein (g)",
        carbsHint = "Carbs (g)",
        fatHint = "Fat (g)",
        estimatedDataTag = "User Estimate",
        verifiedDataTag = "USDA / Verified Reference",
        logSleepTitle = "Log Sleep Session",
        sleepDurationLabel = "Sleep Duration",
        bedtimeLabel = "Bedtime",
        wakeTimeLabel = "Wake Time",
        sleepQualityLabel = "Rest Quality",
        sleepRoutineTip = "Sunnah & Circadian Routine",
        recommendedTodayLabel = "Recommended Today",
        intensityLabel = "Intensity",
        formGuideMode = "Motion Guide",
        studioPhotoMode = "Realistic Anatomy",
        whyHydrationMatters = "Why Hydration Matters",
        scanMealPhotoTitle = "AI Meal Photo Analyzer",
        takeMealPhoto = "Take Photo",
        chooseMealPhoto = "Choose Photo",
        analyzingMealPhoto = "Analyzing meal nutrition & health impact...",
        logAnalyzedMeal = "1-Tap Log Meal",
        searchMealsHint = "Search quick meals..."
    ),
    discipline = DisciplineStringsData(
        tabHabits = "Habits & Goals",
        tabJournal = "Private Journal",
        addHabit = "New Habit Goal",
        habitNameHint = "e.g., Pray Fajr on time, Read 10 min Quran...",
        streakLabel = "Streak",
        bestStreakLabel = "Best",
        recoveryBanner = "Missed a day? Consistency grows through gentle return, never guilt.",
        recoverMissedDay = "Log Recovery Reflection",
        addJournalEntry = "New Journal Entry",
        journalTitleHint = "Reflection title...",
        journalContentHint = "Write freely — stored privately on your device...",
        achievementHint = "Small win or gratitude (optional)",
        moodLabel = "Mood",
        exportJournal = "Export JSON",
        deleteAction = "Delete",
        privateLocalNotice = "Encrypted-scope local Room storage. Never uploaded to any server."
    ),
    settings = SettingsStringsData(
        settingsTitle = "Settings",
        languageSetting = "App Language",
        notificationsTitle = "Reminders & Permissions",
        notificationPermissionGranted = "Notifications Permitted",
        notificationPermissionMissing = "Notification Permission Required",
        grantPermission = "Grant Permission",
        quietHoursTitle = "Quiet Hours (Do Not Disturb)",
        prayerReminders = "Prayer Reminders",
        waterReminders = "Hydration Reminders",
        adhkarReminders = "Morning & Evening Adhkar",
        workoutReminders = "Workout Reminders",
        bedtimeReminders = "Bedtime Reminders",
        lessonReminders = "Daily Islamic Lesson",
        hourlyMotivationReminders = "Hourly Motivation & Knowledge",
        motivationWindowTitle = "Motivation & Reminders",
        openMotivationWindow = "Motivation & Reminders Window",
        sendPreviewNotification = "Send Preview Notification",
        backupRestoreTitle = "Backup & Restore (Local JSON)",
        exportBackupBtn = "Export Backup",
        importBackupBtn = "Restore Backup",
        saveSettings = "Save",
        sourcesAndIntegrityTitle = "Sources & Attribution",
        closeAction = "Close",
        themeModeLabel = "Visual Theme",
        darkGlassTheme = "Dark Obsidian Glass",
        lightGlassTheme = "Light White & Grey-Black Glass",
        countrySetting = "Country / Region",
        selectCountryHint = "Select your country for regional prayer defaults & food presets",
        characterGenderLabel = "Gender",
        maleCharacter = "Male",
        femaleCharacter = "Female",
        safetyPrivacyTitle = "Safety & Privacy",
        safetyPrivacySummary = "All personal wellness logs, habits, and journal reflections stay encrypted-scope locally on your device. Online AI requests send only your prompt and optional wellness summary to RuhZeba AI when connected, never selling or profiling your data.",
        selectiveClearTitle = "Selective Data Clear",
        fullResetAction = "Reset All Data",
        asrSchoolLabel = "Asr Juristic School",
        hijriOffsetLabel = "Hijri Date Offset",
        ramadanModeLabel = "Ramadan Mode",
        kidsModeLabel = "Kids Friendly Mode",
        learningModeLabel = "Learning Mode",
        uiTextSizeLabel = "Interface Text Size",
        reducedMotionLabel = "Reduced Motion",
        reminderToneLabel = "Reminder Sound",
        previewToneAction = "Preview Sound",
        vibrationLabel = "Vibration"
    )
)

val BanglaStrings = AppStrings(
    core = CoreNavStringsData(
        appName = "রূহযেনা",
        tagline = "বুদ্ধিমান ইসলামিক জীবনধারা ও সুস্থতার সঙ্গী",
        navHome = "হোম",
        navSpirituality = "কুরআন ও দ্বীন",
        navAi = "রূহযেবা AI",
        navWellness = "সুস্থতা",
        navDiscipline = "শৃঙ্খলা"
    ),
    onboarding = OnboardingStringsData(
        welcomeTitle = "রূহযেনায় স্বাগতম",
        welcomeSubtitle = "ঈমান, শারীরিক সুস্থতা, আত্মশৃঙ্খলা ও জ্ঞানের সমন্বয়ে আপনার ব্যক্তিগত ও অফলাইন-সক্ষম সঙ্গী।",
        chooseLanguage = "অ্যাপের ভাষা নির্বাচন করুন",
        pillarSpirituality = "আধ্যাত্মিকতা",
        pillarSpiritualityDesc = "সম্পূর্ণ কুরআন, প্রামাণিক যিকির, নামাজের সময়, কিবলা ও দলিলভিত্তিক জ্ঞান।",
        pillarPhysical = "শারীরিক সুস্থতা",
        pillarPhysicalDesc = "অ্যানিমেটেড ব্যায়াম কোচ, পানি পান, ঘুমের রুটিন ও পুষ্টি ট্র্যাকিং।",
        pillarDiscipline = "আত্মশৃঙ্খলা",
        pillarDisciplineDesc = "অপরাধবোধহীন ভালো অভ্যাস গঠন ও নিয়মিত হওয়ার সহায়তা।",
        pillarGrowth = "ব্যক্তিগত উন্নয়ন",
        pillarGrowthDesc = "স্মার্ট AI দিকনির্দেশনা এবং সম্পূর্ণ ব্যক্তিগত ডায়েরি।",
        localPrivacyBadge = "১০০% লোকাল • কোনো বাধ্যতামূলক লগইন বা সাবস্ক্রিপশন নেই",
        continueAction = "এগিয়ে যান",
        startCompanion = "প্রবেশ করুন",
        welcomeQuote = "ঈমান ও আত্মশৃঙ্খলার ছোট্ট কিন্তু আন্তরিক প্রতিটি পদক্ষেপই আপনার সাধারণ দিনকে অর্থবহ জীবনে রূপান্তরিত করতে পারে। এই ইতিবাচক পরিবর্তনের পথে আমরা আপনার পাশে আছি।",
        profileSetupTitle = "ব্যক্তিগত প্রোফাইল সেটআপ",
        profileSetupSubtitle = "আপনার ব্যায়াম, পানি পান ও পরামর্শগুলো ব্যক্তিগতভাবে সাজাতে নিচের তথ্যগুলো দিন।",
        fullNameLabel = "আপনার নাম",
        ageLabel = "বয়স (বছর)",
        weightKgLabel = "ওজন (কেজি)",
        heightCmLabel = "উচ্চতা (সে.মি.)",
        fitnessLevelLabel = "ফিটনেস স্তর",
        primaryGoalLabel = "মূল লক্ষ্য",
        equipmentLabel = "উপলব্ধ সরঞ্জাম",
        limitationsLabel = "হাঁটু/কোমর সতর্কতা (ঐচ্ছিক)",
        startMyJourney = "আমার যাত্রা শুরু করুন",
        under13Notice = "১৩ বছরের কম বয়সীদের অভিভাবকের তত্ত্বাবধানে অ্যাপ ব্যবহার করার পরামর্শ দেওয়া হচ্ছে।"
    ),
    home = HomeStringsData(
        salamGreeting = "আসসালামু আলাইকুম",
        nextPrayerLabel = "পরবর্তী নামাজ",
        prayerInPrefix = "বাকি",
        dailyOverviewTitle = "দৈনিক ছন্দ",
        hydrationLabel = "পানি পান",
        workoutLabel = "ব্যায়াম",
        habitsLabel = "অভ্যাস",
        sleepLabel = "ঘুম",
        nutritionLabel = "পুষ্টি",
        continueReadingQuran = "পড়া চালিয়ে যান",
        dailyIslamicLesson = "আজকের প্রামাণিক শিক্ষা",
        quickActionsTitle = "দ্রুত প্রবেশ",
        qiblaAction = "কিবলা",
        tasbihAction = "তাসবিহ",
        adhkarAction = "আযকার",
        duaAction = "দুআ",
        journalAction = "জার্নাল",
        aiCoachAction = "AI প্রশ্ন",
        offlineBadge = "অফলাইন প্রস্তুত",
        onlineBadge = "অনলাইন"
    ),
    quran = QuranStringsData(
        tabQuran = "কুরআন",
        tabPrayerQibla = "নামাজ ও কিবলা",
        tabAdhkarDua = "আযকার ও দুআ",
        tabTasbih = "তাসবিহ",
        tabLessons = "হিকমাহ ও জ্ঞান",
        searchSurahHint = "১১৪টি সূরা অনুসন্ধান করুন...",
        surahsCountLabel = "১১৪ সূরা",
        ayahsLabel = "আয়াত",
        reciterLabel = "ক্বারী",
        selectReciter = "প্রামাণিক ক্বারী নির্বাচন করুন",
        playSurah = "সূরা শুনুন",
        pauseAudio = "বিরতি",
        resumeAudio = "চালু করুন",
        nextAyah = "পরবর্তী আয়াত",
        prevAyah = "পূর্ববর্তী আয়াত",
        repeatAyah = "আয়াত পুনরাবৃত্তি",
        repeatSurah = "সূরা পুনরাবৃত্তি",
        playbackSpeed = "গতি",
        showPronunciation = "উচ্চারণ দেখান",
        hidePronunciation = "উচ্চারণ লুকান",
        pronunciationNote = "বাংলা উচ্চারণ নির্দেশিকা",
        pronunciationDisclaimer = "বাংলা উচ্চারণ কেবল পড়ার সহায়ক; সঠিক তাজউইদের জন্য ক্বারীর তিলাওয়াত শুনুন।",
        textSizeLabel = "আরবি ফন্ট সাইজ",
        downloadAllSurahs = "অফলাইনের জন্য ১১৪ সূরা ডাউনলোড করুন",
        downloadingSurahs = "প্রামাণিক কুরআন ডেটা ডাউনলোড হচ্ছে...",
        offlineReadyLabel = "অফলাইনে সংরক্ষিত",
        cachedOffline = "অফলাইনে পড়ার যোগ্য",
        requiresOnlineOnce = "অনলাইনে একবার ট্যাপ করে সংরক্ষণ করুন",
        audioLoading = "তিলাওয়াত লোড হচ্ছে...",
        audioError = "তিলাওয়াত চালানো যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করুন।",
        bookmarkSaved = "বুকমার্ক সংরক্ষিত হয়েছে",
        bookmarkRemoved = "বুকমার্ক সরানো হয়েছে",
        bookmarksFilter = "বুকমার্ক",
        deeperContextTitle = "ঐতিহাসিক ও সূরার ধারাবাহিক প্রেক্ষাপট"
    ),
    prayerAndDeen = PrayerAndDeenStringsData(
        prayerTimesTitle = "নামাজের সময়সূচি",
        qiblaCompassTitle = "কিবলা কম্পাস",
        calculationMethod = "গণনা পদ্ধতি",
        locationLabel = "অবস্থান",
        detectLocation = "GPS অবস্থান ব্যবহার করুন",
        manualCity = "শহর নির্বাচন করুন",
        qiblaBearingLabel = "কিবলার দিক",
        compassStatusActive = "লাইভ কম্পাস সেন্সর সক্রিয়",
        compassStatusNoSensor = "কম্পাস সেন্সর নেই — ম্যানুয়াল দিক নির্দেশনা দেখানো হচ্ছে",
        compassCalibrationTip = "সঠিক দিকের জন্য ধাতব বস্তু থেকে দূরে ফোনটি ৮-আকৃতিতে ঘোরান।",
        manualQiblaFallback = "প্রকৃত উত্তর দিক থেকে প্রদর্শিত ডিগ্রি অনুযায়ী মুখ করুন।",
        fajr = "ফজর",
        sunrise = "সূর্যোদয়",
        dhuhr = "যোহর",
        asr = "আসর",
        maghrib = "মাগরিব",
        isha = "ইশা",
        morningAdhkar = "সকাল",
        eveningAdhkar = "সন্ধ্যা",
        bedtimeAdhkar = "ঘুমানোর আগে",
        afterPrayerAdhkar = "নামাজের পর",
        adhkarSection = "আযকার",
        duaSection = "দুআ সমগ্র",
        tasbihTitle = "ডিজিটাল তাসবিহ",
        tapToCount = "যিকির গণনা করতে ট্যাপ করুন",
        resetCounter = "রিসেট",
        customDhikrHint = "নিজের যিকির লিখুন...",
        targetLabel = "লক্ষ্য",
        sessionsCompleted = "সম্পন্ন",
        referenceSource = "সূত্র",
        listenPronunciation = "মানব কণ্ঠে শুনুন",
        explanationTitle = "ব্যাখ্যা ও আধ্যাত্মিক শিক্ষা",
        lifeLessonTitle = "বাস্তব জীবনের শিক্ষা",
        openFullGuide = "সম্পূর্ণ ব্যাখ্যা ও নির্দেশিকা দেখুন",
        explanationAction = "ব্যাখ্যা",
        meaningTitle = "পূর্ণ অর্থ",
        tasbihVirtuesTitle = "ফজিলত, সওয়াব ও প্রামাণিক সূত্র",
        tapForTasbihVirtues = "এই যিকিরের ফজিলত ও সূত্র দেখতে ট্যাপ করুন"
    ),
    ai = AiStringsData(
        aiTitle = "রূহযেবা এআই",
        aiModeIslamic = "জ্ঞান ও সমাধান",
        aiModeWellness = "জীবন ও সঙ্গী",
        aiAskHintIslamic = "কুরআন, হাদিস, ফিকহ, সীরাত বা দৈনন্দিন সমাধান জিজ্ঞাসা করুন...",
        aiAskHintWellness = "জীবন, ব্যায়াম, পানি, অভ্যাস বা মানসিক প্রশান্তি নিয়ে কথা বলুন...",
        aiSend = "পাঠান",
        aiNewChat = "নতুন সেশন",
        aiClearHistory = "ইতিহাস মুছুন",
        aiModelManager = "রূহযেবা এআই সেটিংস",
        aiResearchMode = "অনলাইন গবেষণা মোড",
        aiResearchOnlineDesc = "রূহযেবা এআই কুরআন, হাদিস ও নির্ভরযোগ্য তথ্যসূত্রের আলোকে উত্তর দেয়।",
        aiResearchOfflineDesc = "অফলাইন প্রামাণিক জ্ঞানভান্ডার সক্রিয়। কোনো তথ্য বানিয়ে বলা হয় না।",
        aiDeviceTierLightweight = "জীবন ও সঙ্গী মোড",
        aiDeviceTierBalanced = "জ্ঞান ও সমাধান মোড",
        aiDeviceTierAdvanced = "বিস্তারিত দিকনির্দেশনা",
        aiStatusReadyOnDevice = "রূহযেবা এআই সক্রিয়",
        aiStatusGroundedLocal = "রূহযেবা এআই • অফলাইন জ্ঞান",
        aiStatusDownloading = "প্রস্তুত হচ্ছে...",
        aiStatusInitializing = "সংযোগ হচ্ছে...",
        evidenceQuran = "১. কুরআনের দলিল",
        evidenceHadith = "২. হাদিসের দলিল",
        evidenceScholarly = "৩. আলেমদের ব্যাখ্যা",
        evidenceIkhtilaf = "৪. মতভেদ ও দৃষ্টিভঙ্গি",
        evidenceAiSynthesis = "৫. সহজ ব্যাখ্যা ও করণীয়",
        medicalDisclaimer = "স্বাস্থ্য কোচিং কেবল জীবনধারা নির্দেশনা দেয়; এটি কোনো চিকিৎসা পরামর্শ নয়।",
        downloadModel = "মডেল ডাউনলোড",
        deleteModel = "মডেল মুছুন",
        loadModel = "মেমোরিতে লোড করুন",
        unloadModel = "আনলোড",
        aiCitedSourcesTitle = "উল্লেখিত তথ্যসূত্র",
        aiExplanationSectionTitle = "বিস্তারিত ব্যাখ্যা ও প্রেক্ষাপট"
    ),
    wellness = WellnessStringsData(
        tabWorkouts = "ব্যায়াম ও ডেমো",
        tabHydration = "পানি পান",
        tabNutrition = "পুষ্টি",
        tabSleep = "ঘুম",
        animatedDemoTitle = "অ্যানিমেটেড ব্যায়াম প্রদর্শনী",
        playDemo = "চালু",
        pauseDemo = "বিরতি",
        replayDemo = "পুনরায়",
        slowMotion = "ধীর গতি",
        repeatLoop = "রিপিট",
        captionsToggle = "নির্দেশনা",
        movementStepLabel = "নড়াচড়ার ধাপ",
        musclesInvolved = "সক্রিয় পেশী ও অংশ",
        breathingCue = "শ্বাস-প্রশ্বাসের নিয়ম",
        postureCheckpoints = "সঠিক ভঙ্গির নির্দেশনা",
        commonMistakes = "সাধারণ ভুলসমূহ",
        easierAlternative = "সহজ বিকল্প",
        progressionOption = "উন্নত ধাপ",
        restTimerTitle = "বিশ্রাম টাইমার",
        startRest = "বিশ্রাম শুরু",
        logWorkout = "ব্যায়াম সম্পন্ন ও সংরক্ষণ",
        workoutLoggedMsg = "ব্যায়াম লোকালি সংরক্ষিত হয়েছে",
        generatePersonalizedPlan = "ব্যক্তিগত পরিকল্পনা তৈরি",
        hydrationGoalTitle = "দৈনিক পানি পান",
        addWaterCustom = "কাস্টম মি.লি.",
        logMealTitle = "খাবার যোগ করুন",
        mealNameHint = "খাবারের নাম",
        caloriesHint = "ক্যালোরি (kcal)",
        proteinHint = "প্রোটিন (গ্রাম)",
        carbsHint = "শর্করা (গ্রাম)",
        fatHint = "চর্বি (গ্রাম)",
        estimatedDataTag = "ব্যবহারকারীর অনুমান",
        verifiedDataTag = "USDA / প্রামাণিক তথ্য",
        logSleepTitle = "ঘুমের হিসাব লিখুন",
        sleepDurationLabel = "ঘুমের সময়কাল",
        bedtimeLabel = "ঘুমানোর সময়",
        wakeTimeLabel = "ওঠার সময়",
        sleepQualityLabel = "ঘুমের মান",
        sleepRoutineTip = "সুন্নাহ ও স্বাস্থ্যকর ঘুমের রুটিন",
        recommendedTodayLabel = "আজকের বিশেষ পরামর্শ",
        intensityLabel = "তীব্রতা",
        formGuideMode = "মুভমেন্ট গাইড",
        studioPhotoMode = "বাস্তবিক অ্যানাটমি",
        whyHydrationMatters = "পানি পান কেন এত গুরুত্বপূর্ণ",
        scanMealPhotoTitle = "ছবি দেখে খাবারের পুষ্টি ও স্বাস্থ্য যাচাই",
        takeMealPhoto = "ছবি তুলুন",
        chooseMealPhoto = "গ্যালারি থেকে নিন",
        analyzingMealPhoto = "খাবারের ক্যালোরি ও স্বাস্থ্যগত মান বিশ্লেষণ হচ্ছে...",
        logAnalyzedMeal = "১-ট্যাপে খাবার যোগ করুন",
        searchMealsHint = "খাবারের প্রিসেট খুঁজুন..."
    ),
    discipline = DisciplineStringsData(
        tabHabits = "অভ্যাস ও লক্ষ্য",
        tabJournal = "ব্যক্তিগত জার্নাল",
        addHabit = "নতুন অভ্যাস যোগ",
        habitNameHint = "যেমন: ফজর সময়মতো পড়া, প্রতিদিন ১০ মিনিট কুরআন...",
        streakLabel = "ধারাবাহিকতা",
        bestStreakLabel = "সর্বোচ্চ",
        recoveryBanner = "কোনো দিন বাদ পড়েছে? লজ্জা বা চাপ নয়—সদয়ভাবে আবার শুরু করাই সাফল্য।",
        recoverMissedDay = "পুনরুদ্ধার নোট লিখুন",
        addJournalEntry = "নতুন জার্নাল লিখুন",
        journalTitleHint = "শিরোনাম...",
        journalContentHint = "নির্ভয়ে লিখুন — এটি কেবল আপনার ডিভাইসেই সংরক্ষিত থাকে...",
        achievementHint = "আজকের ছোট অর্জন বা শুকরিয়া (ঐচ্ছিক)",
        moodLabel = "মনোভাব",
        exportJournal = "JSON রপ্তানি",
        deleteAction = "মুছুন",
        privateLocalNotice = "সম্পূর্ণ স্থানীয়ভাবে সংরক্ষিত। কোনো সার্ভারে পাঠানো হয় না।"
    ),
    settings = SettingsStringsData(
        settingsTitle = "সেটিংস",
        languageSetting = "অ্যাপের ভাষা",
        notificationsTitle = "রিমাইন্ডার ও অনুমতি",
        notificationPermissionGranted = "নোটিফিকেশন অনুমোদিত",
        notificationPermissionMissing = "নোটিফিকেশন অনুমতি প্রয়োজন",
        grantPermission = "অনুমতি দিন",
        quietHoursTitle = "নীরব সময় (Quiet Hours)",
        prayerReminders = "নামাজের রিমাইন্ডার",
        waterReminders = "পানি পানের রিমাইন্ডার",
        adhkarReminders = "সকাল-সন্ধ্যার আযকার",
        workoutReminders = "ব্যায়ামের রিমাইন্ডার",
        bedtimeReminders = "ঘুমানোর রিমাইন্ডার",
        lessonReminders = "দৈনিক ইসলামিক শিক্ষা",
        hourlyMotivationReminders = "ঘণ্টায় ঘণ্টায় অনুপ্রেরণা ও জ্ঞান",
        motivationWindowTitle = "অনুপ্রেরণা ও রিমাইন্ডার",
        openMotivationWindow = "অনুপ্রেরণা ও রিমাইন্ডার উইন্ডো",
        sendPreviewNotification = "প্রিভিউ নোটিফিকেশন পাঠান",
        backupRestoreTitle = "ব্যাকআপ ও পুনরুদ্ধার (লোকাল JSON)",
        exportBackupBtn = "ব্যাকআপ সেভ",
        importBackupBtn = "রিস্টোর করুন",
        saveSettings = "সংরক্ষণ",
        sourcesAndIntegrityTitle = "তথ্যসূত্র ও সত্যতা",
        closeAction = "বন্ধ করুন",
        themeModeLabel = "অ্যাপের থিম",
        darkGlassTheme = "ডার্ক গ্লাস (কালো)",
        lightGlassTheme = "হোয়াইট ও গ্রে-ব্ল্যাক গ্লাস (সাদা)",
        countrySetting = "দেশ / অঞ্চল",
        selectCountryHint = "নামাজের নিয়ম ও খাবারের প্রিসেটের জন্য দেশ নির্বাচন করুন",
        characterGenderLabel = "লিঙ্গ",
        maleCharacter = "পুরুষ",
        femaleCharacter = "নারী",
        safetyPrivacyTitle = "নিরাপত্তা ও গোপনীয়তা",
        safetyPrivacySummary = "আপনার জার্নাল, অভ্যাস ও স্বাস্থ্য লগ সম্পূর্ণ আপনার ডিভাইসেই সংরক্ষিত থাকে। কেবল অনলাইনে রূহযেবা এআই ব্যবহার করলে প্রয়োজনীয় প্রশ্ন পাঠানো হয়।",
        selectiveClearTitle = "নির্দিষ্ট তথ্য মুছুন",
        fullResetAction = "সব ডেটা রিসেট করুন",
        asrSchoolLabel = "আসর নামাজের মাজহাব",
        hijriOffsetLabel = "হিজরি তারিখ সমন্বয়",
        ramadanModeLabel = "রমজান মোড",
        kidsModeLabel = "শিশু-বান্ধব মোড",
        learningModeLabel = "শেখার মোড",
        uiTextSizeLabel = "অ্যাপের লেখার আকার",
        reducedMotionLabel = "কম অ্যানিমেশন",
        reminderToneLabel = "রিমাইন্ডারের শব্দ",
        previewToneAction = "শব্দ শুনুন",
        vibrationLabel = "ভাইব্রেশন"
    )
)

val LocalStrings = staticCompositionLocalOf { EnglishStrings }
val LocalAppLanguage = staticCompositionLocalOf { AppLanguage.ENGLISH }

fun stringsFor(language: AppLanguage): AppStrings = when (language) {
    AppLanguage.ENGLISH -> EnglishStrings
    AppLanguage.BANGLA -> BanglaStrings
    AppLanguage.ARABIC -> ArabicStrings
    AppLanguage.URDU -> UrduStrings
    AppLanguage.TURKISH -> TurkishStrings
    AppLanguage.INDONESIAN -> IndonesianStrings
    AppLanguage.MALAY -> MalayStrings
    AppLanguage.FRENCH -> FrenchStrings
}
