package com.example.ruhzena.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.School
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.ruhzena.ai.agent.AiPersonality
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.SegmentedGlassTabRow
import com.example.ruhzena.core.ui.SegmentedTabItem
import com.example.ruhzena.data.islamic.AdhkarCategory
import com.example.ruhzena.media.LocalRuhZenaSound
import com.example.ruhzena.ui.components.DockDestination
import com.example.ruhzena.ui.components.FirstTimeTutorialOverlay
import com.example.ruhzena.ui.components.LiquidGlassAudioPlayerBar
import com.example.ruhzena.ui.components.LocalTutorialTargets
import com.example.ruhzena.ui.components.PortalQuickLaunch
import com.example.ruhzena.ui.components.SanctuaryCompassDock
import com.example.ruhzena.ui.components.SanctuaryPortalOverlay
import com.example.ruhzena.ui.components.TutorialPageId
import com.example.ruhzena.ui.components.TutorialSpotlightRegistry
import com.example.ruhzena.ui.screens.AiAssistantScreen
import com.example.ruhzena.ui.screens.BookmarksHubDialog
import com.example.ruhzena.ui.screens.DisciplineJournalScreen
import com.example.ruhzena.ui.screens.DisciplineSubTab
import com.example.ruhzena.ui.screens.GlobalSearchAction
import com.example.ruhzena.ui.screens.GlobalSearchDialog
import com.example.ruhzena.ui.screens.HifzCompanionDialog
import com.example.ruhzena.ui.screens.HomeDashboardScreen
import com.example.ruhzena.ui.screens.HomeQuickDestination
import com.example.ruhzena.ui.screens.IslamicLearningHubScreen
import com.example.ruhzena.ui.screens.LearningHubTab
import com.example.ruhzena.ui.screens.MotivationAndRemindersDialog
import com.example.ruhzena.ui.screens.MyDayAndJourneyDialog
import com.example.ruhzena.ui.screens.OnboardingScreen
import com.example.ruhzena.ui.screens.SettingsBottomSheet
import com.example.ruhzena.ui.screens.SettingsMenuSection
import com.example.ruhzena.ui.screens.SpiritualityHubScreen
import com.example.ruhzena.ui.screens.SpiritualitySubTab
import com.example.ruhzena.ui.screens.WellnessHubScreen
import com.example.ruhzena.ui.screens.WellnessSubTab
import com.example.ui.theme.LocalRuhZenaPalette
import kotlinx.serialization.Serializable

@Serializable object HomeRoute
@Serializable object SpiritualityRoute
@Serializable object AiRoute
@Serializable object LearningHubRoute
@Serializable object LifeRoute
@Serializable object WellnessRoute
@Serializable object DisciplineRoute

private data class RailNavItem(
    val route: Any,
    val routeName: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private enum class LifeHubSection { WELLNESS, DISCIPLINE }

@Composable
fun RuhZenaApp(
    viewModel: RuhZenaViewModel,
    initialOpenMutePicker: Boolean = false,
    initialOpenHydration: Boolean = false,
    isSignedIn: Boolean = false,
    signedInUserName: String = "",
    signedInUserEmail: String = "",
    onSignOut: () -> Unit = {}
) {
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val prefsReady by viewModel.preferencesReady.collectAsStateWithLifecycle()
    val cloudSyncStatus by viewModel.cloudSyncStatus.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val audioState by viewModel.audioState.collectAsStateWithLifecycle()
    val quranState by viewModel.quranState.collectAsStateWithLifecycle()
    val cachedSurahs by viewModel.cachedSurahNumbers.collectAsStateWithLifecycle()
    val aiUiState by viewModel.aiUiState.collectAsStateWithLifecycle()
    val unifiedAiMessages by viewModel.unifiedAiMessages.collectAsStateWithLifecycle()
    val aiMemories by viewModel.aiMemories.collectAsStateWithLifecycle()
    val aiTasks by viewModel.aiTasks.collectAsStateWithLifecycle()
    val activeAiTask by viewModel.activeAiTask.collectAsStateWithLifecycle()
    val providerHealth by viewModel.providerHealth.collectAsStateWithLifecycle()
    val providerCredentials by viewModel.providerCredentials.collectAsStateWithLifecycle()
    val providerPingResults by viewModel.providerPingResults.collectAsStateWithLifecycle()
    val testingProviderId by viewModel.testingProviderId.collectAsStateWithLifecycle()
    val prayerSchedule by viewModel.prayerSchedule.collectAsStateWithLifecycle()
    val nextPrayer by viewModel.nextPrayer.collectAsStateWithLifecycle()
    val waterMlToday by viewModel.waterMlToday.collectAsStateWithLifecycle()
    val waterLogsToday by viewModel.waterLogsToday.collectAsStateWithLifecycle()
    val waterLogsLast7Days by viewModel.waterLogsLast7Days.collectAsStateWithLifecycle()
    val waterLogsLast30Days by viewModel.waterLogsLast30Days.collectAsStateWithLifecycle()
    val mealsToday by viewModel.mealsToday.collectAsStateWithLifecycle()
    val mealsLast7Days by viewModel.mealsLast7Days.collectAsStateWithLifecycle()
    val mealsLast30Days by viewModel.mealsLast30Days.collectAsStateWithLifecycle()
    val mealScanState by viewModel.mealScanState.collectAsStateWithLifecycle()
    val hasPreviousMealScan by viewModel.hasPreviousMealScan.collectAsStateWithLifecycle()
    val recentWorkouts by viewModel.recentWorkouts.collectAsStateWithLifecycle()
    val workoutsLast7Days by viewModel.workoutsLast7Days.collectAsStateWithLifecycle()
    val workoutsLast30Days by viewModel.workoutsLast30Days.collectAsStateWithLifecycle()
    val workoutsTodayCount by viewModel.workoutsTodayCount.collectAsStateWithLifecycle()
    val habits by viewModel.habits.collectAsStateWithLifecycle()
    val habitChecksToday by viewModel.habitChecksToday.collectAsStateWithLifecycle()
    val habitChecksLast30Days by viewModel.habitChecksLast30Days.collectAsStateWithLifecycle()
    val journalEntries by viewModel.journalEntries.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val tasbihCount by viewModel.tasbihCurrentCount.collectAsStateWithLifecycle()
    val ayahExplanationState by viewModel.ayahExplanationState.collectAsStateWithLifecycle()
    val citySearchResults by viewModel.citySearchResults.collectAsStateWithLifecycle()
    val isSearchingCity by viewModel.isSearchingCity.collectAsStateWithLifecycle()
    val backupStatusMessage by viewModel.backupStatusMessage.collectAsStateWithLifecycle()
    val speakingItemId by viewModel.speakingItemId.collectAsStateWithLifecycle()

    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    if (!prefs.onboardingCompleted) {
        if (!prefsReady) {
            // Prevents flashing OnboardingScreen before DataStore emits initial saved state
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(palette.voidBg, palette.surfaceBg, palette.voidBg)))
            )
            return
        }
        CompositionLocalProvider(LocalRuhZenaSound provides viewModel.soundEngine) {
            OnboardingScreen(
                prefs = prefs,
                onSelectLanguage = viewModel::setLanguage,
                onSelectThemeMode = viewModel::setThemeMode,
                onSelectCountry = { viewModel.setCountry(it, updateLocationDefaults = true) },
                onDetectCountryViaGps = viewModel::detectCountryViaGps,
                onSaveProfile = viewModel::saveOnboardingProfile
            )
        }
        return
    }

    val strings = LocalStrings.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: HomeRoute::class.qualifiedName

    var showSettingsSheet by remember { mutableStateOf(false) }
    var settingsInitialSection by remember { mutableStateOf(SettingsMenuSection.HUB) }
    var showMotivationWindow by remember { mutableStateOf(initialOpenMutePicker || initialOpenHydration) }
    var showGlobalSearch by remember { mutableStateOf(false) }
    var showBookmarksHub by remember { mutableStateOf(false) }
    var showMyDayDialog by remember { mutableStateOf(false) }
    var showHifzDialog by remember { mutableStateOf(false) }
    var portalExpanded by remember { mutableStateOf(false) }
    var showTutorialReplay by rememberSaveable { mutableStateOf(false) }

    var urgeDialogTrigger by rememberSaveable { mutableIntStateOf(0) }
    var spiritualityTab by rememberSaveable { mutableStateOf(SpiritualitySubTab.QURAN) }
    var openQuranReader by rememberSaveable { mutableStateOf(false) }
    var pendingScrollAyah by rememberSaveable { mutableStateOf<Int?>(null) }
    var openDuaDirectly by rememberSaveable { mutableStateOf(false) }
    var pendingDuaId by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingDuaQuery by rememberSaveable { mutableStateOf<String?>(null) }
    var guidedTasbihCategory by rememberSaveable { mutableStateOf<AdhkarCategory?>(null) }
    var returnAdhkarCategory by rememberSaveable { mutableStateOf<AdhkarCategory?>(null) }
    var learningInitialTab by remember { mutableStateOf<LearningHubTab?>(null) }
    var activeLearningTab by rememberSaveable { mutableStateOf(LearningHubTab.GUIDED_PATH) }
    var lifeSection by rememberSaveable { mutableStateOf(LifeHubSection.WELLNESS) }
    var wellnessTab by rememberSaveable { mutableStateOf(WellnessSubTab.WORKOUTS) }
    var disciplineTab by rememberSaveable { mutableStateOf(DisciplineSubTab.HABITS) }

    val railItems = remember(strings, isBn) {
        listOf(
            RailNavItem(HomeRoute, HomeRoute::class.qualifiedName.orEmpty(), strings.navHome, Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
            RailNavItem(SpiritualityRoute, SpiritualityRoute::class.qualifiedName.orEmpty(), strings.navSpirituality, Icons.AutoMirrored.Filled.MenuBook, Icons.AutoMirrored.Outlined.MenuBook, "nav_spirituality"),
            RailNavItem(AiRoute, AiRoute::class.qualifiedName.orEmpty(), "AI", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome, "nav_ai"),
            RailNavItem(LearningHubRoute, LearningHubRoute::class.qualifiedName.orEmpty(), if (isBn) "শিক্ষা" else "Learn", Icons.Filled.School, Icons.Outlined.School, "nav_learn"),
            RailNavItem(WellnessRoute, WellnessRoute::class.qualifiedName.orEmpty(), strings.navWellness, Icons.Filled.FitnessCenter, Icons.Outlined.FitnessCenter, "nav_wellness"),
            RailNavItem(DisciplineRoute, DisciplineRoute::class.qualifiedName.orEmpty(), strings.navDiscipline, Icons.Filled.CheckCircle, Icons.Outlined.CheckCircle, "nav_discipline")
        )
    }

    fun navigateTop(route: Any) {
        portalExpanded = false
        navController.navigate(route) {
            popUpTo(HomeRoute) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun openAiWithPrefill(legacyModeHint: String, prompt: String) {
        val targetPersonality = if (legacyModeHint.equals("EXPERT", ignoreCase = true)) {
            AiPersonality.PRACTICAL_EXPERT
        } else {
            null
        }
        viewModel.setAiPrefillPrompt(prompt, targetPersonality)
        navigateTop(AiRoute)
    }

    val activeDockDest = when (currentRoute) {
        HomeRoute::class.qualifiedName -> DockDestination.HOME
        SpiritualityRoute::class.qualifiedName -> DockDestination.DEEN
        AiRoute::class.qualifiedName -> DockDestination.AI
        LearningHubRoute::class.qualifiedName -> DockDestination.LEARN
        LifeRoute::class.qualifiedName, WellnessRoute::class.qualifiedName, DisciplineRoute::class.qualifiedName -> DockDestination.LIFE
        else -> DockDestination.HOME
    }

    if (portalExpanded) {
        BackHandler { portalExpanded = false }
    } else if (currentRoute == SpiritualityRoute::class.qualifiedName &&
        spiritualityTab == SpiritualitySubTab.QURAN &&
        openQuranReader
    ) {
        BackHandler { openQuranReader = false }
    }

    val tutorialRegistry = remember { TutorialSpotlightRegistry() }
    val completedTutorialPages = remember(prefs.completedTutorialPagesCsv, prefs.tutorialCompleted) {
        val set = prefs.completedTutorialPagesCsv
            .split(',')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toMutableSet()
        if (prefs.tutorialCompleted) set.add(TutorialPageId.HOME.name)
        set.toSet()
    }
    val hasBlockingModal = showSettingsSheet || portalExpanded || showGlobalSearch ||
        showBookmarksHub || showMyDayDialog || showHifzDialog || showMotivationWindow

    val currentPageTutorial: TutorialPageId? = when (currentRoute) {
        HomeRoute::class.qualifiedName -> TutorialPageId.HOME
        SpiritualityRoute::class.qualifiedName -> when (spiritualityTab) {
            SpiritualitySubTab.QURAN -> if (openQuranReader) TutorialPageId.DEEN_SURAH_READER else TutorialPageId.DEEN_QURAN
            SpiritualitySubTab.PRAYER_QIBLA -> TutorialPageId.DEEN_PRAYER
            SpiritualitySubTab.ADHKAR_DUA -> TutorialPageId.DEEN_ADHKAR_DUA
            SpiritualitySubTab.TASBIH -> TutorialPageId.DEEN_TASBIH
            SpiritualitySubTab.LESSONS -> null
        }
        AiRoute::class.qualifiedName -> TutorialPageId.AI_CHAT
        LearningHubRoute::class.qualifiedName -> if (prefs.learningTrackChosen || learningInitialTab != null) {
            if (activeLearningTab == LearningHubTab.ARABIC_STUDIO) TutorialPageId.LEARN_ARABIC else TutorialPageId.LEARN_HUB
        } else TutorialPageId.LEARN_GATE
        LifeRoute::class.qualifiedName -> if (lifeSection == LifeHubSection.WELLNESS) {
            when (wellnessTab) {
                WellnessSubTab.WORKOUTS -> TutorialPageId.LIFE_WORKOUTS
                WellnessSubTab.HYDRATION -> TutorialPageId.LIFE_HYDRATION
                WellnessSubTab.NUTRITION -> TutorialPageId.LIFE_NUTRITION
            }
        } else {
            when (disciplineTab) {
                DisciplineSubTab.HABITS -> TutorialPageId.LIFE_HABITS
                DisciplineSubTab.JOURNAL -> TutorialPageId.LIFE_JOURNAL
            }
        }
        WellnessRoute::class.qualifiedName -> when (wellnessTab) {
            WellnessSubTab.WORKOUTS -> TutorialPageId.LIFE_WORKOUTS
            WellnessSubTab.HYDRATION -> TutorialPageId.LIFE_HYDRATION
            WellnessSubTab.NUTRITION -> TutorialPageId.LIFE_NUTRITION
        }
        DisciplineRoute::class.qualifiedName -> when (disciplineTab) {
            DisciplineSubTab.HABITS -> TutorialPageId.LIFE_HABITS
            DisciplineSubTab.JOURNAL -> TutorialPageId.LIFE_JOURNAL
        }
        else -> null
    }

    val homeTutorialDone = completedTutorialPages.contains(TutorialPageId.HOME.name)
    val pendingTutorialPage: TutorialPageId? = if (prefsReady && prefs.onboardingCompleted && !hasBlockingModal) {
        when {
            showTutorialReplay -> currentPageTutorial ?: TutorialPageId.HOME
            currentPageTutorial == TutorialPageId.HOME && !homeTutorialDone -> TutorialPageId.HOME
            currentPageTutorial != null && currentPageTutorial != TutorialPageId.HOME &&
                homeTutorialDone && !completedTutorialPages.contains(currentPageTutorial.name) -> currentPageTutorial
            else -> null
        }
    } else null

    var settledTutorialPage by remember { mutableStateOf<TutorialPageId?>(null) }
    LaunchedEffect(pendingTutorialPage) {
        if (pendingTutorialPage == null) {
            settledTutorialPage = null
        } else {
            // Brief settle pause so screen transition finishes and spotlight coordinates are exact
            delay(240L)
            settledTutorialPage = pendingTutorialPage
        }
    }

    CompositionLocalProvider(
        LocalRuhZenaSound provides viewModel.soundEngine,
        LocalTutorialTargets provides tutorialRegistry
    ) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(palette.voidBg, palette.surfaceBg, palette.voidBg)))
    ) {
        val useRail = maxWidth >= 600.dp

        Box(modifier = Modifier.fillMaxSize()) {
            Row(modifier = Modifier.fillMaxSize()) {
                if (useRail) {
                    NavigationRail(
                        containerColor = palette.navBarBg,
                        modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))
                        railItems.forEach { item ->
                            val selected = currentRoute == item.routeName
                            val iconScale by animateFloatAsState(
                                targetValue = if (selected) 1.15f else 1f,
                                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                                label = "railIconScale"
                            )
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTop(item.route) },
                                icon = {
                                    if (item.route == AiRoute) {
                                        val logoTint = if (selected) palette.accentPrimary else palette.textSecondary
                                        Image(
                                            painter = painterResource(id = R.drawable.ruhzena_emblem),
                                            contentDescription = "RuhZena AI",
                                            contentScale = ContentScale.Fit,
                                            colorFilter = ColorFilter.tint(logoTint, BlendMode.SrcIn),
                                            modifier = Modifier
                                                .size(22.dp)
                                                .scale(iconScale)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label,
                                            modifier = Modifier.scale(iconScale)
                                        )
                                    }
                                },
                                label = { Text(item.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = palette.accentPrimary,
                                    selectedTextColor = palette.accentPrimary,
                                    indicatorColor = palette.accentContainer,
                                    unselectedIconColor = palette.textSecondary,
                                    unselectedTextColor = palette.textMuted
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                Scaffold(
                    containerColor = Color.Transparent,
                    contentWindowInsets = if (useRail) {
                        WindowInsets.safeDrawing
                    } else {
                        WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal)
                    },
                    bottomBar = {
                        Column(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            AnimatedVisibility(
                                visible = audioState.activeSurahNumber > 0 || audioState.isDhikrMode,
                                enter = slideInVertically { it } + fadeIn(),
                                exit = slideOutVertically { it } + fadeOut()
                            ) {
                                LiquidGlassAudioPlayerBar(
                                    state = audioState,
                                    onTogglePlayPause = viewModel.audioController::togglePlayPause,
                                    onPrev = viewModel.audioController::previousAyah,
                                    onNext = viewModel.audioController::nextAyah,
                                    onJumpToAyah = viewModel.audioController::jumpToAyah,
                                    onSelectReciter = viewModel::selectReciter,
                                    onRepeatAyah = viewModel.audioController::toggleRepeatAyah,
                                    onRepeatSurah = viewModel.audioController::toggleRepeatSurah,
                                    onSetSpeed = viewModel.audioController::setPlaybackSpeed,
                                    onSeek = viewModel.audioController::seekTo,
                                    onSetVolume = viewModel.audioController::setVolume,
                                    onSetSleepTimerMinutes = viewModel.audioController::setSleepTimerMinutes,
                                    onSetSleepAtEndOfSurah = { viewModel.audioController.setSleepAtEndOfSurah(true) },
                                    onCancelSleepTimer = viewModel.audioController::cancelSleepTimer,
                                    onOpenHifzDialog = { showHifzDialog = true },
                                    onClose = viewModel.audioController::stopPlayback
                                )
                            }

                            if (!useRail) {
                                SanctuaryCompassDock(
                                    selected = activeDockDest,
                                    portalExpanded = portalExpanded,
                                    onSelect = { dest ->
                                        when (dest) {
                                            DockDestination.HOME -> navigateTop(HomeRoute)
                                            DockDestination.DEEN -> navigateTop(SpiritualityRoute)
                                            DockDestination.AI -> navigateTop(AiRoute)
                                            DockDestination.LEARN -> {
                                                learningInitialTab = null
                                                navigateTop(LearningHubRoute)
                                            }
                                            DockDestination.LIFE -> navigateTop(LifeRoute)
                                        }
                                    },
                                    onTogglePortal = { portalExpanded = it }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Box(modifier = Modifier.widthIn(max = 680.dp).fillMaxSize()) {
                            NavHost(
                                navController = navController,
                                startDestination = HomeRoute,
                                enterTransition = {
                                    fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                                        slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { it / 12 } +
                                        scaleIn(initialScale = 0.975f, animationSpec = tween(240, easing = FastOutSlowInEasing))
                                },
                                exitTransition = {
                                    fadeOut(tween(180, easing = FastOutSlowInEasing)) +
                                        slideOutHorizontally(tween(200, easing = FastOutSlowInEasing)) { -it / 16 } +
                                        scaleOut(targetScale = 0.985f, animationSpec = tween(180))
                                },
                                popEnterTransition = {
                                    fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                                        slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { -it / 12 } +
                                        scaleIn(initialScale = 0.975f, animationSpec = tween(240, easing = FastOutSlowInEasing))
                                },
                                popExitTransition = {
                                    fadeOut(tween(180, easing = FastOutSlowInEasing)) +
                                        slideOutHorizontally(tween(200, easing = FastOutSlowInEasing)) { it / 16 } +
                                        scaleOut(targetScale = 0.985f, animationSpec = tween(180))
                                }
                            ) {
                                composable<HomeRoute> {
                                    val doneIds = habitChecksToday.map { it.habitId }.toSet()
                                    HomeDashboardScreen(
                                        prefs = prefs,
                                        isOnline = isOnline,
                                        nextPrayer = nextPrayer,
                                        prayerSchedule = prayerSchedule,
                                        waterMlToday = waterMlToday,
                                        workoutsTodayCount = workoutsTodayCount,
                                        habitsDoneCount = habits.count { doneIds.contains(it.id) },
                                        totalHabitsCount = habits.size,
                                        caloriesToday = mealsToday.sumOf { it.calories },
                                        mealsTodayCount = mealsToday.size,
                                        weeklyWaterLogs = waterLogsLast7Days,
                                        habitChecks30Days = habitChecksLast30Days,
                                        recentWorkouts = recentWorkouts,
                                        onOpenSettings = { showSettingsSheet = true },
                                        onOpenSearch = { showGlobalSearch = true },
                                        onOpenMotivationWindow = { showMotivationWindow = true },
                                        onDismissMotivationBanner = { viewModel.setMotivationBannerDismissed(true) },
                                        onQuickAction = { dest ->
                                            when (dest) {
                                                HomeQuickDestination.QURAN_CONTINUE -> {
                                                    pendingScrollAyah = prefs.lastReadAyah
                                                    spiritualityTab = SpiritualitySubTab.QURAN
                                                    viewModel.loadSurah(prefs.lastReadSurah)
                                                    openQuranReader = true
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                HomeQuickDestination.PRAYER_QIBLA -> {
                                                    spiritualityTab = SpiritualitySubTab.PRAYER_QIBLA
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                HomeQuickDestination.TASBIH -> {
                                                    spiritualityTab = SpiritualitySubTab.TASBIH
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                HomeQuickDestination.ADHKAR -> {
                                                    openDuaDirectly = false
                                                    spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                HomeQuickDestination.DUA -> {
                                                    openDuaDirectly = true
                                                    spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                HomeQuickDestination.HYDRATION -> {
                                                    lifeSection = LifeHubSection.WELLNESS
                                                    wellnessTab = WellnessSubTab.HYDRATION
                                                    navigateTop(if (useRail) WellnessRoute else LifeRoute)
                                                }
                                                HomeQuickDestination.WORKOUTS -> {
                                                    lifeSection = LifeHubSection.WELLNESS
                                                    wellnessTab = WellnessSubTab.WORKOUTS
                                                    navigateTop(if (useRail) WellnessRoute else LifeRoute)
                                                }
                                                HomeQuickDestination.NUTRITION -> {
                                                    lifeSection = LifeHubSection.WELLNESS
                                                    wellnessTab = WellnessSubTab.NUTRITION
                                                    navigateTop(if (useRail) WellnessRoute else LifeRoute)
                                                }
                                                HomeQuickDestination.HABITS -> {
                                                    lifeSection = LifeHubSection.DISCIPLINE
                                                    disciplineTab = DisciplineSubTab.HABITS
                                                    navigateTop(if (useRail) DisciplineRoute else LifeRoute)
                                                }
                                                HomeQuickDestination.JOURNAL -> {
                                                    lifeSection = LifeHubSection.DISCIPLINE
                                                    disciplineTab = DisciplineSubTab.JOURNAL
                                                    navigateTop(if (useRail) DisciplineRoute else LifeRoute)
                                                }
                                                HomeQuickDestination.AI_CHAT -> navigateTop(AiRoute)
                                                HomeQuickDestination.LEARNING_HUB -> {
                                                    learningInitialTab = null
                                                    navigateTop(LearningHubRoute)
                                                }
                                                HomeQuickDestination.MY_DAY_JOURNEY -> showMyDayDialog = true
                                            }
                                        }
                                    )
                                }

                                composable<SpiritualityRoute> {
                                    SpiritualityHubScreen(
                                        selectedTab = spiritualityTab,
                                        onSelectTab = {
                                            spiritualityTab = it
                                            if (it != SpiritualitySubTab.QURAN) openQuranReader = false
                                        },
                                        openQuranReader = openQuranReader,
                                        onSetQuranReaderOpen = { openQuranReader = it },
                                        initialShowDua = openDuaDirectly,
                                        pendingDuaId = pendingDuaId,
                                        pendingDuaQuery = pendingDuaQuery,
                                        onConsumedPendingDua = {
                                            pendingDuaId = null
                                            pendingDuaQuery = null
                                        },
                                        pendingScrollAyah = pendingScrollAyah,
                                        onConsumedScrollAyah = { pendingScrollAyah = null },
                                        prefs = prefs,
                                        quranState = quranState,
                                        ayahExplanationState = ayahExplanationState,
                                        cachedSurahs = cachedSurahs,
                                        audioState = audioState,
                                        bookmarks = bookmarks,
                                        isOnline = isOnline,
                                        prayerSchedule = prayerSchedule,
                                        nextPrayer = nextPrayer,
                                        citySearchResults = citySearchResults,
                                        isSearchingCity = isSearchingCity,
                                        tasbihCount = tasbihCount,
                                        activeTasbihCategory = guidedTasbihCategory,
                                        returnAdhkarCategory = returnAdhkarCategory,
                                        onStartGuidedTasbih = { category ->
                                            guidedTasbihCategory = category
                                            returnAdhkarCategory = category
                                            viewModel.resetTasbih()
                                            spiritualityTab = SpiritualitySubTab.TASBIH
                                        },
                                        onCompleteGuidedTasbih = { completedCategory ->
                                            guidedTasbihCategory = null
                                            returnAdhkarCategory = completedCategory
                                            openDuaDirectly = false
                                            spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                                        },
                                        onClearGuidedTasbih = { guidedTasbihCategory = null },
                                        speakingItemId = speakingItemId,
                                        onSpeakArabic = viewModel::speakArabic,
                                        onSpeakLocalized = viewModel::speakLocalized,
                                        onSelectSurah = viewModel::loadSurah,
                                        onPlaySurahAyah = viewModel::playSurahAudio,
                                        onTogglePlayPause = viewModel.audioController::togglePlayPause,
                                        onSelectReciter = viewModel::selectReciter,
                                        onChangeFontSize = viewModel::setQuranFontSize,
                                        onTogglePronunciation = viewModel::setShowPronunciation,
                                        onDownloadAllOffline = viewModel::downloadAllSurahsOffline,
                                        onToggleBookmark = viewModel::toggleBookmark,
                                        onMarkLastRead = viewModel::updateLastReadAyah,
                                        onLoadAyahExplanation = { ayah -> viewModel.loadAyahExplanation(ayah, forceRefresh = false) },
                                        onRetryAyahExplanation = { ayah -> viewModel.loadAyahExplanation(ayah, forceRefresh = true) },
                                        onClearAyahExplanation = viewModel::clearAyahExplanation,
                                        onSearchCity = viewModel::searchCities,
                                        onSelectCity = { city -> viewModel.selectCityPreset(city.name, city.latitude, city.longitude, city.timeZoneId) },
                                        onSelectCalcMethod = viewModel::selectCalcMethod,
                                        onSelectAsrMethod = viewModel::setAsrJuristicMethod,
                                        onAdjustHijriOffset = viewModel::setHijriOffsetDays,
                                        onRefreshGps = viewModel::refreshGpsLocation,
                                        onPlayHumanDhikrOrDua = viewModel::playDhikrOrDuaAudio,
                                        onTapTasbih = viewModel::incrementTasbih,
                                        onUndoTasbih = viewModel::undoTasbih,
                                        onResetTasbih = viewModel::resetTasbih,
                                        onOpenGlobalSearch = { showGlobalSearch = true },
                                        onOpenBookmarksHub = { showBookmarksHub = true },
                                        onOpenLearningHub = {
                                            learningInitialTab = null
                                            navigateTop(LearningHubRoute)
                                        },
                                        onAskRuhZebaAi = ::openAiWithPrefill
                                    )
                                }

                                composable<AiRoute> {
                                    // Reset session greeting when leaving AI so returning starts a fresh session (Salam once per visit)
                                    DisposableEffect(Unit) {
                                        onDispose { viewModel.onExitAiSession() }
                                    }
                                    AiAssistantScreen(
                                        uiState = aiUiState,
                                        messages = unifiedAiMessages,
                                        memories = aiMemories,
                                        tasks = aiTasks,
                                        activeTask = activeAiTask,
                                        isOnline = isOnline,
                                        onSelectPersonality = viewModel::setAiPersonality,
                                        onToggleResearchOnline = viewModel::setResearchOnline,
                                        onSendPrompt = viewModel::askAi,
                                        onClearHistory = viewModel::clearAllAiChatHistory,
                                        onApproveMemory = viewModel::approveMemoryProposal,
                                        onDismissMemoryProposal = viewModel::dismissMemoryProposal,
                                        onAddManualMemory = viewModel::addManualAiMemory,
                                        onToggleMemoryActive = viewModel::toggleAiMemoryActive,
                                        onDeleteMemory = viewModel::deleteAiMemory,
                                        onCompleteTask = viewModel::completeAiTask,
                                        onDeleteTask = viewModel::deleteAiTask,
                                        onDismissError = viewModel::dismissAiError,
                                        onRetryLastPrompt = viewModel::retryLastAiPrompt,
                                        onConsumePrefill = viewModel::consumeAiPrefillPrompt,
                                        onTriggerAiAction = { rawTag ->
                                            val tag = rawTag.trim()
                                            val upper = tag.uppercase()
                                            when {
                                                upper.startsWith("SURAH:") -> {
                                                    val parts = upper.removePrefix("SURAH:").split(":")
                                                    val surahNum = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(1, 114) ?: 1
                                                    val ayahNum = parts.getOrNull(1)?.toIntOrNull()
                                                    pendingScrollAyah = ayahNum
                                                    spiritualityTab = SpiritualitySubTab.QURAN
                                                    viewModel.loadSurah(surahNum)
                                                    openQuranReader = true
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                upper.startsWith("DUA_ID:") -> {
                                                    val duaId = tag.substringAfter("DUA_ID:", "").trim()
                                                    openDuaDirectly = true
                                                    pendingDuaId = duaId
                                                    pendingDuaQuery = null
                                                    spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                upper.startsWith("DUA:") -> {
                                                    val query = tag.substringAfter(":", "").trim()
                                                    openDuaDirectly = true
                                                    pendingDuaId = null
                                                    pendingDuaQuery = query
                                                    spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                upper == "DUA" -> {
                                                    openDuaDirectly = true
                                                    pendingDuaId = null
                                                    pendingDuaQuery = null
                                                    spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                upper.startsWith("ADHKAR:") -> {
                                                    val catName = upper.removePrefix("ADHKAR:")
                                                    returnAdhkarCategory = AdhkarCategory.entries.find { it.name == catName }
                                                    openDuaDirectly = false
                                                    spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                upper == "ADHKAR" -> {
                                                    openDuaDirectly = false
                                                    spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                upper == "TASBIH" -> {
                                                    spiritualityTab = SpiritualitySubTab.TASBIH
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                upper == "QIBLA" || upper == "PRAYER_TIMES" -> {
                                                    spiritualityTab = SpiritualitySubTab.PRAYER_QIBLA
                                                    navigateTop(SpiritualityRoute)
                                                }
                                                upper == "WUDU_GUIDE" || upper == "SALAH_GUIDE" -> {
                                                    learningInitialTab = LearningHubTab.HOW_TO_PRAY
                                                    navigateTop(LearningHubRoute)
                                                }
                                                upper == "ARABIC_STUDIO" -> {
                                                    learningInitialTab = LearningHubTab.ARABIC_STUDIO
                                                    navigateTop(LearningHubRoute)
                                                }
                                                upper == "STORIES" -> {
                                                    learningInitialTab = LearningHubTab.STORIES
                                                    navigateTop(LearningHubRoute)
                                                }
                                                upper == "HAJJ_UMRAH" -> {
                                                    learningInitialTab = LearningHubTab.HAJJ_UMRAH
                                                    navigateTop(LearningHubRoute)
                                                }
                                                upper == "LESSONS" -> {
                                                    learningInitialTab = LearningHubTab.GUIDED_PATH
                                                    navigateTop(LearningHubRoute)
                                                }
                                                upper == "HIFZ" -> showHifzDialog = true
                                                upper == "WORKOUTS" -> {
                                                    lifeSection = LifeHubSection.WELLNESS
                                                    wellnessTab = WellnessSubTab.WORKOUTS
                                                    navigateTop(if (useRail) WellnessRoute else LifeRoute)
                                                }
                                                upper == "HYDRATION" -> {
                                                    lifeSection = LifeHubSection.WELLNESS
                                                    wellnessTab = WellnessSubTab.HYDRATION
                                                    navigateTop(if (useRail) WellnessRoute else LifeRoute)
                                                }
                                                upper == "NUTRITION" -> {
                                                    lifeSection = LifeHubSection.WELLNESS
                                                    wellnessTab = WellnessSubTab.NUTRITION
                                                    navigateTop(if (useRail) WellnessRoute else LifeRoute)
                                                }
                                                upper == "HABITS" -> {
                                                    lifeSection = LifeHubSection.DISCIPLINE
                                                    disciplineTab = DisciplineSubTab.HABITS
                                                    navigateTop(if (useRail) DisciplineRoute else LifeRoute)
                                                }
                                                upper == "JOURNAL" -> {
                                                    lifeSection = LifeHubSection.DISCIPLINE
                                                    disciplineTab = DisciplineSubTab.JOURNAL
                                                    navigateTop(if (useRail) DisciplineRoute else LifeRoute)
                                                }
                                                upper == "HABIT_RECOVERY" || upper == "BREATHING" -> {
                                                    lifeSection = LifeHubSection.DISCIPLINE
                                                    disciplineTab = DisciplineSubTab.HABITS
                                                    urgeDialogTrigger++
                                                    navigateTop(if (useRail) DisciplineRoute else LifeRoute)
                                                }
                                                upper == "BOOKMARKS" -> showBookmarksHub = true
                                                upper == "MY_DAY" -> showMyDayDialog = true
                                            }
                                        },
                                        speakingItemId = speakingItemId,
                                        onSpeakAiMessage = viewModel::speakAiReply
                                    )
                                }

                                composable<LearningHubRoute> {
                                    IslamicLearningHubScreen(
                                        prefs = prefs,
                                        initialTab = learningInitialTab,
                                        speakingItemId = speakingItemId,
                                        onSpeakArabic = viewModel::speakArabic,
                                        onSpeakLocalized = viewModel::speakLocalized,
                                        onStopSpeech = viewModel::stopSpeech,
                                        onCompleteLearningStep = viewModel::completeLearningStep,
                                        onSetLearningAllAccess = viewModel::setLearningAllAccess,
                                        onSelectLearningExperience = viewModel::selectLearningExperience,
                                        onToggleArabicLetterMastered = viewModel::toggleArabicLetterMastered,
                                        onActiveTabChanged = { activeLearningTab = it },
                                        onBack = { navigateTop(HomeRoute) },
                                        onAskRuhZebaAi = ::openAiWithPrefill
                                    )
                                }

                                composable<LifeRoute> {
                                    Column(modifier = Modifier.fillMaxSize()) {
                                        SegmentedGlassTabRow(
                                            items = listOf(
                                                SegmentedTabItem(LifeHubSection.WELLNESS, strings.navWellness, "life_tab_wellness"),
                                                SegmentedTabItem(LifeHubSection.DISCIPLINE, strings.navDiscipline, "life_tab_discipline")
                                            ),
                                            selected = lifeSection,
                                            onSelect = { lifeSection = it },
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                        )
                                        if (lifeSection == LifeHubSection.WELLNESS) {
                                            WellnessHubScreen(
                                                selectedTab = wellnessTab,
                                                onSelectTab = { wellnessTab = it },
                                                prefs = prefs,
                                                waterMlToday = waterMlToday,
                                                waterLogs = waterLogsToday,
                                                weeklyWaterLogs = waterLogsLast7Days,
                                                mealsToday = mealsToday,
                                                mealScanState = mealScanState,
                                                hasPreviousMealScan = hasPreviousMealScan,
                                                recentWorkouts = recentWorkouts,
                                                onAddWater = viewModel::addWater,
                                                onDeleteWater = viewModel::deleteWaterLog,
                                                onSetWaterGoal = viewModel::setHydrationGoal,
                                                onAddMeal = viewModel::addMeal,
                                                onDeleteMeal = viewModel::deleteMeal,
                                                onAnalyzeMealPhoto = viewModel::analyzeMealPhoto,
                                                onReanalyzeMealPhoto = viewModel::reanalyzeLastMealPhoto,
                                                onRestorePreviousMealScan = viewModel::restorePreviousMealScan,
                                                onClearMealScan = viewModel::clearMealScan,
                                                onLogWorkout = viewModel::logWorkout,
                                                onUpdateBiometricProfile = { n, a, w, h, lvl, goal, eq, lim ->
                                                    viewModel.updateFitnessProfile(
                                                        name = n,
                                                        ageYears = a,
                                                        weightKg = w,
                                                        heightCm = h,
                                                        level = lvl,
                                                        goal = goal,
                                                        equipment = eq,
                                                        limitation = lim
                                                    )
                                                },
                                                formatTime = viewModel::formatTimestamp,
                                                onSelectCharacterGender = { g ->
                                                    viewModel.updateFitnessProfile(
                                                        characterGender = g,
                                                        level = prefs.fitnessLevel,
                                                        goal = prefs.fitnessGoal,
                                                        equipment = prefs.availableEquipment,
                                                        limitation = prefs.fitnessLimitation
                                                    )
                                                },
                                                onAskRuhZebaAi = ::openAiWithPrefill
                                            )
                                        } else {
                                            DisciplineJournalScreen(
                                                selectedTab = disciplineTab,
                                                onSelectTab = { disciplineTab = it },
                                                habits = habits,
                                                checksToday = habitChecksToday,
                                                journalEntries = journalEntries,
                                                openUrgeDialogTrigger = urgeDialogTrigger,
                                                onAddHabit = viewModel::addHabit,
                                                onToggleHabit = viewModel::toggleHabit,
                                                onSaveHabitRecovery = viewModel::saveHabitRecovery,
                                                onDeleteHabit = viewModel::deleteHabit,
                                                onAddJournal = viewModel::addJournalEntry,
                                                onDeleteJournal = viewModel::deleteJournalEntry,
                                                onExportJournalJson = viewModel::exportJournalJson,
                                                formatTime = viewModel::formatTimestamp,
                                                onAskRuhZebaAi = ::openAiWithPrefill,
                                                speakingItemId = speakingItemId,
                                                onSpeakArabic = viewModel::speakArabic
                                            )
                                        }
                                    }
                                }

                                composable<WellnessRoute> {
                                    WellnessHubScreen(
                                        selectedTab = wellnessTab,
                                        onSelectTab = { wellnessTab = it },
                                        prefs = prefs,
                                        waterMlToday = waterMlToday,
                                        waterLogs = waterLogsToday,
                                        weeklyWaterLogs = waterLogsLast7Days,
                                        mealsToday = mealsToday,
                                        mealScanState = mealScanState,
                                        hasPreviousMealScan = hasPreviousMealScan,
                                        recentWorkouts = recentWorkouts,
                                        onAddWater = viewModel::addWater,
                                        onDeleteWater = viewModel::deleteWaterLog,
                                        onSetWaterGoal = viewModel::setHydrationGoal,
                                        onAddMeal = viewModel::addMeal,
                                        onDeleteMeal = viewModel::deleteMeal,
                                        onAnalyzeMealPhoto = viewModel::analyzeMealPhoto,
                                        onReanalyzeMealPhoto = viewModel::reanalyzeLastMealPhoto,
                                        onRestorePreviousMealScan = viewModel::restorePreviousMealScan,
                                        onClearMealScan = viewModel::clearMealScan,
                                        onLogWorkout = viewModel::logWorkout,
                                        onUpdateBiometricProfile = { n, a, w, h, lvl, goal, eq, lim ->
                                            viewModel.updateFitnessProfile(
                                                name = n,
                                                ageYears = a,
                                                weightKg = w,
                                                heightCm = h,
                                                level = lvl,
                                                goal = goal,
                                                equipment = eq,
                                                limitation = lim
                                            )
                                        },
                                        formatTime = viewModel::formatTimestamp,
                                        onSelectCharacterGender = { g ->
                                            viewModel.updateFitnessProfile(
                                                characterGender = g,
                                                level = prefs.fitnessLevel,
                                                goal = prefs.fitnessGoal,
                                                equipment = prefs.availableEquipment,
                                                limitation = prefs.fitnessLimitation
                                            )
                                        },
                                        onAskRuhZebaAi = ::openAiWithPrefill
                                    )
                                }

                                composable<DisciplineRoute> {
                                    DisciplineJournalScreen(
                                        selectedTab = disciplineTab,
                                        onSelectTab = { disciplineTab = it },
                                        habits = habits,
                                        checksToday = habitChecksToday,
                                        journalEntries = journalEntries,
                                        openUrgeDialogTrigger = urgeDialogTrigger,
                                        onAddHabit = viewModel::addHabit,
                                        onToggleHabit = viewModel::toggleHabit,
                                        onSaveHabitRecovery = viewModel::saveHabitRecovery,
                                        onDeleteHabit = viewModel::deleteHabit,
                                        onAddJournal = viewModel::addJournalEntry,
                                        onDeleteJournal = viewModel::deleteJournalEntry,
                                        onExportJournalJson = viewModel::exportJournalJson,
                                        formatTime = viewModel::formatTimestamp,
                                        onAskRuhZebaAi = ::openAiWithPrefill,
                                        speakingItemId = speakingItemId,
                                        onSpeakArabic = viewModel::speakArabic
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Upgraded Futuristic Liquid-Glass Customizable Quick Jump Command Deck
            val activeQuickJumpShortcuts = remember(prefs.quickJumpSlotsCsv) {
                PortalQuickLaunch.fromCsv(prefs.quickJumpSlotsCsv)
            }
            SanctuaryPortalOverlay(
                visible = portalExpanded,
                activeShortcuts = activeQuickJumpShortcuts,
                onDismiss = { portalExpanded = false },
                onEditInSettings = {
                    settingsInitialSection = SettingsMenuSection.QUICK_JUMP
                    showSettingsSheet = true
                },
                onLaunch = { action ->
                    portalExpanded = false
                    when (action) {
                        PortalQuickLaunch.CONTINUE_QURAN -> {
                            viewModel.loadSurah(prefs.lastReadSurah.coerceIn(1, 114))
                            spiritualityTab = SpiritualitySubTab.QURAN
                            openQuranReader = true
                            navigateTop(SpiritualityRoute)
                        }
                        PortalQuickLaunch.PRAYER_QIBLA -> {
                            spiritualityTab = SpiritualitySubTab.PRAYER_QIBLA
                            navigateTop(SpiritualityRoute)
                        }
                        PortalQuickLaunch.DAILY_DUAS -> {
                            openDuaDirectly = true
                            spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                            navigateTop(SpiritualityRoute)
                        }
                        PortalQuickLaunch.TASBIH_3D -> {
                            spiritualityTab = SpiritualitySubTab.TASBIH
                            navigateTop(SpiritualityRoute)
                        }
                        PortalQuickLaunch.URGE_RESET -> {
                            lifeSection = LifeHubSection.DISCIPLINE
                            disciplineTab = DisciplineSubTab.HABITS
                            urgeDialogTrigger++
                            navigateTop(if (useRail) DisciplineRoute else LifeRoute)
                        }
                        PortalQuickLaunch.QUICK_WATER -> {
                            viewModel.addWater(250)
                            lifeSection = LifeHubSection.WELLNESS
                            wellnessTab = WellnessSubTab.HYDRATION
                            navigateTop(if (useRail) WellnessRoute else LifeRoute)
                        }
                        PortalQuickLaunch.ARABIC_STUDIO -> {
                            learningInitialTab = LearningHubTab.ARABIC_STUDIO
                            navigateTop(LearningHubRoute)
                        }
                        PortalQuickLaunch.WORKOUTS_3D -> {
                            lifeSection = LifeHubSection.WELLNESS
                            wellnessTab = WellnessSubTab.WORKOUTS
                            navigateTop(if (useRail) WellnessRoute else LifeRoute)
                        }
                        PortalQuickLaunch.MEAL_SCANNER -> {
                            lifeSection = LifeHubSection.WELLNESS
                            wellnessTab = WellnessSubTab.NUTRITION
                            navigateTop(if (useRail) WellnessRoute else LifeRoute)
                        }
                        PortalQuickLaunch.HABITS_JOURNAL -> {
                            lifeSection = LifeHubSection.DISCIPLINE
                            disciplineTab = DisciplineSubTab.HABITS
                            navigateTop(if (useRail) DisciplineRoute else LifeRoute)
                        }
                        PortalQuickLaunch.HIFZ_COMPANION -> {
                            showHifzDialog = true
                        }
                        PortalQuickLaunch.STORIES -> {
                            learningInitialTab = LearningHubTab.STORIES
                            navigateTop(LearningHubRoute)
                        }
                        PortalQuickLaunch.BOOKMARKS -> {
                            showBookmarksHub = true
                        }
                        PortalQuickLaunch.GLOBAL_SEARCH -> {
                            showGlobalSearch = true
                        }
                    }
                }
            )

            // Contextual Per-Page Spotlight Guide (activates automatically on first visit to Home & every other page)
            settledTutorialPage?.let { activePage ->
                FirstTimeTutorialOverlay(
                    page = activePage,
                    activeQuickJumpShortcuts = activeQuickJumpShortcuts,
                    onFinish = {
                        showTutorialReplay = false
                        settledTutorialPage = null
                        viewModel.markTutorialPageCompleted(activePage.name)
                    },
                    onTryQuickJumpNow = {
                        showTutorialReplay = false
                        settledTutorialPage = null
                        viewModel.markTutorialPageCompleted(activePage.name)
                        portalExpanded = true
                    }
                )
            }
        }
    }

    if (showSettingsSheet) {
        SettingsBottomSheet(
            prefs = prefs,
            backupStatusMessage = backupStatusMessage,
            initialSection = settingsInitialSection,
            onDismiss = {
                showSettingsSheet = false
                settingsInitialSection = SettingsMenuSection.HUB
            },
            onSelectLanguage = viewModel::setLanguage,
            onSelectThemeMode = viewModel::setThemeMode,
            onSelectCountry = { viewModel.setCountry(it, updateLocationDefaults = true) },
            onSetUiFontScale = viewModel::setUiFontScale,
            onSetReducedMotion = viewModel::setReducedMotion,
            onSetAsrMethod = viewModel::setAsrJuristicMethod,
            onSetHijriOffset = viewModel::setHijriOffsetDays,
            onSetRamadanMode = viewModel::setRamadanModeEnabled,
            onSetKidsMode = viewModel::setKidsModeEnabled,
            onSetLearningMode = viewModel::setLearningMode,
            onSetNotificationTone = viewModel::setNotificationTone,
            onSetNotificationVibration = viewModel::setNotificationVibration,
            onUpdateBiometricProfile = viewModel::updateFitnessProfile,
            onUpdateReminders = viewModel::updateReminderSettings,
            onOpenMotivationWindow = { showMotivationWindow = true },
            onExportBackup = viewModel::exportBackupToUri,
            onImportBackup = viewModel::importBackupFromUri,
            onClearJournal = viewModel::clearJournalData,
            onClearHabits = viewModel::clearHabitsData,
            onClearWellness = viewModel::clearWellnessData,
            onClearAiChat = viewModel::clearAllAiChatHistory,
            onResetAllData = viewModel::resetAllAppData,
            onClearBackupStatus = viewModel::clearBackupStatus,
            providerCredentials = providerCredentials,
            providerHealth = providerHealth,
            providerPingResults = providerPingResults,
            testingProviderId = testingProviderId,
            onSaveAiProviderCredentials = viewModel::saveAiProviderCredentials,
            onTestAiProvider = viewModel::testAiProvider,
            onClearAiProviderCredentials = viewModel::clearAiProviderCredentials,
            isSignedIn = isSignedIn,
            signedInUserName = signedInUserName,
            signedInUserEmail = signedInUserEmail,
            cloudSyncStatus = cloudSyncStatus,
            onSyncCloudNow = viewModel::syncWithFirebaseCloud,
            onSignOut = {
                showSettingsSheet = false
                onSignOut()
            },
            onSetQuickJumpSlots = viewModel::setQuickJumpSlots,
            onPreviewQuickJump = { portalExpanded = true },
            onSetAdhanMuezzin = viewModel::setAdhanMuezzinId,
            onSetSpeechVoiceStyle = viewModel::setSpeechVoiceStyle,
            onReplayTutorial = {
                showSettingsSheet = false
                viewModel.resetAllTutorials()
                navigateTop(HomeRoute)
                showTutorialReplay = true
            }
        )
    }

    if (showHifzDialog) {
        HifzCompanionDialog(
            prefs = prefs,
            quranState = quranState,
            audioState = audioState,
            onSelectSurah = viewModel::loadSurah,
            onSelectReciter = viewModel::selectReciter,
            onStartHifzLoop = viewModel::playHifzRangeAudio,
            onStopAudio = viewModel.audioController::stopPlayback,
            onCompleteHifzSession = viewModel::recordHifzSession,
            onDismiss = { showHifzDialog = false }
        )
    }

    if (showMotivationWindow) {
        MotivationAndRemindersDialog(
            prefs = prefs,
            waterMlToday = waterMlToday,
            nextPrayer = nextPrayer,
            initialExpandMutePicker = initialOpenMutePicker,
            onAddWater = { viewModel.addWater(it) },
            onSnoozeWater5Min = {
                viewModel.snoozeReminder(com.example.ruhzena.notifications.RuhZenaReminderWorker.TYPE_WATER, 5L)
            },
            onMuteForHours = viewModel::muteNotificationsForHours,
            onUnmuteNotifications = viewModel::unmuteNotifications,
            onSendPreviewNotification = viewModel::sendPreviewNotification,
            onSetBannerDismissed = viewModel::setMotivationBannerDismissed,
            onDismiss = { showMotivationWindow = false }
        )
    }

    if (showGlobalSearch) {
        GlobalSearchDialog(
            onAction = { action ->
                when (action) {
                    is GlobalSearchAction.OpenSurah -> {
                        viewModel.loadSurah(action.surahNumber)
                        spiritualityTab = SpiritualitySubTab.QURAN
                        openQuranReader = true
                        navigateTop(SpiritualityRoute)
                    }
                    GlobalSearchAction.OpenAdhkar -> {
                        openDuaDirectly = false
                        spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                        navigateTop(SpiritualityRoute)
                    }
                    GlobalSearchAction.OpenDua -> {
                        openDuaDirectly = true
                        spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                        navigateTop(SpiritualityRoute)
                    }
                    GlobalSearchAction.OpenTasbih -> {
                        spiritualityTab = SpiritualitySubTab.TASBIH
                        navigateTop(SpiritualityRoute)
                    }
                    GlobalSearchAction.OpenLessons -> {
                        spiritualityTab = SpiritualitySubTab.LESSONS
                        navigateTop(SpiritualityRoute)
                    }
                    GlobalSearchAction.OpenWorkouts -> {
                        lifeSection = LifeHubSection.WELLNESS
                        wellnessTab = WellnessSubTab.WORKOUTS
                        navigateTop(LifeRoute)
                    }
                }
            },
            onDismiss = { showGlobalSearch = false }
        )
    }

    if (showBookmarksHub) {
        BookmarksHubDialog(
            bookmarks = bookmarks,
            onOpenBookmark = { bm ->
                when (bm.itemType) {
                    "QURAN" -> {
                        if (bm.surahNumber > 0) viewModel.loadSurah(bm.surahNumber)
                        spiritualityTab = SpiritualitySubTab.QURAN
                        openQuranReader = true
                        navigateTop(SpiritualityRoute)
                    }
                    "DUA" -> {
                        openDuaDirectly = true
                        spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                        navigateTop(SpiritualityRoute)
                    }
                    else -> {
                        openDuaDirectly = false
                        spiritualityTab = SpiritualitySubTab.ADHKAR_DUA
                        navigateTop(SpiritualityRoute)
                    }
                }
            },
            onRemoveBookmark = { bm -> viewModel.toggleBookmark(bm, true) },
            onDismiss = { showBookmarksHub = false }
        )
    }

    if (showMyDayDialog) {
        MyDayAndJourneyDialog(
            prefs = prefs,
            nextPrayer = nextPrayer,
            prayerSchedule = prayerSchedule,
            waterMlToday = waterMlToday,
            mealsToday = mealsToday,
            workoutsTodayCount = workoutsTodayCount,
            habits = habits,
            habitChecksToday = habitChecksToday,
            waterLogsLast7Days = waterLogsLast7Days,
            mealsLast7Days = mealsLast7Days,
            workoutsLast7Days = workoutsLast7Days,
            waterLogsLast30Days = waterLogsLast30Days,
            mealsLast30Days = mealsLast30Days,
            workoutsLast30Days = workoutsLast30Days,
            habitChecksLast30Days = habitChecksLast30Days,
            bookmarksCount = bookmarks.size,
            journalEntriesCount = journalEntries.size,
            onToggleHabit = viewModel::toggleHabit,
            onDismiss = { showMyDayDialog = false }
        )
    }
    }
}
