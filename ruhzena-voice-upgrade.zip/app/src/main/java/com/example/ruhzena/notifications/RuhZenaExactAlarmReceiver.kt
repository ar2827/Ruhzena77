package com.example.ruhzena.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.ruhzena.data.local.RuhZenaDatabase
import com.example.ruhzena.data.local.UserPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Exact-time alarm receiver for RuhZena Adhan alerts and scheduled reminders.
 * Fires precisely at the calculated Salah Adhan minute (never every 10–15 minutes),
 * enforces per-event deduplication so no alert ever double-fires, plays the actual full
 * Muezzin Adhan for Salah alerts, and immediately schedules the next upcoming event.
 */
class RuhZenaExactAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra(EXTRA_REMINDER_TYPE) ?: return
        val prayerKey = intent.getStringExtra(EXTRA_PRAYER_KEY).orEmpty()
        val prayerTimeFormatted = intent.getStringExtra(EXTRA_PRAYER_TIME).orEmpty()
        val eventKey = intent.getStringExtra(EXTRA_EVENT_KEY).orEmpty()

        val appCtx = context.applicationContext
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (!RuhZenaNotificationHelper.hasNotificationPermission(appCtx)) {
                    return@launch
                }
                val prefs = UserPreferencesRepository(appCtx).preferencesFlow.first()

                val isPrayer = type == RuhZenaReminderWorker.TYPE_PRAYER_EXACT ||
                    type == RuhZenaReminderWorker.TYPE_PRAYER

                val nowMs = System.currentTimeMillis()
                val isMuted = nowMs < prefs.mutedUntilEpochMs

                // Quiet hours apply to non-prayer reminders ONLY; Fajr & Isha Adhan always fire on time unless explicitly muted.
                val blockedByQuietHours = !isPrayer && isWithinQuietHours(prefs)

                val alreadyFired = if (eventKey.isNotBlank()) {
                    ReminderScheduler.hasAlreadyFiredEvent(appCtx, type, eventKey)
                } else {
                    ReminderScheduler.isWithinCooldown(appCtx, type)
                }

                if (!isMuted && !blockedByQuietHours && !alreadyFired) {
                    val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                    val waterTodayMl = runCatching {
                        RuhZenaDatabase.getInstance(appCtx).waterLogDao().getTotalMlForDateSnapshot(todayKey)
                    }.getOrDefault(0)

                    ReminderScheduler.markEventFired(appCtx, type, eventKey)
                    RuhZenaReminderWorker.dispatchNotification(
                        context = appCtx,
                        type = type,
                        prefs = prefs,
                        waterTodayMl = waterTodayMl,
                        exactPrayerKeyOverride = prayerKey.ifBlank { null },
                        exactPrayerTimeOverride = prayerTimeFormatted.ifBlank { null }
                    )
                }

                // Always chain the NEXT occurrence cleanly in the future (strictly > now + 65s)
                when (type) {
                    RuhZenaReminderWorker.TYPE_PRAYER_EXACT,
                    RuhZenaReminderWorker.TYPE_PRAYER -> {
                        if (prefs.prayerRemindersEnabled) {
                            ReminderScheduler.scheduleNextExactPrayer(appCtx, prefs, minFutureOffsetMs = 70_000L)
                        }
                    }
                    RuhZenaReminderWorker.TYPE_WATER -> {
                        if (prefs.waterRemindersEnabled) {
                            ReminderScheduler.scheduleNextWaterAlarm(appCtx, minDelayMinutes = 120L)
                        }
                    }
                    RuhZenaReminderWorker.TYPE_HOURLY_MOTIVATION -> {
                        if (prefs.hourlyMotivationEnabled) {
                            ReminderScheduler.scheduleNextHourlyHikmahAlarm(appCtx)
                        }
                    }
                    RuhZenaReminderWorker.TYPE_ADHKAR -> {
                        if (prefs.adhkarRemindersEnabled) {
                            ReminderScheduler.scheduleNextDailyAlarm(
                                appCtx,
                                RuhZenaReminderWorker.TYPE_ADHKAR,
                                listOf(6 to 30, 17 to 30),
                                minDelayMinutes = 60L
                            )
                        }
                    }
                    RuhZenaReminderWorker.TYPE_WORKOUT -> {
                        if (prefs.workoutRemindersEnabled) {
                            ReminderScheduler.scheduleNextDailyAlarm(
                                appCtx,
                                RuhZenaReminderWorker.TYPE_WORKOUT,
                                listOf(18 to 0),
                                minDelayMinutes = 60L
                            )
                        }
                    }
                    RuhZenaReminderWorker.TYPE_BEDTIME -> {
                        if (prefs.bedtimeRemindersEnabled) {
                            ReminderScheduler.scheduleNextDailyAlarm(
                                appCtx,
                                RuhZenaReminderWorker.TYPE_BEDTIME,
                                listOf(22 to 0),
                                minDelayMinutes = 60L
                            )
                        }
                    }
                    RuhZenaReminderWorker.TYPE_LESSON -> {
                        if (prefs.lessonRemindersEnabled) {
                            ReminderScheduler.scheduleNextDailyAlarm(
                                appCtx,
                                RuhZenaReminderWorker.TYPE_LESSON,
                                listOf(20 to 0),
                                minDelayMinutes = 60L
                            )
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun isWithinQuietHours(prefs: com.example.ruhzena.data.local.UserPreferences): Boolean {
        if (!prefs.quietHoursEnabled) return false
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val start = prefs.quietStartHour
        val end = prefs.quietEndHour
        return if (start <= end) {
            hour in start until end
        } else {
            hour >= start || hour < end
        }
    }

    companion object {
        const val ACTION_EXACT_REMINDER = "com.example.ruhzena.ACTION_EXACT_REMINDER"
        const val EXTRA_REMINDER_TYPE = "extra_reminder_type"
        const val EXTRA_PRAYER_KEY = "extra_prayer_key"
        const val EXTRA_PRAYER_TIME = "extra_prayer_time"
        const val EXTRA_EVENT_KEY = "extra_event_key"
    }
}
