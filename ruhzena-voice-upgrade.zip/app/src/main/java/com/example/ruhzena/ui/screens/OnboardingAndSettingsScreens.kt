package com.example.ruhzena.ui.screens

import com.example.ruhzena.media.NarrationVoiceResolver
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.data.cloud.FirebaseAuthHelper
import com.example.ruhzena.data.cloud.GoogleAuthOutcome
import kotlinx.coroutines.launch
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.CountryCatalog
import com.example.ruhzena.data.islamic.CountryPreset
import com.example.ruhzena.data.islamic.NextPrayerInfo
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.media.LocalRuhZenaSound
import com.example.ruhzena.notifications.MotivationKnowledgeCatalog
import com.example.ruhzena.notifications.RuhZenaNotificationHelper
import com.example.ruhzena.notifications.RuhZenaReminderWorker
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import com.example.ui.theme.RuhZenaThemeMode
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.runtime.mutableStateMapOf
import com.example.ruhzena.ai.agent.AiModelCatalog
import com.example.ruhzena.ai.agent.AiProviderId
import com.example.ruhzena.ai.agent.ProviderPingResult
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.example.ruhzena.ai.agent.ProviderCredentialsSnapshot
import androidx.compose.ui.res.stringResource
import com.example.ruhzena.core.sensors.LocationFetchResult
import com.example.ruhzena.data.cloud.CloudSyncStatus
import com.example.ruhzena.data.local.AiProviderHealthEntity
import com.example.ruhzena.media.AdhanMuezzin
import com.example.ruhzena.media.FullAdhanAudioManager
import com.example.ruhzena.ui.components.PortalQuickLaunch
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ruhzena.ui.exercises.WorkoutEquipmentCatalog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
private fun onboardingFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = LocalRuhZenaPalette.current.accentPrimary,
    unfocusedBorderColor = LocalRuhZenaPalette.current.borderNeutral,
    focusedTextColor = LocalRuhZenaPalette.current.textPrimary,
    unfocusedTextColor = LocalRuhZenaPalette.current.textPrimary,
    focusedLabelColor = LocalRuhZenaPalette.current.accentSoft,
    unfocusedLabelColor = LocalRuhZenaPalette.current.textMuted,
    focusedPlaceholderColor = LocalRuhZenaPalette.current.textMuted,
    unfocusedPlaceholderColor = LocalRuhZenaPalette.current.textMuted
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    prefs: UserPreferences,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectThemeMode: (String) -> Unit,
    onSelectCountry: (CountryPreset) -> Unit,
    onDetectCountryViaGps: (((CountryPreset?, LocationFetchResult) -> Unit)) -> Unit = { cb ->
        cb(null, LocationFetchResult.Unavailable)
    },
    onSaveProfile: (
        name: String,
        ageYears: Int,
        weightKg: Int,
        heightCm: Int,
        characterGender: String,
        level: String,
        goal: String,
        equipment: String,
        limitation: String
    ) -> Unit
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = prefs.language == AppLanguage.BANGLA
    val context = LocalContext.current

    var currentStep by rememberSaveable { mutableIntStateOf(0) }
    var countryQuery by rememberSaveable { mutableStateOf("") }
    var countryDropdownExpanded by remember { mutableStateOf(false) }
    var isDetectingGps by remember { mutableStateOf(false) }
    var gpsStatusText by remember { mutableStateOf<String?>(null) }
    var step1Error by remember { mutableStateOf<String?>(null) }

    val requiredPermissions = remember {
        buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
    }
    var hasLocationPerm by remember { mutableStateOf(hasAnyLocationPermission(context)) }
    var hasNotifPerm by remember { mutableStateOf(RuhZenaNotificationHelper.hasNotificationPermission(context)) }
    var initialPermPrompted by rememberSaveable { mutableStateOf(false) }

    val initialPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val locGranted = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
            hasAnyLocationPermission(context)
        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            grants[Manifest.permission.POST_NOTIFICATIONS] == true ||
                RuhZenaNotificationHelper.hasNotificationPermission(context)
        } else {
            true
        }
        hasLocationPerm = locGranted
        hasNotifPerm = notifGranted
        if (locGranted && prefs.countryCode.isBlank()) {
            isDetectingGps = true
            gpsStatusText = if (isBn) "জিপিএস দিয়ে দেশ শনাক্ত করা হচ্ছে..." else "Detecting your country via GPS..."
            onDetectCountryViaGps { matched, _ ->
                isDetectingGps = false
                if (matched != null) {
                    step1Error = null
                    gpsStatusText = if (isBn) "শনাক্ত হয়েছে: ${matched.nameEn}" else "Detected: ${matched.nameEn}"
                } else {
                    gpsStatusText = null
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!initialPermPrompted && (!hasLocationPerm || !hasNotifPerm)) {
            initialPermPrompted = true
            initialPermissionLauncher.launch(requiredPermissions)
        }
    }

    val gpsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val granted = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            isDetectingGps = true
            gpsStatusText = if (isBn) "জিপিএস দিয়ে দেশ শনাক্ত করা হচ্ছে..." else "Detecting your country via GPS..."
            onDetectCountryViaGps { matched, result ->
                isDetectingGps = false
                if (matched != null) {
                    step1Error = null
                    gpsStatusText = if (isBn) "শনাক্ত হয়েছে: ${matched.nameEn}" else "Detected: ${matched.nameEn}"
                } else {
                    gpsStatusText = when (result) {
                        LocationFetchResult.LocationServicesDisabled ->
                            if (isBn) "ডিভাইসের লোকেশন (GPS) বন্ধ আছে — তালিকা থেকে দেশ নির্বাচন করুন।"
                            else "Device GPS is turned off — please enable it or select your country below."
                        LocationFetchResult.PermissionMissing ->
                            if (isBn) "অবস্থানের অনুমতি প্রয়োজন — তালিকা থেকে দেশ নির্বাচন করুন।"
                            else "Location permission needed — or select your country from the dropdown."
                        else ->
                            if (isBn) "জিপিএস ব্যর্থ হয়েছে — তালিকা থেকে দেশ নির্বাচন করুন।"
                            else "Could not detect GPS — please select your country from the dropdown."
                    }
                }
            }
        } else {
            gpsStatusText = if (isBn) "অবস্থানের অনুমতি না মেলায় তালিকা থেকে দেশ নির্বাচন করুন।" else "Location permission declined — choose your country from the dropdown below."
        }
    }

    var name by rememberSaveable { mutableStateOf("") }
    var ageText by rememberSaveable { mutableStateOf("") }
    var weightText by rememberSaveable { mutableStateOf("") }
    var heightText by rememberSaveable { mutableStateOf("") }
    var characterGender by rememberSaveable { mutableStateOf("") }
    var level by rememberSaveable { mutableStateOf(prefs.fitnessLevel) }
    var goal by rememberSaveable { mutableStateOf(prefs.fitnessGoal) }
    var equipment by rememberSaveable { mutableStateOf(prefs.availableEquipment) }
    var limitation by rememberSaveable { mutableStateOf(prefs.fitnessLimitation) }
    var step2Error by remember { mutableStateOf<String?>(null) }

    val matchingCountries = remember(countryQuery) {
        if (countryQuery.isBlank()) CountryCatalog.countries
        else CountryCatalog.search(countryQuery)
    }

    if (currentStep == 1) {
        BackHandler { currentStep = 0 }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(palette.voidBg, palette.surfaceBg, palette.voidBg)
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .imePadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        AnimatedContent(
            targetState = currentStep,
            transitionSpec = {
                val forward = targetState > initialState
                (fadeIn(tween(260, easing = FastOutSlowInEasing)) +
                    slideInHorizontally(tween(280, easing = FastOutSlowInEasing)) { if (forward) it / 4 else -it / 4 } +
                    scaleIn(initialScale = 0.97f, animationSpec = tween(260))) togetherWith
                    (fadeOut(tween(180)) + slideOutHorizontally(tween(200)) { if (forward) -it / 5 else it / 5 })
            },
            label = "onboarding_step"
        ) { step ->
            if (step == 0) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 560.dp)
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(235.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .border(1.dp, palette.borderAccent, RoundedCornerShape(28.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_welcome_sanctuary),
                            contentDescription = strings.appName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Black.copy(alpha = 0.22f),
                                            Color.Black.copy(alpha = 0.62f),
                                            Color.Black.copy(alpha = 0.94f)
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 20.dp, vertical = 18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(66.dp)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(
                                                palette.accentPrimary.copy(alpha = 0.34f),
                                                Color.Transparent
                                            )
                                        ),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ruhzena_emblem),
                                    contentDescription = strings.appName,
                                    modifier = Modifier.size(56.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = strings.welcomeTitle,
                                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = strings.tagline,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color(0xFFD4AF6A),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        elevated = true,
                        accentBorder = true,
                        cornerRadius = 22.dp,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.Top) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(palette.gold.copy(alpha = 0.14f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FormatQuote,
                                    contentDescription = null,
                                    tint = palette.gold,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = strings.welcomeQuote,
                                style = MaterialTheme.typography.bodyLarge.copy(fontStyle = FontStyle.Italic),
                                color = palette.textPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Liquid-Glass Permissions Status & Recovery Strip
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 20.dp,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                        accentBorder = hasLocationPerm && hasNotifPerm
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (hasLocationPerm && hasNotifPerm) Icons.Default.CheckCircle else Icons.Default.Security,
                                    contentDescription = null,
                                    tint = if (hasLocationPerm && hasNotifPerm) palette.accentSoft else palette.gold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isBn) "অ্যাপ অনুমতিসমূহ" else "App Permissions",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary
                                )
                            }
                            StatusPillBadge(
                                label = if (hasLocationPerm && hasNotifPerm) {
                                    if (isBn) "সব সক্রিয়" else "All Ready"
                                } else {
                                    if (isBn) "ঐচ্ছিক অনুমোদন" else "Setup Needed"
                                },
                                accentColor = if (hasLocationPerm && hasNotifPerm) palette.accentSoft else palette.amber
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StatusPillBadge(
                                label = if (hasLocationPerm) {
                                    if (isBn) "লোকেশন ✓" else "Location ✓"
                                } else {
                                    if (isBn) "লোকেশন বন্ধ" else "Location Off"
                                },
                                accentColor = if (hasLocationPerm) palette.accentSoft else palette.textMuted,
                                icon = Icons.Default.LocationOn
                            )
                            StatusPillBadge(
                                label = if (hasNotifPerm) {
                                    if (isBn) "নোটিফিকেশন ✓" else "Alerts ✓"
                                } else {
                                    if (isBn) "নোটিফিকেশন বন্ধ" else "Alerts Off"
                                },
                                accentColor = if (hasNotifPerm) palette.accentSoft else palette.textMuted,
                                icon = if (hasNotifPerm) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff
                            )
                        }
                        if (!hasLocationPerm || !hasNotifPerm) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                GlassFilterChip(
                                    label = if (isBn) "অনুমতি দিন" else "Grant Now",
                                    selected = true,
                                    onClick = { initialPermissionLauncher.launch(requiredPermissions) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("onboarding_grant_permissions_btn")
                                )
                                GlassFilterChip(
                                    label = if (isBn) "ফোন সেটিংস" else "Phone Settings",
                                    icon = Icons.Default.Settings,
                                    selected = false,
                                    onClick = { openAppSettings(context) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("onboarding_phone_settings_btn")
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Multilingual 8-Language Selector
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 20.dp,
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.chooseLanguage,
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            AppLanguage.entries.forEach { lang ->
                                GlassFilterChip(
                                    label = lang.nativeLabel,
                                    selected = prefs.language == lang,
                                    onClick = { onSelectLanguage(lang) },
                                    modifier = Modifier.testTag("onboarding_lang_${lang.code}")
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Visual Theme Switcher (Dark Glass / White & Grey-Blackish Glass)
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 20.dp,
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (palette.isLight) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = null,
                                tint = palette.gold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.themeModeLabel, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            GlassFilterChip(
                                label = strings.darkGlassTheme,
                                selected = prefs.themeMode == RuhZenaThemeMode.DARK_GLASS.id,
                                icon = Icons.Default.DarkMode,
                                onClick = { onSelectThemeMode(RuhZenaThemeMode.DARK_GLASS.id) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("onboarding_theme_dark")
                            )
                            GlassFilterChip(
                                label = strings.lightGlassTheme,
                                selected = prefs.themeMode == RuhZenaThemeMode.LIGHT_GLASS.id,
                                icon = Icons.Default.LightMode,
                                onClick = { onSelectThemeMode(RuhZenaThemeMode.LIGHT_GLASS.id) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("onboarding_theme_light")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Country Selector (GPS-First + Searchable Dropdown Fallback)
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        cornerRadius = 20.dp,
                        contentPadding = PaddingValues(16.dp),
                        accentBorder = prefs.countryCode.isNotBlank()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Public, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(strings.countrySetting, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                                Text(strings.selectCountryHint, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        // GPS-First Detection Button
                        OutlinedButton(
                            onClick = {
                                gpsPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            },
                            enabled = !isDetectingGps,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("onboarding_detect_gps_button")
                        ) {
                            if (isDetectingGps) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = palette.accentSoft)
                            } else {
                                Icon(Icons.Default.MyLocation, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isBn) "জিপিএস দিয়ে আমার দেশ শনাক্ত করুন" else "Detect My Country via GPS",
                                color = palette.textPrimary
                            )
                        }

                        if (!gpsStatusText.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = gpsStatusText!!,
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.accentSoft
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Searchable Country Dropdown Selector
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(palette.blockBg)
                                    .border(0.9.dp, palette.borderAccent, RoundedCornerShape(14.dp))
                                    .clickable { countryDropdownExpanded = true }
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                                    .testTag("onboarding_country_dropdown"),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (prefs.countryName.isNotBlank()) {
                                        "${prefs.countryName} (${prefs.defaultCitySafe()})"
                                    } else {
                                        if (isBn) "তালিকা থেকে দেশ নির্বাচন করুন..." else "Choose country from searchable list..."
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (prefs.countryName.isNotBlank()) palette.textPrimary else palette.textMuted,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Open country list", tint = palette.gold)
                            }

                            DropdownMenu(
                                expanded = countryDropdownExpanded,
                                onDismissRequest = { countryDropdownExpanded = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.84f)
                                    .background(palette.cardElevatedBg)
                            ) {
                                OutlinedTextField(
                                    value = countryQuery,
                                    onValueChange = { countryQuery = it },
                                    placeholder = { Text(if (isBn) "এখানে লিখুন" else "Type here", color = palette.textMuted) },
                                    singleLine = true,
                                    colors = onboardingFieldColors(),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                        .testTag("onboarding_country_search")
                                )
                                matchingCountries.take(16).forEach { c ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = "${c.nameEn} • ${c.defaultCity}",
                                                color = if (prefs.countryCode == c.code) palette.accentSoft else palette.textPrimary,
                                                fontWeight = if (prefs.countryCode == c.code) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        onClick = {
                                            onSelectCountry(c)
                                            step1Error = null
                                            countryDropdownExpanded = false
                                        },
                                        modifier = Modifier.testTag("onboarding_country_${c.code}")
                                    )
                                }
                            }
                        }

                        // Quick Popular Country Chips for 1-Tap Selection
                        Spacer(modifier = Modifier.height(8.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CountryCatalog.countries.take(6).forEach { c ->
                                GlassFilterChip(
                                    label = c.nameEn,
                                    selected = prefs.countryCode == c.code,
                                    onClick = {
                                        onSelectCountry(c)
                                        step1Error = null
                                    },
                                    modifier = Modifier.testTag("onboarding_country_${c.code}")
                                )
                            }
                        }

                        if (prefs.countryName.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            StatusPillBadge(
                                label = "${prefs.countryName} • ${prefs.defaultCitySafe()}",
                                accentColor = palette.accentSoft
                            )
                        }
                    }

                    if (!step1Error.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = step1Error!!,
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.coral,
                            modifier = Modifier.testTag("onboarding_step1_error")
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    EmeraldActionButton(
                        text = strings.startCompanion,
                        icon = Icons.AutoMirrored.Filled.ArrowForward,
                        onClick = {
                            if (prefs.countryCode.isBlank()) {
                                step1Error = if (isBn) "অনুগ্রহ করে আপনার দেশ নির্বাচন করুন।" else "Please select your country before entering."
                            } else {
                                step1Error = null
                                currentStep = 1
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_enter_button")
                    )
                    Spacer(modifier = Modifier.height(36.dp))
                }
            } else {
                // Page 2: Empty Inputs + Mandatory Validation + Character Gender + Under-13 Notice
                Column(
                    modifier = Modifier
                        .widthIn(max = 560.dp)
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            onClick = { currentStep = 0 },
                            modifier = Modifier.testTag("onboarding_back_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = palette.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(strings.profileSetupTitle, style = MaterialTheme.typography.headlineSmall, color = palette.textPrimary)
                            Text(strings.profileSetupSubtitle, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        }
                    }

                    GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it; step2Error = null },
                            label = { Text(strings.fullNameLabel) },
                            placeholder = { Text(if (isBn) "আপনার নাম লিখুন" else "Enter your name", color = palette.textMuted) },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = palette.accentSoft) },
                            singleLine = true,
                            colors = onboardingFieldColors(),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_name_input")
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = ageText,
                                onValueChange = { ageText = it.filter(Char::isDigit).take(3); step2Error = null },
                                label = { Text(strings.ageLabel) },
                                placeholder = { Text("", color = palette.textMuted) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = onboardingFieldColors(),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("onboarding_age_input")
                            )
                            OutlinedTextField(
                                value = weightText,
                                onValueChange = { weightText = it.filter(Char::isDigit).take(3); step2Error = null },
                                label = { Text(strings.weightKgLabel) },
                                placeholder = { Text("", color = palette.textMuted) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = onboardingFieldColors(),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("onboarding_weight_input")
                            )
                            OutlinedTextField(
                                value = heightText,
                                onValueChange = { heightText = it.filter(Char::isDigit).take(3); step2Error = null },
                                label = { Text(strings.heightCmLabel) },
                                placeholder = { Text("", color = palette.textMuted) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = onboardingFieldColors(),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("onboarding_height_input")
                            )
                        }

                        val parsedAge = ageText.toIntOrNull()
                        if (parsedAge != null && parsedAge in 1..12) {
                            Spacer(modifier = Modifier.height(8.dp))
                            StatusPillBadge(
                                label = strings.under13Notice,
                                accentColor = palette.amber,
                                modifier = Modifier.testTag("onboarding_under13_notice")
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isBn) "লিঙ্গ" else "Gender",
                            style = MaterialTheme.typography.titleSmall,
                            color = palette.accentSoft
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            GlassFilterChip(
                                label = if (isBn) "পুরুষ" else "Male",
                                selected = characterGender == "MALE",
                                onClick = { characterGender = "MALE"; step2Error = null },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("onboarding_gender_male")
                            )
                            GlassFilterChip(
                                label = if (isBn) "নারী" else "Female",
                                selected = characterGender == "FEMALE",
                                onClick = { characterGender = "FEMALE"; step2Error = null },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("onboarding_gender_female")
                            )
                        }
                    }

                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(strings.fitnessLevelLabel, style = MaterialTheme.typography.titleSmall, color = palette.accentSoft)
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Beginner", "Intermediate", "Advanced").forEach { option ->
                                GlassFilterChip(
                                    label = option,
                                    selected = level == option,
                                    onClick = { level = option }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(strings.primaryGoalLabel, style = MaterialTheme.typography.titleSmall, color = palette.accentSoft)
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                "Strength & Toning",
                                "Balanced Health",
                                "Fat Loss & Stamina",
                                "Flexibility & Posture"
                            ).forEach { option ->
                                GlassFilterChip(
                                    label = option,
                                    selected = goal == option,
                                    onClick = { goal = option }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isBn) "আপনার কি ওয়ার্কআউট সরঞ্জাম আছে?" else "Do you have workout equipment?",
                            style = MaterialTheme.typography.titleSmall,
                            color = palette.accentSoft
                        )
                        Text(
                            text = if (isBn) {
                                "সরঞ্জাম না থাকলে 'সরঞ্জাম নেই' বাছুন, আর থাকলে সবগুলো নির্বাচন করুন—আপনার সরঞ্জাম অনুযায়ী পূর্ণ ব্যায়াম ও প্ল্যান সাজানো হবে।"
                            } else {
                                "Pick No Equipment for pure bodyweight workouts, or select all gear you own to unlock matched strength programs & demos."
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        val selectedEqSet = remember(equipment) {
                            WorkoutEquipmentCatalog.parseSelected(equipment)
                        }
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            WorkoutEquipmentCatalog.selectableOptions.forEach { option ->
                                val isEqSelected = selectedEqSet.any { it.equals(option.id, ignoreCase = true) }
                                GlassFilterChip(
                                    label = if (isBn) option.labelBn else option.labelEn,
                                    selected = isEqSelected,
                                    onClick = {
                                        equipment = WorkoutEquipmentCatalog.toggleOption(equipment, option.id)
                                    },
                                    modifier = Modifier.testTag("onboarding_eq_${option.id.lowercase().replace(" ", "_")}")
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(strings.limitationsLabel, style = MaterialTheme.typography.titleSmall, color = palette.gold)
                        Spacer(modifier = Modifier.height(6.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("None", "Knee Friendly", "Lower Back Safe", "Wrist Safe").forEach { option ->
                                GlassFilterChip(
                                    label = option,
                                    selected = limitation == option,
                                    onClick = { limitation = option }
                                )
                            }
                        }
                    }

                    if (!step2Error.isNullOrBlank()) {
                        Text(
                            text = step2Error!!,
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.coral,
                            modifier = Modifier.testTag("onboarding_validation_error")
                        )
                    }

                    EmeraldActionButton(
                        text = strings.startMyJourney,
                        onClick = {
                            val ageVal = ageText.toIntOrNull()
                            val weightVal = weightText.toIntOrNull()
                            val heightVal = heightText.toIntOrNull()
                            when {
                                name.trim().isEmpty() ->
                                    step2Error = if (isBn) "অনুগ্রহ করে আপনার নাম লিখুন।" else "Please enter your name."
                                ageVal == null || ageVal !in 8..100 ->
                                    step2Error = if (isBn) "বয়স ৮ থেকে ১০০ এর মধ্যে লিখুন।" else "Please enter a valid age (8–100)."
                                weightVal == null || weightVal !in 25..250 ->
                                    step2Error = if (isBn) "ওজন ২৫ থেকে ২৫০ কেজির মধ্যে লিখুন।" else "Please enter a valid weight in kg (25–250)."
                                heightVal == null || heightVal !in 100..230 ->
                                    step2Error = if (isBn) "উচ্চতা ১০০ থেকে ২৩০ সে.মি. এর মধ্যে লিখুন।" else "Please enter a valid height in cm (100–230)."
                                characterGender.isBlank() ->
                                    step2Error = if (isBn) "অনুগ্রহ করে আপনার লিঙ্গ নির্বাচন করুন।" else "Please select your gender (Male / Female)."
                                else -> {
                                    step2Error = null
                                    onSaveProfile(
                                        name.trim(),
                                        ageVal,
                                        weightVal,
                                        heightVal,
                                        characterGender,
                                        level,
                                        goal,
                                        equipment,
                                        limitation
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("start_ruhzena_button")
                    )
                    Spacer(modifier = Modifier.height(36.dp))
                }
            }
        }
    }
}

private fun UserPreferences.defaultCitySafe(): String = locationName.ifBlank { "Global" }

enum class SettingsMenuSection(
    val titleEn: String,
    val titleBn: String
) {
    HUB("Settings", "সেটিংস"),
    QUICK_JUMP("Quick Jump Studio", "কুইক জাম্প স্টুডিও"),
    PROFILE_EQUIPMENT("Profile & Equipment", "প্রোফাইল ও সরঞ্জাম"),
    APPEARANCE_LANG("Appearance & Language", "থিম, ভাষা ও দেশ"),
    PRAYER_VOICE("Prayer, Adhan & Voice", "নামাজ, আযান ও কণ্ঠ"),
    NOTIFICATIONS("Notifications & Alerts", "নোটিফিকেশন ও অ্যালার্ট"),
    ACCOUNT_SYNC("Cloud Account & Sync", "ক্লাউড অ্যাকাউন্ট ও সিঙ্ক"),
    DATA_GUIDES("Guides, Privacy & Data", "গাইড, প্রাইভেসি ও ডেটা")
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsBottomSheet(
    prefs: UserPreferences,
    backupStatusMessage: String?,
    initialSection: SettingsMenuSection = SettingsMenuSection.HUB,
    onDismiss: () -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSelectThemeMode: (String) -> Unit,
    onSelectCountry: (CountryPreset) -> Unit,
    onSetUiFontScale: (Float) -> Unit,
    onSetReducedMotion: (Boolean) -> Unit,
    onSetAsrMethod: (String) -> Unit,
    onSetHijriOffset: (Int) -> Unit,
    onSetRamadanMode: (Boolean) -> Unit,
    onSetKidsMode: (Boolean) -> Unit,
    onSetLearningMode: (String) -> Unit,
    onSetNotificationTone: (String) -> Unit,
    onSetNotificationVibration: (Boolean) -> Unit,
    onUpdateBiometricProfile: (
        name: String?,
        age: Int?,
        weight: Int?,
        height: Int?,
        gender: String?,
        level: String,
        goal: String,
        equipment: String,
        limitation: String
    ) -> Unit,
    onUpdateReminders: (
        prayer: Boolean?,
        water: Boolean?,
        adhkar: Boolean?,
        workout: Boolean?,
        bedtime: Boolean?,
        lesson: Boolean?,
        hourlyMotivation: Boolean?,
        quietEnabled: Boolean?,
        quietStart: Int?,
        quietEnd: Int?
    ) -> Unit,
    onOpenMotivationWindow: () -> Unit,
    onExportBackup: (Uri) -> Unit,
    onImportBackup: (Uri) -> Unit,
    onClearJournal: () -> Unit,
    onClearHabits: () -> Unit,
    onClearWellness: () -> Unit,
    onClearAiChat: () -> Unit,
    onResetAllData: () -> Unit,
    onClearBackupStatus: () -> Unit,
    providerCredentials: ProviderCredentialsSnapshot = ProviderCredentialsSnapshot(),
    providerHealth: List<AiProviderHealthEntity> = emptyList(),
    providerPingResults: Map<AiProviderId, ProviderPingResult> = emptyMap(),
    testingProviderId: AiProviderId? = null,
    onSaveAiProviderCredentials: (String?, String?, String?, String?, String?) -> Unit = { _, _, _, _, _ -> },
    onTestAiProvider: (AiProviderId) -> Unit = {},
    onClearAiProviderCredentials: () -> Unit = {},
    isSignedIn: Boolean = false,
    signedInUserName: String = "",
    signedInUserEmail: String = "",
    cloudSyncStatus: CloudSyncStatus = CloudSyncStatus(),
    onSyncCloudNow: () -> Unit = {},
    onSignOut: () -> Unit = {},
    onSetQuickJumpSlots: (List<PortalQuickLaunch>) -> Unit = {},
    onPreviewQuickJump: () -> Unit = {},
    onSetAdhanMuezzin: (String) -> Unit = {},
    onSetSpeechVoiceStyle: (String) -> Unit = {},
    onReplayTutorial: () -> Unit = {}
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = prefs.language == AppLanguage.BANGLA
    val context = LocalContext.current
    val settingsScope = rememberCoroutineScope()
    var activeSection by remember(initialSection) { mutableStateOf(initialSection) }
    var isSigningInFromSettings by remember { mutableStateOf(false) }
    var settingsSignInError by remember { mutableStateOf<String?>(null) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var hasNotifPerm by remember { mutableStateOf(RuhZenaNotificationHelper.hasNotificationPermission(context)) }
    var hasLocationPerm by remember { mutableStateOf(hasAnyLocationPermission(context)) }
    var showResetConfirm by remember { mutableStateOf(false) }

    var editName by remember(prefs.userName) { mutableStateOf(prefs.userName) }
    var editAge by remember(prefs.ageYears) { mutableStateOf(prefs.ageYears.toString()) }
    var editWeight by remember(prefs.weightKg) { mutableStateOf(prefs.weightKg.toString()) }
    var editHeight by remember(prefs.heightCm) { mutableStateOf(prefs.heightCm.toString()) }
    var editGender by remember(prefs.characterGender) { mutableStateOf(prefs.characterGender.ifBlank { "MALE" }) }
    var editLevel by remember(prefs.fitnessLevel) { mutableStateOf(prefs.fitnessLevel.ifBlank { "Intermediate" }) }
    var editGoal by remember(prefs.fitnessGoal) { mutableStateOf(prefs.fitnessGoal.ifBlank { "Strength & Toning" }) }
    var editEquipment by remember(prefs.availableEquipment) { mutableStateOf(prefs.availableEquipment.ifBlank { WorkoutEquipmentCatalog.NONE }) }
    var editLimitation by remember(prefs.fitnessLimitation) { mutableStateOf(prefs.fitnessLimitation.ifBlank { "None" }) }
    var profileSavedMsg by remember { mutableStateOf<String?>(null) }

    val activeShortcuts = remember(prefs.quickJumpSlotsCsv) {
        PortalQuickLaunch.fromCsv(prefs.quickJumpSlotsCsv)
    }
    val activeAdhanMuezzin = AdhanMuezzin.fromId(prefs.adhanMuezzinId)

    val notifLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotifPerm = granted || RuhZenaNotificationHelper.hasNotificationPermission(context)
    }

    val allPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasLocationPerm = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true ||
            hasAnyLocationPermission(context)
        hasNotifPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            grants[Manifest.permission.POST_NOTIFICATIONS] == true ||
                RuhZenaNotificationHelper.hasNotificationPermission(context)
        } else {
            true
        }
    }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let(onExportBackup)
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let(onImportBackup)
    }

    val tonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            onSetNotificationTone(it.toString())
        }
    }

    ModalBottomSheet(
        onDismissRequest = {
            onClearBackupStatus()
            onDismiss()
        },
        sheetState = sheetState,
        containerColor = palette.surfaceBg,
        contentColor = palette.textPrimary
    ) {
        BackHandler(enabled = activeSection != SettingsMenuSection.HUB) {
            activeSection = SettingsMenuSection.HUB
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal))
                .imePadding()
                .padding(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Sticky Categorized Settings Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (activeSection != SettingsMenuSection.HUB) {
                        IconButton(
                            onClick = { activeSection = SettingsMenuSection.HUB },
                            modifier = Modifier.testTag("settings_back_to_hub_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = if (isBn) "সেটিংস মেনুতে ফিরুন" else "Back to Settings Menu",
                                tint = palette.accentSoft
                            )
                        }
                    }
                    Column {
                        Text(
                            text = if (activeSection == SettingsMenuSection.HUB) {
                                strings.settingsTitle
                            } else if (isBn) {
                                activeSection.titleBn
                            } else {
                                activeSection.titleEn
                            },
                            style = MaterialTheme.typography.headlineSmall,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        if (activeSection == SettingsMenuSection.HUB) {
                            Text(
                                text = if (isBn) "একটি বিভাগ বেছে নিন—কোনো দীর্ঘ স্ক্রলিং নেই" else "Choose a menu category—clean & instant access",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textSecondary
                            )
                        }
                    }
                }
                IconButton(
                    onClick = {
                        onClearBackupStatus()
                        onDismiss()
                    },
                    modifier = Modifier.testTag("close_settings_button")
                ) {
                    Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.textSecondary)
                }
            }

            AnimatedContent(
                targetState = activeSection,
                transitionSpec = {
                    val enteringSubmenu = targetState != SettingsMenuSection.HUB
                    (fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                        slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { if (enteringSubmenu) it / 4 else -it / 4 } +
                        scaleIn(initialScale = 0.97f, animationSpec = tween(240))) togetherWith
                        (fadeOut(tween(160)) + slideOutHorizontally(tween(180)) { if (enteringSubmenu) -it / 5 else it / 5 })
                },
                label = "settingsCategoryTransition"
            ) { section ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (section) {
                        SettingsMenuSection.HUB -> {
                            val themeLabel = if (prefs.themeMode == RuhZenaThemeMode.LIGHT_GLASS.id) strings.lightGlassTheme else strings.darkGlassTheme
                            val voiceLabel = when (NarrationVoiceResolver.resolve(prefs.characterGender, prefs.speechVoiceStyle).styleId.uppercase()) {
                                "CALM_SCHOLAR" -> if (isBn) "গম্ভীর ও শান্ত" else "Calm Scholar"
                                "GENTLE_FEMALE" -> if (isBn) "কোমল নারী কণ্ঠ" else "Gentle Female"
                                else -> if (isBn) "স্বাভাবিক আন্তরিক" else "Warm Natural"
                            }

                            SettingsHubMenuCard(
                                icon = Icons.Default.Bolt,
                                iconTint = palette.gold,
                                title = if (isBn) "কুইক জাম্প স্টুডিও" else "Quick Jump Studio",
                                subtitle = if (isBn) "${activeShortcuts.size}/৮টি শর্টকাট • প্রিসেট, সাজানো ও ব্যবহার গাইড" else "${activeShortcuts.size}/8 shortcuts • Live deck, presets & gesture guide",
                                badge = "${activeShortcuts.size}/8",
                                accentBorder = true,
                                testTag = "settings_menu_quick_jump",
                                onClick = { activeSection = SettingsMenuSection.QUICK_JUMP }
                            )

                            SettingsHubMenuCard(
                                icon = Icons.Default.FitnessCenter,
                                iconTint = palette.accentSoft,
                                title = if (isBn) "প্রোফাইল ও ওয়ার্কআউট সরঞ্জাম" else "Profile & Workout Equipment",
                                subtitle = "${prefs.userName.ifBlank { if (isBn) "ব্যবহারকারী" else "Member" }} • ${prefs.availableEquipment.ifBlank { WorkoutEquipmentCatalog.NONE }}",
                                badge = prefs.fitnessLevel.ifBlank { "Fit" },
                                testTag = "settings_menu_profile_equipment",
                                onClick = { activeSection = SettingsMenuSection.PROFILE_EQUIPMENT }
                            )

                            SettingsHubMenuCard(
                                icon = Icons.Default.Palette,
                                iconTint = Color(0xFF38BDF8),
                                title = if (isBn) "থিম, ভাষা ও দেশ" else "Appearance, Language & Country",
                                subtitle = "$themeLabel • ${prefs.language.nativeLabel} • ${prefs.countryName.ifBlank { prefs.locationName }}",
                                badge = "${(prefs.uiFontScale * 100).toInt()}%",
                                testTag = "settings_menu_appearance",
                                onClick = { activeSection = SettingsMenuSection.APPEARANCE_LANG }
                            )

                            SettingsHubMenuCard(
                                icon = Icons.Default.RecordVoiceOver,
                                iconTint = palette.gold,
                                title = if (isBn) "নামাজ, পূর্ণ আযান ও মানব কণ্ঠ" else "Prayer, Full Adhan & Human Voice",
                                subtitle = "${prefs.asrJuristicMethod} • ${if (isBn) activeAdhanMuezzin.nameBn else activeAdhanMuezzin.nameEn} • $voiceLabel",
                                testTag = "settings_menu_prayer_voice",
                                onClick = { activeSection = SettingsMenuSection.PRAYER_VOICE }
                            )

                            SettingsHubMenuCard(
                                icon = if (hasNotifPerm) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                                iconTint = if (hasNotifPerm) palette.accentSoft else palette.amber,
                                title = if (isBn) "নোটিফিকেশন, সাউন্ড ও মিউট" else "Notifications, Tones & Mute",
                                subtitle = if (hasNotifPerm) {
                                    if (isBn) "অ্যালার্ট সক্রিয় • আযান, পানি, যিকির ও রিমাইন্ডার" else "Alerts active • Exact Adhan, water, adhkar & custom tones"
                                } else {
                                    if (isBn) "নোটিফিকেশন অনুমতি প্রয়োজন" else "Permission needed for exact prayer & reminder alerts"
                                },
                                badge = if (hasNotifPerm) (if (isBn) "সক্রিয়" else "ON") else (if (isBn) "বন্ধ" else "OFF"),
                                testTag = "settings_menu_notifications",
                                onClick = { activeSection = SettingsMenuSection.NOTIFICATIONS }
                            )

                            SettingsHubMenuCard(
                                icon = if (isSignedIn) Icons.Default.CloudDone else Icons.Default.CloudOff,
                                iconTint = palette.accentPrimary,
                                title = if (isBn) "ক্লাউড অ্যাকাউন্ট ও সিঙ্ক" else "Cloud Account & Sync (Optional)",
                                subtitle = if (isSignedIn) {
                                    signedInUserEmail.ifBlank { signedInUserName }
                                } else {
                                    if (isBn) "লোকাল মোডে চলছে • চাইলে গুগল সাইন-ইন করুন" else "Local mode active • Optional Google cloud backup"
                                },
                                badge = if (isSignedIn) (if (isBn) "সিঙ্কড" else "Cloud") else (if (isBn) "লোকাল" else "Local"),
                                testTag = "settings_menu_account",
                                onClick = { activeSection = SettingsMenuSection.ACCOUNT_SYNC }
                            )

                            SettingsHubMenuCard(
                                icon = Icons.Default.Security,
                                iconTint = palette.textSecondary,
                                title = if (isBn) "অ্যাপ গাইড, অনুমতি, ব্যাকআপ ও সূত্র" else "App Guides, Permissions, Backup & Sources",
                                subtitle = if (isBn) "টিউটোরিয়াল রিপ্লে, JSON ব্যাকআপ, প্রাইভেসি ও অথেনটিক সূত্র" else "Replay spotlight guides, JSON backup, clear data & authentic sources",
                                testTag = "settings_menu_data_guides",
                                onClick = { activeSection = SettingsMenuSection.DATA_GUIDES }
                            )
                        }

                        SettingsMenuSection.QUICK_JUMP -> {
                            // ── MAXED-OUT FUTURISTIC LIQUID-GLASS QUICK JUMP STUDIO ──
                            val presetBalanced = PortalQuickLaunch.defaultUrgentShortcuts
                            val presetDeen = listOf(
                                PortalQuickLaunch.CONTINUE_QURAN,
                                PortalQuickLaunch.PRAYER_QIBLA,
                                PortalQuickLaunch.DAILY_DUAS,
                                PortalQuickLaunch.TASBIH_3D,
                                PortalQuickLaunch.HIFZ_COMPANION,
                                PortalQuickLaunch.STORIES
                            )
                            val presetLife = listOf(
                                PortalQuickLaunch.WORKOUTS_3D,
                                PortalQuickLaunch.QUICK_WATER,
                                PortalQuickLaunch.MEAL_SCANNER,
                                PortalQuickLaunch.URGE_RESET,
                                PortalQuickLaunch.HABITS_JOURNAL,
                                PortalQuickLaunch.GLOBAL_SEARCH
                            )

                            // 1. Live Futuristic Liquid-Glass Mini-Deck Preview
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                palette.cardElevatedBg.copy(alpha = 0.94f),
                                                palette.blockBg.copy(alpha = 0.96f)
                                            )
                                        )
                                    )
                                    .border(
                                        width = 1.2.dp,
                                        brush = Brush.linearGradient(
                                            listOf(
                                                palette.gold.copy(alpha = 0.6f),
                                                palette.accentSoft.copy(alpha = 0.5f)
                                            )
                                        ),
                                        shape = RoundedCornerShape(24.dp)
                                    )
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.Bolt, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                                        Text(
                                            text = if (isBn) "লাইভ ডেক প্রিভিউ" else "Live Deck Preview",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = palette.gold,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    StatusPillBadge(
                                        label = "${activeShortcuts.size}/8 ${if (isBn) "সক্রিয়" else "active"}",
                                        accentColor = palette.accentSoft
                                    )
                                }

                                val previewColumns = if (activeShortcuts.size <= 4) 2 else 3
                                activeShortcuts.chunked(previewColumns).forEach { rowItems ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        rowItems.forEach { slot ->
                                            val tileTint = when (slot) {
                                                PortalQuickLaunch.URGE_RESET -> palette.coral
                                                PortalQuickLaunch.QUICK_WATER -> Color(0xFF38BDF8)
                                                PortalQuickLaunch.PRAYER_QIBLA, PortalQuickLaunch.CONTINUE_QURAN -> palette.gold
                                                else -> palette.accentSoft
                                            }
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(16.dp))
                                                    .background(palette.surfaceBg.copy(alpha = 0.72f))
                                                    .border(0.9.dp, tileTint.copy(alpha = 0.38f), RoundedCornerShape(16.dp))
                                                    .padding(horizontal = 6.dp, vertical = 9.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(30.dp)
                                                        .clip(CircleShape)
                                                        .background(tileTint.copy(alpha = 0.16f)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(slot.icon, contentDescription = null, tint = tileTint, modifier = Modifier.size(16.dp))
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = if (isBn) slot.titleBn else slot.titleEn,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = palette.textPrimary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                        repeat(previewColumns - rowItems.size) {
                                            Spacer(modifier = Modifier.weight(1f))
                                        }
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    EmeraldActionButton(
                                        text = if (isBn) "এখনই লাইভ ওপেন করুন" else "Launch Live Deck",
                                        icon = Icons.Default.TouchApp,
                                        onClick = {
                                            onDismiss()
                                            onPreviewQuickJump()
                                        },
                                        modifier = Modifier.weight(1.25f).testTag("settings_try_quick_jump_btn")
                                    )
                                    OutlinedButton(
                                        onClick = { onSetQuickJumpSlots(presetBalanced) },
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.weight(0.75f).heightIn(min = 48.dp).testTag("settings_reset_quick_jump_btn")
                                    ) {
                                        Text(if (isBn) "রিসেট" else "Reset", color = palette.textPrimary)
                                    }
                                }
                            }

                            // 2. One-Tap Smart Presets
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = if (isBn) "১-ট্যাপ স্মার্ট প্রিসেট" else "1-Tap Smart Presets",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    GlassFilterChip(
                                        label = if (isBn) "ব্যালেন্সড" else "Balanced",
                                        selected = activeShortcuts == presetBalanced,
                                        onClick = { onSetQuickJumpSlots(presetBalanced) },
                                        modifier = Modifier.weight(1f).testTag("qj_preset_balanced")
                                    )
                                    GlassFilterChip(
                                        label = if (isBn) "দ্বীন ফোকাস" else "Deen Focus",
                                        selected = activeShortcuts == presetDeen,
                                        onClick = { onSetQuickJumpSlots(presetDeen) },
                                        modifier = Modifier.weight(1f).testTag("qj_preset_deen")
                                    )
                                    GlassFilterChip(
                                        label = if (isBn) "ফিটনেস ও জীবন" else "Fitness & Life",
                                        selected = activeShortcuts == presetLife,
                                        onClick = { onSetQuickJumpSlots(presetLife) },
                                        modifier = Modifier.weight(1f).testTag("qj_preset_life")
                                    )
                                }
                            }

                            // 3. How to Open Quick Jump Gesture Card
                            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.TouchApp, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = if (isBn) "কুইক জাম্প কীভাবে ব্যবহার করবেন?" else "How to Open Quick Jump",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = palette.gold,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isBn) {
                                        "• যেকোনো পেজ থেকে নিচের ডকের মাঝখানের AI আইকনে লং-প্রেস করুন অথবা ওপরে সোয়াইপ করুন।\n• এক ট্যাপেই কুরআন, নামাজ, দুআ, প্রশান্তি রিসেট বা +২৫০ মি.লি. পানি খুলুন।\n• ৪ থেকে ৮টি শর্টকাট নিচ থেকে সাজিয়ে নিন।"
                                    } else {
                                        "• Long-press or swipe UP on the center RuhZena AI emblem in the bottom dock from any screen.\n• Launch your most urgent spiritual or wellness tool in a single tap.\n• Customize 4 to 8 active slots and their exact display order below."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary
                                )
                            }

                            // 4. Active Order (Reorder + Quick Remove)
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = if (isBn) "সক্রিয় শর্টকাট ক্রম (${activeShortcuts.size}/৮)" else "Active Slot Order (${activeShortcuts.size}/8)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    activeShortcuts.forEachIndexed { idx, slot ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(palette.blockBg.copy(alpha = 0.78f))
                                                .border(0.7.dp, palette.borderNeutral, RoundedCornerShape(14.dp))
                                                .padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(26.dp)
                                                        .clip(CircleShape)
                                                        .background(palette.accentPrimary.copy(alpha = 0.16f)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = "${idx + 1}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = palette.accentSoft,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                                Icon(slot.icon, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                                                Column {
                                                    Text(
                                                        text = if (isBn) slot.titleBn else slot.titleEn,
                                                        style = MaterialTheme.typography.labelLarge,
                                                        color = palette.textPrimary,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                    Text(
                                                        text = if (isBn) slot.subtitleBn else slot.subtitleEn,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = palette.textMuted
                                                    )
                                                }
                                            }
                                            Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                                                IconButton(
                                                    enabled = idx > 0,
                                                    onClick = {
                                                        val mutable = activeShortcuts.toMutableList()
                                                        val tmp = mutable[idx - 1]
                                                        mutable[idx - 1] = mutable[idx]
                                                        mutable[idx] = tmp
                                                        onSetQuickJumpSlots(mutable)
                                                    },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Default.ArrowUpward,
                                                        contentDescription = "Move up",
                                                        tint = if (idx > 0) palette.accentSoft else palette.textMuted.copy(alpha = 0.3f),
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                                IconButton(
                                                    enabled = idx < activeShortcuts.lastIndex,
                                                    onClick = {
                                                        val mutable = activeShortcuts.toMutableList()
                                                        val tmp = mutable[idx + 1]
                                                        mutable[idx + 1] = mutable[idx]
                                                        mutable[idx] = tmp
                                                        onSetQuickJumpSlots(mutable)
                                                    },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Default.ArrowDownward,
                                                        contentDescription = "Move down",
                                                        tint = if (idx < activeShortcuts.lastIndex) palette.accentSoft else palette.textMuted.copy(alpha = 0.3f),
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                                IconButton(
                                                    enabled = activeShortcuts.size > 4,
                                                    onClick = {
                                                        val mutable = activeShortcuts.toMutableList()
                                                        if (mutable.size > 4) {
                                                            mutable.removeAt(idx)
                                                            onSetQuickJumpSlots(mutable)
                                                        }
                                                    },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Default.RemoveCircleOutline,
                                                        contentDescription = "Remove shortcut",
                                                        tint = if (activeShortcuts.size > 4) palette.coral else palette.textMuted.copy(alpha = 0.3f),
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // 5. Categorized Shortcut Library Picker (Deen vs Life & Tools)
                            val deenShortcuts = listOf(
                                PortalQuickLaunch.CONTINUE_QURAN,
                                PortalQuickLaunch.PRAYER_QIBLA,
                                PortalQuickLaunch.DAILY_DUAS,
                                PortalQuickLaunch.TASBIH_3D,
                                PortalQuickLaunch.HIFZ_COMPANION,
                                PortalQuickLaunch.ARABIC_STUDIO,
                                PortalQuickLaunch.STORIES
                            )
                            val lifeShortcuts = PortalQuickLaunch.entries.filterNot { deenShortcuts.contains(it) }

                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = if (isBn) "দ্বীন ও ইবাদত শর্টকাট" else "Deen & Worship Destinations",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.gold,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    deenShortcuts.forEach { slot ->
                                        val isSelected = activeShortcuts.contains(slot)
                                        GlassFilterChip(
                                            label = if (isBn) slot.titleBn else slot.titleEn,
                                            icon = slot.icon,
                                            selected = isSelected,
                                            onClick = {
                                                val next = activeShortcuts.toMutableList()
                                                if (isSelected) {
                                                    if (next.size > 4) { next.remove(slot); onSetQuickJumpSlots(next) }
                                                } else if (next.size < 8) {
                                                    next.add(slot); onSetQuickJumpSlots(next)
                                                }
                                            },
                                            modifier = Modifier.testTag("settings_qj_toggle_${slot.name.lowercase()}")
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = if (isBn) "স্বাস্থ্য, জীবন ও টুলস" else "Wellness, Discipline & Tools",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.accentSoft,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    lifeShortcuts.forEach { slot ->
                                        val isSelected = activeShortcuts.contains(slot)
                                        GlassFilterChip(
                                            label = if (isBn) slot.titleBn else slot.titleEn,
                                            icon = slot.icon,
                                            selected = isSelected,
                                            onClick = {
                                                val next = activeShortcuts.toMutableList()
                                                if (isSelected) {
                                                    if (next.size > 4) { next.remove(slot); onSetQuickJumpSlots(next) }
                                                } else if (next.size < 8) {
                                                    next.add(slot); onSetQuickJumpSlots(next)
                                                }
                                            },
                                            modifier = Modifier.testTag("settings_qj_toggle_${slot.name.lowercase()}")
                                        )
                                    }
                                }
                            }
                        }

                        SettingsMenuSection.PROFILE_EQUIPMENT -> {
                            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                                Text(strings.profileSetupTitle, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = editName,
                                    onValueChange = { editName = it },
                                    label = { Text(strings.fullNameLabel) },
                                    singleLine = true,
                                    colors = onboardingFieldColors(),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = editAge,
                                        onValueChange = { editAge = it.filter(Char::isDigit).take(3) },
                                        label = { Text(strings.ageLabel) },
                                        singleLine = true,
                                        colors = onboardingFieldColors(),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = editWeight,
                                        onValueChange = { editWeight = it.filter(Char::isDigit).take(3) },
                                        label = { Text(strings.weightKgLabel) },
                                        singleLine = true,
                                        colors = onboardingFieldColors(),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = editHeight,
                                        onValueChange = { editHeight = it.filter(Char::isDigit).take(3) },
                                        label = { Text(strings.heightCmLabel) },
                                        singleLine = true,
                                        colors = onboardingFieldColors(),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    GlassFilterChip(
                                        label = strings.maleCharacter,
                                        selected = editGender == "MALE",
                                        onClick = { editGender = "MALE" },
                                        modifier = Modifier.weight(1f)
                                    )
                                    GlassFilterChip(
                                        label = strings.femaleCharacter,
                                        selected = editGender == "FEMALE",
                                        onClick = { editGender = "FEMALE" },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(strings.fitnessLevelLabel, style = MaterialTheme.typography.labelLarge, color = palette.accentSoft)
                                Spacer(modifier = Modifier.height(6.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("Beginner", "Intermediate", "Advanced").forEach { opt ->
                                        GlassFilterChip(label = opt, selected = editLevel == opt, onClick = { editLevel = opt })
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(strings.primaryGoalLabel, style = MaterialTheme.typography.labelLarge, color = palette.accentSoft)
                                Spacer(modifier = Modifier.height(6.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("Strength & Toning", "Balanced Health", "Fat Loss & Stamina", "Flexibility & Posture").forEach { opt ->
                                        GlassFilterChip(label = opt, selected = editGoal == opt, onClick = { editGoal = opt })
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = if (isBn) "ওয়ার্কআউট সরঞ্জাম (একাধিক বাছাই করা যাবে)" else "Available Workout Equipment (Multi-Select)",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = palette.gold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                val editEqSet = remember(editEquipment) { WorkoutEquipmentCatalog.parseSelected(editEquipment) }
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    WorkoutEquipmentCatalog.selectableOptions.forEach { opt ->
                                        GlassFilterChip(
                                            label = if (isBn) opt.labelBn else opt.labelEn,
                                            selected = editEqSet.any { it.equals(opt.id, ignoreCase = true) },
                                            onClick = { editEquipment = WorkoutEquipmentCatalog.toggleOption(editEquipment, opt.id) },
                                            modifier = Modifier.testTag("settings_eq_${opt.id.lowercase().replace(" ", "_")}")
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(strings.limitationsLabel, style = MaterialTheme.typography.labelLarge, color = palette.textSecondary)
                                Spacer(modifier = Modifier.height(6.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("None", "Knee Friendly", "Lower Back Safe", "Wrist Safe").forEach { opt ->
                                        GlassFilterChip(label = opt, selected = editLimitation == opt, onClick = { editLimitation = opt })
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                EmeraldActionButton(
                                    text = strings.saveSettings,
                                    onClick = {
                                        onUpdateBiometricProfile(
                                            editName.trim().ifBlank { null },
                                            editAge.toIntOrNull(),
                                            editWeight.toIntOrNull(),
                                            editHeight.toIntOrNull(),
                                            editGender,
                                            editLevel,
                                            editGoal,
                                            editEquipment,
                                            editLimitation
                                        )
                                        profileSavedMsg = if (isBn) "প্রোফাইল ও সরঞ্জাম সংরক্ষিত হয়েছে।" else "Profile & equipment updated."
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("settings_save_profile_btn")
                                )
                                if (profileSavedMsg != null) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(profileSavedMsg!!, style = MaterialTheme.typography.labelSmall, color = palette.accentSoft)
                                }
                            }
                        }

                        SettingsMenuSection.APPEARANCE_LANG -> {
                            GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                                Text(strings.themeModeLabel, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    GlassFilterChip(
                                        label = strings.darkGlassTheme,
                                        selected = prefs.themeMode == RuhZenaThemeMode.DARK_GLASS.id,
                                        icon = Icons.Default.DarkMode,
                                        onClick = { onSelectThemeMode(RuhZenaThemeMode.DARK_GLASS.id) },
                                        modifier = Modifier.weight(1f).testTag("settings_theme_dark")
                                    )
                                    GlassFilterChip(
                                        label = strings.lightGlassTheme,
                                        selected = prefs.themeMode == RuhZenaThemeMode.LIGHT_GLASS.id,
                                        icon = Icons.Default.LightMode,
                                        onClick = { onSelectThemeMode(RuhZenaThemeMode.LIGHT_GLASS.id) },
                                        modifier = Modifier.weight(1f).testTag("settings_theme_light")
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("${strings.uiTextSizeLabel}: ${(prefs.uiFontScale * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, color = palette.textSecondary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(0.9f to "S", 1.0f to "M", 1.12f to "L", 1.24f to "XL").forEach { (scale, tag) ->
                                        GlassFilterChip(
                                            label = tag,
                                            selected = kotlin.math.abs(prefs.uiFontScale - scale) < 0.04f,
                                            onClick = { onSetUiFontScale(scale) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                ReminderToggleRow(strings.reducedMotionLabel, prefs.reducedMotion) {
                                    onSetReducedMotion(it)
                                }
                            }

                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(strings.languageSetting, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                                Spacer(modifier = Modifier.height(8.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    AppLanguage.entries.forEach { lang ->
                                        GlassFilterChip(
                                            label = lang.nativeLabel,
                                            selected = prefs.language == lang,
                                            onClick = { onSelectLanguage(lang) },
                                            modifier = Modifier.testTag("settings_lang_${lang.code}")
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("${strings.countrySetting}: ${prefs.countryName.ifBlank { prefs.locationName }}", style = MaterialTheme.typography.titleSmall, color = palette.accentSoft)
                                Spacer(modifier = Modifier.height(6.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    CountryCatalog.countries.take(10).forEach { c ->
                                        GlassFilterChip(
                                            label = c.nameEn,
                                            selected = prefs.countryCode == c.code,
                                            onClick = { onSelectCountry(c) }
                                        )
                                    }
                                }
                            }
                        }

                        SettingsMenuSection.PRAYER_VOICE -> {
                            val adhanPlaying by FullAdhanAudioManager.isPlaying.collectAsState()

                            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                                Text(
                                    text = if (isBn) "পূর্ণ আযান (মুয়াজ্জিন নির্বাচন)" else "Full Adhan Muezzin & Preview",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.gold,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isBn) "নামাজের ঠিক সময়ে আসল পূর্ণ আযান বাজবে এবং অফলাইনে চলার জন্য সংরক্ষিত থাকবে।" else "Plays the complete authentic Muezzin Adhan at exact Salah times and caches locally.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.textSecondary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    AdhanMuezzin.entries.forEach { muezzin ->
                                        GlassFilterChip(
                                            label = if (isBn) muezzin.nameBn else muezzin.nameEn,
                                            selected = activeAdhanMuezzin == muezzin,
                                            onClick = { onSetAdhanMuezzin(muezzin.id) },
                                            modifier = Modifier.testTag("settings_adhan_${muezzin.id.lowercase()}")
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                GlassFilterChip(
                                    label = if (adhanPlaying) {
                                        if (isBn) "আযান থামান" else "Stop Full Adhan"
                                    } else {
                                        if (isBn) "পূর্ণ আযান শুনুন" else "Play Full Adhan"
                                    },
                                    icon = if (adhanPlaying) Icons.Default.StopCircle else Icons.Default.PlayArrow,
                                    selected = adhanPlaying,
                                    onClick = {
                                        if (adhanPlaying) {
                                            FullAdhanAudioManager.stop(context)
                                        } else {
                                            FullAdhanAudioManager.playFullAdhan(
                                                context = context,
                                                muezzinId = activeAdhanMuezzin.id,
                                                prayerTitle = if (isBn) "আযান • ${activeAdhanMuezzin.nameBn}" else "Full Adhan • ${activeAdhanMuezzin.nameEn}"
                                            )
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("preview_prayer_ringtone_btn")
                                )
                            }

                            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isBn) "মানব কণ্ঠের ধরন (গল্প, দুআ ও এআই)" else "Consistent Human Studio Voice",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = palette.textPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isBn) "নির্বাচিত পুরুষ বা নারী কণ্ঠ সব অডিওতে একই থাকবে—কখনো বদলাবে না।" else "Strictly locks one natural male or female voice across AI, stories, and Duas without switching.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.textSecondary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    val activeVoice = NarrationVoiceResolver.resolve(prefs.characterGender, prefs.speechVoiceStyle)
                                    listOf(
                                        "WARM_HUMAN" to (if (isBn) "স্বাভাবিক পুরুষ কণ্ঠ" else "Warm Natural (Male)"),
                                        "CALM_SCHOLAR" to (if (isBn) "গম্ভীর পুরুষ কণ্ঠ" else "Calm Scholar (Male)"),
                                        "GENTLE_FEMALE" to (if (isBn) "কোমল নারী কণ্ঠ" else "Gentle Female")
                                    ).filter { (styleId, _) ->
                                        // Only tones of the user's own gender are offered; gender (profile) is authoritative.
                                        NarrationVoiceResolver.genderOfStyle(styleId) == activeVoice.gender
                                    }.forEach { (styleId, label) ->
                                        GlassFilterChip(
                                            label = label,
                                            selected = activeVoice.styleId.equals(styleId, ignoreCase = true),
                                            onClick = { onSetSpeechVoiceStyle(styleId) },
                                            modifier = Modifier.testTag("settings_voice_$styleId")
                                        )
                                    }
                                }
                            }

                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text("${strings.asrSchoolLabel} & Hijri", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    GlassFilterChip(
                                        label = "Standard",
                                        selected = prefs.asrJuristicMethod == "STANDARD",
                                        onClick = { onSetAsrMethod("STANDARD") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    GlassFilterChip(
                                        label = "Hanafi",
                                        selected = prefs.asrJuristicMethod == "HANAFI",
                                        onClick = { onSetAsrMethod("HANAFI") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("${strings.hijriOffsetLabel}: ${if (prefs.hijriOffsetDays >= 0) "+${prefs.hijriOffsetDays}" else prefs.hijriOffsetDays}d", style = MaterialTheme.typography.labelLarge, color = palette.textSecondary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    (-2..2).forEach { offset ->
                                        GlassFilterChip(
                                            label = if (offset > 0) "+$offset" else "$offset",
                                            selected = prefs.hijriOffsetDays == offset,
                                            onClick = { onSetHijriOffset(offset) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(strings.learningModeLabel, style = MaterialTheme.typography.labelLarge, color = palette.textSecondary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("AUTO" to "Auto", "NEW_MUSLIM" to "Beginner", "REFERENCE" to "Library").forEach { (id, lbl) ->
                                        GlassFilterChip(
                                            label = lbl,
                                            selected = prefs.learningMode == id,
                                            onClick = { onSetLearningMode(id) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                ReminderToggleRow(strings.ramadanModeLabel, prefs.ramadanModeEnabled, onCheckedChange = onSetRamadanMode)
                            }
                        }

                        SettingsMenuSection.NOTIFICATIONS -> {
                            val soundEngine = LocalRuhZenaSound.current
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    StatusPillBadge(
                                        label = if (hasNotifPerm) strings.notificationPermissionGranted else strings.notificationPermissionMissing,
                                        accentColor = if (hasNotifPerm) palette.accentSoft else palette.amber,
                                        icon = if (hasNotifPerm) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff
                                    )
                                    if (!hasNotifPerm && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        GlassFilterChip(
                                            label = strings.grantPermission,
                                            selected = true,
                                            onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                ReminderToggleRow(strings.prayerReminders, prefs.prayerRemindersEnabled) {
                                    onUpdateReminders(it, null, null, null, null, null, null, null, null, null)
                                }
                                ReminderToggleRow(strings.waterReminders, prefs.waterRemindersEnabled) {
                                    onUpdateReminders(null, it, null, null, null, null, null, null, null, null)
                                }
                                ReminderToggleRow(strings.adhkarReminders, prefs.adhkarRemindersEnabled) {
                                    onUpdateReminders(null, null, it, null, null, null, null, null, null, null)
                                }
                                ReminderToggleRow(strings.workoutReminders, prefs.workoutRemindersEnabled) {
                                    onUpdateReminders(null, null, null, it, null, null, null, null, null, null)
                                }
                                ReminderToggleRow(strings.bedtimeReminders, prefs.bedtimeRemindersEnabled) {
                                    onUpdateReminders(null, null, null, null, it, null, null, null, null, null)
                                }
                                ReminderToggleRow(strings.lessonReminders, prefs.lessonRemindersEnabled) {
                                    onUpdateReminders(null, null, null, null, null, it, null, null, null, null)
                                }
                                ReminderToggleRow(
                                    label = strings.hourlyMotivationReminders,
                                    checked = prefs.hourlyMotivationEnabled,
                                    modifier = Modifier.testTag("settings_hourly_motivation_switch")
                                ) {
                                    onUpdateReminders(null, null, null, null, null, null, it, null, null, null)
                                }
                                ReminderToggleRow("${strings.quietHoursTitle} (22:00 – 05:00)", prefs.quietHoursEnabled) {
                                    onUpdateReminders(null, null, null, null, null, null, null, it, null, null)
                                }
                                ReminderToggleRow(strings.vibrationLabel, prefs.notificationVibrationEnabled) {
                                    onSetNotificationVibration(it)
                                }
                            }

                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = if (isBn) "অ্যালার্ট সাউন্ড ও মিউট কন্ট্রোল" else "Alert Sounds & Mute Center",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    GlassFilterChip(
                                        label = if (isBn) "পানির ফোঁটা" else "Water Drop",
                                        icon = Icons.Default.WaterDrop,
                                        selected = false,
                                        onClick = { soundEngine?.playWaterDropPreview() },
                                        modifier = Modifier.weight(1f).testTag("preview_water_drop_btn")
                                    )
                                    GlassFilterChip(
                                        label = if (isBn) "হিকমাহ ঘণ্টা" else "Hikmah Bell",
                                        icon = Icons.Default.AutoAwesome,
                                        selected = false,
                                        onClick = { soundEngine?.playHikmahBellPreview() },
                                        modifier = Modifier.weight(1f).testTag("preview_hikmah_bell_btn")
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    GlassFilterChip(
                                        label = if (isBn) "সাধারণ চাইম" else "Alert Chime",
                                        icon = Icons.Default.VolumeUp,
                                        selected = false,
                                        onClick = { soundEngine?.playNotificationPreview() },
                                        modifier = Modifier.weight(1f).testTag("preview_alert_sound_btn")
                                    )
                                    GlassFilterChip(
                                        label = strings.reminderToneLabel,
                                        icon = Icons.Default.MusicNote,
                                        selected = prefs.notificationToneUri.isNotBlank(),
                                        onClick = { tonePickerLauncher.launch(arrayOf("audio/*")) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedButton(
                                    onClick = {
                                        onDismiss()
                                        onOpenMotivationWindow()
                                    },
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("settings_motivation_window_button")
                                ) {
                                    Icon(Icons.Default.Schedule, contentDescription = null, tint = palette.gold, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(strings.openMotivationWindow, color = palette.textPrimary)
                                }
                            }
                        }

                        SettingsMenuSection.ACCOUNT_SYNC -> {
                            GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(palette.accentPrimary.copy(alpha = 0.16f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (isSignedIn) Icons.Default.CloudDone else Icons.Default.CloudOff,
                                                contentDescription = stringResource(R.string.cloud_account_section_title),
                                                tint = palette.accentPrimary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Text(
                                                text = if (isSignedIn) {
                                                    signedInUserName.ifBlank { stringResource(R.string.cloud_account_section_title) }
                                                } else {
                                                    stringResource(R.string.cloud_local_mode_title)
                                                },
                                                style = MaterialTheme.typography.titleSmall,
                                                color = palette.textPrimary
                                            )
                                            Text(
                                                text = if (isSignedIn && signedInUserEmail.isNotBlank()) {
                                                    signedInUserEmail
                                                } else {
                                                    stringResource(R.string.cloud_local_mode_desc)
                                                },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = palette.textSecondary
                                            )
                                        }
                                    }
                                    StatusPillBadge(
                                        label = if (isSignedIn && cloudSyncStatus.synced) stringResource(R.string.cloud_synced_badge)
                                        else stringResource(R.string.cloud_local_mode_badge),
                                        accentColor = if (isSignedIn) palette.accentPrimary else palette.textSecondary
                                    )
                                }
                                if (isSignedIn) {
                                    if (cloudSyncStatus.syncedCountsSummary.isNotBlank() || !cloudSyncStatus.errorMessage.isNullOrBlank()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = cloudSyncStatus.errorMessage ?: cloudSyncStatus.syncedCountsSummary,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (!cloudSyncStatus.errorMessage.isNullOrBlank()) MaterialTheme.colorScheme.error else palette.textSecondary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = onSyncCloudNow,
                                            enabled = !cloudSyncStatus.syncing,
                                            modifier = Modifier.weight(1f).testTag("cloud_sync_now_button")
                                        ) {
                                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(if (cloudSyncStatus.syncing) stringResource(R.string.cloud_syncing_label) else stringResource(R.string.cloud_sync_now_action))
                                        }
                                        OutlinedButton(
                                            onClick = onSignOut,
                                            modifier = Modifier.weight(1f).testTag("cloud_sign_out_button")
                                        ) {
                                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(stringResource(R.string.cloud_sign_out_action))
                                        }
                                    }
                                } else {
                                    if (!settingsSignInError.isNullOrBlank()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(settingsSignInError.orEmpty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            if (isSigningInFromSettings) return@Button
                                            settingsSignInError = null
                                            settingsScope.launch {
                                                isSigningInFromSettings = true
                                                when (val outcome = FirebaseAuthHelper.signInWithGoogle(context)) {
                                                    is GoogleAuthOutcome.Success -> settingsSignInError = null
                                                    GoogleAuthOutcome.Cancelled -> settingsSignInError = null
                                                    GoogleAuthOutcome.NoSavedCredential -> settingsSignInError = context.getString(R.string.auth_no_google_account_error)
                                                    is GoogleAuthOutcome.Error -> settingsSignInError = outcome.message
                                                }
                                                isSigningInFromSettings = false
                                            }
                                        },
                                        enabled = !isSigningInFromSettings,
                                        shape = RoundedCornerShape(14.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = palette.accentPrimary, contentColor = palette.voidBg),
                                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("settings_google_sign_in_button")
                                    ) {
                                        if (isSigningInFromSettings) {
                                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = palette.voidBg)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(stringResource(R.string.auth_signing_in_label))
                                        } else {
                                            Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(stringResource(R.string.auth_sign_in_with_google))
                                        }
                                    }
                                }
                            }

                            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(if (isBn) "রূহযেনা এআই" else "RuhZena AI", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                                        Text(
                                            text = if (isBn) "কোনো সেটআপ ছাড়াই প্রস্তুত—কুরআন, হাদিস, দৈনন্দিন জীবন ও সুস্থতায় আপনার সঙ্গী।" else "Built in and ready to assist across Quran, Hadith, daily habits, and wellness.",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = palette.textSecondary
                                        )
                                    }
                                }
                            }
                        }

                        SettingsMenuSection.DATA_GUIDES -> {
                            // Interactive Guides Replay
                            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.School, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isBn) "অ্যাপ গাইড ও টিউটোরিয়াল" else "Interactive App Guides",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = palette.textPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isBn) "প্রতিটি পেজের স্পটলাইট টিউটোরিয়াল পুনরায় চালু করুন।" else "Reset and replay contextual spotlight guides across Home, Quran, Surah Reader, Learn, and Life.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedButton(
                                    onClick = {
                                        onDismiss()
                                        onReplayTutorial()
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("settings_replay_tutorial_btn")
                                ) {
                                    Icon(Icons.Default.School, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isBn) "সব পেজের অ্যাপ গাইড আবার দেখুন" else "Replay All App Guides",
                                        color = palette.textPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // Permissions
                            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = !hasNotifPerm || !hasLocationPerm) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Settings, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isBn) "অ্যাপ অনুমতি ও ফোন সেটিংস" else "App Permissions & Phone Settings",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = palette.textPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    StatusPillBadge(
                                        label = if (hasLocationPerm) (if (isBn) "লোকেশন সক্রিয়" else "Location Active") else (if (isBn) "লোকেশন বন্ধ" else "Location Off"),
                                        accentColor = if (hasLocationPerm) palette.accentSoft else palette.amber,
                                        icon = Icons.Default.LocationOn
                                    )
                                    StatusPillBadge(
                                        label = if (hasNotifPerm) (if (isBn) "নোটিফিকেশন সক্রিয়" else "Alerts Active") else (if (isBn) "নোটিফিকেশন বন্ধ" else "Alerts Off"),
                                        accentColor = if (hasNotifPerm) palette.accentSoft else palette.amber,
                                        icon = if (hasNotifPerm) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (!hasLocationPerm || !hasNotifPerm) {
                                        GlassFilterChip(
                                            label = if (isBn) "অনুমতি দিন" else "Grant Permissions",
                                            selected = true,
                                            onClick = {
                                                val req = buildList {
                                                    if (!hasLocationPerm) {
                                                        add(Manifest.permission.ACCESS_FINE_LOCATION)
                                                        add(Manifest.permission.ACCESS_COARSE_LOCATION)
                                                    }
                                                    if (!hasNotifPerm && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                        add(Manifest.permission.POST_NOTIFICATIONS)
                                                    }
                                                }.toTypedArray()
                                                if (req.isNotEmpty()) allPermissionsLauncher.launch(req)
                                            },
                                            modifier = Modifier.weight(1f).testTag("settings_grant_all_permissions_btn")
                                        )
                                    }
                                    OutlinedButton(
                                        onClick = { openAppSettings(context) },
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_open_phone_settings_btn")
                                    ) {
                                        Icon(Icons.Default.Settings, contentDescription = null, tint = palette.gold, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isBn) "ফোন সেটিংস" else "Phone Settings", color = palette.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }

                            // Backup, Selective Clear & Reset
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Backup, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(strings.backupRestoreTitle, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(strings.safetyPrivacySummary, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    EmeraldActionButton(
                                        text = strings.exportBackupBtn,
                                        icon = Icons.Default.Download,
                                        onClick = {
                                            val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                                            exportBackupLauncher.launch("ruhzena_backup_$stamp.json")
                                        },
                                        modifier = Modifier.weight(1f).testTag("settings_backup_export_button")
                                    )
                                    OutlinedButton(
                                        onClick = { importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) },
                                        modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("settings_backup_import_button")
                                    ) {
                                        Icon(Icons.Default.Restore, contentDescription = null, tint = palette.gold, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(strings.importBackupBtn, color = palette.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                if (!backupStatusMessage.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(backupStatusMessage, style = MaterialTheme.typography.labelMedium, color = palette.accentSoft, modifier = Modifier.testTag("backup_status_message"))
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(strings.selectiveClearTitle, style = MaterialTheme.typography.labelLarge, color = palette.textSecondary)
                                Spacer(modifier = Modifier.height(6.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    GlassFilterChip(label = "Clear Journal", selected = false, onClick = onClearJournal)
                                    GlassFilterChip(label = "Clear Habits", selected = false, onClick = onClearHabits)
                                    GlassFilterChip(label = "Clear Wellness Logs", selected = false, onClick = onClearWellness)
                                    GlassFilterChip(label = "Clear AI Chat", selected = false, onClick = onClearAiChat)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = { showResetConfirm = true },
                                    modifier = Modifier.fillMaxWidth().testTag("settings_reset_all_button")
                                ) {
                                    Icon(Icons.Default.DeleteForever, contentDescription = null, tint = palette.coral, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(strings.fullResetAction, color = palette.coral)
                                }
                            }

                            // Sources & Integrity Ledger
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(strings.sourcesAndIntegrityTitle, style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                SourceLinkRow("Quran Text & Translations (Uthmani, Sahih Int'l, Bengali)", "https://alquran.cloud")
                                SourceLinkRow("Quran Recitations (Alafasy, Abdul Basit, Husary, Minshawi, Maher)", "https://islamic.network")
                                SourceLinkRow("Hadith & Adhkar Collections (Bukhari, Muslim, Tirmidhi, Abu Dawud)", "https://sunnah.com")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            containerColor = palette.surfaceBg,
            title = { Text(strings.fullResetAction, color = palette.textPrimary) },
            text = {
                Text(
                    text = if (isBn) "সব ব্যক্তিগত ডেটা এবং প্রোফাইল স্থায়ীভাবে মুছে ফেলা হবে।" else "This permanently deletes all local logs, habits, journal entries, and preferences on this device.",
                    color = palette.textSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showResetConfirm = false
                    onDismiss()
                    onResetAllData()
                }) {
                    Text(strings.deleteAction, color = palette.coral)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text(strings.closeAction, color = palette.textSecondary)
                }
            }
        )
    }
}

@Composable
fun MotivationAndRemindersDialog(
    prefs: UserPreferences,
    waterMlToday: Int,
    nextPrayer: NextPrayerInfo,
    initialExpandMutePicker: Boolean = false,
    onAddWater: (Int) -> Unit,
    onSnoozeWater5Min: () -> Unit = {},
    onMuteForHours: (Int) -> Unit = {},
    onUnmuteNotifications: () -> Unit = {},
    onSendPreviewNotification: (String) -> Boolean,
    onSetBannerDismissed: (Boolean) -> Unit = {},
    onDismiss: () -> Unit
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val context = LocalContext.current
    val currentHour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    var insightOffset by rememberSaveable { mutableIntStateOf(0) }
    var notifFeedback by remember { mutableStateOf<String?>(null) }
    var showMuteDurationPicker by rememberSaveable { mutableStateOf(initialExpandMutePicker) }
    var customWaterInput by rememberSaveable { mutableStateOf("") }
    var pendingPreviewType by remember { mutableStateOf(RuhZenaReminderWorker.TYPE_WATER) }

    val nowMs = System.currentTimeMillis()
    val isMutedNow = prefs.mutedUntilEpochMs > nowMs
    val mutedUntilLabel = remember(prefs.mutedUntilEpochMs) {
        if (prefs.mutedUntilEpochMs > System.currentTimeMillis()) {
            java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault())
                .format(java.util.Date(prefs.mutedUntilEpochMs))
        } else ""
    }

    val insight = remember(currentHour, insightOffset) {
        MotivationKnowledgeCatalog.forHour(currentHour, insightOffset)
    }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onSendPreviewNotification(pendingPreviewType)
            notifFeedback = if (isBn) "অ্যাকশনযোগ্য নোটিফিকেশন ও সাউন্ড পাঠানো হয়েছে!" else "Interactive notification & sound dispatched!"
        } else {
            notifFeedback = if (isBn) "নোটিফিকেশন অনুমতি প্রয়োজন।" else "Notification permission denied."
        }
    }

    fun triggerAlertPreview(type: String, labelEn: String, labelBn: String) {
        pendingPreviewType = type
        if (RuhZenaNotificationHelper.hasNotificationPermission(context)) {
            onSendPreviewNotification(type)
            notifFeedback = if (isBn) "$labelBn নোটিফিকেশন পাঠানো হয়েছে (পানি লিখুন / ৫ মি. স্নুজ / মিউট)।" else "$labelEn notification sent! Pull down the shade to test sound & buttons."
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val soundEngine = LocalRuhZenaSound.current
    val dialogShape = RoundedCornerShape(26.dp)
    val specularRim = Brush.verticalGradient(
        listOf(
            Color.White.copy(alpha = if (palette.isLight) 0.78f else 0.24f),
            palette.borderAccent,
            palette.borderNeutral
        )
    )

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler(onBack = onDismiss)
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
                .border(1.1.dp, specularRim, dialogShape),
            shape = dialogShape,
            color = Color.Transparent
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                palette.cardElevatedBg.copy(alpha = 0.96f),
                                palette.surfaceBg.copy(alpha = 0.98f),
                                palette.voidBg.copy(alpha = 0.98f)
                            )
                        )
                    )
                    .verticalScroll(rememberScrollState())
                    .padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(strings.motivationWindowTitle, style = MaterialTheme.typography.headlineSmall, color = palette.textPrimary)
                        Text(
                            text = if (isBn) "প্রতি ঘণ্টার হিকমাহ, সংক্ষিপ্ত দুআ ও অ্যাকশনযোগ্য রিমাইন্ডার" else "Hourly Hikmah, short Sunnah Duas & interactive reminders",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_motivation_window_button")) {
                        Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.textSecondary)
                    }
                }

                // ── MUTE NOTIFICATIONS CONTROL (Clicking shows hours selector: 1h / 2h / 4h / 8h / 24h) ──
                GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = isMutedNow) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = if (isMutedNow) Icons.Default.NotificationsOff else Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = if (isMutedNow) palette.gold else palette.accentSoft,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isMutedNow) {
                                        if (isBn) "নোটিফিকেশন মিউট আছে ($mutedUntilLabel পর্যন্ত)" else "Alerts muted until $mutedUntilLabel"
                                    } else {
                                        if (isBn) "নোটিফিকেশন মিউট সিস্টেম" else "Mute Notifications"
                                    },
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = if (isBn) "কত ঘণ্টার জন্য মিউট করবেন তা বাছাই করুন" else "Tap Mute to choose how many hours",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.textSecondary
                                )
                            }
                        }
                        if (isMutedNow) {
                            GlassFilterChip(
                                label = if (isBn) "আনমিউট" else "Unmute",
                                selected = true,
                                onClick = {
                                    onUnmuteNotifications()
                                    showMuteDurationPicker = false
                                    notifFeedback = if (isBn) "নোটিফিকেশন পুনরায় চালু হয়েছে।" else "Notifications unmuted."
                                },
                                modifier = Modifier.testTag("unmute_notifications_button")
                            )
                        } else {
                            GlassFilterChip(
                                label = if (isBn) "মিউট" else "Mute",
                                icon = Icons.Default.NotificationsOff,
                                selected = showMuteDurationPicker,
                                onClick = { showMuteDurationPicker = !showMuteDurationPicker },
                                modifier = Modifier.testTag("mute_notifications_toggle_button")
                            )
                        }
                    }

                    if (showMuteDurationPicker) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (isBn) "কত ঘণ্টার জন্য মিউট করবেন?" else "Mute for how many hours?",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.gold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(1, 2, 4, 8, 24).forEach { hrs ->
                                GlassFilterChip(
                                    label = if (isBn) "${hrs}ঘণ্টা" else "${hrs}h",
                                    selected = false,
                                    onClick = {
                                        onMuteForHours(hrs)
                                        showMuteDurationPicker = false
                                        notifFeedback = if (isBn) "$hrs ঘণ্টার জন্য সব নোটিফিকেশন মিউট করা হয়েছে।" else "All alerts muted for ${hrs}h."
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("mute_hours_${hrs}h")
                                )
                            }
                        }
                    }
                }

                // Live Hourly Knowledge, Short Sunnah Duas & Motivation Card
                GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPillBadge(
                            label = if (isBn) insight.themeBn else insight.themeEn,
                            accentColor = palette.gold
                        )
                        Text(
                            text = "#${insight.id}/${MotivationKnowledgeCatalog.items.size}",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = palette.textMuted
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isBn) insight.motivationBn else insight.motivationEn,
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(palette.accentContainer.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                            .border(0.8.dp, palette.borderAccent, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = if (isBn) "সংক্ষিপ্ত ইসলামিক জ্ঞান ও দুআ" else "Short Islamic Knowledge & Dua",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.accentSoft
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isBn) insight.knowledgeBn else insight.knowledgeEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textPrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        com.example.ruhzena.core.ui.GoldSourceTag(
                            sourceText = "${insight.reference} • ${insight.sourceUrl.removePrefix("https://")} ↗",
                            modifier = Modifier
                                .clickable {
                                    runCatching {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(insight.sourceUrl)))
                                    }
                                }
                                .testTag("motivation_source_link")
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GlassFilterChip(
                            label = if (isBn) "আগেরটি" else "Previous",
                            selected = false,
                            onClick = { insightOffset -= 1 },
                            modifier = Modifier.weight(1f)
                        )
                        GlassFilterChip(
                            label = if (isBn) "পরবর্তী" else "Next",
                            selected = true,
                            onClick = { insightOffset += 1 },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("next_insight_button")
                        )
                    }
                }

                // Live Water Direct ml Entry + 5-Min Snooze + Prayer Countdown
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WaterDrop, contentDescription = null, tint = palette.sky, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${strings.hydrationLabel}: $waterMlToday / ${prefs.hydrationGoalMl} ml",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.textPrimary
                            )
                        }
                        GlassFilterChip(
                            label = "+250 ml",
                            selected = true,
                            onClick = {
                                onAddWater(250)
                                notifFeedback = if (isBn) "+২৫০ মি.লি. পানি লগ হয়েছে!" else "Logged +250 ml water!"
                            },
                            modifier = Modifier.testTag("window_add_water_button")
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    val pct = (waterMlToday.toFloat() / prefs.hydrationGoalMl.coerceAtLeast(1)).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { pct },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = palette.sky,
                        trackColor = palette.blockBg
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    // Direct Custom Water ml Input + Log + Snooze 5m
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = customWaterInput,
                            onValueChange = { txt -> customWaterInput = txt.filter { it.isDigit() }.take(4) },
                            placeholder = { Text(if (isBn) "এখানে লিখুন (ml)" else "Type here", color = palette.textMuted) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = palette.sky,
                                unfocusedBorderColor = palette.borderNeutral,
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            ),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("custom_water_ml_input")
                        )
                        GlassFilterChip(
                            label = if (isBn) "লগ" else "Log ml",
                            selected = true,
                            onClick = {
                                val ml = customWaterInput.toIntOrNull()?.coerceIn(10, 5000)
                                if (ml != null) {
                                    onAddWater(ml)
                                    customWaterInput = ""
                                    notifFeedback = if (isBn) "+$ml মি.লি. পানি সংরক্ষণ হয়েছে!" else "Logged +$ml ml water!"
                                }
                            },
                            modifier = Modifier.testTag("log_custom_water_button")
                        )
                        GlassFilterChip(
                            label = if (isBn) "৫মি. স্নুজ" else "Snooze 5m",
                            icon = Icons.Default.Schedule,
                            selected = false,
                            onClick = {
                                onSnoozeWater5Min()
                                notifFeedback = if (isBn) "৫ মিনিট পর পানি পানের রিমাইন্ডার আসবে।" else "Water reminder snoozed for 5 minutes."
                            },
                            modifier = Modifier.testTag("snooze_water_5m_button")
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    val remH = nextPrayer.minutesRemaining / 60
                    val remM = nextPrayer.minutesRemaining % 60
                    val countdown = if (remH > 0) "${remH}h ${remM}m" else "${remM}m"
                    Text(
                        text = "${strings.nextPrayerLabel}: ${nextPrayer.prayerKey} • ${nextPrayer.timeFormatted} (${strings.prayerInPrefix} $countdown)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.gold
                    )
                }

                // Interactive Notification & Ringtone Testing Center
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = if (isBn) "সাউন্ড ও অ্যাকশনযোগ্য নোটিফিকেশন পরীক্ষা" else "Interactive Alert & Sound Center",
                        style = MaterialTheme.typography.titleSmall,
                        color = palette.textPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isBn) "ট্যাপ করলে সাউন্ডসহ নোটিফিকেশন আসবে — পানিতে সরাসরি ml লিখুন, ৫ মি. স্নুজ করুন অথবা মিউট করুন।" else "Tap any alert below to hear its ringtone and test inline Water ml reply, 5m Snooze, and Mute hours in your notification shade.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GlassFilterChip(
                            label = if (isBn) "পানি অ্যালার্ট" else "Water Alert",
                            icon = Icons.Default.WaterDrop,
                            selected = true,
                            onClick = { triggerAlertPreview(RuhZenaReminderWorker.TYPE_WATER, "Water", "পানি পানের") },
                            modifier = Modifier.weight(1f).testTag("preview_water_notif_button")
                        )
                        GlassFilterChip(
                            label = if (isBn) "আযান" else "Adhan",
                            icon = Icons.Default.MusicNote,
                            selected = false,
                            onClick = { triggerAlertPreview(RuhZenaReminderWorker.TYPE_PRAYER, "Prayer Adhan", "নামাজের আযান") },
                            modifier = Modifier.weight(1f).testTag("preview_prayer_notif_button")
                        )
                        GlassFilterChip(
                            label = if (isBn) "হিকমাহ" else "Hikmah",
                            icon = Icons.Default.AutoAwesome,
                            selected = false,
                            onClick = { triggerAlertPreview(RuhZenaReminderWorker.TYPE_HOURLY_MOTIVATION, "Hourly Hikmah", "ঘণ্টাভিত্তিক হিকমাহ") },
                            modifier = Modifier.weight(1f).testTag("preview_motivation_notif_button")
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GlassFilterChip(
                            label = if (isBn) "আযান টোন" else "Hear Adhan",
                            icon = Icons.Default.VolumeUp,
                            selected = false,
                            onClick = { soundEngine?.playRingtonePreview() },
                            modifier = Modifier.weight(1f)
                        )
                        GlassFilterChip(
                            label = if (isBn) "পানি টোন" else "Hear Drop",
                            icon = Icons.Default.VolumeUp,
                            selected = false,
                            onClick = { soundEngine?.playWaterDropPreview() },
                            modifier = Modifier.weight(1f)
                        )
                        GlassFilterChip(
                            label = if (isBn) "বেল টোন" else "Hear Bell",
                            icon = Icons.Default.VolumeUp,
                            selected = false,
                            onClick = { soundEngine?.playHikmahBellPreview() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GlassFilterChip(
                        label = if (prefs.motivationBannerDismissed) {
                            if (isBn) "হোম কার্ড দেখান" else "Show on Home"
                        } else {
                            if (isBn) "হোম কার্ড লুকান" else "Hide Home Card"
                        },
                        selected = !prefs.motivationBannerDismissed,
                        onClick = { onSetBannerDismissed(!prefs.motivationBannerDismissed) },
                        modifier = Modifier.weight(1f)
                    )
                    GlassFilterChip(
                        label = if (isBn) "বন্ধ করুন" else "Close",
                        selected = false,
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    )
                }

                if (notifFeedback != null) {
                    Text(notifFeedback!!, style = MaterialTheme.typography.labelMedium, color = palette.accentSoft)
                }
            }
        }
    }
}

@Composable
private fun SettingsHubMenuCard(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    badge: String? = null,
    accentBorder: Boolean = false,
    testTag: String,
    onClick: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        accentBorder = accentBorder,
        elevated = accentBorder,
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(iconTint.copy(alpha = 0.16f))
                    .border(0.9.dp, iconTint.copy(alpha = 0.42f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(21.dp)
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (!badge.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = iconTint.copy(alpha = 0.14f)
                ) {
                    Text(
                        text = badge,
                        style = MaterialTheme.typography.labelSmall,
                        color = iconTint,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = palette.textMuted,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ReminderToggleRow(
    label: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.onAccent,
                checkedTrackColor = palette.accentPrimary,
                uncheckedThumbColor = palette.textSecondary,
                uncheckedTrackColor = palette.blockBg
            )
        )
    }
}

@Composable
private fun SourceLinkRow(title: String, url: String) {
    val context = LocalContext.current
    val palette = LocalRuhZenaPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(0.6.dp, palette.gold.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
            .clickable {
                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.bodySmall, color = palette.textPrimary, modifier = Modifier.weight(1f))
        Spacer(modifier = Modifier.width(8.dp))
        Text(url.removePrefix("https://"), style = MaterialTheme.typography.labelSmall, color = palette.gold, fontWeight = FontWeight.SemiBold)
    }
}

private fun hasAnyLocationPermission(context: Context): Boolean {
    return ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
}

private fun openAppSettings(context: Context) {
    runCatching {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", context.packageName, null)
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}



