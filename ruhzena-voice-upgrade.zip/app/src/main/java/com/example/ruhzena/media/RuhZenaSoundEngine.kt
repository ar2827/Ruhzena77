package com.example.ruhzena.media

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import androidx.compose.runtime.staticCompositionLocalOf
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Low-latency tactile UI & spiritual sound engine for RuhZena.
 * Plays crisp click feedback on buttons/tabs/dropdowns, authentic olive-wood bead clicks
 * on Tasbih & Adhkar counters, completion chimes, and ringtone/notification previews.
 */
class RuhZenaSoundEngine(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(6)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private var clickSoundId: Int = 0
    private var tasbihBeadSoundId: Int = 0
    private var chimeSoundId: Int = 0
    private val loadedIds = mutableSetOf<Int>()
    private var previewPlayer: MediaPlayer? = null

    @Volatile
    var soundsEnabled: Boolean = true

    init {
        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                synchronized(loadedIds) { loadedIds.add(sampleId) }
            }
        }
        scope.launch {
            runCatching {
                clickSoundId = soundPool.load(appContext, R.raw.ruhzena_click, 1)
                tasbihBeadSoundId = soundPool.load(appContext, R.raw.ruhzena_tasbih_bead, 1)
                chimeSoundId = soundPool.load(appContext, R.raw.ruhzena_chime, 1)
            }
        }
    }

    fun playClick(pitch: Float = 1.0f, volume: Float = 0.52f) {
        if (!soundsEnabled) return
        val id = clickSoundId
        if (id != 0 && isLoaded(id)) {
            runCatching { soundPool.play(id, volume, volume, 1, 0, pitch.coerceIn(0.75f, 1.35f)) }
        }
    }

    fun playFoldDropdown(opening: Boolean) {
        if (!soundsEnabled) return
        val id = clickSoundId
        if (id != 0 && isLoaded(id)) {
            val rate = if (opening) 1.08f else 0.90f
            runCatching { soundPool.play(id, 0.56f, 0.56f, 1, 0, rate) }
        }
    }

    fun playTasbihBead(stepIndex: Int = 0) {
        if (!soundsEnabled) return
        val id = tasbihBeadSoundId
        if (id != 0 && isLoaded(id)) {
            // Subtle organic wood-bead pitch variation so repeated taps feel alive and authentic
            val variation = 0.96f + ((stepIndex % 5) * 0.02f)
            runCatching { soundPool.play(id, 0.85f, 0.85f, 2, 0, variation) }
        }
    }

    fun playChime(volume: Float = 0.72f) {
        if (!soundsEnabled) return
        val id = chimeSoundId
        if (id != 0 && isLoaded(id)) {
            runCatching { soundPool.play(id, volume, volume, 2, 0, 1.0f) }
        }
    }

    fun playBreathPhaseCue(isInhale: Boolean) {
        if (!soundsEnabled) return
        val id = chimeSoundId
        if (id != 0 && isLoaded(id)) {
            val rate = if (isInhale) 1.05f else 0.84f
            runCatching { soundPool.play(id, 0.34f, 0.34f, 1, 0, rate) }
        }
    }

    fun playNotificationPreview() {
        playRawPreview(R.raw.ruhzena_notification)
    }

    fun playRingtonePreview() {
        playRawPreview(R.raw.ruhzena_adhan_prayer)
    }

    fun playWaterDropPreview() {
        playRawPreview(R.raw.ruhzena_water_drop)
    }

    fun playHikmahBellPreview() {
        playRawPreview(R.raw.ruhzena_hikmah_bell)
    }

    fun stopPreview() {
        runCatching {
            previewPlayer?.stop()
            previewPlayer?.release()
        }
        previewPlayer = null
    }

    private fun playRawPreview(rawResId: Int) {
        stopPreview()
        runCatching {
            val mp = MediaPlayer.create(appContext, rawResId)
            previewPlayer = mp
            mp?.setOnCompletionListener {
                runCatching { it.release() }
                if (previewPlayer === it) previewPlayer = null
            }
            mp?.start()
        }
    }

    private fun isLoaded(id: Int): Boolean = synchronized(loadedIds) { loadedIds.contains(id) }

    fun release() {
        stopPreview()
        runCatching { soundPool.release() }
    }
}

val LocalRuhZenaSound = staticCompositionLocalOf<RuhZenaSoundEngine?> { null }
