package com.example.ruhzena.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.ui.exercises.ExerciseLibrary
import com.example.ruhzena.ui.exercises.SculptedExerciseViewport
import com.example.ruhzena.ui.exercises.WorkoutProgram
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import kotlinx.coroutines.delay

private enum class GuidedPhase { GET_READY, ACTIVE_EXERCISE, REST, COMPLETED }

@Composable
fun GuidedWorkoutPreviewDialog(
    program: WorkoutProgram,
    isBn: Boolean,
    onDismiss: () -> Unit,
    onStartWorkout: () -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler(onBack = onDismiss)
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = palette.voidBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(label = "${program.level} • ${program.accentTag}", accentColor = palette.gold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = palette.textSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isBn) program.titleBn else program.titleEn,
                    style = MaterialTheme.typography.headlineMedium,
                    color = palette.textPrimary
                )
                Text(
                    text = if (isBn) program.subtitleBn else program.subtitleEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )

                Spacer(modifier = Modifier.height(10.dp))
                GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true, contentPadding = PaddingValues(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        PreviewStatMetric("${program.durationMinutes} min", if (isBn) "সময়" else "Duration")
                        PreviewStatMetric("~${program.estimatedKcal} kcal", if (isBn) "ক্যালোরি" else "Burn")
                        PreviewStatMetric("${program.stations.size}", if (isBn) "ব্যায়াম" else "Exercises")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = if (isBn) "সেশনের ব্যায়াম তালিকা" else "Workout Sequence",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.accentSoft
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(program.stations) { index, station ->
                        val ex = ExerciseLibrary.findById(station.exerciseId)
                        GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .background(palette.accentPrimary.copy(alpha = 0.16f), CircleShape)
                                            .border(0.8.dp, palette.accentPrimary.copy(alpha = 0.5f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${index + 1}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = palette.accentSoft
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = if (isBn) ex.nameBn else ex.nameEn,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = palette.textPrimary
                                        )
                                        Text(
                                            text = if (isBn) ex.easierAltBn else ex.easierAltEn,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = palette.textMuted,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                val targetLabel = when {
                                    station.durationSec != null -> "${station.durationSec}s"
                                    station.targetReps != null -> "×${station.targetReps}"
                                    else -> "12 reps"
                                }
                                StatusPillBadge(label = targetLabel, accentColor = palette.gold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                EmeraldActionButton(
                    text = if (isBn) "গাইডেড ওয়ার্কআউট শুরু করুন" else "START WORKOUT",
                    icon = Icons.Default.PlayArrow,
                    onClick = onStartWorkout,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("start_guided_workout_button")
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun PreviewStatMetric(value: String, label: String) {
    val palette = LocalRuhZenaPalette.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily, fontWeight = FontWeight.Bold),
            color = palette.textPrimary
        )
        Text(label, style = MaterialTheme.typography.labelSmall, color = palette.textMuted)
    }
}

@Composable
fun GuidedWorkoutSessionDialog(
    program: WorkoutProgram,
    isBn: Boolean,
    characterGender: String = "MALE",
    onDismiss: () -> Unit,
    onCompleteWorkout: (title: String, exerciseCount: Int, durationMin: Int, kcal: Int) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val haptics = LocalHapticFeedback.current
    var stationIndex by remember(program.id) { mutableIntStateOf(0) }
    var phase by remember(program.id) { mutableStateOf(GuidedPhase.GET_READY) }
    var isPaused by remember(program.id) { mutableStateOf(false) }
    var showFormTips by remember(program.id) { mutableStateOf(false) }
    var countdownSec by remember(program.id) { mutableIntStateOf(8) }
    var workoutLogged by remember(program.id) { mutableStateOf(false) }

    val totalStations = program.stations.size
    val currentStation = program.stations[stationIndex.coerceIn(0, totalStations - 1)]
    val currentExercise = ExerciseLibrary.findById(currentStation.exerciseId)

    fun moveToNextStationOrComplete(allowRest: Boolean = true) {
        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
        if (stationIndex >= totalStations - 1) {
            phase = GuidedPhase.COMPLETED
        } else if (allowRest && currentStation.restAfterSec > 0 && phase == GuidedPhase.ACTIVE_EXERCISE) {
            countdownSec = currentStation.restAfterSec
            phase = GuidedPhase.REST
            isPaused = false
        } else {
            val nextIdx = (stationIndex + 1).coerceAtMost(totalStations - 1)
            stationIndex = nextIdx
            val nextSt = program.stations[nextIdx]
            countdownSec = nextSt.durationSec ?: 0
            phase = GuidedPhase.ACTIVE_EXERCISE
            isPaused = false
            showFormTips = false
        }
    }

    fun startActiveFromRestOrReady() {
        if (phase == GuidedPhase.REST) {
            stationIndex = (stationIndex + 1).coerceAtMost(totalStations - 1)
        }
        val st = program.stations[stationIndex]
        countdownSec = st.durationSec ?: 0
        phase = GuidedPhase.ACTIVE_EXERCISE
        isPaused = false
        showFormTips = false
    }

    LaunchedEffect(phase, stationIndex, isPaused) {
        if (isPaused) return@LaunchedEffect
        val isTimedActive = phase == GuidedPhase.ACTIVE_EXERCISE && currentStation.durationSec != null
        val shouldTick = phase == GuidedPhase.GET_READY || phase == GuidedPhase.REST || isTimedActive
        while (shouldTick && !isPaused && countdownSec > 0) {
            delay(1000L)
            countdownSec -= 1
        }
        if (!isPaused && countdownSec == 0) {
            when (phase) {
                GuidedPhase.GET_READY -> startActiveFromRestOrReady()
                GuidedPhase.REST -> startActiveFromRestOrReady()
                GuidedPhase.ACTIVE_EXERCISE -> if (currentStation.durationSec != null) {
                    moveToNextStationOrComplete(allowRest = true)
                }
                GuidedPhase.COMPLETED -> Unit
            }
        }
    }

    LaunchedEffect(phase) {
        if (phase == GuidedPhase.COMPLETED && !workoutLogged) {
            workoutLogged = true
            onCompleteWorkout(
                if (isBn) program.titleBn else program.titleEn,
                program.stations.size,
                program.durationMinutes,
                program.estimatedKcal
            )
        }
    }

    SafeFullScreenDialog(onDismissRequest = onDismiss) {
        BackHandler(onBack = onDismiss)
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = palette.voidBg
        ) {
            BoxWithConstraints(
                modifier = Modifier.fillMaxSize()
            ) {
                val compactPhone = maxHeight < 680.dp
                val demoHeight = if (compactPhone) 168.dp else 210.dp
                val ringSize = if (compactPhone) 110.dp else 130.dp

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 20.dp)
                ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) program.titleBn else program.titleEn,
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (phase == GuidedPhase.COMPLETED) {
                                if (isBn) "সম্পন্ন!" else "Session Completed"
                            } else {
                                "${if (isBn) "ব্যায়াম" else "Exercise"} ${stationIndex + 1} / $totalStations"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.accentSoft
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("guided_close_button")) {
                        Icon(Icons.Default.Close, contentDescription = "Exit workout", tint = palette.textSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (i in 0 until totalStations) {
                        val barColor = when {
                            phase == GuidedPhase.COMPLETED || i < stationIndex -> palette.accentPrimary
                            i == stationIndex -> palette.gold
                            else -> palette.borderNeutral.copy(alpha = 0.45f)
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(barColor)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                AnimatedContent(
                    targetState = phase to stationIndex,
                    transitionSpec = {
                        (fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                            slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { it / 8 } +
                            scaleIn(initialScale = 0.96f, animationSpec = tween(240))) togetherWith
                            (fadeOut(tween(160)) + slideOutHorizontally(tween(180)) { -it / 10 })
                    },
                    modifier = Modifier.weight(1f),
                    label = "workoutPhaseTransition"
                ) { (activePhase, _) ->
                    Column(modifier = Modifier.fillMaxSize()) {
                when (activePhase) {
                    GuidedPhase.GET_READY -> {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            StatusPillBadge(
                                label = if (isBn) "প্রস্তুত হোন" else "READY TO GO",
                                accentColor = palette.gold
                            )
                            Text(
                                text = if (isBn) currentExercise.nameBn else currentExercise.nameEn,
                                style = MaterialTheme.typography.headlineMedium,
                                color = palette.textPrimary,
                                textAlign = TextAlign.Center
                            )
                            SculptedExerciseViewport(
                                exercise = currentExercise,
                                isPlaying = !isPaused,
                                height = demoHeight,
                                characterGender = characterGender
                            )
                            AnimatedCountdownRing(
                                remainingSeconds = countdownSec,
                                totalSeconds = 8,
                                accentColor = palette.accentSoft,
                                ringSize = ringSize
                            )
                            Text(
                                text = if (isBn) currentExercise.breathingBn else currentExercise.breathingEn,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        EmeraldActionButton(
                            text = if (isBn) "এখনই শুরু করুন" else "Skip Countdown",
                            icon = Icons.Default.PlayArrow,
                            onClick = { startActiveFromRestOrReady() },
                            modifier = Modifier.fillMaxWidth().testTag("guided_skip_ready_button")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    GuidedPhase.ACTIVE_EXERCISE -> {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            SculptedExerciseViewport(
                                exercise = currentExercise,
                                isPlaying = !isPaused,
                                height = demoHeight,
                                characterGender = characterGender
                            )

                            Text(
                                text = if (isBn) currentExercise.nameBn else currentExercise.nameEn,
                                style = MaterialTheme.typography.headlineSmall,
                                color = palette.textPrimary,
                                textAlign = TextAlign.Center
                            )

                            val stationDur = currentStation.durationSec
                            if (stationDur != null) {
                                AnimatedCountdownRing(
                                    remainingSeconds = countdownSec,
                                    totalSeconds = stationDur.coerceAtLeast(1),
                                    accentColor = palette.accentSoft,
                                    ringSize = ringSize
                                )
                            } else {
                                Text(
                                    text = "× ${currentStation.targetReps ?: 12}",
                                    style = MaterialTheme.typography.displayMedium.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = palette.gold
                                )
                                Text(
                                    text = if (isBn) "নিয়ন্ত্রিত ও সঠিক ভঙ্গিতে পুনরাবৃত্তি সম্পন্ন করুন" else "Complete target reps with clean controlled form",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                GlassFilterChip(
                                    label = if (isBn) "সঠিক ভঙ্গি" else "Form Tips",
                                    selected = showFormTips,
                                    icon = Icons.Default.Info,
                                    onClick = { showFormTips = !showFormTips }
                                )
                            }

                            AnimatedVisibility(visible = showFormTips) {
                                GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(12.dp)) {
                                    Text(
                                        text = if (isBn) currentExercise.musclesBn else currentExercise.musclesEn,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = palette.accentSoft
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    (if (isBn) currentExercise.postureBn else currentExercise.postureEn).forEach { tip ->
                                        Text("• $tip", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${if (isBn) "সহজ বিকল্প" else "Easier Option"}: ${if (isBn) currentExercise.easierAltBn else currentExercise.easierAltEn}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.gold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    if (stationIndex > 0) {
                                        stationIndex -= 1
                                        countdownSec = program.stations[stationIndex].durationSec ?: 0
                                        isPaused = false
                                    }
                                },
                                enabled = stationIndex > 0,
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(palette.surfaceBg, CircleShape)
                                    .border(1.dp, palette.borderNeutral, CircleShape)
                            ) {
                                Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = palette.textPrimary)
                            }

                            IconButton(
                                onClick = { isPaused = !isPaused },
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(palette.surfaceBg, CircleShape)
                                    .border(1.dp, palette.borderNeutral, CircleShape)
                                    .testTag("guided_pause_button")
                            ) {
                                Icon(
                                    imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                    contentDescription = if (isPaused) "Resume" else "Pause",
                                    tint = palette.gold
                                )
                            }

                            val isFinalStation = stationIndex >= totalStations - 1
                            EmeraldActionButton(
                                text = if (isFinalStation) {
                                    if (isBn) "সম্পন্ন" else "Done"
                                } else {
                                    if (isBn) "পরবর্তী" else "Next"
                                },
                                icon = if (isFinalStation) Icons.Default.Check else Icons.Default.SkipNext,
                                onClick = { moveToNextStationOrComplete(allowRest = true) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("guided_done_next_button")
                            )

                            IconButton(
                                onClick = { moveToNextStationOrComplete(allowRest = false) },
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(palette.surfaceBg, CircleShape)
                                    .border(1.dp, palette.borderNeutral, CircleShape)
                            ) {
                                Icon(Icons.Default.SkipNext, contentDescription = "Skip", tint = palette.textPrimary)
                            }
                        }
                    }

                    GuidedPhase.REST -> {
                        val nextIdx = (stationIndex + 1).coerceAtMost(totalStations - 1)
                        val nextSt = program.stations[nextIdx]
                        val nextEx = ExerciseLibrary.findById(nextSt.exerciseId)

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState()),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Spacer(modifier = Modifier.height(10.dp))
                            StatusPillBadge(label = if (isBn) "বিশ্রাম ও শ্বাস স্বাভাবিক করুন" else "TAKE A REST", accentColor = palette.sky)
                            AnimatedCountdownRing(
                                remainingSeconds = countdownSec,
                                totalSeconds = currentStation.restAfterSec.coerceAtLeast(countdownSec).coerceAtLeast(1),
                                accentColor = palette.gold,
                                ringSize = ringSize
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                GlassFilterChip(
                                    label = "+20s",
                                    selected = false,
                                    icon = Icons.Default.Add,
                                    onClick = { countdownSec += 20 },
                                    modifier = Modifier.testTag("guided_add_rest_button")
                                )
                                GlassFilterChip(
                                    label = if (isBn) "বিশ্রাম স্কিপ" else "Skip Rest",
                                    selected = true,
                                    icon = Icons.Default.SkipNext,
                                    onClick = { startActiveFromRestOrReady() },
                                    modifier = Modifier.testTag("guided_skip_rest_button")
                                )
                            }

                            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                                Text(
                                    text = if (isBn) "পরবর্তী ব্যায়াম (${nextIdx + 1}/$totalStations)" else "UP NEXT (${nextIdx + 1}/$totalStations)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = palette.accentSoft
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isBn) nextEx.nameBn else nextEx.nameEn,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.textPrimary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                SculptedExerciseViewport(
                                    exercise = nextEx,
                                    isPlaying = true,
                                    height = 170.dp,
                                    characterGender = characterGender
                                )
                            }
                        }
                    }

                    GuidedPhase.COMPLETED -> {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(84.dp)
                                    .background(palette.accentPrimary.copy(alpha = 0.16f), CircleShape)
                                    .border(1.5.dp, palette.accentPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = palette.gold, modifier = Modifier.size(44.dp))
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = if (isBn) "মাশাআল্লাহ! সেশন সম্পন্ন" else "Workout Completed!",
                                style = MaterialTheme.typography.headlineMedium,
                                color = palette.textPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isBn) "শরীর আল্লাহর আমানত। আজকের সেশনটি সংরক্ষিত হয়েছে।" else "Alhamdulillah — session saved to your local training log.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textSecondary,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    PreviewStatMetric("${program.stations.size}", if (isBn) "ব্যায়াম" else "Exercises")
                                    PreviewStatMetric("${program.durationMinutes} min", if (isBn) "সময়" else "Minutes")
                                    PreviewStatMetric("~${program.estimatedKcal} kcal", if (isBn) "ক্যালোরি" else "Kcal")
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        EmeraldActionButton(
                            text = if (isBn) "সম্পন্ন" else "Done",
                            icon = Icons.Default.Check,
                            onClick = onDismiss,
                            modifier = Modifier.fillMaxWidth().testTag("guided_finish_done_button")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
                    }
                }
            }
            }
        }
    }
}

@Composable
private fun AnimatedCountdownRing(
    remainingSeconds: Int,
    totalSeconds: Int,
    accentColor: Color,
    ringSize: androidx.compose.ui.unit.Dp = 132.dp
) {
    val palette = LocalRuhZenaPalette.current
    val targetFraction = (remainingSeconds.toFloat() / totalSeconds.coerceAtLeast(1)).coerceIn(0f, 1f)
    val animatedSweep by animateFloatAsState(
        targetValue = 360f * targetFraction,
        animationSpec = tween(durationMillis = 450),
        label = "countdownSweep"
    )
    Box(
        modifier = Modifier.size(ringSize),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 8.dp.toPx()
            drawArc(
                color = palette.borderNeutral.copy(alpha = 0.25f),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = strokeWidth)
            )
            drawArc(
                color = accentColor,
                startAngle = -90f,
                sweepAngle = animatedSweep,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
        Text(
            text = "00:${remainingSeconds.toString().padStart(2, '0')}",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold
            ),
            color = accentColor
        )
    }
}
