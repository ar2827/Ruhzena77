package com.example.ruhzena.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.StopCircle
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.FoldedDropdownOption
import com.example.ruhzena.core.ui.FoldedPageDropdown
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.SafeFullScreenDialog
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.GoldSourceTag
import com.example.ruhzena.core.ui.SegmentedGlassTabRow
import com.example.ruhzena.core.ui.SegmentedTabItem
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.islamic.AdhkarCategory
import com.example.ruhzena.data.islamic.DhikrItem
import com.example.ruhzena.data.islamic.DuaItem
import com.example.ruhzena.data.islamic.GuidedTasbihStep
import com.example.ruhzena.data.islamic.IslamicContentData
import com.example.ruhzena.data.islamic.QuranAudioRef
import com.example.ruhzena.data.islamic.TasbihDhikrPreset
import com.example.ruhzena.data.local.BookmarkEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.media.AudioPlaybackState
import com.example.ruhzena.media.LocalRuhZenaSound
import com.example.ruhzena.notifications.MotivationKnowledgeCatalog
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalRuhZenaPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private sealed interface SelectedPracticeDetail {
    data class Adhkar(val item: DhikrItem) : SelectedPracticeDetail
    data class Dua(val item: DuaItem) : SelectedPracticeDetail
}

@Composable
fun AdhkarAndDuaSection(
    bookmarks: List<BookmarkEntity>,
    audioState: AudioPlaybackState,
    initialShowDua: Boolean = false,
    initialAdhkarCategory: AdhkarCategory? = null,
    pendingDuaId: String? = null,
    pendingDuaQuery: String? = null,
    onConsumedPendingDua: () -> Unit = {},
    speakingItemId: String? = null,
    onSpeakArabic: (itemId: String, arabicText: String, fallbackSpeech: String) -> Unit = { _, _, _ -> },
    onPlayHumanAudio: (
        trackId: String,
        title: String,
        subtitle: String,
        quranRef: QuranAudioRef?,
        hisnChapterId: Int?,
        arabicText: String
    ) -> Unit,
    onToggleBookmark: (BookmarkEntity, Boolean) -> Unit,
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> },
    onStartGuidedTasbih: (AdhkarCategory) -> Unit = {}
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val haptics = LocalHapticFeedback.current
    val sound = LocalRuhZenaSound.current

    var showDua by remember(initialShowDua) { mutableStateOf(initialShowDua) }
    var selectedAdhkarCat by remember(initialAdhkarCategory) {
        mutableStateOf(initialAdhkarCategory ?: AdhkarCategory.MORNING)
    }
    var selectedDuaCategory by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }
    var selectedDetail by remember { mutableStateOf<SelectedPracticeDetail?>(null) }
    val adhkarProgress = remember { mutableStateMapOf<String, Int>() }

    LaunchedEffect(pendingDuaId, pendingDuaQuery) {
        if (!pendingDuaId.isNullOrBlank()) {
            showDua = true
            val match = IslamicContentData.duaList.find { it.id.equals(pendingDuaId, ignoreCase = true) }
            if (match != null) {
                selectedDetail = SelectedPracticeDetail.Dua(match)
            }
            onConsumedPendingDua()
        } else if (!pendingDuaQuery.isNullOrBlank()) {
            showDua = true
            selectedDuaCategory = "ALL"
            searchQuery = pendingDuaQuery
            onConsumedPendingDua()
        }
    }

    selectedDetail?.let { detail ->
        BackHandler { selectedDetail = null }
        when (detail) {
            is SelectedPracticeDetail.Adhkar -> {
                val item = detail.item
                val bmKey = "ADHKAR_${item.id}"
                val isSaved = bookmarks.any { it.key == bmKey }
                val title = if (isBn) item.titleBn else item.titleEn
                val voiceLabel = if (isBn) item.humanVoiceLabelBn else item.humanVoiceLabelEn
                val isThisTrack = audioState.activeTrackId == item.id

                PracticeFullDetailView(
                    categoryLabel = "${item.sourceRef} • ${item.grading}",
                    title = title,
                    arabicText = item.arabicText,
                    pronunciation = if (isBn) item.transliterationBn else item.transliterationEn,
                    pronunciationTip = if (isBn) {
                        "প্রস্তাবিত পাঠ সংখ্যা: ${item.targetCount} বার • সঠিক তাজউইদের জন্য মানব কণ্ঠে অডিও শুনুন।"
                    } else {
                        "Recommended repetition: ${item.targetCount}× • Listen to the verified human reciter for Tajweed."
                    },
                    translation = if (isBn) item.translationBn else item.translationEn,
                    explanation = if (isBn) item.explanationBn else item.explanationEn,
                    sourceText = "${item.sourceRef} (${item.grading})",
                    sourceUrl = item.sourceUrl,
                    voiceLabel = voiceLabel,
                    isPlaying = isThisTrack && audioState.isPlaying,
                    isBuffering = isThisTrack && audioState.isBuffering,
                    isBookmarked = isSaved,
                    onBack = { selectedDetail = null },
                    onPlayAudio = {
                        onPlayHumanAudio(
                            item.id,
                            title,
                            voiceLabel,
                            item.quranAudioRef,
                            item.hisnChapterId,
                            item.arabicText
                        )
                    },
                    onToggleBookmark = {
                        onToggleBookmark(
                            BookmarkEntity(bmKey, "ADHKAR", item.titleEn, item.sourceRef, item.arabicText),
                            isSaved
                        )
                    },
                    onAskRuhZebaAi = {
                        val q = if (isBn) {
                            "'$title' যিকিরটির ফজিলত ও কখন/কীভাবে পাঠ করা উত্তম তা রূহযেনা AI বুঝিয়ে বলুন।"
                        } else {
                            "Explain the meaning, virtues, and authentic etiquette of '$title' (${item.sourceRef})."
                        }
                        onAskRuhZebaAi("ISLAMIC", q)
                    }
                )
            }
            is SelectedPracticeDetail.Dua -> {
                val dua = detail.item
                val bmKey = "DUA_${dua.id}"
                val isSaved = bookmarks.any { it.key == bmKey }
                val title = if (isBn) dua.titleBn else dua.titleEn
                val voiceLabel = if (isBn) dua.humanVoiceLabelBn else dua.humanVoiceLabelEn
                val isThisTrack = audioState.activeTrackId == dua.id

                PracticeFullDetailView(
                    categoryLabel = if (isBn) dua.categoryBn else dua.categoryEn,
                    title = title,
                    arabicText = dua.arabicText,
                    pronunciation = if (isBn) dua.transliterationBn else dua.transliterationEn,
                    pronunciationTip = if (isBn) dua.pronunciationNoteBn else dua.pronunciationNoteEn,
                    translation = if (isBn) dua.translationBn else dua.translationEn,
                    explanation = if (isBn) dua.explanationBn else dua.explanationEn,
                    sourceText = "${dua.sourceRef} • ${dua.grading}",
                    sourceUrl = dua.sourceUrl,
                    voiceLabel = voiceLabel,
                    isPlaying = isThisTrack && audioState.isPlaying,
                    isBuffering = isThisTrack && audioState.isBuffering,
                    isBookmarked = isSaved,
                    onBack = { selectedDetail = null },
                    onPlayAudio = {
                        onPlayHumanAudio(
                            dua.id,
                            title,
                            voiceLabel,
                            dua.quranAudioRef,
                            dua.hisnChapterId,
                            dua.arabicText
                        )
                    },
                    onToggleBookmark = {
                        onToggleBookmark(
                            BookmarkEntity(bmKey, "DUA", dua.titleEn, dua.sourceRef, dua.arabicText),
                            isSaved
                        )
                    },
                    onAskRuhZebaAi = {
                        val q = if (isBn) {
                            "'$title' দুআটির অর্থ, প্রেক্ষাপট ও প্রয়োগ বুঝিয়ে বলুন।"
                        } else {
                            "Explain the deeper meaning, wisdom, and context of the Dua '$title' (${dua.sourceRef})."
                        }
                        onAskRuhZebaAi("ISLAMIC", q)
                    }
                )
            }
        }
        return
    }

    val duaCategories = remember {
        IslamicContentData.duaList.map { it.categoryEn to it.categoryBn }.distinctBy { it.first }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("adhkar_dua_list"),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SegmentedGlassTabRow(
                items = listOf(
                    SegmentedTabItem(false, strings.adhkarSection, "toggle_adhkar_tab"),
                    SegmentedTabItem(true, strings.duaSection, "toggle_dua_tab")
                ),
                selected = showDua,
                onSelect = { showDua = it },
                modifier = Modifier.tutorialTarget(TutorialTargetKeys.ADHKAR_DUA_SWITCH)
            )

            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        if (isBn) "এখানে লিখুন" else "Type here",
                        color = palette.textMuted
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.textSecondary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = palette.textMuted)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.accentPrimary,
                    unfocusedBorderColor = palette.borderNeutral,
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .tutorialTarget(TutorialTargetKeys.ADHKAR_DUA_SEARCH)
                    .testTag("adhkar_dua_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))
            Box(modifier = Modifier.tutorialTarget(TutorialTargetKeys.ADHKAR_DUA_CATEGORY)) {
            if (!showDua) {
                val adhkarCatOptions = remember(isBn, strings) {
                    listOf(
                        FoldedDropdownOption(
                            value = AdhkarCategory.MORNING,
                            label = strings.morningAdhkar,
                            subtitle = if (isBn) "ফজরের পর সকালের আমল" else "After Fajr remembrance",
                            testTag = "adhkar_cat_morning"
                        ),
                        FoldedDropdownOption(
                            value = AdhkarCategory.EVENING,
                            label = strings.eveningAdhkar,
                            subtitle = if (isBn) "আসর ও মাগরিবের আমল" else "After Asr & evening",
                            testTag = "adhkar_cat_evening"
                        ),
                        FoldedDropdownOption(
                            value = AdhkarCategory.BEDTIME,
                            label = strings.bedtimeAdhkar,
                            subtitle = if (isBn) "ঘুমানোর আগের সুরক্ষা" else "Before sleep protection",
                            testTag = "adhkar_cat_bedtime"
                        ),
                        FoldedDropdownOption(
                            value = AdhkarCategory.AFTER_PRAYER,
                            label = strings.afterPrayerAdhkar,
                            subtitle = if (isBn) "ফরজ নামাজের পরের যিকির" else "After Fard Salah",
                            testTag = "adhkar_cat_after_prayer"
                        ),
                        FoldedDropdownOption(
                            value = AdhkarCategory.DAILY_LIFE,
                            label = if (isBn) "দৈনন্দিন" else "Daily Life",
                            subtitle = if (isBn) "ঘর, সফর ও দৈনিক যিকির" else "Home, travel & daily life",
                            testTag = "adhkar_cat_daily"
                        ),
                        FoldedDropdownOption(
                            value = AdhkarCategory.PROTECTION,
                            label = if (isBn) "সুরক্ষা" else "Protection",
                            subtitle = if (isBn) "রুকইয়াহ ও হিফাজত" else "Shield & Ruqyah",
                            testTag = "adhkar_cat_protection"
                        )
                    )
                }
                FoldedPageDropdown(
                    options = adhkarCatOptions,
                    selected = selectedAdhkarCat,
                    onSelect = { selectedAdhkarCat = it },
                    sectionLabel = if (isBn) "যিকিরের সময়" else "Adhkar Routine",
                    triggerTestTag = "adhkar_category_dropdown"
                )
            } else {
                val duaCatOptions = remember(duaCategories, isBn) {
                    buildList {
                        add(
                            FoldedDropdownOption(
                                value = "ALL",
                                label = if (isBn) "সকল দুআ (${IslamicContentData.duaList.size})" else "All Duas (${IslamicContentData.duaList.size})",
                                testTag = "dua_cat_all"
                            )
                        )
                        duaCategories.forEach { (catEn, catBn) ->
                            val count = IslamicContentData.duaList.count { it.categoryEn == catEn }
                            add(
                                FoldedDropdownOption(
                                    value = catEn,
                                    label = if (isBn) "$catBn ($count)" else "$catEn ($count)",
                                    testTag = "dua_cat_${catEn.lowercase().replace(" ", "_")}"
                                )
                            )
                        }
                    }
                }
                FoldedPageDropdown(
                    options = duaCatOptions,
                    selected = selectedDuaCategory,
                    onSelect = { selectedDuaCategory = it },
                    sectionLabel = if (isBn) "দুআর বিভাগ" else "Dua Category",
                    triggerTestTag = "dua_category_dropdown"
                )
            }
            }
        }

        if (!showDua) {
            val q = searchQuery.trim().lowercase()
            val filtered = IslamicContentData.adhkarList.filter { item ->
                val matchesCat = q.isNotEmpty() || item.category == selectedAdhkarCat
                val matchesSearch = q.isEmpty() ||
                    item.titleEn.lowercase().contains(q) ||
                    item.titleBn.contains(q) ||
                    item.translationEn.lowercase().contains(q) ||
                    item.transliterationEn.lowercase().contains(q) ||
                    item.sourceRef.lowercase().contains(q)
                matchesCat && matchesSearch
            }

            val completedInCat = filtered.count { (adhkarProgress[it.id] ?: 0) >= it.targetCount }
            val allStepsDone = filtered.isNotEmpty() && completedInCat == filtered.size
            val firstIncompleteIdx = filtered.indexOfFirst { (adhkarProgress[it.id] ?: 0) < it.targetCount }

            // Progressive Step-by-Step Unlock: Locked upcoming steps are NEVER shown on screen
            // until the current step is completed!
            val visibleAdhkar = if (q.isNotEmpty() || firstIncompleteIdx == -1) {
                filtered
            } else {
                filtered.take(firstIncompleteIdx + 1)
            }

            if (q.isEmpty() && filtered.isNotEmpty()) {
                val progressFraction = (completedInCat.toFloat() / filtered.size.coerceAtLeast(1)).coerceIn(0f, 1f)
                val catLabel = adhkarCategoryDisplayName(selectedAdhkarCat, isBn)

                item(key = "adhkar_systemic_progress_${selectedAdhkarCat.name}") {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("adhkar_systemic_progress_card"),
                        elevated = true,
                        accentBorder = allStepsDone,
                        contentPadding = PaddingValues(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isBn) "$catLabel • ধাপে ধাপে আমল" else "$catLabel • Step-by-Step Routine",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.textPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (allStepsDone) {
                                        if (isBn) "সব ${filtered.size}টি ধাপ সম্পন্ন! নিচে তাসবিহ শুরু করুন"
                                        else "All ${filtered.size} steps complete! Guided Tasbih unlocked below"
                                    } else {
                                        if (isBn) "ধাপ ${firstIncompleteIdx + 1} / ${filtered.size} • পাঠ শেষে কার্ডে ট্যাপ করুন"
                                        else "Step ${firstIncompleteIdx + 1} of ${filtered.size} • Recite & tap card to unlock next"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.textSecondary
                                )
                            }
                            if (completedInCat > 0 || filtered.any { (adhkarProgress[it.id] ?: 0) > 0 }) {
                                IconButton(
                                    onClick = {
                                        sound?.playClick(0.95f)
                                        filtered.forEach { adhkarProgress.remove(it.id) }
                                    },
                                    modifier = Modifier.testTag("adhkar_reset_progress_button")
                                ) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        contentDescription = if (isBn) "রিসেট করুন" else "Reset progress",
                                        tint = palette.textSecondary
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(50)),
                            color = if (allStepsDone) palette.gold else palette.accentPrimary,
                            trackColor = palette.borderNeutral,
                            strokeCap = StrokeCap.Round
                        )
                    }
                }
            }

            itemsIndexed(visibleAdhkar, key = { _, item -> item.id }) { index, item ->
                val bmKey = "ADHKAR_${item.id}"
                val isSaved = bookmarks.any { it.key == bmKey }
                val title = if (isBn) item.titleBn else item.titleEn
                val speechId = "adhkar_speak_${item.id}"
                val isSpeakingThis = speakingItemId == speechId || (audioState.activeTrackId == item.id && audioState.isPlaying)
                val doneCount = adhkarProgress[item.id] ?: 0
                val isDone = doneCount >= item.targetCount
                val isCurrentStep = q.isEmpty() && !isDone && index == firstIncompleteIdx

                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("adhkar_card_${item.id}"),
                    elevated = isCurrentStep,
                    accentBorder = isCurrentStep || isSpeakingThis || isDone,
                    contentPadding = PaddingValues(14.dp),
                    onClick = {
                        if (!isDone) {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            val next = doneCount + 1
                            adhkarProgress[item.id] = next
                            if (next >= item.targetCount) {
                                sound?.playChime()
                            } else {
                                sound?.playTasbihBead(next)
                            }
                        } else {
                            selectedDetail = SelectedPracticeDetail.Adhkar(item)
                        }
                    }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            StatusPillBadge(
                                label = if (isDone) {
                                    if (isBn) "✓ ধাপ ${index + 1}" else "✓ Step ${index + 1}"
                                } else {
                                    if (isBn) "ধাপ ${index + 1}/${filtered.size}" else "Step ${index + 1}/${filtered.size}"
                                },
                                accentColor = if (isDone) palette.gold else palette.accentSoft
                            )
                            Text(
                                text = item.sourceRef,
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    val voiceLabel = if (isBn) item.humanVoiceLabelBn else item.humanVoiceLabelEn
                                    if (item.quranAudioRef != null || item.hisnChapterId != null) {
                                        onPlayHumanAudio(item.id, title, voiceLabel, item.quranAudioRef, item.hisnChapterId, item.arabicText)
                                    } else {
                                        onSpeakArabic(speechId, item.arabicText, item.transliterationEn)
                                    }
                                },
                                modifier = Modifier.testTag("adhkar_listen_${item.id}")
                            ) {
                                Icon(
                                    imageVector = if (isSpeakingThis) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = if (isBn) "শুনুন" else "Listen",
                                    tint = if (isSpeakingThis) palette.gold else palette.accentSoft
                                )
                            }
                            IconButton(onClick = {
                                onToggleBookmark(
                                    BookmarkEntity(bmKey, "ADHKAR", item.titleEn, item.sourceRef, item.arabicText),
                                    isSaved
                                )
                            }) {
                                Icon(
                                    if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = strings.bookmarkSaved,
                                    tint = if (isSaved) palette.gold else palette.textSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = item.arabicText,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontFamily = ArabicFontFamily,
                            fontSize = if (isCurrentStep) 21.sp else 18.sp,
                            lineHeight = if (isCurrentStep) 36.sp else 30.sp,
                            textDirection = TextDirection.Rtl
                        ),
                        color = palette.gold.copy(alpha = if (isDone) 0.72f else 0.96f),
                        maxLines = if (isCurrentStep) 8 else 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (isCurrentStep) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isBn) item.transliterationBn else item.transliterationEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.accentSoft
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isBn) item.translationBn else item.translationEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPillBadge(
                            label = if (isDone) {
                                if (isBn) "সম্পন্ন • ${item.targetCount}/${item.targetCount}" else "Completed • ${item.targetCount}/${item.targetCount}"
                            } else {
                                if (isBn) "গণনা: $doneCount / ${item.targetCount} • কার্ডে ট্যাপ করুন" else "Count: $doneCount / ${item.targetCount} • Tap card"
                            },
                            accentColor = if (isDone) palette.gold else palette.accentSoft,
                            icon = if (isDone) Icons.Default.Check else null,
                            modifier = Modifier.testTag("adhkar_count_badge_${item.id}")
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable {
                                    sound?.playClick()
                                    selectedDetail = SelectedPracticeDetail.Adhkar(item)
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("adhkar_open_guide_${item.id}")
                        ) {
                            Text(
                                text = strings.openFullGuide,
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.accentSoft
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = palette.accentSoft,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }
            }

            // Final Phase Card: Appears cleanly once all Adhkar steps in this routine are completed
            if (q.isEmpty() && allStepsDone) {
                val tasbihSteps = IslamicContentData.tasbihRoutineForCategory(selectedAdhkarCat)
                val catLabel = adhkarCategoryDisplayName(selectedAdhkarCat, isBn)
                val previewSequence = tasbihSteps.joinToString(" → ") { step ->
                    "${step.targetCount}× ${if (isBn) step.titleBn else step.titleEn}"
                }

                item(key = "adhkar_final_tasbih_cta_${selectedAdhkarCat.name}") {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, bottom = 12.dp)
                            .testTag("adhkar_start_guided_tasbih"),
                        elevated = true,
                        accentBorder = true,
                        contentPadding = PaddingValues(16.dp),
                        onClick = { onStartGuidedTasbih(selectedAdhkarCat) }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusPillBadge(
                                label = if (isBn) "চূড়ান্ত ধাপ • তাসবিহ পর্ব" else "Final Phase • Guided Tasbih",
                                accentColor = palette.gold,
                                icon = Icons.Default.AutoAwesome
                            )
                            Text(
                                text = if (isBn) "${tasbihSteps.size}টি ধাপ" else "${tasbihSteps.size} Steps",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.accentSoft,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isBn) "$catLabel — ধাপে ধাপে তাসবিহ শুরু করুন" else "Start Guided $catLabel Tasbih",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = previewSequence,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = if (isBn) "তাসবিহ পাতায় যান এবং ধাপে ধাপে গণনা করুন" else "Open Step-by-Step Tasbih Session",
                                style = MaterialTheme.typography.labelLarge,
                                color = palette.gold,
                                fontWeight = FontWeight.SemiBold
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = palette.gold,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        } else {
            val q = searchQuery.trim().lowercase()
            val filteredDuas = IslamicContentData.duaList.filter { dua ->
                val matchesCat = selectedDuaCategory == "ALL" || dua.categoryEn == selectedDuaCategory
                val matchesSearch = q.isEmpty() ||
                    dua.titleEn.lowercase().contains(q) ||
                    dua.titleBn.contains(q) ||
                    dua.categoryEn.lowercase().contains(q) ||
                    dua.categoryBn.contains(q) ||
                    dua.translationEn.lowercase().contains(q) ||
                    dua.transliterationEn.lowercase().contains(q) ||
                    dua.sourceRef.lowercase().contains(q)
                matchesCat && matchesSearch
            }
            items(filteredDuas, key = { it.id }) { dua ->
                val bmKey = "DUA_${dua.id}"
                val isSaved = bookmarks.any { it.key == bmKey }
                val title = if (isBn) dua.titleBn else dua.titleEn
                val speechId = "dua_speak_${dua.id}"
                val isSpeakingThis = speakingItemId == speechId || (audioState.activeTrackId == dua.id && audioState.isPlaying)

                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dua_card_${dua.id}"),
                    accentBorder = isSpeakingThis,
                    contentPadding = PaddingValues(14.dp),
                    onClick = { selectedDetail = SelectedPracticeDetail.Dua(dua) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPillBadge(
                            label = if (isBn) dua.categoryBn else dua.categoryEn,
                            accentColor = palette.gold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    val voiceLabel = if (isBn) dua.humanVoiceLabelBn else dua.humanVoiceLabelEn
                                    if (dua.quranAudioRef != null || dua.hisnChapterId != null) {
                                        onPlayHumanAudio(dua.id, title, voiceLabel, dua.quranAudioRef, dua.hisnChapterId, dua.arabicText)
                                    } else {
                                        onSpeakArabic(speechId, dua.arabicText, dua.transliterationEn)
                                    }
                                },
                                modifier = Modifier.testTag("dua_listen_${dua.id}")
                            ) {
                                Icon(
                                    imageVector = if (isSpeakingThis) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = if (isBn) "শুনুন" else "Listen",
                                    tint = if (isSpeakingThis) palette.gold else palette.accentSoft
                                )
                            }
                            IconButton(onClick = {
                                onToggleBookmark(
                                    BookmarkEntity(bmKey, "DUA", dua.titleEn, dua.sourceRef, dua.arabicText),
                                    isSaved
                                )
                            }) {
                                Icon(
                                    if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                    contentDescription = strings.bookmarkSaved,
                                    tint = if (isSaved) palette.gold else palette.textSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.textPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = dua.arabicText,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontFamily = ArabicFontFamily,
                            textDirection = TextDirection.Rtl
                        ),
                        color = palette.gold.copy(alpha = 0.88f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${dua.sourceRef} • ${strings.openFullGuide}",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.accentSoft,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = palette.accentSoft,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PracticeFullDetailView(
    categoryLabel: String,
    title: String,
    arabicText: String,
    pronunciation: String,
    pronunciationTip: String,
    translation: String,
    explanation: String,
    sourceText: String,
    sourceUrl: String,
    voiceLabel: String,
    isPlaying: Boolean,
    isBuffering: Boolean,
    isBookmarked: Boolean,
    onBack: () -> Unit,
    onPlayAudio: () -> Unit,
    onToggleBookmark: () -> Unit,
    onAskRuhZebaAi: () -> Unit = {}
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("practice_detail_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("detail_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = palette.textPrimary)
                }
                Column {
                    StatusPillBadge(label = categoryLabel, accentColor = palette.gold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        color = palette.textPrimary
                    )
                }
            }
            IconButton(onClick = onToggleBookmark) {
                Icon(
                    imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = strings.bookmarkSaved,
                    tint = if (isBookmarked) palette.gold else palette.textSecondary
                )
            }
        }

        GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
            Text(
                text = arabicText,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = ArabicFontFamily,
                    fontSize = 25.sp,
                    lineHeight = 42.sp,
                    textDirection = TextDirection.Rtl
                ),
                color = palette.gold,
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            HumanReciterPlayButton(
                label = voiceLabel,
                isPlaying = isPlaying,
                isBuffering = isBuffering,
                onClick = onPlayAudio,
                modifier = Modifier.testTag("detail_play_human_audio")
            )
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(strings.pronunciationNote, style = MaterialTheme.typography.labelLarge, color = palette.accentSoft)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = pronunciation,
                style = MaterialTheme.typography.bodyLarge,
                color = palette.textPrimary,
                fontWeight = FontWeight.Medium
            )
            if (pronunciationTip.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = pronunciationTip,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textMuted
                )
            }
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(strings.meaningTitle, style = MaterialTheme.typography.labelLarge, color = palette.gold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = translation,
                style = MaterialTheme.typography.bodyLarge,
                color = palette.textSecondary
            )
        }

        val isBnNow = LocalAppLanguage.current == AppLanguage.BANGLA
        val richContext = remember(title, categoryLabel, explanation, sourceText, isBnNow) {
            com.example.ruhzena.data.islamic.AuthenticDuaContextEnricher.enrich(
                titleEn = title,
                categoryEn = categoryLabel,
                existingExplanationEn = if (isBnNow) "" else explanation,
                existingExplanationBn = if (isBnNow) explanation else "",
                sourceRef = sourceText
            )
        }

        GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isBnNow) "প্রামাণ্য নববী প্রেক্ষাপট ও বিস্তারিত ব্যাখ্যা" else "Authentic Prophetic Occasion & Full Context",
                    style = MaterialTheme.typography.labelLarge,
                    color = palette.accentSoft
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isBnNow) richContext.propheticOccasionBn else richContext.propheticOccasionEn,
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textPrimary,
                lineHeight = 22.sp,
                modifier = Modifier.testTag("detail_explanation_text")
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = if (isBnNow) "গভীর আত্মিক তাৎপর্য" else "Deeper Spiritual Meaning",
                style = MaterialTheme.typography.labelLarge,
                color = palette.gold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isBnNow) richContext.spiritualMeaningBn else richContext.spiritualMeaningEn,
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary,
                lineHeight = 22.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = if (isBnNow) "সুন্নাহ আদব ও আমলের নিয়ম" else "Sunnah Etiquette & When to Recite",
                style = MaterialTheme.typography.labelLarge,
                color = palette.accentSoft
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isBnNow) richContext.sunnahEtiquetteBn else richContext.sunnahEtiquetteEn,
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary,
                lineHeight = 22.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            GoldSourceTag(
                sourceText = "$sourceText ↗",
                modifier = Modifier.clickable {
                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(sourceUrl))) }
                }
            )
            Spacer(modifier = Modifier.height(10.dp))
            GlassFilterChip(
                label = if (isBnNow) "রূহযেনা AI-কে জিজ্ঞাসা করুন" else "Ask RuhZena AI",
                selected = false,
                icon = Icons.Default.AutoAwesome,
                onClick = onAskRuhZebaAi,
                modifier = Modifier.testTag("detail_ask_ai_button")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun HumanReciterPlayButton(
    label: String,
    isPlaying: Boolean,
    isBuffering: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        color = if (isPlaying) palette.accentContainer else palette.blockBg,
        border = BorderStroke(0.8.dp, if (isPlaying) palette.borderAccent else palette.borderNeutral),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isBuffering) {
                CircularProgressIndicator(modifier = Modifier.size(15.dp), color = palette.accentSoft, strokeWidth = 2.dp)
            } else {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else if (label.contains("Quran")) Icons.Default.GraphicEq else Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = label,
                    tint = palette.accentSoft,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = if (isPlaying) palette.accentSoft else palette.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private fun adhkarCategoryDisplayName(category: AdhkarCategory, isBn: Boolean): String = when (category) {
    AdhkarCategory.MORNING -> if (isBn) "সকালের যিকির" else "Morning"
    AdhkarCategory.EVENING -> if (isBn) "সন্ধ্যার যিকির" else "Evening"
    AdhkarCategory.AFTER_PRAYER -> if (isBn) "নামাজের পর" else "After Prayer"
    AdhkarCategory.BEDTIME -> if (isBn) "ঘুমানোর আগে" else "Bedtime"
    AdhkarCategory.DAILY_LIFE -> if (isBn) "দৈনন্দিন" else "Daily Life"
    AdhkarCategory.PROTECTION -> if (isBn) "সুরক্ষা" else "Protection"
}

@Composable
fun TasbihSection(
    prefs: UserPreferences,
    currentCount: Int,
    onTapCount: (Int) -> Unit,
    onUndo: () -> Unit = {},
    onReset: () -> Unit,
    guidedCategory: AdhkarCategory? = null,
    speakingItemId: String? = null,
    onSpeakArabic: (itemId: String, arabicText: String, fallbackSpeech: String) -> Unit = { _, _, _ -> },
    onCompleteGuidedCategory: (AdhkarCategory) -> Unit = {}
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val sound = LocalRuhZenaSound.current
    val scope = rememberCoroutineScope()

    val presets = IslamicContentData.tasbihPresets
    var selectedPreset by remember { mutableStateOf(presets.first()) }
    var popupPreset by remember { mutableStateOf<TasbihDhikrPreset?>(null) }
    var customDhikr by remember { mutableStateOf("") }
    var target by remember { mutableIntStateOf(33) }
    var roundCelebrationVisible by remember { mutableStateOf(false) }

    // Step-by-Step Guided Tasbih Session state (when launched from an Adhkar time category)
    val guidedSteps: List<GuidedTasbihStep> = remember(guidedCategory) {
        guidedCategory?.let { IslamicContentData.tasbihRoutineForCategory(it) }.orEmpty()
    }
    val isGuidedMode = guidedCategory != null && guidedSteps.isNotEmpty()
    var guidedStepIndex by remember(guidedCategory) { mutableIntStateOf(0) }
    var guidedRoutineCompleted by remember(guidedCategory) { mutableStateOf(false) }
    val activeGuidedStep = if (isGuidedMode) {
        guidedSteps[guidedStepIndex.coerceIn(0, guidedSteps.lastIndex)]
    } else null

    val effectiveTarget = activeGuidedStep?.targetCount ?: target

    val medallionScale = remember { Animatable(1f) }
    val rippleProgress = remember { Animatable(1f) }
    val animatedProgress by animateFloatAsState(
        targetValue = (currentCount.toFloat() / effectiveTarget.coerceAtLeast(1)).coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "tasbih_ring_progress"
    )

    val activePhrase = when {
        activeGuidedStep != null -> activeGuidedStep.arabicText
        customDhikr.isNotBlank() -> customDhikr
        else -> selectedPreset.arabicText
    }
    val activePronunciation = when {
        activeGuidedStep != null -> if (isBn) activeGuidedStep.transliterationBn else activeGuidedStep.transliterationEn
        customDhikr.isNotBlank() -> customDhikr
        else -> if (isBn) selectedPreset.transliterationBn else selectedPreset.transliterationEn
    }
    val activeSubtitle = when {
        activeGuidedStep != null -> if (isBn) activeGuidedStep.meaningBn else activeGuidedStep.meaningEn
        customDhikr.isNotBlank() -> if (isBn) "কাস্টম যিকির" else "Custom Dhikr"
        else -> if (isBn) selectedPreset.meaningBn else selectedPreset.meaningEn
    }
    val activeVirtueText = when {
        activeGuidedStep != null -> if (isBn) activeGuidedStep.virtueBn else activeGuidedStep.virtueEn
        else -> if (isBn) selectedPreset.virtueBn else selectedPreset.virtueEn
    }
    val activeSourceRef = activeGuidedStep?.sourceRef ?: selectedPreset.sourceRef
    val activeSourceUrl = activeGuidedStep?.sourceUrl ?: selectedPreset.sourceUrl

    val tasbihSpeechId = "tasbih_speak_${activePhrase.hashCode()}"
    val isSpeakingTasbih = speakingItemId == tasbihSpeechId

    LaunchedEffect(roundCelebrationVisible) {
        if (roundCelebrationVisible) {
            delay(1800L)
            roundCelebrationVisible = false
        }
    }

    // Automatically return to originating Adhkar page once all guided Tasbih steps are complete!
    LaunchedEffect(guidedRoutineCompleted, guidedCategory) {
        if (guidedRoutineCompleted && guidedCategory != null) {
            sound?.playChime()
            delay(950L)
            onReset()
            onCompleteGuidedCategory(guidedCategory)
        }
    }

    popupPreset?.let { preset ->
        TasbihVirtueDialog(
            preset = preset,
            isBn = isBn,
            onDismiss = { popupPreset = null }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Guided Step-by-Step Header (when entered from an Adhkar time category)
        if (isGuidedMode && guidedCategory != null) {
            item(key = "guided_tasbih_header") {
                val catName = adhkarCategoryDisplayName(guidedCategory, isBn)
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tasbih_guided_header"),
                    elevated = true,
                    accentBorder = true,
                    contentPadding = PaddingValues(14.dp)
                ) {
                    StatusPillBadge(
                        label = if (isBn) "$catName • ধাপে ধাপে তাসবিহ" else "$catName • Guided Tasbih",
                        accentColor = palette.gold,
                        icon = Icons.Default.AutoAwesome
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (guidedRoutineCompleted) {
                            if (isBn) "মাশাআল্লাহ! সব ধাপ সম্পন্ন — যিকির পাতায় ফিরছি..." else "MashaAllah! All steps complete — returning to Adhkar..."
                        } else {
                            if (isBn) "ধাপ ${guidedStepIndex + 1} / ${guidedSteps.size}: ${activeGuidedStep?.titleBn.orEmpty()}"
                            else "Step ${guidedStepIndex + 1} of ${guidedSteps.size}: ${activeGuidedStep?.titleEn.orEmpty()}"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        color = palette.textPrimary,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = {
                            if (guidedRoutineCompleted) 1f
                            else (guidedStepIndex.toFloat() / guidedSteps.size.coerceAtLeast(1)).coerceIn(0f, 1f)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50)),
                        color = palette.gold,
                        trackColor = palette.borderNeutral,
                        strokeCap = StrokeCap.Round
                    )
                }
            }
        } else {
            // Folded-Page Falling Dropdown selector for 18+ Dhikrs
            item {
                val presetOptions = remember(presets, isBn) {
                    presets.map { preset ->
                        FoldedDropdownOption(
                            value = preset,
                            label = if (isBn) "${preset.titleBn} (${preset.suggestedTarget}×)" else "${preset.titleEn} (${preset.suggestedTarget}×)",
                            subtitle = if (isBn) preset.meaningBn else preset.meaningEn,
                            testTag = "tasbih_preset_${preset.id}"
                        )
                    }
                }
                Box(modifier = Modifier.tutorialTarget(TutorialTargetKeys.TASBIH_DHIKR_SELECTOR)) {
                    FoldedPageDropdown(
                        options = presetOptions,
                        selected = selectedPreset,
                        onSelect = { preset ->
                            customDhikr = ""
                            selectedPreset = preset
                            target = preset.suggestedTarget
                        },
                        sectionLabel = if (isBn) "তাসবিহ নির্বাচন করুন" else "Select Dhikr",
                        triggerTestTag = "tasbih_dropdown_button"
                    )
                }
            }
        }

        // Main Animated Radial Tasbih Cockpit (Brushed Silver & Champagne Gold Medallion)
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                elevated = true,
                accentBorder = true,
                contentPadding = PaddingValues(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isGuidedMode && customDhikr.isBlank()) {
                                sound?.playClick()
                                popupPreset = selectedPreset
                            }
                            .padding(vertical = 4.dp)
                            .testTag("tasbih_virtue_button"),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = activePhrase,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontFamily = ArabicFontFamily,
                                textDirection = TextDirection.Rtl
                            ),
                            color = palette.gold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = activePronunciation,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = palette.accentSoft,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.testTag("tasbih_pronunciation_text")
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = activeSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.tutorialTarget(TutorialTargetKeys.TASBIH_AUDIO_VIRTUES),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GlassFilterChip(
                            label = if (isSpeakingTasbih) {
                                if (isBn) "থামান" else "Stop"
                            } else {
                                if (isBn) "উচ্চারণ শুনুন" else "Listen"
                            },
                            selected = isSpeakingTasbih,
                            icon = if (isSpeakingTasbih) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                            onClick = { onSpeakArabic(tasbihSpeechId, activePhrase, activePronunciation) },
                            modifier = Modifier.testTag("tasbih_listen_button")
                        )
                        if (!isGuidedMode && customDhikr.isBlank()) {
                            GlassFilterChip(
                                label = if (isBn) "ফজিলত" else "Virtues",
                                selected = false,
                                icon = Icons.Default.Info,
                                onClick = { popupPreset = selectedPreset },
                                modifier = Modifier.testTag("tasbih_virtues_chip")
                            )
                        }
                    }

                    AnimatedVisibility(visible = roundCelebrationVisible) {
                        StatusPillBadge(
                            label = if (isGuidedMode && !guidedRoutineCompleted) {
                                if (isBn) "মাশাআল্লাহ! পরবর্তী ধাপে অগ্রসর হলেন" else "MashaAllah! Advanced to Next Step"
                            } else {
                                if (isBn) "মাশাআল্লাহ! ১টি চক্র সম্পন্ন হয়েছে" else "MashaAllah! Round Completed"
                            },
                            accentColor = palette.gold,
                            icon = Icons.Default.AutoAwesome,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Box(
                        modifier = Modifier
                            .size(226.dp)
                            .tutorialTarget(TutorialTargetKeys.TASBIH_TAP_BEAD),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val rProg = rippleProgress.value
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        palette.accentPrimary.copy(alpha = 0.24f),
                                        palette.gold.copy(alpha = 0.10f),
                                        Color.Transparent
                                    )
                                ),
                                radius = size.minDimension * 0.49f
                            )
                            if (rProg < 0.99f) {
                                val baseRadius = size.minDimension * 0.39f
                                val maxRadius = size.minDimension * 0.495f
                                val curRadius = baseRadius + (maxRadius - baseRadius) * rProg
                                val alpha = (1f - rProg).coerceIn(0f, 1f) * 0.78f
                                drawCircle(
                                    color = palette.gold.copy(alpha = alpha),
                                    radius = curRadius,
                                    style = Stroke(width = 4.2.dp.toPx() * (1f - rProg * 0.55f))
                                )
                                val innerProg = (rProg * 1.25f).coerceAtMost(1f)
                                if (innerProg < 0.98f) {
                                    drawCircle(
                                        color = palette.accentSoft.copy(alpha = (1f - innerProg) * 0.50f),
                                        radius = baseRadius + (maxRadius - baseRadius) * innerProg * 0.72f,
                                        style = Stroke(width = 2.4.dp.toPx())
                                    )
                                }
                            }
                        }

                        // Brushed Platinum Silver & Champagne-Gold Bezel 3D Medallion
                        Box(
                            modifier = Modifier
                                .size(188.dp)
                                .scale(medallionScale.value)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            Color(0xFFE9EDF3),
                                            Color(0xFFB5BDC9),
                                            Color(0xFF6B7380),
                                            Color(0xFFD8DEE8)
                                        )
                                    ),
                                    CircleShape
                                )
                                .padding(4.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        colors = if (palette.isLight) {
                                            listOf(
                                                Color(0xFFFFFFFF),
                                                Color(0xFFF0F3F7),
                                                Color(0xFFDCE1E9),
                                                Color(0xFFBDC5D1)
                                            )
                                        } else {
                                            listOf(
                                                Color(0xFF333945),
                                                Color(0xFF1F242E),
                                                Color(0xFF13171F),
                                                Color(0xFF0A0D12)
                                            )
                                        },
                                        center = androidx.compose.ui.geometry.Offset(130f, 110f),
                                        radius = 320f
                                    ),
                                    CircleShape
                                )
                                .border(1.1.dp, Color.White.copy(alpha = if (palette.isLight) 0.90f else 0.30f), CircleShape)
                                .clickable(enabled = !guidedRoutineCompleted) {
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    val nextCount = currentCount + 1
                                    val willComplete = nextCount >= effectiveTarget
                                    if (willComplete) {
                                        sound?.playChime()
                                        roundCelebrationVisible = true
                                        if (isGuidedMode) {
                                            if (guidedStepIndex < guidedSteps.lastIndex) {
                                                guidedStepIndex += 1
                                            } else {
                                                guidedRoutineCompleted = true
                                            }
                                        }
                                    } else {
                                        sound?.playTasbihBead(nextCount)
                                    }
                                    onTapCount(effectiveTarget)
                                    scope.launch {
                                        medallionScale.snapTo(0.93f)
                                        medallionScale.animateTo(
                                            1f,
                                            animationSpec = spring(
                                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                                stiffness = Spring.StiffnessMedium
                                            )
                                        )
                                    }
                                    scope.launch {
                                        rippleProgress.snapTo(0f)
                                        rippleProgress.animateTo(
                                            1f,
                                            animationSpec = tween(durationMillis = 520, easing = FastOutSlowInEasing)
                                        )
                                    }
                                }
                                .testTag("tasbih_tap_circle"),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawArc(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            Color.White.copy(alpha = if (palette.isLight) 0.78f else 0.32f),
                                            Color.Transparent
                                        ),
                                        startY = 0f,
                                        endY = size.height * 0.45f
                                    ),
                                    startAngle = 205f,
                                    sweepAngle = 130f,
                                    useCenter = false,
                                    topLeft = androidx.compose.ui.geometry.Offset(size.width * 0.11f, size.height * 0.06f),
                                    size = androidx.compose.ui.geometry.Size(size.width * 0.78f, size.height * 0.44f),
                                    style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
                                )
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = if (palette.isLight) 0.12f else 0.48f)),
                                        radius = size.minDimension * 0.52f
                                    ),
                                    radius = size.minDimension * 0.5f,
                                    style = Stroke(width = 6.dp.toPx())
                                )
                            }

                            CircularProgressIndicator(
                                progress = { animatedProgress },
                                modifier = Modifier.size(164.dp),
                                color = palette.gold,
                                trackColor = palette.accentPrimary.copy(alpha = 0.24f),
                                strokeWidth = 7.dp
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = currentCount.toString(),
                                    style = MaterialTheme.typography.displayLarge.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = palette.textPrimary
                                )
                                Text(
                                    text = "/ $effectiveTarget",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = palette.gold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(strings.tapToCount, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .tutorialTarget(TutorialTargetKeys.TASBIH_TARGET_RESET)
                    ) {
                        if (!isGuidedMode) {
                            Spacer(modifier = Modifier.height(10.dp))
                            SegmentedGlassTabRow(
                                items = listOf(33, 99, 100).map { t ->
                                    SegmentedTabItem(t, "${strings.targetLabel}: $t")
                                },
                                selected = target,
                                onSelect = { target = it }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                        StatusPillBadge(
                            label = "${strings.sessionsCompleted}: ${prefs.tasbihSessionsCompleted} • Total: ${prefs.tasbihTotalCount}",
                            accentColor = palette.gold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    sound?.playClick(0.92f)
                                    onUndo()
                                },
                                enabled = currentCount > 0,
                                modifier = Modifier.testTag("tasbih_undo_button")
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.Undo,
                                    contentDescription = if (isBn) "এক ধাপ পেছনে" else "Undo tap",
                                    tint = if (currentCount > 0) palette.textPrimary else palette.textMuted
                                )
                            }
                            IconButton(
                                onClick = {
                                    sound?.playClick(0.88f)
                                    onReset()
                                },
                                modifier = Modifier.testTag("tasbih_reset_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = strings.resetCounter, tint = palette.textPrimary)
                            }
                        }
                        }
                    }
                }
            }
        }

        if (isGuidedMode || customDhikr.isBlank()) {
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(14.dp),
                    onClick = { if (!isGuidedMode) popupPreset = selectedPreset }
                ) {
                    Text(
                        text = strings.tasbihVirtuesTitle,
                        style = MaterialTheme.typography.labelLarge,
                        color = palette.sky
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = activeVirtueText,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    GoldSourceTag(
                        sourceText = "$activeSourceRef ↗",
                        modifier = Modifier
                            .clickable {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(activeSourceUrl)))
                                }
                            }
                            .testTag("tasbih_virtue_source_tag")
                    )
                }
            }
        }

        if (!isGuidedMode) {
            item {
                OutlinedTextField(
                    value = customDhikr,
                    onValueChange = { customDhikr = it },
                    placeholder = { Text(strings.customDhikrHint, color = palette.textMuted) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.accentPrimary,
                        unfocusedBorderColor = palette.borderNeutral,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun TasbihVirtueDialog(
    preset: TasbihDhikrPreset,
    isBn: Boolean,
    onDismiss: () -> Unit
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val context = LocalContext.current

    SafeFullScreenDialog(onDismissRequest = onDismiss, centerContent = true) {
        BackHandler(onBack = onDismiss)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("tasbih_virtue_popup"),
            shape = RoundedCornerShape(24.dp),
            color = palette.surfaceBg,
            border = BorderStroke(1.dp, palette.borderAccent)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.tasbihVirtuesTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.gold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(48.dp).testTag("close_tasbih_virtue_popup")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.textPrimary)
                    }
                }

                GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true, accentBorder = true) {
                    Text(
                        text = preset.arabicText,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = ArabicFontFamily,
                            textDirection = TextDirection.Rtl
                        ),
                        color = palette.gold,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(strings.pronunciationNote, style = MaterialTheme.typography.labelMedium, color = palette.accentSoft)
                    Text(
                        text = "${preset.transliterationEn}\n${preset.transliterationBn}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textPrimary
                    )
                }

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(strings.meaningTitle, style = MaterialTheme.typography.labelLarge, color = palette.gold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isBn) preset.meaningBn else preset.meaningEn,
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textSecondary
                    )
                }

                GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBn) "পাঠের ফজিলত ও প্রাপ্তি" else "Rewards & Spiritual Benefits",
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.accentSoft
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isBn) preset.virtueBn else preset.virtueEn,
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    GoldSourceTag(
                        sourceText = "${preset.sourceRef} • ${preset.sourceUrl.removePrefix("https://")} ↗",
                        modifier = Modifier.clickable {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(preset.sourceUrl))) }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DailyLessonsSection(
    speakingItemId: String? = null,
    onSpeakLocalized: (itemId: String, text: String) -> Unit = { _, _ -> },
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> }
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val context = LocalContext.current

    val currentHourlyGem = remember { MotivationKnowledgeCatalog.forCurrentHour() }
    var selectedFilter by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }

    val knowledgeCategories = remember {
        MotivationKnowledgeCatalog.items.map { it.category }.distinct()
    }
    val filterOptions = remember(isBn, knowledgeCategories) {
        buildList {
            add(
                FoldedDropdownOption(
                    value = "ALL",
                    label = if (isBn) "সব হিকমাহ ও গভীর পাঠ (${MotivationKnowledgeCatalog.items.size + IslamicContentData.lessonsList.size})"
                    else "All Daily Hikmah & Gems (${MotivationKnowledgeCatalog.items.size + IslamicContentData.lessonsList.size})",
                    testTag = "hikmah_filter_all"
                )
            )
            add(
                FoldedDropdownOption(
                    value = "DEEP_LESSONS",
                    label = if (isBn) "গভীর তাদাব্বুর ও আরবি পাঠ (${IslamicContentData.lessonsList.size})"
                    else "Deep Reflections (${IslamicContentData.lessonsList.size})",
                    testTag = "hikmah_filter_deep"
                )
            )
            knowledgeCategories.forEach { cat ->
                val count = MotivationKnowledgeCatalog.items.count { it.category == cat }
                add(
                    FoldedDropdownOption(
                        value = cat,
                        label = "$cat ($count)",
                        testTag = "hikmah_filter_${cat.lowercase()}"
                    )
                )
            }
        }
    }

    val q = searchQuery.trim().lowercase()
    val filteredGems = remember(selectedFilter, q) {
        if (selectedFilter == "DEEP_LESSONS") emptyList()
        else MotivationKnowledgeCatalog.items.filter { gem ->
            val matchCat = selectedFilter == "ALL" || gem.category == selectedFilter
            val matchQ = q.isEmpty() ||
                gem.titleEn.lowercase().contains(q) ||
                gem.titleBn.contains(q) ||
                gem.bodyEn.lowercase().contains(q) ||
                gem.sourceRef.lowercase().contains(q) ||
                gem.category.lowercase().contains(q)
            matchCat && matchQ
        }
    }
    val filteredLessons = remember(selectedFilter, q) {
        if (selectedFilter != "ALL" && selectedFilter != "DEEP_LESSONS") emptyList()
        else IslamicContentData.lessonsList.filter { lesson ->
            q.isEmpty() ||
                lesson.titleEn.lowercase().contains(q) ||
                lesson.titleBn.contains(q) ||
                lesson.bodyEn.lowercase().contains(q) ||
                lesson.sourceRef.lowercase().contains(q)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("daily_hikmah_list"),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 64.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Featured Hourly Wisdom Hero Card
        item(key = "hourly_featured_hikmah") {
            val heroSpeechId = "hikmah_hero_${currentHourlyGem.id}"
            val heroPlaying = speakingItemId == heroSpeechId
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                elevated = true,
                accentBorder = true,
                contentPadding = PaddingValues(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(
                        label = if (isBn) "এই ঘণ্টার হিকমাহ • ${currentHourlyGem.category}" else "This Hour's Hikmah • ${currentHourlyGem.category}",
                        accentColor = palette.gold,
                        icon = Icons.Default.AutoAwesome
                    )
                    IconButton(
                        onClick = {
                            val spoken = if (isBn) "${currentHourlyGem.titleBn}. ${currentHourlyGem.bodyBn}"
                            else "${currentHourlyGem.titleEn}. ${currentHourlyGem.bodyEn}"
                            onSpeakLocalized(heroSpeechId, spoken)
                        },
                        modifier = Modifier.testTag("hikmah_hero_listen")
                    ) {
                        Icon(
                            imageVector = if (heroPlaying) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Listen",
                            tint = if (heroPlaying) palette.gold else palette.accentSoft
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isBn) currentHourlyGem.titleBn else currentHourlyGem.titleEn,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isBn) currentHourlyGem.bodyBn else currentHourlyGem.bodyEn,
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                GoldSourceTag(sourceText = currentHourlyGem.sourceRef)
            }
        }

        // Folded-Page Filter Dropdown & Search
        item(key = "hikmah_controls") {
            FoldedPageDropdown(
                options = filterOptions,
                selected = selectedFilter,
                onSelect = { selectedFilter = it },
                sectionLabel = if (isBn) "হিকমাহ বিভাগ" else "Hikmah Collection",
                triggerTestTag = "hikmah_category_dropdown"
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        if (isBn) "এখানে লিখুন" else "Type here",
                        color = palette.textMuted
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.textSecondary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = palette.textMuted)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.accentPrimary,
                    unfocusedBorderColor = palette.borderNeutral,
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                modifier = Modifier.fillMaxWidth().testTag("hikmah_search_input")
            )
        }

        // Deep Reflections with Arabic Text
        items(filteredLessons, key = { "lesson_${it.id}" }) { lesson ->
            val speechId = "lesson_speak_${lesson.id}"
            val isSpeaking = speakingItemId == speechId
            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(label = if (isBn) lesson.typeBn else lesson.typeEn, accentColor = palette.accentSoft)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusPillBadge(label = lesson.grading, accentColor = palette.gold)
                        IconButton(
                            onClick = {
                                val spoken = if (isBn) "${lesson.titleBn}. ${lesson.bodyBn}" else "${lesson.titleEn}. ${lesson.bodyEn}"
                                onSpeakLocalized(speechId, spoken)
                            }
                        ) {
                            Icon(
                                imageVector = if (isSpeaking) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Listen",
                                tint = if (isSpeaking) palette.gold else palette.accentSoft
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isBn) lesson.titleBn else lesson.titleEn,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = lesson.arabicText,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = ArabicFontFamily,
                        fontSize = 20.sp,
                        lineHeight = 32.sp,
                        textDirection = TextDirection.Rtl
                    ),
                    color = palette.gold,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isBn) lesson.transliterationBn else lesson.transliterationEn,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.accentSoft
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isBn) lesson.bodyBn else lesson.bodyEn,
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                GoldSourceTag(
                    sourceText = "${lesson.sourceRef} ↗",
                    modifier = Modifier.clickable {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(lesson.sourceUrl))) }
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                GlassFilterChip(
                    label = if (isBn) "রূহযেনা AI-কে জিজ্ঞাসা করুন" else "Ask RuhZena AI",
                    selected = false,
                    icon = Icons.Default.AutoAwesome,
                    onClick = {
                        val titleText = if (isBn) lesson.titleBn else lesson.titleEn
                        val q = if (isBn) {
                            "'$titleText' (${lesson.sourceRef}) শিক্ষাটি দৈনন্দিন জীবনে কীভাবে প্রয়োগ করব?"
                        } else {
                            "Help me understand and apply '$titleText' (${lesson.sourceRef}) in everyday life."
                        }
                        onAskRuhZebaAi("ISLAMIC", q)
                    },
                    modifier = Modifier.testTag("lesson_ask_ai_${lesson.id}")
                )
            }
        }

        // 72 Verified Hourly Knowledge Gems
        items(filteredGems, key = { "gem_${it.id}" }) { gem ->
            val speechId = "gem_speak_${gem.id}"
            val isSpeaking = speakingItemId == speechId
            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusPillBadge(label = "#${gem.id} • ${gem.category}", accentColor = palette.accentSoft)
                    IconButton(
                        onClick = {
                            val spoken = if (isBn) "${gem.titleBn}. ${gem.bodyBn}" else "${gem.titleEn}. ${gem.bodyEn}"
                            onSpeakLocalized(speechId, spoken)
                        }
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Listen",
                            tint = if (isSpeaking) palette.gold else palette.accentSoft
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isBn) gem.titleBn else gem.titleEn,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isBn) gem.bodyBn else gem.bodyEn,
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GoldSourceTag(sourceText = gem.sourceRef)
                    GlassFilterChip(
                        label = if (isBn) "AI-কে প্রশ্ন" else "Ask AI",
                        selected = false,
                        icon = Icons.Default.AutoAwesome,
                        onClick = {
                            val titleText = if (isBn) gem.titleBn else gem.titleEn
                            val q = if (isBn) {
                                "'$titleText' (${gem.sourceRef}) এর গভীর ব্যাখ্যা ও দৈনিক আমল বলুন।"
                            } else {
                                "Explain the deeper meaning and practical application of '$titleText' (${gem.sourceRef})."
                            }
                            onAskRuhZebaAi("ISLAMIC", q)
                        }
                    )
                }
            }
        }
    }
}
