package com.example.ruhzena.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ruhzena.ai.AiEvidenceResponse
import com.example.ruhzena.ai.RuhZenaInAppRouter
import com.example.ruhzena.ai.agent.AiPersonality
import com.example.ruhzena.ai.agent.CandidateMemoryProposal
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.ui.EmeraldActionButton
import com.example.ruhzena.core.ui.GlassCard
import com.example.ruhzena.core.ui.GlassFilterChip
import com.example.ruhzena.core.ui.GoldSourceTag
import com.example.ruhzena.core.ui.RuhZenaMarkdownText
import com.example.ruhzena.core.ui.SegmentedGlassTabRow
import com.example.ruhzena.core.ui.SegmentedTabItem
import com.example.ruhzena.core.ui.StatusPillBadge
import com.example.ruhzena.data.local.AiMemoryEntity
import com.example.ruhzena.data.local.AiMessageEntity
import com.example.ruhzena.data.local.AiTaskStateEntity
import com.example.ruhzena.ui.AiChatUiState
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.LocalRuhZenaPalette
import kotlinx.serialization.json.Json

private data class UnifiedStarterPrompt(
    val titleEn: String,
    val titleBn: String,
    val subtitleEn: String,
    val subtitleBn: String,
    val promptEn: String,
    val promptBn: String
)

private val companionStarters = listOf(
    UnifiedStarterPrompt(
        titleEn = "Heart Peace & Tawakkul",
        titleBn = "হৃদয়ের প্রশান্তি ও তাওয়াক্কুল",
        subtitleEn = "Calm guidance & Dua",
        subtitleBn = "কুরআন ও সুন্নাহর সান্ত্বনা",
        promptEn = "I am feeling overwhelmed today. Share calm encouragement, a relevant Quran verse, and one gentle action I can take.",
        promptBn = "আজ মন কিছুটা অস্থির লাগছে। কুরআন ও সুন্নাহ থেকে প্রশান্তিময় পরামর্শ ও একটি সহজ আমল বলুন।"
    ),
    UnifiedStarterPrompt(
        titleEn = "Consistent Salah",
        titleBn = "নামাজে নিয়মিত হওয়া",
        subtitleEn = "Sincerity & rhythm",
        subtitleBn = "আন্তরিকতা ও অভ্যাস",
        promptEn = "Help me stay consistent in all 5 daily prayers with mercy, practical structure, and authentic encouragement.",
        promptBn = "৫ ওয়াক্ত নামাজে নিয়মিত হওয়ার জন্য বাস্তবসম্মত ও অনুপ্রেরণাদায়ক পরামর্শ দিন।"
    ),
    UnifiedStarterPrompt(
        titleEn = "Overcome a Bad Habit",
        titleBn = "খারাপ অভ্যাস ত্যাগ",
        subtitleEn = "Tawbah & recovery",
        subtitleBn = "তাওবা ও আত্মশৃঙ্খলা",
        promptEn = "Guide me gently through overcoming a recurring bad habit with Tawbah, Sabr, and practical steps.",
        promptBn = "খারাপ অভ্যাস ত্যাগ ও তাওবার সহজ এবং কার্যকর ইসলামিক উপায় বলুন।"
    ),
    UnifiedStarterPrompt(
        titleEn = "Daily Balance Check-In",
        titleBn = "আজকের ভারসাম্য পর্যালোচনা",
        subtitleEn = "Deen, hydration & energy",
        subtitleBn = "দ্বীন, পানি ও শক্তি",
        promptEn = "Review my wellness rhythm today and suggest a peaceful evening routine combining Ibadah, hydration, and rest.",
        promptBn = "আমার আজকের স্বাস্থ্য ও আমলের ভারসাম্য দেখে একটি প্রশান্তিময় রুটিন সাজিয়ে দিন।"
    )
)

private val expertStarters = listOf(
    UnifiedStarterPrompt(
        titleEn = "Authentic Fiqh & Sources",
        titleBn = "দলিলসহ ফিকহ ও মাসআলা",
        subtitleEn = "Quran, Hadith & Ikhtilaf",
        subtitleBn = "কুরআন, হাদিস ও মাযহাব",
        promptEn = "Explain the authentic rulings and etiquette of Wudu and Salah with clear Quran and Sahih Hadith citations.",
        promptBn = "অজু ও সালাতের সুন্নাহ-সম্মত নিয়ম ও দলিলসহ সংক্ষিপ্ত ব্যাখ্যা দিন।"
    ),
    UnifiedStarterPrompt(
        titleEn = "7-Day Home Workout Plan",
        titleBn = "৭ দিনের ঘরোয়া ব্যায়াম",
        subtitleEn = "Tailored to your body",
        subtitleBn = "আপনার ফিটনেস প্রোফাইল অনুযায়ী",
        promptEn = "Create a structured 7-day home workout plan tailored to my fitness profile, equipment, and limitations.",
        promptBn = "আমার ফিটনেস প্রোফাইল ও লক্ষ্য অনুযায়ী ৭ দিনের ঘরোয়া ব্যায়াম পরিকল্পনা তৈরি করুন।"
    ),
    UnifiedStarterPrompt(
        titleEn = "Nutrition & Calorie Plan",
        titleBn = "পুষ্টি ও ক্যালরি পরিকল্পনা",
        subtitleEn = "Balanced halal macros",
        subtitleBn = "সুষম হালাল খাবার",
        promptEn = "Design a practical daily halal nutrition and hydration strategy based on my logged intake and goal.",
        promptBn = "আমার আজকের খাবার ও পানি পানের তথ্য দেখে একটি সুষম হালাল পুষ্টি পরিকল্পনা দিন।"
    ),
    UnifiedStarterPrompt(
        titleEn = "Deep Tafsir Context",
        titleBn = "গভীর তাফসির ও প্রেক্ষাপট",
        subtitleEn = "Surah context & lessons",
        subtitleBn = "আয়াতের শানে নুযূল ও শিক্ষা",
        promptEn = "Explain the historical context and deeper lessons of Surah Ad-Duha (93) with authentic scholarly notes.",
        promptBn = "সূরা আদ-দুহা (৯৩)-এর প্রেক্ষাপট এবং বাস্তব জীবনের শিক্ষা দলিলসহ ব্যাখ্যা করুন।"
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(
    uiState: AiChatUiState,
    messages: List<AiMessageEntity>,
    memories: List<AiMemoryEntity>,
    tasks: List<AiTaskStateEntity>,
    activeTask: AiTaskStateEntity?,
    isOnline: Boolean,
    onSelectPersonality: (AiPersonality) -> Unit,
    onToggleResearchOnline: (Boolean) -> Unit,
    onSendPrompt: (String) -> Unit,
    onClearHistory: () -> Unit,
    onApproveMemory: (CandidateMemoryProposal) -> Unit,
    onDismissMemoryProposal: () -> Unit,
    onAddManualMemory: (String, String) -> Unit,
    onToggleMemoryActive: (AiMemoryEntity) -> Unit,
    onDeleteMemory: (Long) -> Unit,
    onCompleteTask: (Long) -> Unit,
    onDeleteTask: (Long) -> Unit,
    onDismissError: () -> Unit = {},
    onRetryLastPrompt: () -> Unit = {},
    onConsumePrefill: () -> Unit = {},
    onTriggerAiAction: (String) -> Unit = {},
    speakingItemId: String? = null,
    onSpeakAiMessage: (itemId: String, text: String) -> Unit = { _, _ -> }
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val json = remember { Json { ignoreUnknownKeys = true } }
    var inputText by remember { mutableStateOf("") }
    var showMemoryManager by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val starterPrompts = remember {
        listOf(
            companionStarters[0],
            expertStarters[0],
            expertStarters[1],
            expertStarters[2],
            companionStarters[1],
            companionStarters[2]
        )
    }
    val activeMemoryCount = remember(memories) { memories.count { it.isActive && it.isApproved } }

    LaunchedEffect(uiState.prefillPrompt) {
        val prefill = uiState.prefillPrompt
        if (!prefill.isNullOrBlank()) {
            inputText = prefill
            onConsumePrefill()
        }
    }

    LaunchedEffect(messages.size, uiState.isThinking) {
        if (messages.isNotEmpty() || uiState.isThinking) {
            val targetIdx = (messages.size + if (uiState.isThinking) 0 else -1).coerceAtLeast(0)
            runCatching { listState.animateScrollToItem(targetIdx) }
        }
    }

    LaunchedEffect(uiState.streamingText.length / 40) {
        if (uiState.isThinking && uiState.streamingText.isNotEmpty()) {
            val targetIdx = messages.size.coerceAtLeast(0)
            runCatching { listState.scrollToItem(targetIdx) }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Unified Single-Page RuhZena AI Header
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isBn) "রূহযেনা এআই" else "RuhZena AI",
                        style = MaterialTheme.typography.headlineSmall,
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isBn) {
                            "দ্বীন, কুরআন, ফিটনেস, পুষ্টি ও জীবনের সকল প্রশ্ন এক জায়গায়"
                        } else {
                            "Islam, Quran, heart peace, workouts, nutrition & life — all in one place"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Memory & Active Task Manager Drawer Button
                IconButton(
                    onClick = { showMemoryManager = true },
                    modifier = Modifier
                        .tutorialTarget(TutorialTargetKeys.AI_MEMORY_BTN)
                        .testTag("ai_memory_manager_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (activeMemoryCount > 0 || activeTask != null) {
                                Badge(containerColor = palette.gold, contentColor = Color.Black) {
                                    Text("${activeMemoryCount + if (activeTask != null) 1 else 0}")
                                }
                            }
                        }
                    ) {
                        Icon(
                            Icons.Default.Psychology,
                            contentDescription = if (isBn) "মেমোরি ও টাস্ক ম্যানেজার" else "Memory & Task Manager",
                            tint = palette.gold
                        )
                    }
                }

                IconButton(
                    onClick = onClearHistory,
                    modifier = Modifier.testTag("ai_clear_history_button")
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = strings.aiClearHistory, tint = palette.textSecondary)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val engineStatusText = when {
                uiState.isThinking && uiState.statusHint.isNotBlank() -> uiState.statusHint
                isOnline -> if (isBn) "রূহযেনা এআই • প্রস্তুত" else "RuhZena AI • Ready"
                else -> strings.aiStatusGroundedLocal
            }
            StatusPillBadge(
                label = engineStatusText,
                accentColor = if (isOnline) palette.accentSoft else palette.gold,
                modifier = Modifier.fillMaxWidth()
            )

            // Active Multi-Step Task Pill (if ongoing)
            if (activeTask != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.accentContainer.copy(alpha = 0.65f))
                        .border(0.7.dp, palette.borderAccent, RoundedCornerShape(12.dp))
                        .clickable { showMemoryManager = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("ai_active_task_banner"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.TaskAlt, contentDescription = null, tint = palette.gold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${if (isBn) "চলমান ধাপ:" else "Active Plan:"} ${activeTask.title}",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = if (isBn) "দেখুন" else "Manage",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.accentSoft,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Calm Error Banner with 1-Tap Retry (preserves message, never exposes technical error codes)
            if (!uiState.errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.coral.copy(alpha = 0.14f), RoundedCornerShape(12.dp))
                        .border(0.7.dp, palette.coral.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("ai_error_banner"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = uiState.errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.coral,
                        modifier = Modifier.weight(1f)
                    )
                    if (!uiState.lastFailedPrompt.isNullOrBlank() && !uiState.isThinking) {
                        TextButton(
                            onClick = onRetryLastPrompt,
                            modifier = Modifier.testTag("ai_retry_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isBn) "আবার চেষ্টা" else "Retry",
                                color = palette.accentSoft,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                    IconButton(onClick = onDismissError, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.coral, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // Unified Continuous Conversation Feed
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true, elevated = true) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = palette.gold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isBn) "একটি রূহযেনা এআই — সকল বিষয়ের সঙ্গী" else "One Unified RuhZena AI",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.textPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isBn) {
                                "কুরআন, সহীহ হাদিস, ফিকহ, নামাজ, মানসিক প্রশান্তি, ব্যায়াম ও পুষ্টি—যেকোনো প্রশ্ন করুন স্বাভাবিকভাবে।"
                            } else {
                                "Ask anything about Quran, Sahih Hadith, Salah, inner peace, workouts, nutrition, or daily habits — naturally in one continuous conversation."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = if (isBn) "দ্রুত শুরু করুন" else "Start a Conversation",
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.accentSoft
                        )
                        starterPrompts.chunked(2).forEach { pair ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                pair.forEach { item ->
                                    val promptText = if (isBn) item.promptBn else item.promptEn
                                    GlassCard(
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(12.dp),
                                        onClick = { onSendPrompt(promptText) }
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = palette.accentSoft, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = if (isBn) item.titleBn else item.titleEn,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = palette.textPrimary,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(3.dp))
                                        Text(
                                            text = if (isBn) item.subtitleBn else item.subtitleEn,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = palette.textMuted,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            items(messages, key = { it.id }) { msg ->
                if (msg.role == "USER") {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.84f)
                                .background(palette.accentPrimary.copy(alpha = 0.16f), RoundedCornerShape(16.dp))
                                .border(0.8.dp, palette.accentPrimary.copy(alpha = 0.42f), RoundedCornerShape(16.dp))
                                .padding(12.dp)
                        ) {
                            Text(msg.content, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
                        }
                    }
                } else {
                    val parsedEvidence = remember(msg.evidenceJson) {
                        if (msg.evidenceJson.isNotBlank()) {
                            runCatching { json.decodeFromString<AiEvidenceResponse>(msg.evidenceJson) }.getOrNull()
                        } else null
                    }
                    val hasStructuredEvidence = parsedEvidence != null &&
                        (parsedEvidence.quranicEvidence.isNotBlank() || parsedEvidence.hadithEvidence.isNotBlank())

                    val speechId = "ai_msg_${msg.id}"
                    when {
                        hasStructuredEvidence && parsedEvidence != null -> EvidenceStructuredCard(
                            ev = parsedEvidence,
                            speechId = speechId,
                            isSpeaking = speakingItemId == speechId,
                            onSpeak = { onSpeakAiMessage(speechId, parsedEvidence.aiSynthesis.ifBlank { msg.content }) },
                            onTriggerAiAction = onTriggerAiAction
                        )
                        parsedEvidence != null -> ChatStyleAssistantCard(
                            msg = msg,
                            evidence = parsedEvidence,
                            speechId = speechId,
                            isSpeaking = speakingItemId == speechId,
                            onSpeak = { text -> onSpeakAiMessage(speechId, text) },
                            onTriggerAiAction = onTriggerAiAction
                        )
                        else -> {
                            val isSpeaking = speakingItemId == speechId
                            GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    GlassFilterChip(
                                        label = if (isSpeaking) (if (isBn) "থামান" else "Stop") else (if (isBn) "শুনুন" else "Listen"),
                                        selected = isSpeaking,
                                        icon = if (isSpeaking) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                                        onClick = { onSpeakAiMessage(speechId, msg.content) },
                                        modifier = Modifier.testTag("ai_listen_${msg.id}")
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                RuhZenaMarkdownText(
                                    markdown = msg.content,
                                    baseColor = palette.textPrimary
                                )
                            }
                        }
                    }
                }
            }

            if (uiState.isThinking) {
                item {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_streaming_bubble"),
                        accentBorder = true,
                        elevated = true
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = palette.accentSoft, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isBn) "রূহযেনা এআই লিখছে..." else "RuhZena AI is replying...",
                                style = MaterialTheme.typography.labelLarge,
                                color = palette.accentSoft
                            )
                        }
                        if (uiState.streamingText.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            RuhZenaMarkdownText(
                                markdown = "${uiState.streamingText} ▍",
                                baseColor = palette.textPrimary
                            )
                        }
                    }
                }
            }
        }

        // Inline User-Approved Long-Term Memory Permission Proposal Chip
        AnimatedVisibility(visible = uiState.pendingMemoryProposal != null) {
            uiState.pendingMemoryProposal?.let { proposal ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.gold.copy(alpha = 0.14f))
                        .border(0.9.dp, palette.gold.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("ai_memory_proposal_card"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.BookmarkAdded, contentDescription = null, tint = palette.gold, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "রূহযেনা মেমোরিতে সংরক্ষণ করবেন?" else "Save to RuhZena Memory?",
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.gold,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = proposal.content,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(
                        onClick = { onApproveMemory(proposal) },
                        modifier = Modifier.size(36.dp).testTag("ai_memory_approve_button")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Save memory", tint = palette.accentSoft)
                    }
                    IconButton(
                        onClick = onDismissMemoryProposal,
                        modifier = Modifier.size(36.dp).testTag("ai_memory_dismiss_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Dismiss memory", tint = palette.textMuted)
                    }
                }
            }
        }

        // Quick 1-Tap Prompt Chips when chat is active
        if (messages.isNotEmpty()) {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(starterPrompts) { item ->
                    GlassFilterChip(
                        label = if (isBn) item.titleBn else item.titleEn,
                        selected = false,
                        onClick = { onSendPrompt(if (isBn) item.promptBn else item.promptEn) }
                    )
                }
            }
        }

        // Input Composer (imePadding keeps the text box & send button clear above the keyboard on all phones)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .imePadding()
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 14.dp)
                .tutorialTarget(TutorialTargetKeys.AI_INPUT_BAR),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = {
                    Text(
                        if (isBn) "এখানে লিখুন" else "Type here",
                        color = palette.textMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.accentPrimary,
                    unfocusedBorderColor = palette.borderNeutral,
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary
                ),
                modifier = Modifier.weight(1f).testTag("ai_prompt_input")
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (inputText.isNotBlank() && !uiState.isThinking) {
                        onSendPrompt(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(palette.accentPrimary, CircleShape)
                    .testTag("ai_send_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = strings.aiSend, tint = palette.onAccent)
            }
        }
    }

    // Memory & Active Multi-Step Task Manager Sheet
    if (showMemoryManager) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        var newMemoryText by remember { mutableStateOf("") }
        var newMemoryCat by remember { mutableStateOf("GOAL") }

        ModalBottomSheet(
            onDismissRequest = { showMemoryManager = false },
            sheetState = sheetState,
            containerColor = palette.surfaceBg,
            contentColor = palette.textPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 40.dp)
                    .testTag("ai_memory_manager_sheet"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "রূহযেনা মেমোরি ও টাস্ক ম্যানেজার" else "RuhZena Memory & Task Manager",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.textPrimary
                        )
                        Text(
                            text = if (isBn) "আপনার অনুমতি ছাড়া কোনো মেমোরি সংরক্ষিত হয় না। ব্যক্তিগত জার্নাল কখনো AI-তে পাঠানো হয় না।" else "Only your approved memories are shared with RuhZena AI. Private journals are never sent.",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                    IconButton(onClick = { showMemoryManager = false }) {
                        Icon(Icons.Default.Close, contentDescription = strings.closeAction, tint = palette.textSecondary)
                    }
                }

                // Add Custom Memory
                GlassCard(modifier = Modifier.fillMaxWidth(), accentBorder = true) {
                    Text(
                        text = if (isBn) "নতুন মেমোরি যোগ করুন" else "Add a Long-Term Memory",
                        style = MaterialTheme.typography.titleSmall,
                        color = palette.accentSoft
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("GOAL", "PREFERENCE", "SPIRITUAL", "HEALTH").forEach { cat ->
                            GlassFilterChip(
                                label = cat.lowercase().replaceFirstChar { it.uppercase() },
                                selected = newMemoryCat == cat,
                                onClick = { newMemoryCat = cat }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newMemoryText,
                        onValueChange = { newMemoryText = it },
                        placeholder = {
                            Text(
                                if (isBn) "যেমন: আমি হানাফী মাযহাব অনুসরণ করি / আমি হাঁটুর ব্যায়াম এড়াতে চাই"
                                else "e.g., I prefer concise step-by-step plans / knee-safe workouts",
                                color = palette.textMuted
                            )
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.accentPrimary,
                            unfocusedBorderColor = palette.borderNeutral,
                            focusedTextColor = palette.textPrimary,
                            unfocusedTextColor = palette.textPrimary
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("ai_add_memory_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    EmeraldActionButton(
                        text = if (isBn) "মেমোরি সংরক্ষণ করুন" else "Save Approved Memory",
                        icon = Icons.Default.Add,
                        onClick = {
                            if (newMemoryText.isNotBlank()) {
                                onAddManualMemory(newMemoryCat, newMemoryText)
                                newMemoryText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("ai_add_memory_button")
                    )
                }

                // Saved Approved Memories
                Text(
                    text = if (isBn) "সংরক্ষিত মেমোরি (${memories.size})" else "Saved Long-Term Memories (${memories.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = palette.gold
                )
                if (memories.isEmpty()) {
                    Text(
                        text = if (isBn) "এখনো কোনো মেমোরি সংরক্ষিত নেই।" else "No saved memories yet. Approve a suggestion during chat or add one above.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textMuted
                    )
                } else {
                    memories.forEach { mem ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    StatusPillBadge(label = mem.category, accentColor = if (mem.isActive) palette.accentSoft else palette.textMuted)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = mem.content,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (mem.isActive) palette.textPrimary else palette.textMuted
                                    )
                                }
                                Switch(
                                    checked = mem.isActive,
                                    onCheckedChange = { onToggleMemoryActive(mem) },
                                    colors = SwitchDefaults.colors(checkedTrackColor = palette.accentPrimary)
                                )
                                IconButton(onClick = { onDeleteMemory(mem.id) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete memory", tint = palette.coral)
                                }
                            }
                        }
                    }
                }

                // Multi-Step Persistent Agent Tasks
                Text(
                    text = if (isBn) "বহু-ধাপ পরিকল্পনা ও টাস্ক (${tasks.size})" else "Persistent Multi-Step Agent Tasks (${tasks.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = palette.sky
                )
                if (tasks.isEmpty()) {
                    Text(
                        text = if (isBn) "কোনো চলমান পরিকল্পনা নেই।" else "When RuhZena AI helps you build a multi-step plan, it saves progress here so it survives model switches and restarts.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textMuted
                    )
                } else {
                    tasks.forEach { task ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(task.title, style = MaterialTheme.typography.titleSmall, color = palette.textPrimary)
                                    Text(
                                        text = "${task.status} • ${task.nextAction.ifBlank { task.objective }}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.textSecondary
                                    )
                                }
                                if (task.status == "ACTIVE") {
                                    IconButton(onClick = { onCompleteTask(task.id) }) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = "Mark complete", tint = palette.accentSoft)
                                    }
                                }
                                IconButton(onClick = { onDeleteTask(task.id) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete task", tint = palette.coral)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun ChatStyleAssistantCard(
    msg: AiMessageEntity,
    evidence: AiEvidenceResponse?,
    speechId: String,
    isSpeaking: Boolean,
    onSpeak: (String) -> Unit,
    onTriggerAiAction: (String) -> Unit
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val context = LocalContext.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val replyBody = evidence?.aiSynthesis?.takeIf { it.isNotBlank() } ?: msg.content
    val explanationBody = evidence?.scholarlyExplanations.orEmpty()
    val sourceLinks = evidence?.sourceLinks.orEmpty()
    val actionTags = evidence?.actionTags.orEmpty()

    GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isBn) "রূহযেনা এআই" else "RuhZena AI",
                style = MaterialTheme.typography.labelLarge,
                color = palette.gold,
                fontWeight = FontWeight.SemiBold
            )
            GlassFilterChip(
                label = if (isSpeaking) (if (isBn) "থামান" else "Stop") else (if (isBn) "শুনুন" else "Listen"),
                selected = isSpeaking,
                icon = if (isSpeaking) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                onClick = { onSpeak(replyBody) },
                modifier = Modifier.testTag("ai_listen_$speechId")
            )
        }
        Spacer(modifier = Modifier.height(6.dp))

        RuhZenaMarkdownText(
            markdown = replyBody,
            baseColor = palette.textPrimary
        )

        if (explanationBody.isNotBlank()) {
            EvidenceBlock(
                heading = strings.aiExplanationSectionTitle,
                body = explanationBody,
                accent = palette.sky
            )
        }

        if (actionTags.isNotEmpty()) {
            AiActionChipsRow(actionTags = actionTags, onTriggerAiAction = onTriggerAiAction)
        }

        if (sourceLinks.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = strings.aiCitedSourcesTitle,
                style = MaterialTheme.typography.labelLarge,
                color = palette.gold,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sourceLinks) { rawSource ->
                    val (displayLabel, browserUrl) = remember(rawSource) { resolveClickableSource(rawSource) }
                    GoldSourceTag(
                        sourceText = "$displayLabel ↗",
                        modifier = Modifier.clickable {
                            runCatching {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(browserUrl)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun EvidenceStructuredCard(
    ev: AiEvidenceResponse,
    speechId: String,
    isSpeaking: Boolean,
    onSpeak: () -> Unit,
    onTriggerAiAction: (String) -> Unit
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val context = LocalContext.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                ev.topic,
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            GlassFilterChip(
                label = if (isSpeaking) (if (isBn) "থামান" else "Stop") else (if (isBn) "শুনুন" else "Listen"),
                selected = isSpeaking,
                icon = if (isSpeaking) Icons.Default.StopCircle else Icons.AutoMirrored.Filled.VolumeUp,
                onClick = onSpeak,
                modifier = Modifier.testTag("ai_listen_$speechId")
            )
        }

        EvidenceBlock(strings.evidenceQuran, ev.quranicEvidence, palette.accentSoft)
        EvidenceBlock(strings.evidenceHadith, ev.hadithEvidence, palette.gold)
        EvidenceBlock(strings.evidenceScholarly, ev.scholarlyExplanations, palette.sky)
        EvidenceBlock(strings.evidenceIkhtilaf, ev.scholarlyDifferences, palette.amber)
        EvidenceBlock(strings.evidenceAiSynthesis, ev.aiSynthesis, palette.textPrimary)

        if (ev.actionTags.isNotEmpty()) {
            AiActionChipsRow(actionTags = ev.actionTags, onTriggerAiAction = onTriggerAiAction)
        }

        if (ev.sourceLinks.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ev.sourceLinks) { rawSource ->
                    val (displayLabel, browserUrl) = remember(rawSource) { resolveClickableSource(rawSource) }
                    GoldSourceTag(
                        sourceText = "$displayLabel ↗",
                        modifier = Modifier.clickable {
                            runCatching {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(browserUrl)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            }
                        }
                    )
                }
            }
        }
    }
}

/**
 * Resolves any AI-cited source ("Label|https://...", raw URL, "Quran 2:286", "Sahih al-Bukhari 6464",
 * "Sahih Muslim 2568", etc.) into a clean display label and a guaranteed clickable HTTPS browser URL.
 */
private fun resolveClickableSource(raw: String): Pair<String, String> {
    val trimmed = raw.trim()
    if ("|" in trimmed) {
        val parts = trimmed.split("|", limit = 2)
        val label = parts[0].trim()
        val url = parts[1].trim()
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return (label.ifBlank { url.removePrefix("https://").removePrefix("http://") }) to url
        }
    }
    if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
        return trimmed.removePrefix("https://").removePrefix("http://").removeSuffix("/") to trimmed
    }

    val lower = trimmed.lowercase()
    // Match Quran surah:ayah citations like "Quran 2:286" or "Al-Baqarah 2:255"
    val quranMatch = Regex("(\\d{1,3}):(\\d{1,3})").find(trimmed)
    if (quranMatch != null && (lower.contains("quran") || lower.contains("surah") || lower.contains("ayah") || lower.contains("কুরআন") || lower.contains("সূরা"))) {
        val surah = quranMatch.groupValues[1]
        val ayah = quranMatch.groupValues[2]
        return trimmed to "https://quran.com/$surah/$ayah"
    }
    // Match authentic Hadith collection numbers
    val num = Regex("\\b(\\d{1,5})\\b").find(trimmed)?.groupValues?.get(1)
    if (num != null) {
        when {
            lower.contains("bukhari") -> return trimmed to "https://sunnah.com/bukhari:$num"
            lower.contains("muslim") -> return trimmed to "https://sunnah.com/muslim:$num"
            lower.contains("tirmidhi") -> return trimmed to "https://sunnah.com/tirmidhi:$num"
            lower.contains("dawud") || lower.contains("daud") -> return trimmed to "https://sunnah.com/abudawud:$num"
            lower.contains("nasai") || lower.contains("nasa'i") -> return trimmed to "https://sunnah.com/nasai:$num"
            lower.contains("majah") -> return trimmed to "https://sunnah.com/ibnmajah:$num"
            lower.contains("riyad") -> return trimmed to "https://sunnah.com/riyadussalihin:$num"
        }
    }
    val encoded = Uri.encode(trimmed)
    return if (lower.contains("quran") || lower.contains("surah") || lower.contains("tafsir")) {
        trimmed to "https://quran.com/search?q=$encoded"
    } else if (lower.contains("hadith") || lower.contains("bukhari") || lower.contains("muslim") || lower.contains("sunnah")) {
        trimmed to "https://sunnah.com/search?q=$encoded"
    } else {
        trimmed to "https://www.google.com/search?q=$encoded"
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AiActionChipsRow(
    actionTags: List<String>,
    onTriggerAiAction: (String) -> Unit
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    Spacer(modifier = Modifier.height(10.dp))
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        actionTags.forEach { tag ->
            val desc = remember(tag, isBn) { RuhZenaInAppRouter.describeActionTag(tag, isBn) }
            val label = if (isBn) desc.labelBn else desc.labelEn
            val icon = when (desc.kind) {
                RuhZenaInAppRouter.ActionKind.QURAN -> Icons.AutoMirrored.Filled.MenuBook
                RuhZenaInAppRouter.ActionKind.DUA,
                RuhZenaInAppRouter.ActionKind.ADHKAR -> Icons.Default.Favorite
                RuhZenaInAppRouter.ActionKind.TASBIH -> Icons.Default.RadioButtonChecked
                RuhZenaInAppRouter.ActionKind.PRAYER_QIBLA -> Icons.Default.Explore
                RuhZenaInAppRouter.ActionKind.WUDU_SALAH -> Icons.Default.SelfImprovement
                RuhZenaInAppRouter.ActionKind.LEARNING -> Icons.Default.School
                RuhZenaInAppRouter.ActionKind.WORKOUT -> Icons.Default.FitnessCenter
                RuhZenaInAppRouter.ActionKind.WELLNESS -> Icons.Default.WaterDrop
                RuhZenaInAppRouter.ActionKind.DISCIPLINE -> Icons.Default.CheckCircle
                RuhZenaInAppRouter.ActionKind.BREATHING -> Icons.Default.SelfImprovement
                RuhZenaInAppRouter.ActionKind.GENERAL -> Icons.Default.Today
            }
            AssistChip(
                onClick = { onTriggerAiAction(tag) },
                label = { Text("$label →", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold) },
                leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
                colors = AssistChipDefaults.assistChipColors(
                    containerColor = palette.accentContainer,
                    labelColor = palette.accentSoft,
                    leadingIconContentColor = palette.gold
                ),
                modifier = Modifier.testTag("ai_action_chip_$tag")
            )
        }
    }
}

@Composable
private fun EvidenceBlock(heading: String, body: String, accent: Color) {
    val palette = LocalRuhZenaPalette.current
    if (body.isBlank()) return
    Spacer(modifier = Modifier.height(8.dp))
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.blockBg, RoundedCornerShape(12.dp))
            .border(0.8.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Text(heading, style = MaterialTheme.typography.labelLarge, color = accent, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(4.dp))
        RuhZenaMarkdownText(
            markdown = body,
            baseColor = palette.textSecondary,
            baseStyle = MaterialTheme.typography.bodySmall
        )
    }
}
