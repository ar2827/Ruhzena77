package com.example.ruhzena.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.example.R
import com.example.ruhzena.core.i18n.AppLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DailyAyahWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val snap = RuhZenaWidgetUpdater.loadSnapshot(context)
                val isBn = snap.prefs.language == AppLanguage.BANGLA

                for (appWidgetId in appWidgetIds) {
                    val views = RemoteViews(context.packageName, R.layout.widget_daily_ayah).apply {
                        setTextViewText(R.id.widget_ayah_title, if (isBn) "রূহজেনা • দৈনিক আয়াত ও শিক্ষা" else "RuhZena • DAILY VERSE")
                        setTextViewText(R.id.widget_ayah_arabic, snap.dailyArabic)
                        setTextViewText(R.id.widget_ayah_translation, snap.dailyTranslation)
                        setTextViewText(R.id.widget_ayah_ref, snap.dailyRef)
                        setOnClickPendingIntent(
                            R.id.widget_ayah_root,
                            RuhZenaWidgetUpdater.launchAppPendingIntent(context, 4401)
                        )
                    }
                    appWidgetManager.updateAppWidget(appWidgetId, views)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
