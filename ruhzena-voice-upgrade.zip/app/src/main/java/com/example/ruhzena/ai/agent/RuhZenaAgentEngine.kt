package com.example.ruhzena.ai.agent

import android.graphics.Bitmap
import android.util.Log
import com.example.ruhzena.ai.FirebaseGeminiService
import com.example.ruhzena.ai.MealPhotoAnalysis
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.data.local.AiConversationSummaryEntity
import com.example.ruhzena.data.local.AiMemoryEntity
import com.example.ruhzena.data.local.AiMessageEntity
import com.example.ruhzena.data.local.AiProviderHealthEntity
import com.example.ruhzena.data.local.AiTaskStateEntity
import com.example.ruhzena.data.local.MealLogEntity
import com.example.ruhzena.data.local.RuhZenaDataRepository
import com.example.ruhzena.data.local.UserPreferences
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import kotlin.math.min

/**
 * Persistence contract decoupling the persistent RuhZena Agent Engine from concrete Room internals
 * (enables 100% deterministic unit & Robolectric testing across restarts and failovers).
 */
interface AiAgentMemoryStore : HealthPersistenceSink {
    suspend fun getAllMessages(): List<AiMessageEntity>
    suspend fun getActiveMemories(): List<AiMemoryEntity>
    suspend fun getSummary(sessionId: String = "unified"): AiConversationSummaryEntity?
    suspend fun saveSummary(summary: AiConversationSummaryEntity)
    suspend fun getActiveTask(): AiTaskStateEntity?
    suspend fun saveTask(task: AiTaskStateEntity): Long
}

class RoomAiAgentMemoryStore(private val repo: RuhZenaDataRepository) : AiAgentMemoryStore {
    override suspend fun getAllMessages(): List<AiMessageEntity> = repo.getAllAiMessagesSnapshot()
    override suspend fun getActiveMemories(): List<AiMemoryEntity> = repo.getActiveApprovedMemoriesSnapshot()
    override suspend fun getSummary(sessionId: String): AiConversationSummaryEntity? = repo.getConversationSummary(sessionId)
    override suspend fun saveSummary(summary: AiConversationSummaryEntity) = repo.upsertConversationSummary(summary)
    override suspend fun getActiveTask(): AiTaskStateEntity? = repo.getActiveAiTaskSnapshot()
    override suspend fun saveTask(task: AiTaskStateEntity): Long = repo.upsertAiTask(task)
    override suspend fun loadAllHealth(): List<AiProviderHealthEntity> = repo.getProviderHealthSnapshot()
    override suspend fun saveHealth(entity: AiProviderHealthEntity) = repo.upsertProviderHealth(entity)
}

data class WellnessTelemetryContext(
    val waterTodayMl: Int = 0,
    val mealsToday: List<MealLogEntity> = emptyList(),
    val workoutsThisWeek: Int = 0,
    val habitsDoneCount: Int = 0,
    val totalHabitsCount: Int = 0
)

/**
 * Persistent, model-independent RuhZena AI Agent Engine.
 *
 * Performance & Reliability Architecture:
 * - Concurrent DB context preload (history, memories, active task, rolling summary, health).
 * - Single-pass system prompt construction reused across failover attempts.
 * - Complexity-aware + latency-aware routing across existing core providers (Groq, OpenRouter,
 *   Cloudflare Workers AI, Firebase AI Logic).
 * - Dual stall watchdog (fast first-token timeout + mid-stream hang timeout) for rapid failover.
 * - Frame-paced streaming coalescing (0ms first-token emission + smooth 35ms batching) with
 *   partial-stream overlap de-duplication so conversations continue seamlessly across switches.
 */
class RuhZenaAgentEngine(
    private val adapters: List<AiProviderAdapter>,
    private val memoryStore: AiAgentMemoryStore,
    val healthTracker: ProviderHealthTracker = ProviderHealthTracker(persistence = memoryStore),
    val router: IntelligentModelRouter = IntelligentModelRouter(healthTracker),
    private val clock: AgentClock = SystemAgentClock,
    private val discoveryHttpClient: OkHttpClient? = null,
    private val firstTokenStallMsOverride: Long? = null,
    private val interChunkStallMsOverride: Long? = null
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val adapterMap: Map<AiProviderId, AiProviderAdapter> = adapters.associateBy { it.providerId }

    fun getConfiguredProviders(): Set<AiProviderId> =
        adapters.filter { it.isConfigured() }.map { it.providerId }.toSet()

    /**
     * Executes a lightweight real API completion ping against a single configured provider
     * to verify live connectivity, auth, and latency without affecting active chat history.
     */
    suspend fun testSingleProvider(providerId: AiProviderId): ProviderPingResult {
        val adapter = adapterMap[providerId]
            ?: return ProviderPingResult(providerId, "", false, 0L, "Adapter unavailable")
        if (!adapter.isConfigured()) {
            return ProviderPingResult(providerId, "", false, 0L, "Unconfigured (missing API key)")
        }
        val spec = AiModelCatalog.primaryModelForProvider(providerId)
            ?: return ProviderPingResult(providerId, "", false, 0L, "No model registered")

        val started = clock.nowMillis()
        val buf = StringBuilder()
        return try {
            val pingPayload = AgentRequestPayload(
                systemPrompt = "You are RuhZena AI. Reply concisely with: Ready.",
                messages = listOf(ChatTurn(isUser = true, content = "Ping")),
                maxOutputTokens = 24,
                temperature = 0.0,
                streamTimeoutMs = 15_000L
            )
            adapter.streamCompletion(spec, pingPayload).collect { chunk ->
                buf.append(chunk)
            }
            val elapsed = (clock.nowMillis() - started).coerceAtLeast(1L)
            if (buf.isNotBlank()) {
                healthTracker.recordSuccess(spec, elapsed, elapsed)
                ProviderPingResult(providerId, spec.modelId, true, elapsed, "Connected (${elapsed}ms)")
            } else {
                ProviderPingResult(providerId, spec.modelId, false, elapsed, "Empty response")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            val elapsed = (clock.nowMillis() - started).coerceAtLeast(1L)
            val classified = HttpFailureClassifier.classifyThrowable(t)
            healthTracker.recordFailure(spec, classified.kind, classified.retryAfterSeconds, classified.message)
            ProviderPingResult(providerId, spec.modelId, false, elapsed, "${classified.kind.name}: ${classified.message.take(100)}")
        }
    }

    /**
     * Streams a continuous, fast, resilient response for a user prompt, automatically failing over
     * across configured core providers/models and recovering partial streams seamlessly.
     */
    fun streamAgentResponse(
        userPrompt: String,
        personality: AiPersonality,
        language: AppLanguage,
        prefs: UserPreferences,
        telemetry: WellnessTelemetryContext = WellnessTelemetryContext(),
        includeTelemetry: Boolean = false,
        alreadyGreetedInSession: Boolean = false
    ): Flow<AgentStreamEvent> = channelFlow {
        val isBn = language == AppLanguage.BANGLA
        val cleanPrompt = userPrompt.trim()
        if (cleanPrompt.isEmpty()) return@channelFlow

        val configuredProviders = getConfiguredProviders()

        // Refresh OpenRouter live free catalog asynchronously in background — NEVER block reply!
        if (discoveryHttpClient != null && AiProviderId.OPENROUTER in configuredProviders) {
            val nowMs = clock.nowMillis()
            backgroundScope.launch {
                runCatching { router.refreshOpenRouterFreeCatalogIfStale(discoveryHttpClient, nowMs) }
            }
        }

        // Emit immediate feedback before DB preload completes
        send(
            AgentStreamEvent.Status(
                friendlyMessage = if (isBn) "রূহযেনা AI চিন্তা করছে..." else "RuhZena AI is thinking...",
                isFailover = false
            )
        )

        // Concurrent DB context preload (eliminates 5 sequential Room queries before first token)
        val (allHistory, approvedMemories, activeTask, existingSummary) = coroutineScope {
            val historyDef = async { memoryStore.getAllMessages() }
            val memoriesDef = async { memoryStore.getActiveMemories() }
            val taskDef = async { memoryStore.getActiveTask() }
            val summaryDef = async { memoryStore.getSummary("unified") }
            val healthDef = async { healthTracker.ensureLoaded() }
            healthDef.await()
            ContextSnapshot(
                allHistory = historyDef.await(),
                approvedMemories = memoriesDef.await(),
                activeTask = taskDef.await(),
                existingSummary = summaryDef.await()
            )
        }

        // Maintain rolling summary when conversation grows beyond 10 turns so context stays compact
        val rollingSummary = updateRollingSummaryIfNeeded(allHistory, existingSummary)

        val queryProfile = router.classifyQuery(
            query = cleanPrompt,
            requiresVision = false,
            requiresStructuredJson = false,
            estimatedInputTokens = estimateTokens(cleanPrompt) + 500
        )

        val inAppHint = com.example.ruhzena.ai.RuhZenaInAppRouter.buildPromptAvailabilityNote(cleanPrompt, isBn)

        // Build system prompt ONCE per turn and reuse identically across all failover attempts
        val prebuiltSystemPrompt = buildSystemPrompt(
            personality = personality,
            language = language,
            prefs = prefs,
            telemetry = telemetry,
            includeTelemetry = includeTelemetry || queryProfile.domain == QueryDomain.WELLNESS_FITNESS,
            approvedMemories = approvedMemories,
            activeTask = activeTask,
            rollingSummary = rollingSummary,
            alreadyGreetedInSession = alreadyGreetedInSession,
            inAppAvailabilityHint = inAppHint
        )

        val firstTokenBudgetMs = firstTokenStallMsOverride ?: when (queryProfile.complexity) {
            QueryComplexity.SIMPLE -> FIRST_TOKEN_STALL_SIMPLE_MS
            QueryComplexity.STANDARD -> FIRST_TOKEN_STALL_STANDARD_MS
            QueryComplexity.COMPLEX -> FIRST_TOKEN_STALL_COMPLEX_MS
        }
        val interChunkBudgetMs = interChunkStallMsOverride ?: INTER_CHUNK_STALL_TIMEOUT_MS

        val triedModelKeys = mutableSetOf<String>()
        var lastFailedProvider: AiProviderId? = null
        var accumulatedPartial = ""
        var attemptCount = 0
        val maxTotalAttempts = 8

        while (attemptCount < maxTotalAttempts) {
            val ranked = router.rankCandidates(
                profile = queryProfile,
                configuredProviders = configuredProviders,
                excludeModelKeys = triedModelKeys,
                preferredSkipProvider = lastFailedProvider
            )
            val candidate = ranked.firstOrNull() ?: break
            val adapter = adapterMap[candidate.provider]
            if (adapter == null || !adapter.isConfigured()) {
                triedModelKeys.add(candidate.modelKey)
                continue
            }

            triedModelKeys.add(candidate.modelKey)
            attemptCount++

            if (attemptCount > 1) {
                send(
                    AgentStreamEvent.Status(
                        friendlyMessage = if (isBn) "রূহযেনা AI উত্তর লিখছে..." else "RuhZena AI is replying...",
                        isFailover = true
                    )
                )
            }

            val isContinuation = accumulatedPartial.length >= MIN_PARTIAL_FOR_CONTINUATION
            val payload = buildBudgetedPayload(
                targetModel = candidate,
                userPrompt = cleanPrompt,
                personality = personality,
                language = language,
                prefs = prefs,
                telemetry = telemetry,
                includeTelemetry = includeTelemetry || queryProfile.domain == QueryDomain.WELLNESS_FITNESS,
                approvedMemories = approvedMemories,
                activeTask = activeTask,
                rollingSummary = rollingSummary,
                allHistory = allHistory,
                partialToContinue = if (isContinuation) accumulatedPartial else null,
                alreadyGreetedInSession = alreadyGreetedInSession,
                complexity = queryProfile.complexity,
                prebuiltSystemPrompt = prebuiltSystemPrompt
            )

            val startedMs = clock.nowMillis()
            var firstTokenMs = 0L
            var lastChunkElapsedMs = 0L
            var lastUiEmitMs = 0L
            var lastEmittedLength = 0
            val attemptBuffer = StringBuilder()

            try {
                // Dual watchdog:
                // 1) Fast first-token stall guard (5.5s simple / 7.5s complex) triggers immediate failover
                // 2) Inter-chunk stall guard (10s) catches mid-sentence hangs and continues seamlessly
                coroutineScope {
                    val streamJob = async {
                        adapter.streamCompletion(candidate, payload).collect { chunk ->
                            if (chunk.isNotEmpty()) {
                                val nowMs = clock.nowMillis()
                                val elapsed = (nowMs - startedMs).coerceAtLeast(1L)
                                val isFirstChunk = (firstTokenMs == 0L)
                                if (isFirstChunk) {
                                    firstTokenMs = elapsed
                                }
                                lastChunkElapsedMs = elapsed
                                attemptBuffer.append(chunk)

                                // Emit the VERY FIRST token immediately (0ms delay), then frame-pace
                                // rapid token streams every ~35ms to avoid Compose recomposition storms.
                                if (isFirstChunk || (nowMs - lastUiEmitMs) >= STREAM_EMIT_COALESCE_MS) {
                                    lastUiEmitMs = nowMs
                                    lastEmittedLength = attemptBuffer.length
                                    val displaySoFar = if (isContinuation) {
                                        mergeContinuationWithoutDuplication(accumulatedPartial, attemptBuffer.toString())
                                    } else {
                                        attemptBuffer.toString()
                                    }
                                    val cleanLive = ensureRespectfulSalamIfNeeded(
                                        text = fastStripControlTags(displaySoFar),
                                        userPrompt = cleanPrompt,
                                        alreadyGreetedInSession = alreadyGreetedInSession,
                                        language = language,
                                        characterGender = prefs.characterGender,
                                        isFinal = false
                                    )
                                    send(AgentStreamEvent.TextProgress(cleanLive))
                                }
                            }
                        }
                    }
                    val watchdog = launch {
                        // Phase 1: Wait up to firstTokenBudgetMs for the first token
                        delay(firstTokenBudgetMs)
                        if (firstTokenMs == 0L && streamJob.isActive) {
                            streamJob.cancel(
                                CancellationException("First-token stall > ${firstTokenBudgetMs}ms")
                            )
                            return@launch
                        }
                        // Phase 2: Monitor for mid-stream hangs while active
                        while (streamJob.isActive) {
                            val snapshotChunkElapsed = lastChunkElapsedMs
                            delay(interChunkBudgetMs)
                            if (streamJob.isActive && lastChunkElapsedMs == snapshotChunkElapsed) {
                                streamJob.cancel(
                                    CancellationException("Mid-stream stall > ${interChunkBudgetMs}ms")
                                )
                                return@launch
                            }
                        }
                    }
                    try {
                        streamJob.await()
                    } catch (ce: CancellationException) {
                        val reason = ce.message.orEmpty()
                        if (reason.contains("First-token stall")) {
                            throw AiProviderException(
                                kind = AiFailureKind.TIMEOUT_OR_STALL,
                                message = "Provider stalled > ${firstTokenBudgetMs}ms before first token"
                            )
                        }
                        if (reason.contains("Mid-stream stall")) {
                            throw AiProviderException(
                                kind = AiFailureKind.MID_STREAM_INTERRUPT,
                                message = "Provider stalled mid-stream > ${interChunkBudgetMs}ms"
                            )
                        }
                        throw ce
                    } finally {
                        watchdog.cancel()
                    }
                }

                // Flush final coalesced tail so UI never misses the last streamed characters
                if (attemptBuffer.length > lastEmittedLength) {
                    val displayTail = if (isContinuation) {
                        mergeContinuationWithoutDuplication(accumulatedPartial, attemptBuffer.toString())
                    } else {
                        attemptBuffer.toString()
                    }
                    val cleanTail = ensureRespectfulSalamIfNeeded(
                        text = fastStripControlTags(displayTail),
                        userPrompt = cleanPrompt,
                        alreadyGreetedInSession = alreadyGreetedInSession,
                        language = language,
                        characterGender = prefs.characterGender,
                        isFinal = false
                    )
                    send(AgentStreamEvent.TextProgress(cleanTail))
                }

                val latency = (clock.nowMillis() - startedMs).coerceAtLeast(1L)
                val finalRaw = if (isContinuation) {
                    mergeContinuationWithoutDuplication(accumulatedPartial, attemptBuffer.toString())
                } else {
                    attemptBuffer.toString()
                }

                if (finalRaw.isBlank()) {
                    throw AiProviderException(AiFailureKind.EMPTY_RESPONSE, message = "Empty completion")
                }

                healthTracker.recordSuccess(candidate, latency, if (firstTokenMs > 0L) firstTokenMs else latency)

                // Extract optional memory proposal & multi-step task updates before stripping tags
                val memoryProposal = extractMemoryProposal(finalRaw, cleanPrompt)
                extractAndPersistTaskUpdate(finalRaw, cleanPrompt, activeTask)

                val cleanedVisibleText = ensureRespectfulSalamIfNeeded(
                    text = stripInternalControlTags(finalRaw),
                    userPrompt = cleanPrompt,
                    alreadyGreetedInSession = alreadyGreetedInSession,
                    language = language,
                    characterGender = prefs.characterGender,
                    isFinal = true
                )
                val parsed = FirebaseGeminiService.parseChatSections(cleanedVisibleText, cleanPrompt)

                send(
                    AgentStreamEvent.Completed(
                        rawText = cleanedVisibleText,
                        mainReply = parsed.mainReply,
                        explanation = parsed.explanation,
                        citedSources = parsed.citedSources,
                        topic = parsed.topic,
                        actionTags = parsed.actionTags,
                        memoryProposal = memoryProposal,
                        usedFailover = attemptCount > 1,
                        attemptCount = attemptCount,
                        servedByProvider = candidate.provider,
                        servedByModelId = candidate.modelId
                    )
                )
                return@channelFlow
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                val classified = HttpFailureClassifier.classifyThrowable(
                    t,
                    hadPartialStream = attemptBuffer.isNotEmpty()
                )
                Log.w(TAG, "Failover from ${candidate.modelKey} (${classified.kind}): ${classified.message}")

                healthTracker.recordFailure(
                    spec = candidate,
                    kind = classified.kind,
                    retryAfterSeconds = classified.retryAfterSeconds,
                    summary = classified.message
                )
                lastFailedProvider = candidate.provider

                // Preserve meaningful partial output internally so the next healthy provider continues smoothly
                if (attemptBuffer.isNotEmpty()) {
                    accumulatedPartial = if (isContinuation) {
                        mergeContinuationWithoutDuplication(accumulatedPartial, attemptBuffer.toString())
                    } else {
                        attemptBuffer.toString()
                    }
                }
            }
        }

        // If every cloud provider failed, preserve partial if substantial or emit calm user-friendly failure
        if (accumulatedPartial.length >= 160) {
            val cleaned = stripInternalControlTags(accumulatedPartial)
            val parsed = FirebaseGeminiService.parseChatSections(cleaned, cleanPrompt)
            send(
                AgentStreamEvent.Completed(
                    rawText = cleaned,
                    mainReply = parsed.mainReply,
                    explanation = parsed.explanation,
                    citedSources = parsed.citedSources,
                    topic = parsed.topic,
                    actionTags = parsed.actionTags,
                    memoryProposal = null,
                    usedFailover = attemptCount > 1,
                    attemptCount = attemptCount,
                    servedByProvider = AiProviderId.OFFLINE_CORPUS,
                    servedByModelId = "partial-recovered"
                )
            )
            return@channelFlow
        }

        val friendlyErr = if (isBn) {
            "রূহযেনা AI এই মুহূর্তে অস্থায়ীভাবে ব্যস্ত বা অফলাইন আছে। আপনার বার্তাটি সংরক্ষিত আছে — কিছুক্ষণ পর আবার চেষ্টা করুন।"
        } else {
            "RuhZena AI is temporarily unable to reach its cloud engines right now. Your message is preserved — please tap Retry in a moment."
        }
        send(
            AgentStreamEvent.Failed(
                friendlyMessage = friendlyErr,
                preservedUserPrompt = cleanPrompt,
                allProvidersExhausted = true
            )
        )
    }

    /**
     * Applies the exact same multi-provider automatic failover engine to the Nutrition Photo/Meal Checker.
     */
    suspend fun analyzeMealPhotoWithFailover(
        bitmap: Bitmap,
        prefs: UserPreferences,
        mealType: String
    ): Pair<MealPhotoAnalysis, AiModelSpec> {
        val profile = QueryProfile(
            domain = QueryDomain.WELLNESS_FITNESS,
            complexity = QueryComplexity.COMPLEX,
            requiresVision = true,
            requiresStructuredJson = true,
            estimatedInputTokens = 1200
        )
        val configured = getConfiguredProviders()
        val tried = mutableSetOf<String>()
        var lastFailed: AiProviderId? = null
        var lastErr: Throwable? = null

        repeat(5) {
            val candidate = router.rankCandidates(
                profile = profile,
                configuredProviders = configured,
                excludeModelKeys = tried,
                preferredSkipProvider = lastFailed
            ).firstOrNull() ?: return@repeat

            val adapter = adapterMap[candidate.provider]
            if (adapter == null || !adapter.isConfigured()) {
                tried.add(candidate.modelKey)
                return@repeat
            }
            tried.add(candidate.modelKey)

            val startedMs = clock.nowMillis()
            try {
                val result = adapter.analyzeMealImage(candidate, bitmap, prefs, mealType)
                healthTracker.recordSuccess(candidate, (clock.nowMillis() - startedMs).coerceAtLeast(1L))
                return result to candidate
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                val classified = HttpFailureClassifier.classifyThrowable(t)
                lastErr = classified
                lastFailed = candidate.provider
                healthTracker.recordFailure(
                    spec = candidate,
                    kind = classified.kind,
                    retryAfterSeconds = classified.retryAfterSeconds,
                    summary = classified.message
                )
            }
        }

        throw lastErr ?: AiProviderException(
            kind = AiFailureKind.SERVER_OUTAGE_5XX,
            message = "Unable to analyze this meal photo right now. Please try again in a moment."
        )
    }

    /**
     * Multi-provider automatic failover engine for In-Depth Quran Ayah Explanation (Tafsir).
     * Eliminates single-model "high demand" failures by routing across all configured providers
     * (Groq, OpenRouter, Cloudflare Workers AI, and Firebase AI Logic) using health & latency scoring.
     */
    suspend fun explainAyahWithFailover(
        ayah: com.example.ruhzena.data.islamic.QuranAyah,
        language: AppLanguage
    ): com.example.ruhzena.data.islamic.AyahExplanation {
        val isBn = language == AppLanguage.BANGLA
        val meta = com.example.ruhzena.data.islamic.SurahCatalog.getMeta(ayah.surahNumber)
        val systemPrompt = """
            You are an authentic Islamic Tafsir scholar providing FULL, detailed, accurate, contextual verse explanations rooted in classical Tafsir (Ibn Kathir, Al-Tabari, Al-Sa'di, Maariful Quran).
            NEVER give a brief 1–2 sentence summary. Always provide thorough, multi-paragraph explanation of the verse in its surrounding Surah flow, verified Asbab al-Nuzul (never fabricate stories), Arabic word-by-word nuances, related Sahih Hadith, and practical life guidance.
            CRITICAL OUTPUT FORMAT: Respond with ONLY a single valid JSON object (no markdown fences, no extra prose) containing these exact 5 string keys:
            {"title":"...","deeperContext":"...","explanation":"...","lifeLesson":"...","sourceNote":"..."}
        """.trimIndent()

        val userPrompt = buildString {
            appendLine("Language for ALL JSON string values: ${if (isBn) "Bangla (বাংলা)" else "English"}.")
            appendLine("Surah ${meta.number}: ${meta.englishName} (${meta.englishMeaning}) — ${meta.revelationPlace}, ${meta.ayahCount} ayahs.")
            appendLine("Ayah ${ayah.surahNumber}:${ayah.ayahNumber}:")
            appendLine("Arabic: ${ayah.arabicText}")
            appendLine("Translation (EN): ${ayah.englishTranslation}")
            appendLine("Translation (BN): ${ayah.banglaTranslation}")
            appendLine("Provide FULL, rich, authentic Tafsir (NOT a short summary): detailed surrounding Surah narrative & authentic Asbab al-Nuzul (deeperContext), key Arabic linguistic depth & scholarly Tafsir meaning (explanation), actionable daily Sunnah reflection (lifeLesson), and classical Tafsir/Hadith citations (sourceNote). Return valid JSON only.")
        }

        val profile = QueryProfile(
            domain = QueryDomain.ISLAMIC_KNOWLEDGE,
            complexity = QueryComplexity.STANDARD,
            requiresVision = false,
            requiresStructuredJson = true,
            estimatedInputTokens = estimateTokens(systemPrompt + userPrompt) + 120
        )

        val configured = getConfiguredProviders()
        val tried = mutableSetOf<String>()
        var lastFailed: AiProviderId? = null
        var lastErr: Throwable? = null

        repeat(6) {
            val candidate = router.rankCandidates(
                profile = profile,
                configuredProviders = configured,
                excludeModelKeys = tried,
                preferredSkipProvider = lastFailed
            ).firstOrNull() ?: return@repeat

            val adapter = adapterMap[candidate.provider]
            if (adapter == null || !adapter.isConfigured()) {
                tried.add(candidate.modelKey)
                return@repeat
            }
            tried.add(candidate.modelKey)

            val startedMs = clock.nowMillis()
            try {
                val payload = AgentRequestPayload(
                    systemPrompt = systemPrompt,
                    messages = listOf(ChatTurn(isUser = true, content = userPrompt)),
                    maxOutputTokens = 1800,
                    temperature = 0.25,
                    streamTimeoutMs = 24_000L
                )
                val sb = StringBuilder()
                adapter.streamCompletion(candidate, payload).collect { chunk ->
                    if (chunk.isNotEmpty()) sb.append(chunk)
                }
                val raw = sb.toString().trim()
                if (raw.isBlank()) {
                    throw AiProviderException(AiFailureKind.EMPTY_RESPONSE, message = "Empty Tafsir response")
                }

                val parsed = parseAyahTafsirJsonOrProse(raw, ayah, meta, isBn)
                val latency = (clock.nowMillis() - startedMs).coerceAtLeast(1L)
                healthTracker.recordSuccess(candidate, latency, latency)
                return parsed
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                val classified = HttpFailureClassifier.classifyThrowable(t)
                lastErr = classified
                lastFailed = candidate.provider
                Log.w(TAG, "Ayah Tafsir failover from ${candidate.modelKey} (${classified.kind}): ${classified.message}")
                healthTracker.recordFailure(
                    spec = candidate,
                    kind = classified.kind,
                    retryAfterSeconds = classified.retryAfterSeconds,
                    summary = classified.message
                )
            }
        }

        // Final safety net: direct FirebaseGeminiService (which also fails over 3.8-flash -> 3.5-flash-lite)
        return runCatching {
            FirebaseGeminiService.explainAyahInDepth(ayah, language)
        }.getOrElse { fallbackErr ->
            throw lastErr ?: fallbackErr
        }
    }

    private fun parseAyahTafsirJsonOrProse(
        raw: String,
        ayah: com.example.ruhzena.data.islamic.QuranAyah,
        meta: com.example.ruhzena.data.islamic.SurahMeta,
        isBn: Boolean
    ): com.example.ruhzena.data.islamic.AyahExplanation {
        val stripped = raw
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        val firstBrace = stripped.indexOf('{')
        val lastBrace = stripped.lastIndexOf('}')
        val jsonSlice = if (firstBrace >= 0 && lastBrace > firstBrace) {
            stripped.substring(firstBrace, lastBrace + 1)
        } else {
            null
        }

        var title = ""
        var deeperContext = ""
        var explanation = ""
        var lifeLesson = ""
        var sourceNote = "Classical Tafsir (Ibn Kathir, Al-Sa'di, Maariful Quran)"

        if (jsonSlice != null) {
            runCatching {
                val obj = org.json.JSONObject(jsonSlice)
                title = obj.optString("title").trim()
                deeperContext = obj.optString("deeperContext").trim()
                explanation = obj.optString("explanation").trim()
                lifeLesson = obj.optString("lifeLesson").trim()
                sourceNote = obj.optString("sourceNote").trim().ifBlank { sourceNote }
            }
        }

        if (explanation.isBlank()) {
            // Graceful prose salvage if a smaller fast model returned plain text instead of strict JSON
            val cleanProse = stripped.replace(Regex("""[{}"\[\]]"""), " ").replace(Regex("\\s+"), " ").trim()
            if (cleanProse.length < 40) {
                throw AiProviderException(AiFailureKind.EMPTY_RESPONSE, message = "Unusable Tafsir output")
            }
            explanation = cleanProse.take(1200)
        }

        val resolvedTitle = title.ifBlank {
            if (isBn) "আয়াত ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.banglaName}"
            else "Ayah ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.englishName}"
        }

        return com.example.ruhzena.data.islamic.AyahExplanation(
            surahNumber = ayah.surahNumber,
            ayahNumber = ayah.ayahNumber,
            titleEn = if (!isBn) resolvedTitle else "Ayah ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.englishName}",
            titleBn = if (isBn) resolvedTitle else "আয়াত ${ayah.surahNumber}:${ayah.ayahNumber} — ${meta.banglaName}",
            explanationEn = if (!isBn) explanation else "",
            explanationBn = if (isBn) explanation else "",
            lifeLessonEn = if (!isBn) lifeLesson else "",
            lifeLessonBn = if (isBn) lifeLesson else "",
            surahContextEn = "Surah ${meta.number}: ${meta.englishName} (${meta.arabicName}) • ${meta.revelationPlace} • ${meta.ayahCount} Ayahs",
            surahContextBn = "সূরা ${meta.number}: ${meta.banglaName} (${meta.arabicName}) • ${if (meta.revelationPlace == "Meccan") "মক্কী" else "মাদানী"} • ${meta.ayahCount} আয়াত",
            sourceNote = sourceNote,
            deeperContextEn = if (!isBn) deeperContext else "",
            deeperContextBn = if (isBn) deeperContext else ""
        )
    }

    /**
     * Builds a token-budgeted prompt packet tailored to the target model's safe context/TPM window,
     * preserving identity, personality, Islamic standards, approved memories, active task state,
     * rolling summary, and recent turns without silent critical truncation.
     */
    internal fun buildBudgetedPayload(
        targetModel: AiModelSpec,
        userPrompt: String,
        personality: AiPersonality,
        language: AppLanguage,
        prefs: UserPreferences,
        telemetry: WellnessTelemetryContext,
        includeTelemetry: Boolean,
        approvedMemories: List<AiMemoryEntity>,
        activeTask: AiTaskStateEntity?,
        rollingSummary: AiConversationSummaryEntity?,
        allHistory: List<AiMessageEntity>,
        partialToContinue: String? = null,
        alreadyGreetedInSession: Boolean = false,
        complexity: QueryComplexity = QueryComplexity.STANDARD,
        prebuiltSystemPrompt: String? = null
    ): AgentRequestPayload {
        val isBn = language == AppLanguage.BANGLA
        val systemPrompt = prebuiltSystemPrompt ?: buildSystemPrompt(
            personality = personality,
            language = language,
            prefs = prefs,
            telemetry = telemetry,
            includeTelemetry = includeTelemetry,
            approvedMemories = approvedMemories,
            activeTask = activeTask,
            rollingSummary = rollingSummary,
            alreadyGreetedInSession = alreadyGreetedInSession
        )

        val systemTokens = estimateTokens(systemPrompt)
        val userTokens = estimateTokens(userPrompt)
        val remainingHistoryBudget = (targetModel.safePromptBudgetTokens - systemTokens - userTokens - 250)
            .coerceAtLeast(350)

        val priorHistory = allHistory.dropLastWhile {
            it.role == "USER" && it.content.trim() == userPrompt
        }

        val maxHistoryTurns = when (complexity) {
            QueryComplexity.SIMPLE -> 6
            QueryComplexity.STANDARD -> 8
            QueryComplexity.COMPLEX -> 10
        }

        val selectedTurns = mutableListOf<ChatTurn>()
        var usedTokens = 0
        for (msg in priorHistory.asReversed()) {
            val contentClipped = msg.content.take(900)
            val cost = estimateTokens(contentClipped)
            if (usedTokens + cost > remainingHistoryBudget && selectedTurns.size >= 2) break
            selectedTurns.add(ChatTurn(isUser = msg.role == "USER", content = contentClipped, timestamp = msg.timestamp))
            usedTokens += cost
            if (selectedTurns.size >= maxHistoryTurns) break
        }
        selectedTurns.reverse()

        val finalUserTurn = if (partialToContinue != null) {
            val tailSnippet = partialToContinue.takeLast(1200)
            """
            Original User Request: $userPrompt
            [INTERNAL CONTINUATION — DO NOT REPEAT PRIOR TEXT]
            Continue smoothly from the exact point where the response stopped without repeating already written sentences.
            Already written:
            $tailSnippet
            """.trimIndent()
        } else {
            val langHint = if (isBn) "[Reply naturally in Bangla (বাংলা)]" else "[Reply naturally in English]"
            "$langHint\n$userPrompt"
        }

        selectedTurns.add(ChatTurn(isUser = true, content = finalUserTurn))

        val adaptiveMaxTokens = when (complexity) {
            QueryComplexity.SIMPLE -> min(420, targetModel.maxOutputTokens)
            QueryComplexity.STANDARD -> min(920, targetModel.maxOutputTokens)
            QueryComplexity.COMPLEX -> min(1500, targetModel.maxOutputTokens)
        }

        val adaptiveStreamTimeoutMs = when (complexity) {
            QueryComplexity.SIMPLE -> 20_000L
            QueryComplexity.STANDARD -> 28_000L
            QueryComplexity.COMPLEX -> 38_000L
        }

        return AgentRequestPayload(
            systemPrompt = systemPrompt,
            messages = selectedTurns,
            maxOutputTokens = adaptiveMaxTokens,
            temperature = if (personality == AiPersonality.PRACTICAL_EXPERT) 0.35 else 0.55,
            streamTimeoutMs = adaptiveStreamTimeoutMs
        )
    }

    internal fun buildSystemPrompt(
        personality: AiPersonality,
        language: AppLanguage,
        prefs: UserPreferences,
        telemetry: WellnessTelemetryContext,
        includeTelemetry: Boolean,
        approvedMemories: List<AiMemoryEntity>,
        activeTask: AiTaskStateEntity?,
        rollingSummary: AiConversationSummaryEntity?,
        alreadyGreetedInSession: Boolean = false,
        inAppAvailabilityHint: String = ""
    ): String = buildString {
        val genderHonorificEn = when (prefs.characterGender.uppercase()) {
            "MALE" -> "brother"
            "FEMALE" -> "sister"
            else -> ""
        }
        val genderHonorificBn = when (prefs.characterGender.uppercase()) {
            "MALE" -> "ভাই"
            "FEMALE" -> "বোন"
            else -> ""
        }
        val userNameClean = prefs.userName.trim()

        appendLine("You are RuhZena AI — a dignified, deeply respectful, knowledgeable Islamic companion for Quran, Sunnah, daily ibadah, and disciplined personal wellness.")
        appendLine("IDENTITY: Your sole name is RuhZena AI. Never mention underlying model names, API providers, failover, or infrastructure.")
        if (genderHonorificEn.isNotEmpty() || userNameClean.isNotEmpty()) {
            append("ADDRESSING: ")
            if (userNameClean.isNotEmpty()) append("Name: \"$userNameClean\". ")
            if (genderHonorificEn.isNotEmpty()) {
                append("Respectfully address them as \"dear $genderHonorificEn\" / \"$genderHonorificEn\" (Bangla: \"প্রিয় $genderHonorificBn\" / \"$genderHonorificBn\") with genuine Islamic warmth.")
            }
            appendLine()
        }

        val personaDirective = when (personality) {
            AiPersonality.PEACE_COMPANION ->
                "ACTIVE MINDSET (HEART & LIFE COMPANION): Speak with serene Islamic adab (etiquette), empathy, Sabr, Tawakkul, and sincere du'a for the user."
            AiPersonality.PRACTICAL_EXPERT ->
                "ACTIVE MINDSET (SCHOLAR & STRATEGY COACH): Speak with respectful scholarly dignity, crisp evidence-first structure, precise steps, and clear Islamic etiquette."
        }
        appendLine(personaDirective)
        appendLine("ISLAMIC ADAB & TONE (STRICT): Always speak with dignified, warm Islamic courtesy — NEVER use casual slang, overly informal chatter ('hey', 'yo', 'cool', 'gotcha', 'no worries', 'bro', 'awesome sauce'). Naturally weave sincere Islamic expressions (Bismillah, Alhamdulillah, In sha Allah, BarakAllahu feek, MashaAllah, May Allah grant you ease) where fitting.")
        appendLine("COACHING: Gently correct mistakes in Islamic etiquette, Arabic, Salah/Wudu, or health facts with kindness so the user genuinely learns.")

        if (alreadyGreetedInSession) {
            appendLine("ISLAMIC GREETING RULE: If the user gives Salam now, reply warmly with 'Wa Alaikumus Salam wa Rahmatullahi wa Barakatuh!'. Otherwise maintain respectful Islamic courtesy (e.g., 'Alhamdulillah', 'BarakAllahu feek', 'In sha Allah') without sounding casual.")
        } else {
            appendLine("ISLAMIC GREETING RULE (MANDATORY FIRST TURN): ALWAYS begin your reply with a warm Islamic Salam! If the user gave Salam first, open with 'Wa Alaikumus Salam wa Rahmatullahi wa Barakatuh'. Otherwise, open with 'Assalamu Alaikum wa Rahmatullahi wa Barakatuh' (in Bangla: 'আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহি ওয়া বারাকাতুহু'). If they greeted with casual 'hi'/'hello', kindly greet them with 'Assalamu Alaikum wa Rahmatullahi wa Barakatuh' and gently remind them of the beauty of spreading Salam.")
        }

        appendLine("BUILT-IN RUHZENA FEATURES (DIRECT USERS HERE WHEN RELEVANT): RuhZena already includes: full 114-Surah Quran Reader with audio recitation, translation & Tafsir (tag [[ACTION:SURAH:<number>]] or [[ACTION:SURAH:<number>:<ayah>]], e.g. [[ACTION:SURAH:67]] for Surah Al-Mulk, [[ACTION:SURAH:2:255]] for Ayat al-Kursi); Comprehensive Daily Sunnah Duas Library (washroom, home, stairs, bazaar, masjid, travel, sleep, anxiety, forgiveness — tag [[ACTION:DUA]]); Step-by-Step Adhkar ([[ACTION:ADHKAR:MORNING|EVENING|AFTER_PRAYER|BEDTIME]]); Tasbih Counter ([[ACTION:TASBIH]]); Prayer Times & Qibla ([[ACTION:PRAYER_TIMES]], [[ACTION:QIBLA]]); 3D Wudu & Salah Guides ([[ACTION:WUDU_GUIDE]], [[ACTION:SALAH_GUIDE]]); Arabic Writing Studio ([[ACTION:ARABIC_STUDIO]]); Prophet Stories ([[ACTION:STORIES]]); Hajj & Umrah ([[ACTION:HAJJ_UMRAH]]); Hifz Companion ([[ACTION:HIFZ]]); Guided Workouts ([[ACTION:WORKOUTS]]); Water Tracker ([[ACTION:HYDRATION]]); Meal Scanner ([[ACTION:NUTRITION]]); Habits & Calm Breathing ([[ACTION:HABITS]], [[ACTION:BREATHING]]); Reflection Journal ([[ACTION:JOURNAL]]). Whenever the user asks for any Surah, Dua, Adhkar, or tool available in RuhZena, explicitly tell them they can open it right inside RuhZena using the button below!")
        if (inAppAvailabilityHint.isNotBlank()) {
            appendLine(inAppAvailabilityHint)
        }

        appendLine("ISLAMIC INTEGRITY: Never fabricate, guess, or invent Quran Surah:Ayah or Hadith numbers. Distinguish Quran, Sahih Hadith, scholarly Ikhtilaf, and wellness advice. State uncertainty honestly and include verified URLs (https://quran.com/..., https://sunnah.com/...) where relevant.")
        appendLine("FORMAT & RICH TEXT: Use clean Markdown so your answers look crisp and readable: **bold** key terms, __underline__ key takeaways, ==highlight== sacred phrases or core reminders, and use ### headings & bullet points when helpful. For substantive Islamic or wellness questions use: direct answer, then optional '### Explanation' and '### Sources'. Optional final-line tags when relevant: [[ACTION:...]], [[MEMORY_SUGGEST:GOAL|fact]], [[TASK_UPDATE:title|done|next]].")

        if (approvedMemories.isNotEmpty()) {
            appendLine()
            appendLine("USER-APPROVED LONG-TERM MEMORIES (only rely on these verified facts):")
            approvedMemories.take(12).forEach { mem ->
                appendLine("- [${mem.category}] ${mem.content}")
            }
        }

        if (activeTask != null && activeTask.status == "ACTIVE") {
            appendLine()
            appendLine("ACTIVE PERSISTENT MULTI-STEP TASK (continue seamlessly from this exact state):")
            appendLine("- Title: ${activeTask.title}")
            appendLine("- Objective: ${activeTask.objective}")
            if (activeTask.constraints.isNotBlank()) appendLine("- Constraints: ${activeTask.constraints}")
            appendLine("- Completed Steps: ${activeTask.completedStepsJson}")
            appendLine("- Remaining Steps: ${activeTask.remainingStepsJson}")
            if (activeTask.workingNotes.isNotBlank()) appendLine("- Working Notes: ${activeTask.workingNotes}")
            if (activeTask.nextAction.isNotBlank()) appendLine("- Next Action: ${activeTask.nextAction}")
        }

        if (rollingSummary != null && rollingSummary.summaryText.isNotBlank()) {
            appendLine()
            appendLine("EARLIER CONVERSATION SUMMARY:")
            appendLine(rollingSummary.summaryText.take(900))
        }

        if (includeTelemetry) {
            val totalCal = telemetry.mealsToday.sumOf { it.calories }
            val totalProtein = telemetry.mealsToday.sumOf { it.proteinGrams }
            appendLine()
            appendLine("RELEVANT WELLNESS PROFILE (non-sensitive summary only; do not assume journal contents):")
            if (prefs.userName.isNotBlank()) append("Name: ${prefs.userName} | ")
            appendLine(
                "Age: ${prefs.ageYears}, Weight: ${prefs.weightKg}kg, Height: ${prefs.heightCm}cm, " +
                    "Level: ${prefs.fitnessLevel}, Goal: ${prefs.fitnessGoal}, Equipment: ${prefs.availableEquipment}, " +
                    "Limitations: ${prefs.fitnessLimitation}, Water: ${telemetry.waterTodayMl}/${prefs.hydrationGoalMl} ml, " +
                    "Meals today: $totalCal kcal (${totalProtein}g protein), Workouts this week: ${telemetry.workoutsThisWeek}, " +
                    "Habits done: ${telemetry.habitsDoneCount}/${telemetry.totalHabitsCount}."
            )
            appendLine("Note: Wellness guidance is educational and not medical diagnosis.")
        }

        if (language == AppLanguage.BANGLA) {
            appendLine()
            appendLine("Preferred Language: Bangla (বাংলা).")
        }
    }.trim()

    private suspend fun updateRollingSummaryIfNeeded(
        allHistory: List<AiMessageEntity>,
        existing: AiConversationSummaryEntity?
    ): AiConversationSummaryEntity? {
        if (allHistory.size <= 10) return existing
        val olderMessages = allHistory.dropLast(6)
        val latestCoveredId = olderMessages.lastOrNull()?.id ?: return existing
        if (existing != null && existing.coveredUpToMessageId >= latestCoveredId) return existing

        val userTopics = olderMessages
            .filter { it.role == "USER" }
            .takeLast(8)
            .map { it.content.replace('\n', ' ').trim().take(90) }
        val assistantHighlights = olderMessages
            .filter { it.role == "ASSISTANT" }
            .takeLast(4)
            .map { it.content.replace('\n', ' ').trim().take(110) }

        val compressed = buildString {
            if (!existing?.summaryText.isNullOrBlank()) {
                append(existing!!.summaryText.take(360)).append(" ")
            }
            append("Recent user questions: ").append(userTopics.joinToString(" | ")).append(". ")
            if (assistantHighlights.isNotEmpty()) {
                append("Key guidance given: ").append(assistantHighlights.joinToString(" | "))
            }
        }.take(950)

        val updated = AiConversationSummaryEntity(
            sessionId = "unified",
            summaryText = compressed,
            coveredUpToMessageId = latestCoveredId,
            activeTopicsCsv = userTopics.takeLast(3).joinToString(","),
            updatedAt = clock.nowMillis()
        )
        runCatching { memoryStore.saveSummary(updated) }
        return updated
    }

    private fun extractMemoryProposal(rawText: String, userPrompt: String): CandidateMemoryProposal? {
        val tagMatch = MEMORY_TAG_REGEX.find(rawText)
        if (tagMatch != null) {
            val cat = tagMatch.groupValues[1].trim().uppercase().ifBlank { "GENERAL" }
            val fact = tagMatch.groupValues[2].trim()
            if (fact.length in 6..180) {
                return CandidateMemoryProposal(category = cat, content = fact, sourcePrompt = userPrompt.take(120))
            }
        }
        val lower = userPrompt.lowercase()
        val explicitTrigger = lower.startsWith("remember ") ||
            lower.contains("remember that i ") ||
            lower.contains("my goal is ") ||
            lower.contains("i am allergic to ") ||
            lower.contains("i follow the ") ||
            lower.contains("prefer ")
        if (explicitTrigger && userPrompt.length in 12..160) {
            val cat = when {
                lower.contains("halal") || lower.contains("allergic") || lower.contains("diet") -> "NUTRITION"
                lower.contains("workout") || lower.contains("knee") || lower.contains("fitness") -> "FITNESS"
                lower.contains("hanafi") || lower.contains("shafi") || lower.contains("quran") || lower.contains("hifz") -> "SPIRITUAL"
                else -> "PREFERENCE"
            }
            return CandidateMemoryProposal(category = cat, content = userPrompt.trim(), sourcePrompt = userPrompt.take(120))
        }
        return null
    }

    private suspend fun extractAndPersistTaskUpdate(
        rawText: String,
        userPrompt: String,
        existingTask: AiTaskStateEntity?
    ) {
        val match = TASK_TAG_REGEX.find(rawText) ?: return
        val title = match.groupValues[1].trim().ifBlank { existingTask?.title ?: userPrompt.take(50) }
        val completedStep = match.groupValues[2].trim()
        val nextStep = match.groupValues[3].trim()

        val prevCompleted = existingTask?.completedStepsJson?.let { decodeList(it) } ?: emptyList()
        val prevRemaining = existingTask?.remainingStepsJson?.let { decodeList(it) } ?: emptyList()

        val newCompleted = (prevCompleted + listOfNotNull(completedStep.takeIf { it.isNotBlank() })).distinct()
        val newRemaining = (prevRemaining.filterNot { it.equals(completedStep, ignoreCase = true) } +
            listOfNotNull(nextStep.takeIf { it.isNotBlank() })).distinct()

        val updated = AiTaskStateEntity(
            id = existingTask?.id ?: 0L,
            sessionId = "unified",
            title = title,
            objective = existingTask?.objective?.ifBlank { userPrompt.take(160) } ?: userPrompt.take(160),
            constraints = existingTask?.constraints.orEmpty(),
            completedStepsJson = json.encodeToString(newCompleted),
            remainingStepsJson = json.encodeToString(newRemaining),
            findingsJson = existingTask?.findingsJson ?: "[]",
            workingNotes = existingTask?.workingNotes.orEmpty(),
            nextAction = nextStep.ifBlank { existingTask?.nextAction.orEmpty() },
            unresolvedQuestionsJson = existingTask?.unresolvedQuestionsJson ?: "[]",
            status = "ACTIVE",
            updatedAt = clock.nowMillis()
        )
        runCatching { memoryStore.saveTask(updated) }
    }

    private fun decodeList(rawJson: String): List<String> =
        runCatching { json.decodeFromString<List<String>>(rawJson) }.getOrDefault(emptyList())

    private data class ContextSnapshot(
        val allHistory: List<AiMessageEntity>,
        val approvedMemories: List<AiMemoryEntity>,
        val activeTask: AiTaskStateEntity?,
        val existingSummary: AiConversationSummaryEntity?
    )

    companion object {
        private const val TAG = "RuhZenaAgentEngine"
        private const val MIN_PARTIAL_FOR_CONTINUATION = 35
        private const val FIRST_TOKEN_STALL_SIMPLE_MS = 5_500L
        private const val FIRST_TOKEN_STALL_STANDARD_MS = 6_000L
        private const val FIRST_TOKEN_STALL_COMPLEX_MS = 7_500L
        private const val INTER_CHUNK_STALL_TIMEOUT_MS = 10_000L
        private const val STREAM_EMIT_COALESCE_MS = 35L
        private val MEMORY_TAG_REGEX = Regex("""\[\[MEMORY_SUGGEST:([A-Za-z_]+)\|([^\]]+)]]""")
        private val TASK_TAG_REGEX = Regex("""\[\[TASK_UPDATE:([^|\]]+)\|([^|\]]*)\|([^\]]*)]]""")
        private val LEADING_SALAM_REGEX = Regex(
            pattern = """^\s*(?:(?:wa\s*)?(?:as-?)?sala[au]?m(?:u|o)?\s*(?:['’`]?alaikum|alaykum)(?:\s+wa\s+rahmatullah(?:i\s+wa\s+barakatuh)?)?|(?:আসসালামু|ওয়া\s+আলাইকুমুস)\s+আলাইকুম(?:\s+ওয়া\s+রাহমাতুল্লাহ)?)(?:\s+(?:brother|sister|ভাই|বোন))?[\s,!.:—–-]*""",
            option = RegexOption.IGNORE_CASE
        )

        fun estimateTokens(text: String): Int = (text.length / 4).coerceAtLeast(1)

        /**
         * Fast-path tag stripping during live streaming: skips regex scanning completely
         * unless the buffer actually contains a `[[` internal tag marker.
         */
        private fun fastStripControlTags(text: String): String =
            if (text.contains("[[")) stripInternalControlTags(text) else text

        fun stripInternalControlTags(text: String): String = text
            .replace(MEMORY_TAG_REGEX, "")
            .replace(TASK_TAG_REGEX, "")
            .trim()

        fun ensureRespectfulSalamIfNeeded(
            text: String,
            userPrompt: String,
            alreadyGreetedInSession: Boolean,
            language: AppLanguage,
            characterGender: String = "",
            isFinal: Boolean = true
        ): String {
            if (text.isBlank()) return text
            val trimmed = text.trimStart()
            val alreadyStartsWithSalam = LEADING_SALAM_REGEX.containsMatchIn(trimmed)
            if (alreadyStartsWithSalam) return text

            val promptLower = userPrompt.lowercase().trim()
            val userSaidSalam = promptLower.contains("salam") ||
                promptLower.contains("salaam") ||
                promptLower.contains("সালাম") ||
                promptLower.contains("السلام")
            val userCasualGreeting = Regex("""^(hi|hello|hey|yo|sup|good morning|good evening|hlo|হাই|হ্যালো)\b""", RegexOption.IGNORE_CASE)
                .containsMatchIn(promptLower)

            val mustHaveSalam = !alreadyGreetedInSession || userSaidSalam || userCasualGreeting
            if (!mustHaveSalam) return text

            // Avoid prepending prematurely on tiny partial fragments during streaming until a few words arrive
            if (!isFinal && trimmed.length < 18) return text

            val isBn = language == AppLanguage.BANGLA
            val honorific = when (characterGender.uppercase()) {
                "MALE" -> if (isBn) " ভাই" else ", brother"
                "FEMALE" -> if (isBn) " বোন" else ", sister"
                else -> ""
            }
            val salamPrefix = when {
                userSaidSalam && isBn -> "ওয়া আলাইকুমুস সালাম ওয়া রাহমাতুল্লাহি ওয়া বারাকাতুহু$honorific।\n\n"
                userSaidSalam -> "Wa Alaikumus Salam wa Rahmatullahi wa Barakatuh$honorific.\n\n"
                isBn -> "আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহি ওয়া বারাকাতুহু$honorific।\n\n"
                else -> "Assalamu Alaikum wa Rahmatullahi wa Barakatuh$honorific.\n\n"
            }
            return salamPrefix + trimmed
        }

        fun stripRepeatedSessionSalamIfNeeded(
            text: String,
            userPrompt: String,
            alreadyGreetedInSession: Boolean
        ): String = text

        fun mergeContinuationWithoutDuplication(existingPartial: String, continuation: String): String {
            if (existingPartial.isBlank()) return continuation
            if (continuation.isBlank()) return existingPartial

            val base = existingPartial
            val next = continuation.trimStart()
            if (next.isEmpty()) return base

            if (next.startsWith(base.trim(), ignoreCase = true)) {
                return next
            }

            val maxOverlap = min(min(base.length, next.length), 160)
            var bestOverlap = 0
            for (len in maxOverlap downTo 8) {
                val suffix = base.substring(base.length - len)
                val prefix = next.substring(0, len)
                if (suffix.equals(prefix, ignoreCase = true)) {
                    bestOverlap = len
                    break
                }
            }

            val nonOverlappingNext = if (bestOverlap > 0) {
                next.substring(bestOverlap)
            } else {
                val lastSentence = base.trimEnd().substringAfterLast('.', "").trim()
                if (lastSentence.length >= 16 && next.startsWith(lastSentence, ignoreCase = true)) {
                    next.substring(lastSentence.length).trimStart('.', ' ')
                } else {
                    next
                }
            }

            if (nonOverlappingNext.isEmpty()) return base

            val needsSpace = !base.last().isWhitespace() &&
                !nonOverlappingNext.first().isWhitespace() &&
                nonOverlappingNext.first() !in setOf('.', ',', '!', '?', ';', ':', ')', ']')
            return if (needsSpace) "$base $nonOverlappingNext" else "$base$nonOverlappingNext"
        }
    }
}
