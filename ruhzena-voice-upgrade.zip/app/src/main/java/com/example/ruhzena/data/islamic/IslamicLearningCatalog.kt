package com.example.ruhzena.data.islamic

data class LearningTopicItem(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val arabicBadge: String,
    val summaryEn: String,
    val summaryBn: String,
    val evidenceRef: String,
    val sourceUrl: String
)

enum class VisualPracticePose {
    WUDU_HANDS_FACE,
    WUDU_ARMS_FEET,
    SALAH_QIYAM,
    SALAH_RUKU,
    SALAH_SUJUD,
    SALAH_JALSA
}

data class VisualPracticeStep(
    val id: String,
    val category: String, // "WUDU", "GHUSL", "SALAH"
    val stepNumber: Int,
    val titleEn: String,
    val titleBn: String,
    val arabicPhrase: String,
    val transliteration: String,
    val detailEn: String,
    val detailBn: String,
    val rulingTag: String, // Fard, Sunnah, Wajib
    val pose: VisualPracticePose,
    val sourceRef: String,
    val sourceUrl: String
)

data class HajjUmrahStep(
    val id: String,
    val kind: String, // "UMRAH", "HAJJ"
    val dayOrPhaseEn: String,
    val dayOrPhaseBn: String,
    val titleEn: String,
    val titleBn: String,
    val arabicDua: String,
    val transliteration: String,
    val detailEn: String,
    val detailBn: String,
    val sourceUrl: String
)

data class HistoryMilestone(
    val id: String,
    val eraEn: String,
    val eraBn: String,
    val yearLabel: String,
    val titleEn: String,
    val titleBn: String,
    val summaryEn: String,
    val summaryBn: String,
    val takeawayEn: String,
    val takeawayBn: String
)

data class ArabicCurriculumLesson(
    val level: Int, // 1..5
    val levelTitleEn: String,
    val levelTitleBn: String,
    val objectiveEn: String,
    val objectiveBn: String,
    val arabicExample: String,
    val transliterationEn: String,
    val transliterationBn: String,
    val practiceDrillEn: String,
    val practiceDrillBn: String
)

data class KidsStoryCard(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val moralEn: String,
    val moralBn: String,
    val storyEn: String,
    val storyBn: String,
    val sourceRef: String
)

object IslamicLearningCatalog {

    val articlesOfFaith: List<LearningTopicItem> = listOf(
        LearningTopicItem(
            id = "iman_allah",
            titleEn = "1. Belief in Allah (Tawhid)",
            titleBn = "১. আল্লাহর প্রতি ঈমান (তাওহীদ)",
            arabicBadge = "لَا إِلَٰهَ إِلَّا اللَّهُ",
            summaryEn = "Affirming Allah's absolute Oneness in Lordship, Worship, and His Beautiful Names & Attributes without partners.",
            summaryBn = "আল্লাহকে একক সৃষ্টিকর্তা, রব এবং একমাত্র ইবাদতের যোগ্য হিসেবে বিশ্বাস করা ও তাঁর সুন্দর নামসমূহে ঈমান আনা।",
            evidenceRef = "Quran 112:1–4 • Muslim 8a",
            sourceUrl = "https://quran.com/112"
        ),
        LearningTopicItem(
            id = "iman_angels",
            titleEn = "2. Belief in the Angels",
            titleBn = "২. ফেরেশতাদের প্রতি ঈমান",
            arabicBadge = "المَلَائِكَة",
            summaryEn = "Honored servants created from light who obey Allah completely—such as Jibril (revelation) and Mikail.",
            summaryBn = "নূরের তৈরি সম্মানিত সৃষ্টি যারা সদা আল্লাহর নির্দেশ পালন করেন—যেমন জিবরাইল (আ.) ও মিকাইল (আ.)।",
            evidenceRef = "Quran 2:285",
            sourceUrl = "https://quran.com/2/285"
        ),
        LearningTopicItem(
            id = "iman_books",
            titleEn = "3. Belief in Revealed Scriptures",
            titleBn = "৩. আসমানী কিতাবসমূহের প্রতি ঈমান",
            arabicBadge = "الكُتُب السَّمَاوِيَّة",
            summaryEn = "Believing in the Tawrah, Zabur, Injil in their original revelations, and the Noble Quran as Allah's preserved final Word.",
            summaryBn = "পূর্ববর্তী আসমানী কিতাবগুলোর মূল অবতরণ এবং সংরক্ষিত চূড়ান্ত কিতাব পবিত্র কুরআনের প্রতি পূর্ণ বিশ্বাস।",
            evidenceRef = "Quran 15:9 • 5:48",
            sourceUrl = "https://quran.com/15/9"
        ),
        LearningTopicItem(
            id = "iman_prophets",
            titleEn = "4. Belief in the Messengers",
            titleBn = "৪. নবী-রাসূলগণের প্রতি ঈমান",
            arabicBadge = "الرُّسُل وَالأَنْبِيَاء",
            summaryEn = "Honoring all Prophets from Adam, Nuh, Ibrahim, Musa, and Isa to the Final Messenger Muhammad (peace be upon them all).",
            summaryBn = "আদম, নূহ, ইব্রাহিম, মূসা ও ঈসা (আ.) থেকে শুরু করে শেষ নবী মুহাম্মদ (সা.) পর্যন্ত সকল নবীর প্রতি শ্রদ্ধা ও বিশ্বাস।",
            evidenceRef = "Quran 2:285 • 33:40",
            sourceUrl = "https://quran.com/33/40"
        ),
        LearningTopicItem(
            id = "iman_last_day",
            titleEn = "5. Belief in the Last Day",
            titleBn = "৫. পরকাল ও শেষ দিবসের প্রতি ঈমান",
            arabicBadge = "اليَوْم الآخِر",
            summaryEn = "Accountability for every deed, divine justice, Paradise (Jannah), and purposeful living with hope and responsibility.",
            summaryBn = "মৃত্যুর পর পুনরুত্থান, প্রতিটি কাজের হিসাব, ন্যায়বিচার ও জান্নাত-জাহান্নামের প্রতি দৃঢ় বিশ্বাস।",
            evidenceRef = "Quran 99:7–8",
            sourceUrl = "https://quran.com/99/7-8"
        ),
        LearningTopicItem(
            id = "iman_qadr",
            titleEn = "6. Belief in Divine Decree (Al-Qadr)",
            titleBn = "৬. তাকদীর বা ভাগ্যের ভালো-মন্দের প্রতি ঈমান",
            arabicBadge = "القَضَاء وَالقَدَر",
            summaryEn = "Allah's complete knowledge and wisdom encompass all things—combining human effort and responsibility with inner peace and reliance (Tawakkul).",
            summaryBn = "আল্লাহর সর্বব্যাপী জ্ঞান ও প্রজ্ঞায় বিশ্বাস—চেষ্টা ও দায়িত্বশীলতার সাথে আল্লাহর ওপর ভরসা (তাওয়াক্কুল) রাখা।",
            evidenceRef = "Muslim 8a • Quran 54:49",
            sourceUrl = "https://sunnah.com/muslim:8a"
        )
    )

    val fivePillars: List<LearningTopicItem> = listOf(
        LearningTopicItem(
            id = "pillar_shahadah",
            titleEn = "1. Shahadah (Testimony of Faith)",
            titleBn = "১. শাহাদাহ (ঈমানের সাক্ষ্য)",
            arabicBadge = "الشَّهَادَة",
            summaryEn = "Ashhadu an la ilaha illallah, wa ashhadu anna Muhammadan rasulullah — entering life with sincere devotion and following the Prophetic example.",
            summaryBn = "আল্লাহর একত্ববাদ ও মুহাম্মদ (সা.)-এর রিসালাতের আন্তরিক সাক্ষ্য ও জীবনজুড়ে তা অনুসরণ।",
            evidenceRef = "Bukhari 8 • Muslim 16",
            sourceUrl = "https://sunnah.com/bukhari:8"
        ),
        LearningTopicItem(
            id = "pillar_salah",
            titleEn = "2. Salah (Five Daily Prayers)",
            titleBn = "২. সালাত (পাঁচ ওয়াক্ত নামাজ)",
            arabicBadge = "الصَّلَاة",
            summaryEn = "Fajr, Dhuhr, Asr, Maghrib, and Isha — five daily anchors of mindfulness, gratitude, and direct connection with Allah.",
            summaryBn = "ফজর, যোহর, আসর, মাগরিব ও এশা—প্রতিদিন পাঁচবার আল্লাহর সাথে সরাসরি সংযোগ ও আত্মশুদ্ধির স্তম্ভ।",
            evidenceRef = "Quran 2:43 • Bukhari 528",
            sourceUrl = "https://sunnah.com/bukhari:528"
        ),
        LearningTopicItem(
            id = "pillar_zakah",
            titleEn = "3. Zakah (Purifying Charity)",
            titleBn = "৩. যাকাত (বাধ্যতামূলক দান)",
            arabicBadge = "الزَّكَاة",
            summaryEn = "Giving 2.5% of qualifying annual savings above Nisab to uplift those in need and purify wealth and character.",
            summaryBn = "নিসাব পরিমাণ সম্পদ এক বছর পূর্ণ হলে ২.৫% দরিদ্র ও হকদারদের মাঝে বণ্টন করে সম্পদ পবিত্র করা।",
            evidenceRef = "Quran 9:60 • 9:103",
            sourceUrl = "https://quran.com/9/103"
        ),
        LearningTopicItem(
            id = "pillar_sawm",
            titleEn = "4. Sawm (Fasting in Ramadan)",
            titleBn = "৪. সিয়াম (রমজানের রোজা)",
            arabicBadge = "الصَّوْم",
            summaryEn = "Abstaining from food, drink, and ill speech from Fajr to Maghrib to cultivate Taqwa (God-consciousness) and empathy.",
            summaryBn = "সুবহে সাদিক থেকে সূর্যাস্ত পর্যন্ত পানাহার ও মন্দ কাজ থেকে বিরত থেকে তাকওয়া ও আত্মনিয়ন্ত্রণ অর্জন।",
            evidenceRef = "Quran 2:183",
            sourceUrl = "https://quran.com/2/183"
        ),
        LearningTopicItem(
            id = "pillar_hajj",
            titleEn = "5. Hajj (Pilgrimage to Makkah)",
            titleBn = "৫. হজ (বাইতুল্লাহ শরীফ যিয়ারত)",
            arabicBadge = "الحَجّ",
            summaryEn = "Once in a lifetime for those physically and financially able — uniting humanity in humility before Allah.",
            summaryBn = "শারীরিক ও আর্থিকভাবে সামর্থ্যবানদের জন্য জীবনে একবার মক্কায় পবিত্র হজ আদায় করা।",
            evidenceRef = "Quran 3:97",
            sourceUrl = "https://quran.com/3/97"
        )
    )

    val visualPracticeSteps: List<VisualPracticeStep> = listOf(
        VisualPracticeStep(
            id = "wudu_1",
            category = "WUDU",
            stepNumber = 1,
            titleEn = "Intention, Bismillah & Wash Hands",
            titleBn = "নিয়ত, বিসমিল্লাহ ও হাত ধোয়া",
            arabicPhrase = "بِسْمِ اللَّهِ",
            transliteration = "Bismillah (In the name of Allah)",
            detailEn = "Form sincere intention (Niyyah) in the heart, say Bismillah, and wash both hands up to the wrists 3 times, cleaning between fingers.",
            detailBn = "মনে মনে অজুর নিয়ত করে 'বিসমিল্লাহ' বলুন এবং উভয় হাত কবজি পর্যন্ত আঙুলের ফাঁকসহ ৩ বার ধৌত করুন।",
            rulingTag = "Sunnah Start",
            pose = VisualPracticePose.WUDU_HANDS_FACE,
            sourceRef = "Bukhari 159",
            sourceUrl = "https://sunnah.com/bukhari:159"
        ),
        VisualPracticeStep(
            id = "wudu_2",
            category = "WUDU",
            stepNumber = 2,
            titleEn = "Mouth, Nose & Wash Entire Face",
            titleBn = "কুলি করা, নাক পরিষ্কার ও মুখমণ্ডল ধোয়া",
            arabicPhrase = "",
            transliteration = "",
            detailEn = "Perform silently (no specific spoken Dua is prescribed). Rinse mouth (3×) and inhale gently into nostrils and blow out (3×). Then wash the whole face (forehead hairline to chin, ear to ear) 3 times (Fard).",
            detailBn = "নীরবে সম্পন্ন করুন (নির্দিষ্ট কোনো দুআ নেই)। ৩ বার কুলি করুন ও ৩ বার নাকে পানি দিয়ে পরিষ্কার করুন। এরপর কপালের চুলের গোড়া থেকে থুতনির নিচ ও এক কান থেকে অন্য কান পর্যন্ত সম্পূর্ণ মুখমণ্ডল ৩ বার ধৌত করুন (ফরজ)।",
            rulingTag = "Fard (Face)",
            pose = VisualPracticePose.WUDU_HANDS_FACE,
            sourceRef = "Quran 5:6",
            sourceUrl = "https://quran.com/5/6"
        ),
        VisualPracticeStep(
            id = "wudu_3",
            category = "WUDU",
            stepNumber = 3,
            titleEn = "Forearms, Head Wipe & Feet",
            titleBn = "কনুইসহ হাত ধোয়া, মাথা মাসাহ ও পা ধোয়া",
            arabicPhrase = "",
            transliteration = "",
            detailEn = "Perform silently (no specific spoken Dua during washing). Wash right then left arm thoroughly past the elbows (3×, Fard). Wipe wet hands over the head and ears once (Masah, Fard). Wash both feet including ankles (3×, Fard), then recite the post-Wudu Shahadah Dua.",
            detailBn = "ধোয়ার সময় নীরবে সম্পন্ন করুন (নির্দিষ্ট কোনো দুআ নেই)। ডান ও বাম হাত কনুইসহ ৩ বার ধুয়ে নিন (ফরজ)। ভেজা হাতে একবার মাথা ও কান মাসাহ করুন (ফরজ)। উভয় পা টাখনুসহ ৩ বার ধুয়ে অজু শেষে কালিমা শাহাদাত দুআ পাঠ করুন।",
            rulingTag = "Fard Steps",
            pose = VisualPracticePose.WUDU_ARMS_FEET,
            sourceRef = "Muslim 234 • Quran 5:6",
            sourceUrl = "https://sunnah.com/muslim:234"
        ),
        VisualPracticeStep(
            id = "ghusl_1",
            category = "GHUSL",
            stepNumber = 1,
            titleEn = "Ghusl (Full Ritual Purification)",
            titleBn = "ফরজ গোসলের নিয়ম (তাহারাত)",
            arabicPhrase = "بِسْمِ اللَّهِ",
            transliteration = "Niyyah in heart • Bismillah",
            detailEn = "1) Intention & wash hands/private parts cleanly. 2) Perform complete Wudu. 3) Pour water over head 3× reaching hair roots, then pour water over right side then left side ensuring water reaches every part of the body (Quran 5:6; Bukhari 248).",
            detailBn = "১) নিয়ত ও পবিত্রতা অর্জন, ২) পূর্ণ অজু করা, ৩) মাথায় ৩ বার পানি ঢেলে চুলের গোড়া ভিজানো এবং ডান দিক ও বাম দিকসহ পুরো শরীর এমনভাবে ধোয়া যেন কোনো অংশ শুকনো না থাকে (বুখারী ২৪৮)।",
            rulingTag = "Fard (3 Essentials)",
            pose = VisualPracticePose.WUDU_ARMS_FEET,
            sourceRef = "Bukhari 248",
            sourceUrl = "https://sunnah.com/bukhari:248"
        ),
        VisualPracticeStep(
            id = "salah_1",
            category = "SALAH",
            stepNumber = 1,
            titleEn = "Standing (Qiyam), Takbir & Al-Fatihah",
            titleBn = "কিয়াম (দাঁড়ানো), তাকবীরে তাহরীমা ও সূরা ফাতিহা",
            arabicPhrase = "اللَّهُ أَكْبَرُ",
            transliteration = "Allahu Akbar • Al-Fatihah + Surah",
            detailEn = "Face Qibla calmly. Raise hands for Takbiratul Ihram ('Allahu Akbar'), fold hands naturally, recite opening Sana/Ta'awwudh, Surah Al-Fatihah, and a short Surah with stillness.",
            detailBn = "কিবলামুখী হয়ে শান্তভাবে দাঁড়ান। 'আল্লাহু আকবার' বলে হাত বেঁধে ছানা, সূরা ফাতিহা ও অন্য একটি সূরা বা কয়েকটি আয়াত তিলাওয়াত করুন।",
            rulingTag = "Fard Pillar",
            pose = VisualPracticePose.SALAH_QIYAM,
            sourceRef = "Bukhari 757",
            sourceUrl = "https://sunnah.com/bukhari:757"
        ),
        VisualPracticeStep(
            id = "salah_2",
            category = "SALAH",
            stepNumber = 2,
            titleEn = "Bowing (Ruku) & Rising Calmly",
            titleBn = "রুকু ও সোজা হয়ে দাঁড়ানো (কাওমা)",
            arabicPhrase = "سُبْحَانَ رَبِّيَ الْعَظِيمِ",
            transliteration = "Subhana Rabbiyal-Azim (3×)",
            detailEn = "Say 'Allahu Akbar' and bow with a flat back and hands resting comfortably on knees. Pause calmly saying 'Subhana Rabbiyal-Azim' 3×. Rise upright saying 'Sami'Allahu liman hamidah, Rabbana wa lakal-hamd'.",
            detailBn = "'আল্লাহু আকবার' বলে পিঠ সোজা রেখে রুকুতে যান এবং ৩ বার 'সুবহানা রাব্বিয়াল আজীম' পড়ুন। এরপর 'সামিআল্লাহু লিমান হামিদাহ—রাব্বানা ওয়া লাকাল হামদ' বলে সোজা দাঁড়ান।",
            rulingTag = "Fard Pillar",
            pose = VisualPracticePose.SALAH_RUKU,
            sourceRef = "Bukhari 757 • Muslim 772",
            sourceUrl = "https://sunnah.com/bukhari:757"
        ),
        VisualPracticeStep(
            id = "salah_3",
            category = "SALAH",
            stepNumber = 3,
            titleEn = "Two Prostrations (Sujud)",
            titleBn = "দুই সিজদা (সিজদায় প্রশান্তি)",
            arabicPhrase = "سُبْحَانَ رَبِّيَ الْأَعْلَى",
            transliteration = "Subhana Rabbiyal-A'la (3×)",
            detailEn = "Prostrate with 7 points touching: forehead+nose, both palms, both knees, and toes. Say 'Subhana Rabbiyal-A'la' 3× and make heartfelt Dua. Sit briefly between the two sujud ('Rabbighfir li'), then repeat second Sujud.",
            detailBn = "কপাল-নাক, দুই হাত, দুই হাঁটু ও পায়ের আঙুল জমিনে রেখে সিজদা করুন ও ৩ বার 'সুবহানা রাব্বিয়াল আ'লা' পড়ুন। মাঝে একটু সোজা বসে 'রাব্বিগফির লী' পড়ে দ্বিতীয় সিজদা করুন।",
            rulingTag = "Fard Pillar",
            pose = VisualPracticePose.SALAH_SUJUD,
            sourceRef = "Bukhari 812",
            sourceUrl = "https://sunnah.com/bukhari:812"
        ),
        VisualPracticeStep(
            id = "salah_4",
            category = "SALAH",
            stepNumber = 4,
            titleEn = "Tashahhud Sitting (Jalsa) & Taslim",
            titleBn = "বৈঠক (তাশাহহুদ, দরুদ ও সালাম)",
            arabicPhrase = "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ",
            transliteration = "At-Tahiyyat + Durood Ibrahim + Taslim",
            detailEn = "In the final sitting, recite Tashahhud (At-Tahiyyat), Salawat upon the Prophet (Durood Ibrahim), and final Dua, then conclude by turning right then left saying 'Assalamu Alaikum wa Rahmatullah'.",
            detailBn = "শেষ বৈঠকে তাশাহহুদ, দরুদে ইব্রাহিম ও দুআ মাসূরা পাঠ করে ডান ও বাম কাঁধে 'আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহ' বলে নামাজ সম্পন্ন করুন।",
            rulingTag = "Fard Ending",
            pose = VisualPracticePose.SALAH_JALSA,
            sourceRef = "Bukhari 831",
            sourceUrl = "https://sunnah.com/bukhari:831"
        )
    )

    val hajjUmrahSteps: List<HajjUmrahStep> = listOf(
        HajjUmrahStep(
            id = "umrah_1",
            kind = "UMRAH",
            dayOrPhaseEn = "Step 1 • Miqat",
            dayOrPhaseBn = "ধাপ ১ • মীকাত",
            titleEn = "Enter Ihram & Talbiyah",
            titleBn = "ইহরাম ও তালবিয়াহ পাঠ",
            arabicDua = "لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لَا شَرِيكَ لَكَ لَبَّيْكَ",
            transliteration = "Labbayk Allahumma Umrah / Labbayk Allahumma Labbayk",
            detailEn = "Purify, wear Ihram garments before crossing Miqat, make intention for Umrah, and recite Talbiyah gently.",
            detailBn = "মীকাত অতিক্রমের আগে পবিত্র হয়ে ইহরাম পরিধান, উমরাহর নিয়ত এবং তালবিয়াহ পাঠ করুন।",
            sourceUrl = "https://sunnah.com/bukhari:1549"
        ),
        HajjUmrahStep(
            id = "umrah_2",
            kind = "UMRAH",
            dayOrPhaseEn = "Step 2 • Kaaba",
            dayOrPhaseBn = "ধাপ ২ • কাবা শরীফ",
            titleEn = "Tawaf (7 Circuits) & Maqam Ibrahim",
            titleBn = "৭ চক্কর তাওয়াফ ও মাকামে ইব্রাহিমে নামাজ",
            arabicDua = "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً",
            transliteration = "Rabbana atina fid-dunya hasanatan...",
            detailEn = "Perform 7 counter-clockwise circuits around the Kaaba starting/ending at Hajar al-Aswad, then pray 2 rak'ahs behind Maqam Ibrahim if able.",
            detailBn = "হাজরে আসওয়াদ থেকে শুরু করে কাবা শরীফের চারপাশে ৭ চক্কর তাওয়াফ ও ২ রাকাত নামাজ আদায় করুন।",
            sourceUrl = "https://sunnah.com/muslim:1218a"
        ),
        HajjUmrahStep(
            id = "umrah_3",
            kind = "UMRAH",
            dayOrPhaseEn = "Step 3 • Safa & Marwa",
            dayOrPhaseBn = "ধাপ ৩ • সাফা-মারওয়া",
            titleEn = "Sa'i (7 Laps) & Halq / Taqsir",
            titleBn = "সাঈ (৭ বার) ও মাথার চুল মুণ্ডন/ছোট করা",
            arabicDua = "إِنَّ الصَّفَا وَالْمَرْوَةَ مِن شَعَائِرِ اللَّهِ",
            transliteration = "Innas-Safa wal-Marwata min sha'a'irillah",
            detailEn = "Walk 7 laps from Safa to Marwa praising Allah, then shave or trim hair (men) / trim fingertip-length (women) to complete Umrah.",
            detailBn = "সাফা থেকে মারওয়া পর্যন্ত ৭ বার সাঈ সম্পন্ন করে চুল ছোট বা মুণ্ডন করে ইহরাম খুলুন।",
            sourceUrl = "https://quran.com/2/158"
        ),
        HajjUmrahStep(
            id = "hajj_1",
            kind = "HAJJ",
            dayOrPhaseEn = "8–9 Dhul-Hijjah",
            dayOrPhaseBn = "৮–৯ জিলহজ",
            titleEn = "Mina, Wuquf at Arafah & Muzdalifah",
            titleBn = "মিনা, আরাফাতে অবস্থান ও মুযদালিফায় রাত যাপন",
            arabicDua = "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
            transliteration = "The best Dua is the Dua of Day of Arafah",
            detailEn = "Camp at Mina on 8th Dhul-Hijjah; stand in sincere Dua at Arafah on 9th Dhul-Hijjah ('Hajj is Arafah' — Tirmidhi 889); then spend night at Muzdalifah after Maghrib.",
            detailBn = "৮ জিলহজ মিনায় অবস্থান, ৯ জিলহজ আরাফাতের ময়দানে দুআ-রোনাজারি এবং রাতে মুযদালিফায় অবস্থান।",
            sourceUrl = "https://sunnah.com/tirmidhi:889"
        ),
        HajjUmrahStep(
            id = "hajj_2",
            kind = "HAJJ",
            dayOrPhaseEn = "10–13 Dhul-Hijjah",
            dayOrPhaseBn = "১০–১৩ জিলহজ",
            titleEn = "Rami Jamarat, Qurbani, Halq & Tawaf al-Ifadah",
            titleBn = "কঙ্কর নিক্ষেপ, কুরবানি, চুল কাটা ও তাওয়াফে যিয়ারাহ",
            arabicDua = "اللَّهُ أَكْبَرُ",
            transliteration = "Allahu Akbar at each pebble at Jamarat",
            detailEn = "Throw 7 pebbles at Jamrat al-Aqabah, offer Udhiyah/Qurbani, shave/trim hair, perform Tawaf al-Ifadah & Sa'i, and complete Days of Tashriq at Mina.",
            detailBn = "বড় জামরায় কঙ্কর নিক্ষেপ, কুরবানি, চুল মুণ্ডন/ছোট করা, তাওয়াফে ইফাদা এবং মিনায় আইয়ামে তাশরীক সম্পন্ন।",
            sourceUrl = "https://sunnah.com/muslim:1218a"
        )
    )

    val sunnahVsBidahGuides: List<LearningTopicItem> = listOf(
        LearningTopicItem(
            id = "principle_source",
            titleEn = "Foundational Criterion of Worship",
            titleBn = "ইবাদতের মৌলিক মানদণ্ড (দলিল ও সুন্নাহ)",
            arabicBadge = "مَنْ أَحْدَثَ فِي أَمْرِنَا هَٰذَا",
            summaryEn = "In acts of worship (Ibadah), we follow what Allah and His Messenger prescribed rather than inventing new religious rituals.",
            summaryBn = "ইবাদতের ক্ষেত্রে কুরআন ও সহীহ সুন্নাহ দ্বারা প্রমাণিত পদ্ধতি অনুসরণ করাই আসল পথ; মনগড়া নতুন ইবাদত উদ্ভাবন করা উচিত নয়।",
            evidenceRef = "Bukhari 2697 • Muslim 1718",
            sourceUrl = "https://sunnah.com/bukhari:2697"
        ),
        LearningTopicItem(
            id = "recognized_ikhtilaf",
            titleEn = "Distinguishing Bid'ah from Valid Ikhtilaf",
            titleBn = "স্বীকৃত ফিকহী মতভেদ (ইখতিলাফ) বনাম বিদআত",
            arabicBadge = "أَدَبُ الخِلَاف",
            summaryEn = "Not every disagreement is Bid'ah. Recognized juristic differences among classical Imams (e.g., where to place hands in Salah, raising hands in Raf' al-Yadayn, or Qunut in Fajr/Witr) have scholarly evidence on multiple sides and deserve mutual respect.",
            summaryBn = "সব মতপার্থক্য বিদআত নয়। নামাজে হাত বাঁধার স্থান, রফউল ইয়াদাইন বা ফজর/বিতরে কুনূতের মতো স্বীকৃত মাযহাবী মতভেদগুলো কুরআন-হাদিসের ব্যাখ্যাভিত্তিক—তাই পারস্পরিক শ্রদ্ধা ও প্রজ্ঞা বজায় রাখা জরুরি।",
            evidenceRef = "Quran 16:125 • Classical Usool",
            sourceUrl = "https://quran.com/16/125"
        )
    )

    val historyTimeline: List<HistoryMilestone> = listOf(
        HistoryMilestone(
            id = "hist_1",
            eraEn = "Prophetic Era (Makkah)",
            eraBn = "নবুয়ত ও মক্কী যুগ",
            yearLabel = "610–622 CE",
            titleEn = "First Revelation in Cave Hira & Steadfastness",
            titleBn = "হেরা গুহায় প্রথম ওহী (ইকরা) ও ধৈর্যের যুগ",
            summaryEn = "Angel Jibril brought Surah Al-Alaq (96:1–5) emphasizing reading, knowledge, and Tawhid amid thirteen years of patient resilience.",
            summaryBn = "জিবরাইল (আ.) 'ইকরা' (পড়ো) বাণী নিয়ে আসেন। দীর্ঘ ১৩ বছর মক্কায় ধৈর্য ও উত্তম চরিত্রের মাধ্যমে তাওহীদের দাওয়াত দেওয়া হয়।",
            takeawayEn = "Sacred journey always begins with sincere knowledge and patience.",
            takeawayBn = "যেকোনো কল্যাণকর পরিবর্তন শুরু হয় সঠিক জ্ঞান ও ধৈর্যের মাধ্যমে।"
        ),
        HistoryMilestone(
            id = "hist_2",
            eraEn = "Madinah Community",
            eraBn = "মাদানী রাষ্ট্র ও ভ্রাতৃত্ব",
            yearLabel = "622–632 CE",
            titleEn = "Hijrah, Charter of Madinah & Brotherhood",
            titleBn = "হিজরত, মদিনা সনদ ও আনসার-মুহাজির ভ্রাতৃত্ব",
            summaryEn = "Prophet Muhammad (pbuh) established Masjid an-Nabawi, civic justice through the Charter of Madinah, social care, and mercy.",
            summaryBn = "মসজিদে নববী নির্মাণ, আনসার-মুহাজিরদের মাঝে ভ্রাতৃত্ব এবং ন্যায়ভিত্তিক মদিনা সনদ প্রতিষ্ঠিত হয়।",
            takeawayEn = "Faith blossoms into justice, brotherhood, and community care.",
            takeawayBn = "ঈমান সমাজে ন্যায়বিচার, ভ্রাতৃত্ব ও পারস্পরিক সহযোগিতা গড়ে তোলে।"
        ),
        HistoryMilestone(
            id = "hist_3",
            eraEn = "Rashidun Caliphate",
            eraBn = "খুলাফায়ে রাশেদীন",
            yearLabel = "632–661 CE",
            titleEn = "Abu Bakr, Umar, Uthman & Ali (RA)",
            titleBn = "আবু বকর, উমর, উসমান ও আলী (রা.)",
            summaryEn = "Compilation of the single written Mushaf under Abu Bakr & Uthman (ra), public welfare institutions under Umar (ra), and judicial wisdom of Ali (ra).",
            summaryBn = "কুরআন সংকলন, রাষ্ট্রীয় জনকল্যাণ ব্যবস্থা, ন্যায়বিচার ও ইসলামী জ্ঞানের প্রসার ঘটে।",
            takeawayEn = "Leadership is an Amanah anchored in consultation (Shura) and humility.",
            takeawayBn = "নেতৃত্ব হলো আমানত—যা পরামর্শ ও বিনয়ের ওপর প্রতিষ্ঠিত।"
        ),
        HistoryMilestone(
            id = "hist_4",
            eraEn = "Islamic Golden Age",
            eraBn = "মুসলিম জ্ঞান-বিজ্ঞানের স্বর্ণযুগ",
            yearLabel = "8th–13th Century",
            titleEn = "House of Wisdom, Medicine, Algebra & Optics",
            titleBn = "বাইতুল হিকমাহ, চিকিৎসা, বীজগণিত ও অপটিক্স",
            summaryEn = "Fatima al-Fihri founded Al-Qarawiyyin University (859 CE); Al-Khwarizmi pioneered Algebra; Ibn al-Haytham pioneered the scientific method; Ibn Sina advanced clinical medicine.",
            summaryBn = "ফাতিমা আল-ফিহরি বিশ্বের প্রাচীনতম বিশ্ববিদ্যালয় আল-কারাউইয়্যিন প্রতিষ্ঠা করেন; আল-খাওয়ারিজমি বীজগণিত, ইবনুল হাইসাম পরীক্ষামূলক বিজ্ঞান ও ইবনে সিনা চিকিৎসাশাস্ত্রে অবদান রাখেন।",
            takeawayEn = "Seeking beneficial knowledge in spirit and science honors Islam's heritage.",
            takeawayBn = "দ্বীন ও দুনিয়ার উপকারী জ্ঞান অন্বেষণ মুসলিম ঐতিহ্যেরই অংশ।"
        )
    )

    val arabicAlphabetSample: List<Pair<String, String>> = listOf(
        "ا" to "Alif", "ب" to "Ba", "ت" to "Ta", "ث" to "Tha",
        "ج" to "Jim", "ح" to "Ha", "خ" to "Kha", "د" to "Dal",
        "ذ" to "Dhal", "ر" to "Ra", "ز" to "Zay", "س" to "Sin",
        "ش" to "Shin", "ص" to "Sad", "ض" to "Dad", "ط" to "Ta'",
        "ظ" to "Za'", "ع" to "Ayn", "غ" to "Ghayn", "ف" to "Fa",
        "ق" to "Qaf", "ك" to "Kaf", "ل" to "Lam", "م" to "Mim",
        "ن" to "Nun", "هـ" to "Ha'", "و" to "Waw", "ي" to "Ya"
    )

    val arabicCurriculum: List<ArabicCurriculumLesson> = listOf(
        ArabicCurriculumLesson(
            level = 1,
            levelTitleEn = "Level 1: The 28 Arabic Letters",
            levelTitleBn = "স্তর ১: আরবি ২৮টি মূল হরফ",
            objectiveEn = "Recognize letter shapes & throat/tongue articulation points (Makharij) without relying on guesswork.",
            objectiveBn = "প্রতিটি আরবি হরফের সঠিক আকৃতি ও উচ্চারণের স্থান (মাখরাজ) চিনে নেওয়া।",
            arabicExample = "أ ب ت ث ج ح خ",
            transliterationEn = "Alif • Ba • Ta • Tha • Jim • Ha (deep chest/throat) • Kha",
            transliterationBn = "আলিফ • বা • তা • ছা • জীম • হা (গলার মাঝখান থেকে) • খা",
            practiceDrillEn = "Tap letters below and distinguish soft ت (Ta) from heavy ط (Ta').",
            practiceDrillBn = "নিচের হরফগুলো চর্চা করুন এবং পাতলা ت ও মোটা ط-এর পার্থক্য বুঝুন।"
        ),
        ArabicCurriculumLesson(
            level = 2,
            levelTitleEn = "Level 2: Short Vowels (Harakat)",
            levelTitleBn = "স্তর ২: হরকত (যবর, যের, পেশ)",
            objectiveEn = "Master Fatha (a), Kasra (i), Damma (u), and Sukun (resting consonant).",
            objectiveBn = "যবর (আ-কার), যের (ই-কার), পেশ (উ-কার) ও সুকূনের উচ্চারণ আয়ত্ত করা।",
            arabicExample = "بَ بِ بُ • كَتَبَ",
            transliterationEn = "Ba (a) • Bi (i) • Bu (u)  |  Ka-ta-ba ('he wrote')",
            transliterationBn = "বা • বি • বু  |  কা-তা-বা (এক হরফের সাথে অন্য হরফের স্বর)",
            practiceDrillEn = "Keep every Harakat short and crisp—exactly 1 count (no accidental stretching).",
            practiceDrillBn = "প্রতিটি হরকত টান ছাড়া স্পষ্ট ও সংক্ষিপ্ত ১ মাত্রায় উচ্চারণ করুন।"
        ),
        ArabicCurriculumLesson(
            level = 3,
            levelTitleEn = "Level 3: Joining Letters in Words",
            levelTitleBn = "স্তর ৩: যুক্তবর্ণ (শুরু, মাঝ ও শেষ রূপ)",
            objectiveEn = "Read connected Arabic script fluently by spotting letter dots and hooks.",
            objectiveBn = "শব্দের শুরু, মাঝ ও শেষে হরফ কীভাবে যুক্ত হয় তা নুকতা দেখে চেনা।",
            arabicExample = "حَمْد • رَبِّ • مَلِكِ",
            transliterationEn = "Ham-d (Ha-Mim-Dal) • Rab-bi • Ma-li-ki",
            transliterationBn = "হামদ (ح + م + د) • রাব্বি (ر + ب) • মালিকি (م + ل + ك)",
            practiceDrillEn = "Non-connectors (ا د ذ ر ز و) break on the left, while Ba/Sin/Mim/Kaf flow smoothly.",
            practiceDrillBn = "আলিফ, দাল, যাল, রা, যা, ওয়াও বাম দিকের হরফের সাথে যুক্ত হয় না।"
        ),
        ArabicCurriculumLesson(
            level = 4,
            levelTitleEn = "Level 4: Tanween, Shaddah & Madd",
            levelTitleBn = "স্তর ৪: তানভীন, তাশদীদ ও মাদ্দ (টান)",
            objectiveEn = "Learn double vowels (-an/-in/-un), doubled consonants (Shaddah), and 2-count long vowels (ا و ي).",
            objectiveBn = "দুই যবর-যের-পেশ (তানভীন), দ্বিগুণ উচ্চারণ (তাশদীদ) ও টেনে পড়া (মাদ্দ) শেখা।",
            arabicExample = "رَحِيمٌ • إِيَّاكَ • قُلْ هُوَ",
            transliterationEn = "Ra-hee-mun (2-count ee + un) • Iy-yaa-ka (stressed Y + 2-count aa)",
            transliterationBn = "রাহীমুন • ইয়্যাকা (তাশদীদ ও ২ আলিফ টান) • কুল হুয়া",
            practiceDrillEn = "Notice how 'أَيَّ' doubles the consonant while 'قَالَ' stretches Alif smoothly.",
            practiceDrillBn = "তাশদীদযুক্ত হরফে একটু চাপ দিন এবং আলিফ-ওয়াও-ইয়ার মাদ্দে ২ মাত্রা টানুন।"
        ),
        ArabicCurriculumLesson(
            level = 5,
            levelTitleEn = "Level 5: Short Quranic Reading",
            levelTitleBn = "স্তর ৫: ছোট সূরা সরাসরি তিলাওয়াত চর্চা",
            objectiveEn = "Combine all rules to read Surah Al-Ikhlas & Al-Fatihah cleanly while listening to a human reciter.",
            objectiveBn = "শেখা নিয়মগুলো মিলিয়ে সূরা ইখলাস ও সূরা ফাতিহা ক্বারীর তিলাওয়াতের সাথে পড়া।",
            arabicExample = "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ",
            transliterationEn = "Qul Huwallahu Ahad • Allahus-Samad",
            transliterationBn = "কুল হুওয়াল্লাহু আহাদ • আল্লাহুস সামাদ",
            practiceDrillEn = "Open Surah 112 in Quran Reader and follow word-by-word with human audio.",
            practiceDrillBn = "কুরআন বিভাগে সূরা ১১২ (আল-ইখলাস) খুলে মানব কণ্ঠের সাথে মিলিয়ে পড়ুন।"
        )
    )

    val kidsStories: List<KidsStoryCard> = listOf(
        KidsStoryCard(
            id = "kids_honesty",
            titleEn = "As-Sadiq Al-Amin (The Trustworthy)",
            titleBn = "আস-সাদিক আল-আমীন (সত্যবাদী ও বিশ্বস্ত)",
            moralEn = "Always tell the truth and keep promises—Allah loves honesty!",
            moralBn = "সর্বদা সত্য কথা বলো ও আমানত রক্ষা করো—আল্লাহ সত্যবাদীদের ভালোবাসেন।",
            storyEn = "Even before Prophethood, everyone in Makkah trusted Muhammad (pbuh) with their valuables because he never broke a promise and always spoke the truth with kindness.",
            storyBn = "নবুয়তের আগে থেকেই মক্কার সবাই মুহাম্মদ (সা.)-কে 'আল-আমীন' (বিশ্বস্ত) ডাকত, কারণ তিনি কখনো মিথ্যা বলতেন না এবং সবার আমানত যত্নে ফিরিয়ে দিতেন।",
            sourceRef = "Bukhari 2684 (Sirah)"
        ),
        KidsStoryCard(
            id = "kids_kindness_animals",
            titleEn = "Mercy to Every Living Creature",
            titleBn = "পশুপাখি ও সব সৃষ্টির প্রতি দয়া",
            moralEn = "Giving water or kindness to any animal brings reward from Allah.",
            moralBn = "পশুপাখিকে পানি পান করানো বা দয়া দেখানোও একটি বড় নেক কাজ।",
            storyEn = "The Prophet (pbuh) taught that a thirsty traveler was forgiven because he climbed down a well to give water to a panting dog! Every small act of care counts.",
            storyBn = "নবীজি (সা.) বলেছেন, এক তৃষ্ণার্ত মানুষ পিপাসার্ত কুকুরকে কূপ থেকে পানি তুলে খাইয়েছিল বলে আল্লাহ তাকে মাফ করে দিয়েছিলেন।",
            sourceRef = "Bukhari 2466"
        ),
        KidsStoryCard(
            id = "kids_bismillah",
            titleEn = "The Superpower of 'Bismillah'",
            titleBn = "'বিসমিল্লাহ' বলার সুন্দর অভ্যাস",
            moralEn = "Start eating, drinking, studying, and stepping outside with Bismillah.",
            moralBn = "খাওয়া, পান করা, পড়াশোনা ও ঘর থেকে বের হওয়ার আগে 'বিসমিল্লাহ' বললে কাজে বরকত হয়।",
            storyEn = "The Prophet (pbuh) gently taught young Umar ibn Abi Salamah: 'Say Bismillah, eat with your right hand, and eat from what is closest to you!'",
            storyBn = "নবীজি (সা.) ছোট্ট উমর ইবনে আবী সালামাকে আদর করে শিখিয়েছিলেন: 'খাবারের আগে বিসমিল্লাহ বলো, ডান হাতে খাও এবং নিজের সামনের দিক থেকে খাও!'",
            sourceRef = "Bukhari 5376"
        )
    )
}
