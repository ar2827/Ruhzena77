package com.example.ruhzena.data.islamic

data class ArabicLetterStudioItem(
    val key: String,
    val nameEn: String,
    val nameBn: String,
    val isolated: String,
    val initial: String,
    val medial: String,
    val finalForm: String,
    val transliteration: String,
    val makhrajEn: String,
    val makhrajBn: String,
    val strokeHintEn: String,
    val strokeHintBn: String
)

data class EncyclopediaEntry(
    val id: String,
    val categoryId: String,
    val titleEn: String,
    val titleBn: String,
    val arabicTerm: String,
    val summaryEn: String,
    val summaryBn: String,
    val evidenceRef: String,
    val sourceUrl: String
)

data class BeginnerRoadmapStep(
    val id: String,
    val stepNumber: Int,
    val titleEn: String,
    val titleBn: String,
    val subtitleEn: String,
    val subtitleBn: String,
    val targetTabName: String
)

object IslamicAcademyCatalog {

    val beginnerRoadmap: List<BeginnerRoadmapStep> = listOf(
        BeginnerRoadmapStep(
            id = "beg_1",
            stepNumber = 1,
            titleEn = "Know Allah & The 6 Articles of Faith",
            titleBn = "আল্লাহর পরিচয় ও ঈমানের ৬টি রুকন",
            subtitleEn = "Calm, step-by-step introduction to Tawhid, Prophets, and Akhirah.",
            subtitleBn = "তাওহীদ, নবী-রাসূল ও আখিরাতের সহজ পরিচিতি।",
            targetTabName = "ESSENTIALS"
        ),
        BeginnerRoadmapStep(
            id = "beg_2",
            stepNumber = 2,
            titleEn = "Learn Wudu & Daily Salah Visually",
            titleBn = "অজু ও ৫ ওয়াক্ত নামাজ শিখুন",
            subtitleEn = "Clear posture illustrations, Arabic phrases, and gentle pace.",
            subtitleBn = "চিত্রসহ অজু ও সালাতের ধাপ এবং সহজ উচ্চারণ।",
            targetTabName = "WUDU_SALAH"
        ),
        BeginnerRoadmapStep(
            id = "beg_3",
            stepNumber = 3,
            titleEn = "Write & Pronounce the 28 Arabic Letters",
            titleBn = "২৮টি আরবি হরফ লেখা ও উচ্চারণ",
            subtitleEn = "Trace every letter with your finger and learn Makharij articulation.",
            subtitleBn = "আঙুল দিয়ে হরফ অনুশীলন ও সঠিক মাখরাজ শিখুন।",
            targetTabName = "ARABIC_STUDIO"
        ),
        BeginnerRoadmapStep(
            id = "beg_4",
            stepNumber = 4,
            titleEn = "Everyday Halal, Character & Sunnah",
            titleBn = "দৈনন্দিন হালাল-হারাম, আখলাক ও সুন্নাহ",
            subtitleEn = "Practical Dos & Don'ts backed by Quran & Sahih Hadith.",
            subtitleBn = "কুরআন ও সহীহ হাদিসের আলোকে করণীয় ও বর্জনীয়।",
            targetTabName = "ENCYCLOPEDIA"
        )
    )

    val all28ArabicLetters: List<ArabicLetterStudioItem> = listOf(
        ArabicLetterStudioItem("alif", "Alif", "আলিফ", "ا", "ا", "ـا", "ـا", "a / ā", "Empty space of throat & mouth (Al-Jawf)", "মুখ ও কণ্ঠের শূন্যস্থান (আল-জাওফ)", "Draw one straight stroke top to bottom.", "উপর থেকে নিচে সোজা রেখা টানুন।"),
        ArabicLetterStudioItem("ba", "Ba", "বা", "ب", "بـ", "ـبـ", "ـب", "b", "Press both wet parts of lips together", "দুই ঠোঁটের ভেজা অংশ মিলিয়ে", "Wide boat curve right-to-left + 1 dot underneath.", "ডান থেকে বামে নৌকার মতো বাঁক + নিচে ১ নুকতা।"),
        ArabicLetterStudioItem("ta", "Ta", "তা", "ت", "تـ", "ـتـ", "ـت", "t", "Tip of tongue touches roots of upper front teeth", "জিহ্বার ডগা উপরের সামনের দাঁতের গোড়ায়", "Wide boat curve right-to-left + 2 dots inside.", "নৌকার মতো বাঁক + উপরে ২ নুকতা।"),
        ArabicLetterStudioItem("tha", "Tha", "ছা", "ث", "ثـ", "ـثـ", "ـث", "th (soft)", "Tip of tongue gently touches edge of upper front teeth", "জিহ্বার ডগা উপরের দাঁতের কিনারায়", "Wide boat curve right-to-left + 3 dots triangle above.", "নৌকার মতো বাঁক + উপরে ৩ নুকতা।"),
        ArabicLetterStudioItem("jim", "Jeem", "জীম", "ج", "جـ", "ـجـ", "ـج", "j", "Middle of tongue touches middle of hard palate", "জিহ্বার মধ্যভাগ উপরের তালুর সাথে", "Short slanted wave right, then deep C-belly + 1 dot inside.", "উপরে ঢেউ টেনে নিচে গভীর বাঁক + ভেতরে ১ নুকতা।"),
        ArabicLetterStudioItem("ha_light", "Haa (Throat)", "হা (কণ্ঠ)", "ح", "حـ", "ـحـ", "ـح", "ḥ", "Middle of the throat (clear breathy H)", "কণ্ঠনালীর মধ্যভাগ থেকে বাতাসসহ", "Same smooth wave and deep C-belly as Jeem, no dots.", "জীমের মতো আকার, কোনো নুকতা নেই।"),
        ArabicLetterStudioItem("kha", "Khaa", "খা", "خ", "خـ", "ـخـ", "ـخ", "kh", "Top of throat near uvula (soft rasp)", "কণ্ঠনালীর উপরের অংশ থেকে", "Same wave + deep C-belly + 1 dot above.", "একই আকার + উপরে ১ নুকতা।"),
        ArabicLetterStudioItem("dal", "Dal", "দাল", "د", "د", "ـد", "ـد", "d", "Tip of tongue touches roots of upper front teeth", "জিহ্বার আগা উপরের দাঁতের গোড়ায়", "Curved angle sloping down-right then left along baseline.", "বাঁকা কোণ নিচে ডানে এনে বামে টানুন।"),
        ArabicLetterStudioItem("dhal", "Dhal", "যাল", "ذ", "ذ", "ـذ", "ـذ", "dh (soft)", "Tip of tongue at edge of upper front teeth", "জিহ্বার আগা উপরের সামনের দাঁতের প্রান্তে", "Same curve as Dal + 1 dot above.", "দালের মতো আকার + উপরে ১ নুকতা।"),
        ArabicLetterStudioItem("ra", "Ra", "রা", "ر", "ر", "ـر", "ـر", "r", "Tip and top edge of tongue gently taps upper gums", "জিহ্বার আগার পিঠ উপরের মাড়িতে", "Short downward curve sweeping below the baseline left.", "ছোট বাঁক নিচে নেমে বামে বাঁকান।"),
        ArabicLetterStudioItem("zay", "Zay", "যা", "ز", "ز", "ـز", "ـز", "z", "Tip of tongue behind lower front teeth (crisp buzz)", "জিহ্বার ডগা নিচের দাঁতের ভেতরের প্রান্তে", "Same crescent sweep as Ra + 1 dot above.", "রা-এর মতো বাঁক + উপরে ১ নুকতা।"),
        ArabicLetterStudioItem("sin", "Seen", "সীন", "س", "سـ", "ـسـ", "ـس", "s", "Tip of tongue near lower front teeth (whistle sound)", "জিহ্বার ডগা নিচের দাঁতের কাছে (শিস ধ্বনি)", "Two small teeth right-to-left + deep bowl sweeping up.", "দুটি ছোট দাঁত + নিচে গভীর বাটির মতো বাঁক।"),
        ArabicLetterStudioItem("shin", "Sheen", "শীন", "ش", "شـ", "ـشـ", "ـش", "sh", "Middle of tongue rises with spread air (Tafashshi)", "জিহ্বার মধ্যভাগ ও ছড়িয়ে পড়া বাতাস", "Same two teeth + deep bowl + 3 dots above.", "সীনের মতো আকার + উপরে ৩ নুকতা।"),
        ArabicLetterStudioItem("sad", "Saad", "ছোয়াদ", "ص", "صـ", "ـصـ", "ـص", "ṣ (heavy)", "Heavy S with back of tongue elevated (Tafkheem)", "ভারী 'স' — জিহ্বার পেছন উঁচু করে", "Oval almond loop right-to-left, small tooth, deep bowl.", "বাদামের মতো লুপ + ছোট দাঁত + গভীর বাটি।"),
        ArabicLetterStudioItem("dad", "Daad", "দোয়াদ", "ض", "ضـ", "ـضـ", "ـض", "ḍ (heavy)", "Side edge of tongue presses upper back molars", "জিহ্বার কিনারা উপরের মাড়ির দাঁতের গোড়ায়", "Same almond loop + deep bowl + 1 dot above.", "ছোয়াদের মতো আকার + উপরে ১ নুকতা।"),
        ArabicLetterStudioItem("taa_heavy", "Taa (Heavy)", "তোয়া", "ط", "طـ", "ـطـ", "ـط", "ṭ (heavy)", "Heavy T — tip at upper roots, back of tongue raised", "ভারী 'ত' — জিহ্বার পেছন উঁচু রেখে", "Almond loop along baseline + tall vertical mast down.", "নিচে লুপ + উপর থেকে লম্বা খাড়া দাগ।"),
        ArabicLetterStudioItem("dhaa_heavy", "Dhaa (Heavy)", "যোয়া", "ظ", "ظـ", "ـظـ", "ـظ", "ẓ (heavy)", "Heavy Dh — tip at upper teeth edge, back raised", "ভারী 'য' — উপরের দাঁতের প্রান্ত ও উঁচু জিহ্বা", "Same loop + vertical mast + 1 dot to the right.", "তোয়া-এর মতো আকার + ১ নুকতা।"),
        ArabicLetterStudioItem("ayn", "Ayn", "আইন", "ع", "عـ", "ـعـ", "ـع", "ʿ (deep)", "Middle of throat gently constricted", "কণ্ঠনালীর মধ্যভাগ থেকে গভীর স্বর", "Small upper 'c' sitting atop a larger lower 'C' curve.", "উপরে ছোট 'c' এবং নিচে বড় 'C' বাঁক।"),
        ArabicLetterStudioItem("ghayn", "Ghayn", "গাইন", "غ", "غـ", "ـغـ", "ـغ", "gh", "Top of throat (like soft French 'r')", "কণ্ঠনালীর উপরের অংশ থেকে", "Same double-C shape as Ayn + 1 dot above.", "আইনের মতো আকার + উপরে ১ নুকতা।"),
        ArabicLetterStudioItem("fa", "Fa", "ফা", "ف", "فـ", "ـفـ", "ـف", "f", "Edges of upper front teeth touch inside of lower lip", "উপরের সামনের দাঁত নিচের ঠোঁটের ভেতরে", "Small raised loop right-to-left + flat boat + 1 dot.", "উঁচু ছোট গোল মাথা + লম্বা নৌকা + ১ নুকতা।"),
        ArabicLetterStudioItem("qaf", "Qaf", "ক্বাফ", "ق", "قـ", "ـقـ", "ـق", "q (deep)", "Deepest back of tongue touches soft palate", "জিহ্বার একদম গোড়া নরম তালুর সাথে", "Small loop + deep round bowl + 2 dots above.", "গোল মাথা + গভীর বাটি + উপরে ২ নুকতা।"),
        ArabicLetterStudioItem("kaf", "Kaf", "কাফ", "ك", "كـ", "ـكـ", "ـك", "k", "Back of tongue touches hard/soft palate slightly forward of Qaf", "ক্বাফের একটু সামনে তালু থেকে", "Vertical stem down, horizontal base left + tiny hamza-like mark inside.", "খাড়া দাগ + অনুভূমিক ভিত্তি + ভেতরে ছোট বাঁকা চিহ্ন।"),
        ArabicLetterStudioItem("lam", "Lam", "লাম", "ل", "لـ", "ـلـ", "ـل", "l", "Front edges of tongue touch gums of upper front teeth", "জিহ্বার সামনের কিনারা উপরের মাড়িতে", "Tall vertical stroke down hooking smoothly left under baseline.", "লম্বা খাড়া দাগ নিচে নেমে বাঁকা হুক।"),
        ArabicLetterStudioItem("mim", "Meem", "মীম", "م", "مـ", "ـمـ", "ـم", "m", "Close outer dry part of both lips gently", "দুই ঠোঁটের শুষ্ক অংশ মিলিয়ে", "Tiny loop right-to-left, short top bar, vertical tail down.", "ছোট গোল বৃত্ত + নিচে লম্বা লেজ।"),
        ArabicLetterStudioItem("nun", "Noon", "নূন", "ن", "نـ", "ـنـ", "ـن", "n", "Tip of tongue touches upper gums with gentle nasal resonance", "জিহ্বার আগা উপরের মাড়িতে (মৃদু নাসিক্যসহ)", "Deep round cup right-to-left + 1 centered dot above.", "গভীর গোল বাটি + মাঝখানে ১ নুকতা।"),
        ArabicLetterStudioItem("ha_soft", "Ha (Deep Chest)", "হা (গভীর)", "ه", "هـ", "ـهـ", "ـه", "h", "Bottom of throat (chest voice — soft 'h')", "কণ্ঠনালীর নিচের অংশ থেকে কোমল 'হ'", "Clean closed teardrop / oval circle.", "পরিচ্ছন্ন গোল ফোঁটার মতো বৃত্ত।"),
        ArabicLetterStudioItem("waw", "Waw", "ওয়াও", "و", "و", "ـو", "ـو", "w / ū", "Round both lips forward into a smooth circle", "দুই ঠোঁট গোল করে সামনে বাড়িয়ে", "Small head loop curving down into a crescent tail.", "ছোট গোল মাথা নিচে বাঁকা লেজে শেষ।"),
        ArabicLetterStudioItem("ya", "Ya", "ইয়া", "ي", "يـ", "ـيـ", "ـي", "y / ī", "Middle of tongue rises toward center palate", "জিহ্বার মধ্যভাগ তালুর দিকে তুলে", "S-neck curving down into a wide bowl + 2 dots underneath.", "হাঁসের গলার মতো বাঁক + নিচে ২ নুকতা।")
    )

    val encyclopediaCategories: List<Pair<String, Pair<String, String>>> = listOf(
        "ALL" to ("All Topics" to "সব বিষয়"),
        "PROPHETS_SAHABA" to ("Prophets & Sahaba" to "নবী-রাসূল ও সাহাবা"),
        "DOS_DONTS" to ("Dos & Don'ts" to "করণীয় ও বর্জনীয়"),
        "BIDAH_SUNNAH" to ("Sunnah vs. Bid'ah" to "সুন্নাহ বনাম বিদ'আত"),
        "HALAL_HARAM" to ("Halal & Haram" to "হালাল ও হারাম"),
        "FIQH_SCIENCES" to ("Fiqh & Sciences" to "ফিকহ ও উলূম")
    )

    val encyclopediaEntries: List<EncyclopediaEntry> = listOf(
        EncyclopediaEntry(
            id = "prophets_ibrahim",
            categoryId = "PROPHETS_SAHABA",
            titleEn = "Prophet Ibrahim (AS) — The Friend of Allah (Khalilullah)",
            titleBn = "নবী ইবরাহীম (আ.) — খলীলুল্লাহ",
            arabicTerm = "إبراهيم عليه السلام",
            summaryEn = "Model of unwavering Tawhid, gentle invitation to truth, sacrifice, and building the Ka'bah with Isma'il (AS). Allah commanded believers to follow his pure monotheism.",
            summaryBn = "অটল তাওহীদ, ধৈর্য, ত্যাগ এবং ইসমাইল (আ.)-এর সাথে কাবা পুনর্নির্মাণের উজ্জ্বল দৃষ্টান্ত।",
            evidenceRef = "Quran 16:120 • 2:127",
            sourceUrl = "https://quran.com/16/120"
        ),
        EncyclopediaEntry(
            id = "prophets_musa",
            categoryId = "PROPHETS_SAHABA",
            titleEn = "Prophet Musa (AS) — Courage, Reliance & Truth",
            titleBn = "নবী মূসা (আ.) — সাহস ও আল্লাহর ওপর ভরসা",
            arabicTerm = "موسى عليه السلام",
            summaryEn = "When trapped between Pharaoh's army and the Red Sea, Musa declared: 'Never! Indeed, with me is my Lord; He will guide me.' A timeless anchor during hardship.",
            summaryBn = "ফেরাউনের বাহিনী ও সাগরের মাঝে পড়েও তিনি বলেছিলেন—‘কখনোই নয়! নিশ্চয়ই আমার রব আমার সাথে আছেন, তিনিই পথ দেখাবেন।’",
            evidenceRef = "Quran 26:62",
            sourceUrl = "https://quran.com/26/62"
        ),
        EncyclopediaEntry(
            id = "sahaba_abubakr",
            categoryId = "PROPHETS_SAHABA",
            titleEn = "Abu Bakr As-Siddiq (RA) — Immediate Truthfulness",
            titleBn = "আবু বকর সিদ্দীক (রা.) — সত্যবাদিতা ও নিষ্ঠা",
            arabicTerm = "أبو بكر الصديق",
            summaryEn = "Companion of the Prophet ﷺ in the Cave of Thawr ('Do not grieve; indeed Allah is with us'). Known for quiet charity, humility, and steadfast leadership.",
            summaryBn = "সাওর গুহার সাথী ('দুঃখ করো না, নিশ্চয় আল্লাহ আমাদের সাথে আছেন')। গোপন দান, বিনয় ও অটল ঈমানের আদর্শ।",
            evidenceRef = "Quran 9:40 • Sahih al-Bukhari 3654",
            sourceUrl = "https://quran.com/9/40"
        ),
        EncyclopediaEntry(
            id = "sahaba_khadijah",
            categoryId = "PROPHETS_SAHABA",
            titleEn = "Khadijah bint Khuwaylid (RA) — Pillar of Compassion",
            titleBn = "খাদীজা বিনতে খুওয়াইলিদ (রা.) — সহমর্মিতার স্তম্ভ",
            arabicTerm = "خديجة رضي الله عنها",
            summaryEn = "First believer in Islam who comforted the Prophet ﷺ at the very first revelation with wisdom and dignity. Angel Jibril conveyed Allah's Salam directly to her.",
            summaryBn = "প্রথম ইসলাম গ্রহণকারী; প্রথম ওহীর সময় নবীজি ﷺ-কে দৃঢ় সাহস ও প্রশান্তি দিয়েছিলেন। জিবরীল (আ.) তাঁকে আল্লাহর সালাম পৌঁছে দেন।",
            evidenceRef = "Sahih al-Bukhari 3820",
            sourceUrl = "https://sunnah.com/bukhari:3820"
        ),
        EncyclopediaEntry(
            id = "dos_parents",
            categoryId = "DOS_DONTS",
            titleEn = "Honoring Parents & Keeping Family Ties (Birr al-Walidayn)",
            titleBn = "পিতা-মাতার প্রতি সদাচরণ ও আত্মীয়তার সম্পর্ক",
            arabicTerm = "بر الوالدين",
            summaryEn = "DO speak with gentleness, lower the wing of humility, and make Dua for them. DON'T even utter 'Uff' in impatience or sever family bonds.",
            summaryBn = "করণীয়: নম্র ভাষায় কথা বলা ও তাঁদের জন্য দুআ করা। বর্জনীয়: বিরক্ত হয়ে 'উফ' বলা বা আত্মীয়তার সম্পর্ক ছিন্ন করা।",
            evidenceRef = "Quran 17:23–24",
            sourceUrl = "https://quran.com/17/23"
        ),
        EncyclopediaEntry(
            id = "donts_backbiting",
            categoryId = "DOS_DONTS",
            titleEn = "Guarding the Tongue: Avoiding Backbiting (Gheebah) & Envy",
            titleBn = "জবান সংযত রাখা: গীবত ও হিংসা বর্জন",
            arabicTerm = "الغيبة والبهتان",
            summaryEn = "DO speak good or remain silent, verify news before sharing, and make sincere excuses for others. DON'T mock, spy, or speak ill behind someone's back.",
            summaryBn = "করণীয়: উত্তম কথা বলা অথবা নীরব থাকা এবং সংবাদ যাচাই করা। বর্জনীয়: গীবত, গোপন দোষ খোঁজা ও বিদ্রূপ করা।",
            evidenceRef = "Quran 49:11–12 • Sahih al-Bukhari 6018",
            sourceUrl = "https://quran.com/49/12"
        ),
        EncyclopediaEntry(
            id = "bidah_sunnah_rule",
            categoryId = "BIDAH_SUNNAH",
            titleEn = "Core Principle: Sunnah vs. Bid'ah (Religious Innovation)",
            titleBn = "মূলনীতি: সুন্নাহ বনাম বিদ'আত",
            arabicTerm = "السنة والبدعة",
            summaryEn = "Acts of worship (Ibadah) require clear proof from Quran & authentic Sunnah; worldly tools (phones, cars, apps) are permissible unless harmful. Inventing new religious rituals without evidence is Bid'ah.",
            summaryBn = "ইবাদতের ক্ষেত্রে কুরআন ও সহীহ সুন্নাহর দলিল আবশ্যক। দুনিয়াবি প্রযুক্তি বা বৈধ উপকরণ বিদ'আত নয়; বরং দ্বীনের নামে দলিলবিহীন নতুন ইবাদত উদ্ভাবন করাই বিদ'আত।",
            evidenceRef = "Sahih al-Bukhari 2697 • Sahih Muslim 1718",
            sourceUrl = "https://sunnah.com/bukhari:2697"
        ),
        EncyclopediaEntry(
            id = "bidah_tawakkul",
            categoryId = "BIDAH_SUNNAH",
            titleEn = "Authentic Ruqyah & Tawakkul vs. Amulets & Superstitions",
            titleBn = "সুন্নাহ-সম্মত রুকইয়াহ বনাম তাবিজ ও কুসংস্কার",
            arabicTerm = "الرقية الشرعية",
            summaryEn = "Sunnah protection is reciting Surah Al-Fatihah, Ayat al-Kursi, and Al-Mu'awwidhat (112, 113, 114) trusting Allah alone—never relying on horoscopes, omens, or lucky charms.",
            summaryBn = "সুন্নাহ হলো সূরা ফাতিহা, আয়াতুল কুরসি ও তিন কুল পড়ে এক আল্লাহর ওপর ভরসা করা—ভাগ্যগণনা, কুলক্ষণ বা কুসংস্কার বর্জনীয়।",
            evidenceRef = "Sahih al-Bukhari 5017 • Sunan Abi Dawud 3883",
            sourceUrl = "https://sunnah.com/bukhari:5017"
        ),
        EncyclopediaEntry(
            id = "halal_earnings",
            categoryId = "HALAL_HARAM",
            titleEn = "Halal Earnings, Honest Trade & Avoiding Riba (Usury)",
            titleBn = "হালাল উপার্জন, সৎ ব্যবসা ও সুদ (রিবা) বর্জন",
            arabicTerm = "الحلال والحرام",
            summaryEn = "Allah permits honest trade and forbids interest (Riba), fraud, and cheating in weights or contracts. Pure halal sustenance brings barakah and accepted Dua.",
            summaryBn = "আল্লাহ সৎ ব্যবসা হালাল এবং সুদ, প্রতারণা ও ওজনে কম দেওয়া হারাম করেছেন। হালাল রিজিক দুআ কবুল ও বরকতের মাধ্যম।",
            evidenceRef = "Quran 2:275 • Sahih Muslim 1015",
            sourceUrl = "https://quran.com/2/275"
        ),
        EncyclopediaEntry(
            id = "halal_food_intoxicants",
            categoryId = "HALAL_HARAM",
            titleEn = "Tayyib (Wholesome) Nutrition & Prohibition of Intoxicants",
            titleBn = "হালাল-তাইয়্যিব খাদ্য ও মাদকদ্রব্য নিষিদ্ধতা",
            arabicTerm = "حلالاً طيباً",
            summaryEn = "Eat what is lawful and wholesome without excess. Alcohol, intoxicants, pork, and unlawfully slaughtered meat are clearly prohibited to protect mind, body, and faith.",
            summaryBn = "হালাল ও স্বাস্থ্যকর খাদ্য পরিমিত গ্রহণ করুন। মদ, সকল মাদকদ্রব্য ও হারাম মাংস বিবেক, শরীর ও ঈমানের সুরক্ষায় নিষিদ্ধ।",
            evidenceRef = "Quran 2:168 • 5:90",
            sourceUrl = "https://quran.com/5/90"
        ),
        EncyclopediaEntry(
            id = "fiqh_four_madhhabs",
            categoryId = "FIQH_SCIENCES",
            titleEn = "Respectful Ikhtilaf: The Four Sunni Schools of Fiqh",
            titleBn = "ফিকহী মাযহাব ও সম্মানজনক মতভিন্নতা (ইখতিলাফ)",
            arabicTerm = "أصول الفقه",
            summaryEn = "Hanafi, Maliki, Shafi'i, and Hanbali imams all derived rulings from Quran and Sunnah using rigorous Usul al-Fiqh. Valid scholarly differences are a mercy—never a reason for hostility.",
            summaryBn = "হানাফী, মালেকী, শাফেয়ী ও হাম্বলী ইমামগণ কুরআন ও সুন্নাহ থেকেই উসূলুল ফিকহ অনুসরণ করেছেন। বৈধ মতভিন্নতা বিভেদের নয়, বরং সম্মানের বিষয়।",
            evidenceRef = "Quran 4:59 • Classical Usul Consensus",
            sourceUrl = "https://quran.com/4/59"
        ),
        EncyclopediaEntry(
            id = "hadith_sciences",
            categoryId = "FIQH_SCIENCES",
            titleEn = "How Hadith Authenticity Is Verified (Isnad & Matn)",
            titleBn = "হাদিস যাচাইয়ের বিজ্ঞান (সনদ ও মতন)",
            arabicTerm = "علوم الحديث",
            summaryEn = "Scholars classify narrations as Sahih (authentic), Hasan (good), Da'if (weak), or Mawdu' (fabricated) by examining chain continuity, narrator integrity, precision, and absence of hidden defects.",
            summaryBn = "রাবীদের ধারাবাহিকতা, বিশ্বস্ততা ও স্মৃতিশক্তি যাচাই করে হাদিসকে সহীহ, হাসান, দুর্বল বা জাল হিসেবে শ্রেণিবদ্ধ করা হয়।",
            evidenceRef = "Sahih Muslim Muqaddimah",
            sourceUrl = "https://sunnah.com/muslim/introduction"
        )
    )
}
