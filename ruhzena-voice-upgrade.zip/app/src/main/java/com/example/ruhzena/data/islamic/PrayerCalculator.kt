package com.example.ruhzena.data.islamic

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

enum class PrayerCalcMethod(
    val id: String,
    val labelEn: String,
    val labelBn: String,
    val fajrAngle: Double,
    val ishaAngle: Double,
    val ishaMinutesAfterMaghrib: Int? = null,
    val asrShadowFactor: Double = 1.0
) {
    KARACHI("KARACHI", "Karachi (Hanafi / South Asia)", "করাচি (হানাফি / দক্ষিণ এশিয়া)", 18.0, 18.0, null, 2.0),
    MWL("MWL", "Muslim World League", "মুসলিম ওয়ার্ল্ড লিগ", 18.0, 17.0, null, 1.0),
    ISNA("ISNA", "ISNA (North America)", "ISNA (উত্তর আমেরিকা)", 15.0, 15.0, null, 1.0),
    MAKKAH("MAKKAH", "Umm al-Qura (Makkah)", "উম্মুল কুরা (মক্কা)", 18.5, 0.0, 90, 1.0),
    EGYPT("EGYPT", "Egyptian General Authority", "মিশরীয় সাধারণ কর্তৃপক্ষ", 19.5, 17.5, null, 1.0);

    companion object {
        fun fromId(id: String): PrayerCalcMethod = entries.firstOrNull { it.id == id } ?: KARACHI
    }
}

data class CityPreset(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val timeZoneId: String
)

data class DailyPrayerSchedule(
    val fajrMinutes: Int,
    val sunriseMinutes: Int,
    val dhuhrMinutes: Int,
    val asrMinutes: Int,
    val maghribMinutes: Int,
    val ishaMinutes: Int
)

data class NextPrayerInfo(
    val prayerKey: String, // FAJR, DHUHR, ASR, MAGHRIB, ISHA
    val timeFormatted: String,
    val minutesRemaining: Int
)

object PrayerCalculator {
    val cityPresets = listOf(
        CityPreset("Dhaka, Bangladesh", 23.8103, 90.4125, "Asia/Dhaka"),
        CityPreset("Chattogram, Bangladesh", 22.3569, 91.7832, "Asia/Dhaka"),
        CityPreset("Sylhet, Bangladesh", 24.8949, 91.8687, "Asia/Dhaka"),
        CityPreset("Makkah, Saudi Arabia", 21.4225, 39.8262, "Asia/Riyadh"),
        CityPreset("Madinah, Saudi Arabia", 24.4672, 39.6111, "Asia/Riyadh"),
        CityPreset("London, UK", 51.5072, -0.1276, "Europe/London"),
        CityPreset("New York, USA", 40.7128, -74.0060, "America/New_York"),
        CityPreset("Toronto, Canada", 43.6532, -79.3832, "America/Toronto"),
        CityPreset("Istanbul, Turkey", 41.0082, 28.9784, "Europe/Istanbul"),
        CityPreset("Kuala Lumpur, Malaysia", 3.1390, 101.6869, "Asia/Kuala_Lumpur"),
        CityPreset("Cairo, Egypt", 30.0444, 31.2357, "Africa/Cairo")
    )

    fun calculateQiblaBearing(latitude: Double, longitude: Double): Double {
        val kaabaLat = Math.toRadians(21.4225)
        val kaabaLon = Math.toRadians(39.8262)
        val userLat = Math.toRadians(latitude)
        val userLon = Math.toRadians(longitude)
        val dLon = kaabaLon - userLon
        val y = sin(dLon)
        val x = cos(userLat) * tan(kaabaLat) - sin(userLat) * cos(dLon)
        var bearing = Math.toDegrees(atan2(y, x))
        bearing = (bearing + 360.0) % 360.0
        return bearing
    }

    fun calculateForDate(
        latitude: Double,
        longitude: Double,
        method: PrayerCalcMethod,
        calendar: Calendar = Calendar.getInstance(),
        timeZone: TimeZone = calendar.timeZone,
        asrShadowFactorOverride: Double? = null
    ): DailyPrayerSchedule {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val tzOffsetHours = timeZone.getOffset(calendar.timeInMillis) / 3600000.0

        val jd = julianDay(year, month, day) - longitude / (15.0 * 24.0)
        val d = jd - 2451545.0

        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sinDeg(g) + 0.020 * sinDeg(2 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = Math.toDegrees(atan2(cosDeg(e) * sinDeg(l), cosDeg(l))) / 15.0
        val decl = Math.toDegrees(asin(sinDeg(e) * sinDeg(l)))
        val eqTime = q / 15.0 - fixHour(ra)

        val dhuhrHour = fixHour(12.0 + tzOffsetHours - longitude / 15.0 - eqTime)

        val fajrHour = dhuhrHour - sunHourAngle(latitude, decl, method.fajrAngle)
        val sunriseHour = dhuhrHour - sunHourAngle(latitude, decl, 0.833)
        val sunsetHour = dhuhrHour + sunHourAngle(latitude, decl, 0.833)
        val effectiveAsrFactor = asrShadowFactorOverride ?: method.asrShadowFactor
        val asrHour = dhuhrHour + asrHourAngle(latitude, decl, effectiveAsrFactor)
        val ishaHour = if (method.ishaMinutesAfterMaghrib != null) {
            sunsetHour + method.ishaMinutesAfterMaghrib / 60.0
        } else {
            dhuhrHour + sunHourAngle(latitude, decl, method.ishaAngle)
        }

        return DailyPrayerSchedule(
            fajrMinutes = hoursToMinutes(fajrHour),
            sunriseMinutes = hoursToMinutes(sunriseHour),
            dhuhrMinutes = hoursToMinutes(dhuhrHour),
            asrMinutes = hoursToMinutes(asrHour),
            maghribMinutes = hoursToMinutes(sunsetHour),
            ishaMinutes = hoursToMinutes(ishaHour)
        )
    }

    fun getNextPrayer(schedule: DailyPrayerSchedule, now: Calendar = Calendar.getInstance()): NextPrayerInfo {
        val currentMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val slots = listOf(
            "FAJR" to schedule.fajrMinutes,
            "DHUHR" to schedule.dhuhrMinutes,
            "ASR" to schedule.asrMinutes,
            "MAGHRIB" to schedule.maghribMinutes,
            "ISHA" to schedule.ishaMinutes
        )
        val upcoming = slots.firstOrNull { it.second > currentMin }
        return if (upcoming != null) {
            NextPrayerInfo(
                prayerKey = upcoming.first,
                timeFormatted = formatMinutes(upcoming.second),
                minutesRemaining = upcoming.second - currentMin
            )
        } else {
            NextPrayerInfo(
                prayerKey = "FAJR",
                timeFormatted = formatMinutes(schedule.fajrMinutes),
                minutesRemaining = (24 * 60 - currentMin) + schedule.fajrMinutes
            )
        }
    }

    fun formatMinutes(totalMinutes: Int): String {
        val m = ((totalMinutes % 1440) + 1440) % 1440
        val hour24 = m / 60
        val min = m % 60
        val amPm = if (hour24 >= 12) "PM" else "AM"
        val hour12 = when {
            hour24 == 0 -> 12
            hour24 > 12 -> hour24 - 12
            else -> hour24
        }
        return "%d:%02d %s".format(hour12, min, amPm)
    }

    private fun sunHourAngle(lat: Double, decl: Double, angle: Double): Double {
        val num = -sinDeg(angle) - sinDeg(lat) * sinDeg(decl)
        val den = cosDeg(lat) * cosDeg(decl)
        val ratio = (num / den).coerceIn(-0.9999, 0.9999)
        return Math.toDegrees(acos(ratio)) / 15.0
    }

    private fun asrHourAngle(lat: Double, decl: Double, shadowFactor: Double): Double {
        val angle = -Math.toDegrees(atan2(1.0, shadowFactor + tan(Math.toRadians(kotlin.math.abs(lat - decl)))))
        return sunHourAngle(lat, decl, angle)
    }

    private fun julianDay(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun hoursToMinutes(hours: Double): Int = ((fixHour(hours) * 60.0).toInt()).coerceIn(0, 1439)
    private fun fixAngle(a: Double): Double = (a % 360.0 + 360.0) % 360.0
    private fun fixHour(a: Double): Double = (a % 24.0 + 24.0) % 24.0
    private fun sinDeg(d: Double) = sin(Math.toRadians(d))
    private fun cosDeg(d: Double) = cos(Math.toRadians(d))
}
