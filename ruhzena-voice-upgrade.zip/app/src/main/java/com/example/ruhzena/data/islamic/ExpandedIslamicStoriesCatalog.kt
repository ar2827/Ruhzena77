package com.example.ruhzena.data.islamic

/**
 * Full, richly detailed chronological Islamic stories with authentic scholarly explanations
 * grounded in the Noble Quran, Sahih al-Bukhari, Sahih Muslim, and classical Tafsir (Ibn Kathir).
 */
object ExpandedIslamicStoriesCatalog {

    val allDetailedStories: List<NarratedIslamicStory> = listOf(
        NarratedIslamicStory(
            id = "story_01_creation_pen",
            categoryEn = "Origin of Creation",
            categoryBn = "সৃষ্টির সূচনা",
            titleEn = "The First Creation — The Throne, The Pen & The Heavens",
            titleBn = "সৃষ্টির সূচনা — আরশ, কলম এবং আসমান-জমিন",
            arabicName = "بداية الخلق • العرش والقلم",
            arabicNameTransliteration = "Bidayatul-Khalq • Al-Arsh wal-Qalam",
            eraOrder = 1,
            eraLabelEn = "Era 1 • Before Time & Humanity",
            eraLabelBn = "অধ্যায় ১ • সৃষ্টির আদি ইতিহাস",
            estimatedReadMinutes = 5,
            storyEn = """
                Before there were galaxies, sunrises, oceans, or human footsteps, Allah the Exalted existed alone — without beginning, without partner, and without need. As the Prophet Muhammad ﷺ taught in Sahih al-Bukhari, Allah existed when there was nothing besides Him, and His majestic Throne (Al-Arsh) was over the water.

                Then Allah initiated the blueprint of all existence. The Prophet ﷺ narrated in an authentic hadith that the very first command Allah issued to the Pen (Al-Qalam) was: "Write!" The Pen asked in awe: "O my Lord, what shall I write?" Allah commanded: "Write the decrees of all things until the Day of Resurrection." In the Preserved Tablet (Al-Lawh al-Mahfuz), every star's orbit, every falling leaf, every human breath, and every act of mercy was recorded with absolute divine knowledge — fifty thousand years before the heavens and the earth were fashioned.

                Next, Allah shaped the seven heavens and the earth in six divine stages (Ayyam). He raised the sky as a balanced canopy without visible pillars, anchored the earth with deep-rooted mountains so it would stand firm, spread oceans and rivers across its face, and placed the sun and moon in precise orbits to measure nights, days, and seasons. He populated the heavens with Angels created from pure light (Nur) who glorify Him tirelessly without fatigue or disobedience, and He created the Jinn from smokeless fire (Nar) with free will to choose guidance or arrogance.

                Nothing in the universe came into existence by blind accident. Every atom, star, and angel testified to a single truth: Allah is Al-Khaliq (The Creator), Al-Bari' (The Evolver), and Al-Musawwir (The Fashioner).
            """.trimIndent(),
            storyBn = """
                যখন কোনো ছায়াপথ, সূর্যোদয়, সমুদ্র কিংবা মানুষের পদচিহ্ন ছিল না, তখন কেবল মহান আল্লাহ একাই ছিলেন—কোনো শুরু ছাড়া, কোনো শরিক ছাড়া এবং সম্পূর্ণ অমুখাপেক্ষী। সহীহ বুখারীর হাদীসে নবী মুহাম্মদ ﷺ জানিয়েছেন, শুরুতে কেবল আল্লাহ ছিলেন এবং তাঁর পূর্বে কিছুই ছিল না; আর তাঁর মহান আরশ ছিল পানির ওপর।

                অতঃপর আল্লাহ সৃষ্টির মহাপরিকল্পনার সূচনা করেন। তিনি কলম (আল-কলম) সৃষ্টি করে আদেশ দিলেন: “লেখো!” কলম বিনয়ে জিজ্ঞাসা করল: “হে আমার রব, কী লিখব?” আল্লাহ বললেন: “কিয়ামত পর্যন্ত যা কিছু ঘটবে, তার সব তাকদীর লিখে ফেলো।” আসমান ও জমিন সৃষ্টির পঞ্চাশ হাজার বছর পূর্বেই লাওহে মাহফুজে প্রতিটি নক্ষত্রের গতিপথ, প্রতিটি ঝরে পড়া পাতা এবং প্রতিটি মানুষের জীবনলিপি লিপিবদ্ধ হয়ে যায়।

                এরপর আল্লাহ ছয় দিনে সাত আসমান ও জমিন সৃষ্টি করেন। কোনো দৃশ্যমান খুঁটি ছাড়াই বিশাল আকাশকে সুসজ্জিত ছাদ হিসেবে স্থাপন করেন, পৃথিবীকে স্থিতিশীল রাখতে সুদৃঢ় পাহাড় গেঁথে দেন, নদী-সাগর প্রবাহিত করেন এবং দিন-রাত ও ঋতু গণনার জন্য সূর্য ও চাঁদকে নির্ভুল কক্ষপথে স্থাপন করেন। তিনি নূর থেকে ফেরেশতাদের সৃষ্টি করেন যাঁরা ক্লান্তিহীনভাবে তাঁর তাসবিহ পাঠ করেন, আর ধোঁয়াহীন আগুন থেকে জিন জাতি সৃষ্টি করেন।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Purpose Before Creation: The sequence of creating the Throne, Water, and the Pen before humanity establishes that the universe is purposeful and governed by divine wisdom (Hikmah), not chaos.
                2. Divine Knowledge vs. Human Free Will: The Preserved Tablet (Al-Lawh al-Mahfuz) reflects Allah's timeless omniscience — He knows what we will freely choose, without forcing our choices. Understanding Qadr brings deep serenity during hardship: nothing misses you that was written for you, and nothing strikes you without Allah's wisdom.
                3. The "Six Days" (Sittati Ayyam): Classical scholars like Ibn Kathir note that Allah could have created everything with a single word "Kun" (Be), yet He created in measured stages to teach humanity patience, order, and steady craftsmanship.
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. উদ্দেশ্যপূর্ণ সৃষ্টি: আরশ ও কলম প্রথমে সৃষ্টির তাৎপর্য হলো—এই মহাবিশ্ব এলোমেলো কোনো দুর্ঘটনা নয়, বরং আল্লাহর অসীম প্রজ্ঞা ও সুশৃঙ্খল পরিকল্পনার ফল।
                ২. তাকদীর ও প্রশান্তি: লাওহে মাহফুজে সবকিছু লিপিবদ্ধ থাকার অর্থ আল্লাহর অসীম জ্ঞান। এতে বান্দার অন্তরে গভীর প্রশান্তি আসে যে—যা আপনার জন্য নির্ধারিত তা কখনো হাতছাড়া হবে না।
                ৩. ছয় ধাপে সৃষ্টির শিক্ষা: ইবনে কাসীর (রহ.) উল্লেখ করেন, আল্লাহ মুহূর্তেই 'কুন' বলে সব সৃষ্টি করতে পারতেন, কিন্তু ধাপে ধাপে সৃষ্টি করে মানুষকে ধৈর্য ও শৃঙ্খলার শিক্ষা দিয়েছেন।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"He is the Originator of the heavens and the earth. When He decrees a matter, He only says to it, 'Be,' and it is.\" — Quran 2:117",
            keyVerseOrHadithBn = "“তিনি আসমান ও জমিনের উদ্ভাবক। যখন তিনি কোনো কাজের সিদ্ধান্ত নেন, তখন কেবল বলেন ‘হও’, আর তা হয়ে যায়।” — কুরআন ২:১১৭",
            lessonEn = "Your life is not an accident — the same Lord who calibrated the stars and wrote destiny knows your name, hears your whisper, and designed you with purpose.",
            lessonBn = "আপনার জীবন কোনো দুর্ঘটনা নয়—যিনি মহাবিশ্বকে সুনিপুণভাবে সাজিয়েছেন, তিনি আপনার প্রতিটি প্রার্থনা শোনেন এবং আপনাকে মহৎ উদ্দেশ্যে সৃষ্টি করেছেন।",
            sourceRef = "Quran 7:54 • Sahih al-Bukhari 3191 • Sahih Muslim 2653",
            sourceUrl = "https://sunnah.com/bukhari:3191"
        ),
        NarratedIslamicStory(
            id = "story_02_adam_tawbah",
            categoryEn = "First Prophet & Humanity",
            categoryBn = "প্রথম নবী ও মানবজাতির সূচনা",
            titleEn = "Prophet Adam (AS) & Hawwa — Honor, Slip & The Gift of Tawbah",
            titleBn = "নবী আদম (আ.) ও হাওয়া — মর্যাদা, পদস্খলন ও তাওবার শিক্ষা",
            arabicName = "آدم عليه السلام",
            arabicNameTransliteration = "Adam Alayhis Salam",
            eraOrder = 2,
            eraLabelEn = "Era 2 • Dawn of Humanity",
            eraLabelBn = "অধ্যায় ২ • মানবজাতির সূচনা",
            estimatedReadMinutes = 6,
            storyEn = """
                Allah announced to the Angels a historic decree: "Indeed, I will make upon the earth a successive steward (Khalifah)." Allah fashioned Prophet Adam (AS) directly with His own hands from clay gathered across the earth — reflecting every hue and temperament of his future children — and breathed into him a noble soul.

                Allah honored Adam above the Angels by teaching him the names and realities of all things. When Allah asked the Angels to name them, they humbled themselves: "Glory be to You; we have no knowledge except what You have taught us." Then Adam spoke the names fluently, proving that humanity's true crown is knowledge combined with humility. Allah commanded all the Angels to prostrate in honor before Adam. Every Angel obeyed immediately — except Iblis (from the Jinn), who stood rigid in pride and declared: "I am better than him! You created me from fire and created him from clay." That single spark of arrogance (Kibr) became the first sin in creation.

                Allah created Hawwa (Eve) as Adam's companion of peace and placed them both in a lush Paradise where they could enjoy every fruit freely — save one single tree, a simple test of conscious obedience. Iblis whispered persistently, swearing falsely by Allah's name that the tree promised immortality and an eternal kingdom. In a moment of human forgetfulness, Adam and Hawwa tasted from the tree, and immediately felt overwhelming shame and sorrow.

                Here lies the defining difference between Adam (AS) and Iblis: Iblis blamed Allah and grew more defiant, whereas Adam and Hawwa wept in sincerity, owned their mistake completely, and pleaded with the words Allah Himself mercifully taught them: "Rabbana zalamna anfusana wa in lam taghfir lana wa tarhamna lanakunanna minal-khasirin — Our Lord, we have wronged ourselves, and if You do not forgive us and have mercy upon us, we will surely be among the losers." Allah accepted their repentance completely and sent them to earth not as cursed outcasts, but as honored stewards carrying His promise of eternal guidance.
            """.trimIndent(),
            storyBn = """
                মহান আল্লাহ ফেরেশতাদের উদ্দেশ্যে ঘোষণা করলেন: “নিশ্চয়ই আমি পৃথিবীতে খলিফা (প্রতিনিধি) সৃষ্টি করতে যাচ্ছি।” আল্লাহ নিজ হাতে পৃথিবীর বিভিন্ন রঙের মাটি থেকে নবী আদম (আ.)-কে সৃষ্টি করলেন এবং তাঁর ভেতরে সম্মানিত রূহ ফুঁকে দিলেন।

                আল্লাহ আদম (আ.)-কে সব বস্তুর নাম ও জ্ঞান শিক্ষা দিয়ে ফেরেশতাদের ওপর মর্যাদা দান করলেন। যখন আল্লাহ ফেরেশতাদের সেসব নাম বলতে বললেন, তাঁরা বিনীতভাবে বললেন: “আপনি পবিত্র, আপনি আমাদের যা শিখিয়েছেন তা ছাড়া আমাদের কোনো জ্ঞান নেই।” অতঃপর আদম (আ.) সব নাম বলে দিলেন। আল্লাহ ফেরেশতাদের আদম (আ.)-এর সম্মানে সিজদা করার আদেশ দিলেন। সকল ফেরেশতা সিজদা করল, কেবল জিন জাতির অন্তর্ভুক্ত ইবলিস অহংকার করে অস্বীকার করল এবং বলল: “আমি তাঁর চেয়ে শ্রেষ্ঠ! আপনি আমাকে আগুন থেকে আর তাঁকে মাটি থেকে সৃষ্টি করেছেন।” এই অহংকারই ছিল সৃষ্টির প্রথম গুনাহ।

                আল্লাহ আদম (আ.)-এর প্রশান্তির সঙ্গী হিসেবে হাওয়া (আ.)-কে সৃষ্টি করলেন এবং উভয়কে জান্নাতে বসবাস করতে দিলেন—শুধু একটি গাছের কাছে যেতে নিষেধ করলেন। কিন্তু ইবলিস মিথ্যা শপথ করে চিরস্থায়ী জীবনের প্রলোভন দেখাল। মানবীয় ভুলে তাঁরা সেই গাছের ফল খেয়ে ফেললেন এবং সাথে সাথেই গভীর অনুশোচনায় ভেঙে পড়লেন।

                এখানেই আদম (আ.) ও ইবলিসের মধ্যে আসল পার্থক্য: ইবলিস নিজের ভুলের জন্য আল্লাহকে দোষারোপ করে অহংকারে অটল থাকল, আর আদম ও হাওয়া (আ.) কোনো অজুহাত না দিয়ে আন্তরিকভাবে কাঁদলেন এবং আল্লাহর শেখানো দুআ পড়লেন: “রাব্বানা যালামনা আনফুসানা ওয়া ইল্লাম তাগফির লানা ওয়া তারহামনা লানাকুনান্না মিনাল খাসিরীন।” আল্লাহ তাঁদের তাওবা সম্পূর্ণ কবুল করে নিলেন এবং হেদায়েতের প্রতিশ্রুতি দিয়ে পৃথিবীতে মানবজাতির আবাদ শুরু করলেন।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. No "Original Sin" in Islam: Unlike other traditions, the Quran (2:37, 20:122) explicitly states that Allah forgave Adam and Hawwa completely and chose Adam for guidance. Every child is born pure (upon Fitrah), free from inherited guilt.
                2. The Two Opposite Reactions to Sin: Iblis's sin was arrogance + justifying disobedience; Adam's slip was weakness + instant humility and repentance. In Islamic spirituality, sincere Tawbah erases the past and can elevate a believer closer to Allah than before the slip.
                3. The First Root of Racism & Arrogance: Scholars point out that Iblis's claim ("I am made of fire, he of clay") was the first ideology of superiority based on origin. Islam dismantles superiority by declaring that honor lies solely in Taqwa (God-consciousness).
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. ইসলামে জন্মগত পাপের ধারণা নেই: সূরা বাকারাহ (২:৩৭) ও সূরা ত্ব-হা (২০:১২২) স্পষ্ট জানায় যে আল্লাহ আদম ও হাওয়া (আ.)-কে সম্পূর্ণ ক্ষমা করে দিয়েছেন। প্রতিটি শিশু নিষ্পাপ ফিতরাতের ওপর জন্মগ্রহণ করে।
                ২. ভুলের পর দুটি পথ: ইবলিস অহংকার ও অজুহাতের পথ বেছে নিয়ে অভিশপ্ত হলো, আর আদম (আ.) অনুতাপ ও তাওবার পথ বেছে নিয়ে আল্লাহর নৈকট্য ফিরে পেলেন।
                ৩. অহংকারের মূলোৎপাটন: আলেমগণ বলেন, "আগুন মাটির চেয়ে শ্রেষ্ঠ"—ইবলিসের এই যুক্তিই ছিল প্রথম বর্ণবাদ ও অহংকার। ইসলাম ঘোষণা করেছে, মর্যাদার একমাত্র মাপকাঠি হলো তাকওয়া।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"Our Lord, we have wronged ourselves, and if You do not forgive us and have mercy upon us, we will surely be among the losers.\" — Quran 7:23",
            keyVerseOrHadithBn = "“হে আমাদের রব, আমরা নিজেদের ওপর জুলুম করেছি। আপনি যদি আমাদের ক্ষমা না করেন ও দয়া না করেন, তবে আমরা অবশ্যই ক্ষতিগ্রস্তদের অন্তর্ভুক্ত হব।” — কুরআন ৭:২৩",
            lessonEn = "Arrogance justifies mistakes and destroys the heart; sincere Tawbah owns the slip immediately and opens the doors of Allah's endless mercy.",
            lessonBn = "অহংকার মানুষকে ধ্বংস করে, আর আন্তরিক তাওবা ও ক্ষমা প্রার্থনা বান্দাকে আবার আল্লাহর সবচেয়ে কাছে নিয়ে আসে।",
            sourceRef = "Quran 2:30–37 • 7:11–23",
            sourceUrl = "https://quran.com/7/23"
        ),
        NarratedIslamicStory(
            id = "story_03_nuh_ark",
            categoryEn = "Early Prophets",
            categoryBn = "প্রাচীন নবীগণ",
            titleEn = "Prophet Nuh (AS) — 950 Years of Patience & The Ark of Salvation",
            titleBn = "নবী নূহ (আ.) — ৯৫০ বছরের ধৈর্য ও নাজাতের নৌকা",
            arabicName = "نوح عليه السلام",
            arabicNameTransliteration = "Nuh Alayhis Salam",
            eraOrder = 3,
            eraLabelEn = "Era 3 • First Messenger to Idolatry",
            eraLabelBn = "অধ্যায় ৩ • তাওহীদের প্রথম রাসূল",
            estimatedReadMinutes = 6,
            storyEn = """
                For ten generations after Adam (AS), humanity worshiped Allah alone. Gradually, after righteous elders passed away, Shaytan persuaded people to carve statues in their memory — and generations later those statues were worshiped as idols (Wadd, Suwa', Yaghuth, Ya'uq, and Nasr). To call humanity back to pure Tawhid, Allah sent Prophet Nuh (AS), the first Messenger (Rasul) sent to idolaters.

                For an astonishing 950 years, Nuh (AS) invited his people with relentless compassion — speaking privately, calling publicly, reminding them by day and by night, pointing to the rains, the moon, and the gardens as signs of Allah's generosity. Yet the wealthy chiefs mocked him, stuffed their fingers into their ears, pulled their garments over their heads, and sneered that only the poor and humble followed him.

                After nearly a millennium when Allah revealed that no more of them would believe, Allah commanded Nuh (AS): "Construct the ship under Our observation and Our inspiration." Far from any ocean, Nuh planted timber and built a massive wooden Ark plank by plank. Every day passersby burst out laughing: "Look! Yesterday you claimed to be a prophet, and today you are a carpenter building a boat in the dry desert!" Nuh answered calmly: "If you ridicule us today, then we shall surely watch the truth unfold tomorrow."

                When the appointed sign arrived — water gushing violently from the earth's ovens and torrential rain pouring from the gates of the sky — Nuh loaded pairs of every animal and the small band of humble believers aboard. Even as towering mountain-like waves rose, Nuh called out with a father's aching heart to his disbelieving son: "O my son, come aboard with us and do not be with the disbelievers!" His son refused, trusting a high mountain peak — and a wave swept between them. When the flood subsided, the Ark came to rest peacefully upon Mount Judi, and humanity began anew from the grateful believers.
            """.trimIndent(),
            storyBn = """
                আদম (আ.)-এর পর দশ প্রজন্ম পর্যন্ত মানুষ এক আল্লাহর ইবাদত করত। কিন্তু পরবর্তীতে কিছু নেককার মানুষের মৃত্যুর পর শয়তানের প্ররোচনায় তাঁদের স্মরণে মূর্তি বানানো হয় এবং কয়েক প্রজন্ম পর মানুষ সেই মূর্তিগুলোর পূজা শুরু করে। মানবজাতিকে পুনরায় তাওহীদের পথে ফেরাতে আল্লাহ নবী নূহ (আ.)-কে প্রথম রাসূল হিসেবে প্রেরণ করেন।

                সুদীর্ঘ ৯৫০ বছর ধরে নূহ (আ.) দিন-রাত, গোপনে ও প্রকাশ্যে অত্যন্ত মমতার সাথে তাঁর জাতিকে এক আল্লাহর দিকে ডাকলেন। তিনি আকাশের বৃষ্টি, চাঁদ-সূর্য ও উদ্যানের কথা স্মরণ করিয়ে দিলেন। কিন্তু অহংকারী নেতারা তাঁকে উপহাস করল, কানে আঙুল গুঁজে দিল এবং গরিব-দুর্বল মুমিনদের তুচ্ছ করে ফিরিয়ে দিল।

                অবশেষে আল্লাহ ওহী করলেন যে আর কেউ ঈমান আনবে না, এবং আদেশ দিলেন: “আমার তত্ত্বাবধানে ও ওহী অনুযায়ী একটি বিশাল নৌকা নির্মাণ করো।” সমুদ্র থেকে বহু দূরে শুকনো জমিতে নূহ (আ.) কাঠ দিয়ে নৌকা তৈরি করতে শুরু করলে পথচারীরা ঠাট্টা করে বলত: “নবী থেকে এখন কাঠমিস্ত্রি হয়ে গেছ!” নূহ (আ.) অবিচল ধৈর্যে কাজ চালিয়ে গেলেন।

                নির্ধারিত সময় এলে ভূগর্ভ থেকে প্রবল পানির ফোয়ারা এবং আকাশ থেকে মুষলধারে বৃষ্টি নেমে এল। নূহ (আ.) প্রতিটি প্রাণীর এক জোড়া করে এবং মুমিনদের নৌকায় তুলে নিলেন। পাহাড়সমান ঢেউয়ের মাঝে তিনি পিতার ব্যাকুল হৃদয়ে তাঁর অবিশ্বাসী পুত্রকে ডাকলেন: “হে বৎস, আমাদের সাথে আরোহণ করো!” কিন্তু পুত্র পাহাড়ের চূড়ায় আশ্রয় নিতে গিয়ে ডুবে গেল। মহাপ্লাবন থামার পর নৌকাটি জুদী পর্বতে স্থির হলো এবং কৃতজ্ঞ মুমিনদের মাধ্যমে পৃথিবীতে নতুন যুগের সূচনা হলো।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Success Is Effort, Not Numbers: After 950 years, Ibn Abbas (RA) reports that only about eighty people boarded the Ark — yet Nuh (AS) is one of the five Ulul-'Azm (Greatest Messengers of Resolve). Allah rewards steadfast effort and sincerity, not viral popularity.
                2. Prepare Before the Storm: Building the Ark on dry land while mocked teaches believers to obey Allah's guidance and build spiritual habits (Salah, Quran, character) BEFORE life's crises hit.
                3. Faith Over Lineage: The heartbreaking loss of Nuh's son proves that salvation comes from personal Iman and righteous deeds, never merely from noble family ties (Quran 11:46).
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. সাফল্যের মাপকাঠি সংখ্যা নয়, নিষ্ঠা: ৯৫০ বছর দাওয়াতের পরও মাত্র প্রায় ৮০ জন ঈমান এনেছিলেন—তবুও নূহ (আ.) পাঁচজন শ্রেষ্ঠ 'উলুল আযম' রাসূলের একজন। আল্লাহ ফলাফল নয়, অবিরাম প্রচেষ্টা ও ইখলাস দেখেন।
                ২. ঝড় আসার আগেই প্রস্তুতি: শুকনো মাটিতে নৌকা তৈরির শিক্ষা হলো—বিপদ আসার আগেই নামাজ, কুরআন ও সৎকর্মের মাধ্যমে নিজের ঈমানি নৌকা প্রস্তুত রাখা।
                ৩. বংশ নয়, ঈমানই মুক্তির পথ: নূহ (আ.)-এর পুত্রের ঘটনা প্রমাণ করে যে কেবল নবী-পরিবারে জন্ম নিলেই মুক্তি মেলে না; ব্যক্তিগত ঈমান ও আমল অপরিহার্য।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"And it was revealed to Nuh: 'Construct the ship under Our eyes and Our inspiration.'\" — Quran 11:37",
            keyVerseOrHadithBn = "“আর নূহের প্রতি ওহী করা হলো—তুমি আমার তত্ত্বাবধানে ও আমার ওহী অনুযায়ী নৌকা নির্মাণ করো।” — কুরআন ১১:৩৭",
            lessonEn = "Never abandon what is right just because the crowd mocks you — keep building your Ark of faith quietly, and Allah will carry you safely through every storm.",
            lessonBn = "মানুষের উপহাস দেখে সত্যের পথ ছাড়বেন না—নীরবে নিজের ঈমান ও আমলের প্রস্তুতি গড়ে তুলুন, আল্লাহই আপনাকে প্রতিটি ঝড় থেকে রক্ষা করবেন।",
            sourceRef = "Quran 11:25–48 • 71:1–28",
            sourceUrl = "https://quran.com/11/37"
        ),
        NarratedIslamicStory(
            id = "story_04_ibrahim_fire",
            categoryEn = "Khalilullah • Friend of Allah",
            categoryBn = "খলিলুল্লাহ • আল্লাহর বন্ধু",
            titleEn = "Prophet Ibrahim (AS) — Breaking the Idols & The Cool Fire",
            titleBn = "নবী ইবরাহীম (আ.) — সত্যের অন্বেষণ ও অগ্নিকুণ্ডে শান্তি",
            arabicName = "إبراهيم الخليل عليه السلام",
            arabicNameTransliteration = "Ibrahim Al-Khalil Alayhis Salam",
            eraOrder = 4,
            eraLabelEn = "Era 4 • Champion of Tawhid",
            eraLabelBn = "অধ্যায় ৪ • তাওহীদের মহাবীর",
            estimatedReadMinutes = 6,
            storyEn = """
                Born in Babylon into a household of idol-makers — his own father Azar carved statues for a living — young Prophet Ibrahim (AS) possessed an extraordinary clarity of heart and intellect. Looking up at the night sky, he reasoned gently with his people: stars fade, the moon sets, and even the blazing sun disappears at dusk. "I do not love things that disappear!" he proclaimed. "Indeed, I have turned my face purely toward Him who created the heavens and the earth."

                To awaken his people's dormant reason, Ibrahim waited until a city festival emptied the temple. He entered and smashed all the smaller idols, hanging his axe around the neck of the largest statue. When the furious crowd questioned him, Ibrahim pointed calmly to the intact chief statue: "Ask them, if they can speak!" For a brief moment, their consciences stirred and they admitted among themselves: "Indeed, you yourselves are the wrongdoers — you know these statues cannot speak!" Yet pride quickly extinguished their honesty.

                Tyrant King Namrud and the chiefs dug a colossal pit, filled it with mountains of firewood for days, and ignited a blaze so scorching that birds flying overhead fell from the heat. Unable to approach the flames, they built a catapult, bound Ibrahim (AS), and launched him directly into the roaring inferno. Mid-air, Angel Jibril (AS) appeared and asked: "O Ibrahim, do you have any need?" Ibrahim replied with absolute Tawakkul: "From you, no! From Allah — His knowledge of my state is sufficient for me! Hasbunallahu wa ni'mal-wakil (Allah is sufficient for us, and He is the best Disposer of affairs)."

                In that instant, Allah overturned the laws of physics with a single majestic decree: "Qulna ya naru kuni bardan wa salaman ala Ibrahim — O fire, be coolness and safety upon Ibrahim!" The flames burned away only the ropes tying his wrists, leaving him seated calmly inside a garden of comfort until he walked out unscathed before stunned eyes.
            """.trimIndent(),
            storyBn = """
                ব্যাবিলনের মূর্তি-নির্মাতা পরিবারে জন্ম নেওয়া তরুণ নবী ইবরাহীম (আ.) ছিলেন অসাধারণ বিবেক ও বুদ্ধির অধিকারী। রাতের আকাশের তারা, চাঁদ ও সূর্যের উদয়-অস্ত দেখে তিনি জাতিকে যুক্তি দিয়ে বোঝালেন: “যা অস্ত যায়, তা কখনো রব হতে পারে না! আমি আমার মুখ একনিষ্ঠভাবে সেই মহান স্রষ্টার দিকে ফেরালাম যিনি আসমান ও জমিন সৃষ্টি করেছেন।”

                জাতির বিবেক জাগ্রত করতে একদিন উৎসবের সময় তিনি মন্দিরে প্রবেশ করে ছোট মূর্তিগুলো ভেঙে কুড়ালটি সবচেয়ে বড় মূর্তির কাঁধে ঝুলিয়ে দিলেন। ক্রুদ্ধ জনতা প্রশ্ন করলে তিনি শান্তভাবে বললেন: “ওদেরকেই জিজ্ঞাসা করো, যদি ওরা কথা বলতে পারে!” মুহূর্তের জন্য তাদের বিবেক কেঁপে উঠল এবং তারা স্বীকার করল যে এই মূর্তিগুলো কথা বলতে পারে না। কিন্তু অহংকার তাদের সত্য গ্রহণ করতে দিল না।

                অত্যাচারী রাজা নমরুদ ও নেতারা বিশাল গর্ত খুঁড়ে দিনভর কাঠ জ্বালিয়ে এমন ভয়াবহ অগ্নিকুণ্ড তৈরি করল যে এর তাপে ওপর দিয়ে পাখিও উড়তে পারত না। চড়কিতে বেঁধে ইবরাহীম (আ.)-কে সেই লেলিহান আগুনে নিক্ষেপ করা হলো। শূন্যে ভাসমান অবস্থায় জিবরীল (আ.) এসে বললেন: “হে ইবরাহীম, আপনার কোনো প্রয়োজন আছে কি?” তিনি অটল তাওয়াক্কুলে বললেন: “তোমার কাছে নয়! আমার রব আমার অবস্থা জানেন, তিনিই আমার জন্য যথেষ্ট—হাসবুনাল্লাহু ওয়া নি’মাল ওয়াকিল!”

                সেই মুহূর্তে আল্লাহ আগুনকে আদেশ দিলেন: “হে আগুন! তুমি ইবরাহীমের জন্য শীতল ও নিরাপদ হয়ে যাও!” আগুন কেবল তাঁর হাতের রশি পুড়িয়ে দিল, আর ভেতরে তিনি সম্পূর্ণ নিরাপদে প্রশান্ত অবস্থায় বসে থাকলেন এবং অক্ষত বেরিয়ে এলেন।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Why Allah Said BOTH "Coolness AND Safety": Ibn Abbas (RA) famously explained that had Allah only commanded the fire to be "cool" (Bardan), its freezing cold would have harmed Ibrahim! By adding "and Safety" (Wa Salaman), Allah demonstrated His meticulous, loving care for His servants.
                2. The Power of "Hasbunallahu wa ni'mal-wakil": Sahih al-Bukhari (4563) records Ibn Abbas's statement that this exact phrase was spoken by Prophet Ibrahim (AS) when thrown into the fire, and by Prophet Muhammad ﷺ when told armies had gathered against Madinah. It is the believer's ultimate shield against fear.
                3. Respectful Da'wah With Reason: Ibrahim used gentle logic and questioning rather than insults, proving Islam invites minds to reflect deeply.
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. ‘শীতল’ এর সাথে ‘নিরাপদ’ বলার তাৎপর্য: ইবনে আব্বাস (রা.) ব্যাখ্যা করেন—আল্লাহ কেবল “শীতল হও” বললে তীব্র শীতে ইবরাহীম (আ.)-এর কষ্ট হতো! তাই আল্লাহ “এবং নিরাপদ (সালামান)” যুক্ত করে পরম মমতার পরিচয় দিয়েছেন।
                ২. হাসবুনাল্লাহু ওয়া নি’মাল ওয়াকিলের শক্তি: সহীহ বুখারী (৪৫৬৩) অনুযায়ী, এই দুআই ইবরাহীম (আ.) আগুনে নিক্ষিপ্ত হওয়ার সময় এবং নবী মুহাম্মদ ﷺ কঠিন সংকটের মুহূর্তে পাঠ করেছিলেন।
                ৩. যুক্তিনিষ্ঠ দাওয়াত: ইবরাহীম (আ.) গালিগালাজ নয়, বরং বিবেক ও যুক্তি দিয়ে সত্যের প্রমাণ তুলে ধরেছেন।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"We said, 'O fire, be coolness and safety upon Ibrahim.'\" — Quran 21:69",
            keyVerseOrHadithBn = "“আমি বললাম, হে আগুন! তুমি ইবরাহীমের জন্য শীতল ও নিরাপদ হয়ে যাও।” — কুরআন ২১:৬৯",
            lessonEn = "When you rely purely on Allah (Hasbunallahu wa ni'mal-wakil), even the hottest fire of life turns into coolness and peace by His command.",
            lessonBn = "যখন আপনি সম্পূর্ণভাবে আল্লাহর ওপর ভরসা করেন, তখন জীবনের সবচেয়ে ভয়াবহ অগ্নিকুণ্ডও তাঁর আদেশে শীতল ও নিরাপদ হয়ে যায়।",
            sourceRef = "Quran 21:51–70 • Sahih al-Bukhari 4563",
            sourceUrl = "https://quran.com/21/69"
        ),
        NarratedIslamicStory(
            id = "story_05_ibrahim_ismail_kabah",
            categoryEn = "Foundations of Makkah",
            categoryBn = "মক্কা ও কাবার ইতিহাস",
            titleEn = "Hajar, Zamzam & Building the Sacred Ka'bah",
            titleBn = "হাজেরা (আ.), যমযম ও পবিত্র কাবা নির্মাণ",
            arabicName = "إبراهيم وإسماعيل وهاجر • الكعبة وزمزم",
            arabicNameTransliteration = "Ibrahim wa Ismail wa Hajar • Al-Ka'bah wa Zamzam",
            eraOrder = 5,
            eraLabelEn = "Era 5 • Birth of Makkah & Hajj",
            eraLabelBn = "অধ্যায় ৫ • মক্কা ও হজের সূচনা",
            estimatedReadMinutes = 6,
            storyEn = """
                By Allah's direct command, Prophet Ibrahim (AS) traveled across arid deserts with his wife Hajar and their nursing infant Ismail (AS) until they reached a completely barren valley surrounded by rocky hills — the future site of Makkah — where there was not a single tree, house, or drop of water. Leaving them a small bag of dates and a waterskin, Ibrahim turned to walk back. Hajar hurried after him: "O Ibrahim, where are you going, leaving us in this valley where there is neither companion nor sustenance?" He could not bear to look back. Finally she asked the decisive question: "Has Allah commanded you to do this?" Ibrahim answered: "Yes." Immediately Hajar's face shone with serene conviction: "Then He will never abandon us!"

                Days later, the waterskin ran dry and baby Ismail cried from thirst. Refusing to surrender to despair, Hajar ran swiftly between the hills of Safa and Marwah seven times, scanning the horizon for water or travelers while praying with every step. As she completed her seventh run near Marwah, she heard a sound beside her child — Angel Jibril (AS) struck the desert sand, and a crystal-clear spring burst forth beneath Ismail's heels! Hajar quickly built a tiny sand rim around the gushing spring crying "Zummi, zummi!" (Gather, gather!), giving Zamzam its eternal name. Over 4,000 years later, that very spring still quenches millions of pilgrims every single day.

                Years later, after father and son passed the ultimate test of devotion and obedience, Allah revealed the ancient foundations of the Sacred House. Together, elderly Ibrahim and youthful Ismail hauled stones with their own hands and raised the walls of the Holy Ka'bah. As they laid stone upon stone, their hearts overflowed not with pride, but with humble awe: "Rabbana taqabbal minna innaka Antas-Sami'ul-Alim — Our Lord, accept this from us; indeed You are the All-Hearing, the All-Knowing." And they prayed for a final Messenger to arise from their descendants — a dua answered millennia later in Prophet Muhammad ﷺ.
            """.trimIndent(),
            storyBn = """
                আল্লাহর প্রত্যক্ষ আদেশে নবী ইবরাহীম (আ.) তাঁর স্ত্রী হাজেরা (আ.) ও দুগ্ধপোষ্য শিশু ইসমাঈল (আ.)-কে নিয়ে এমন এক জনমানবহীন শুষ্ক উপত্যকায় এলেন যেখানে কোনো গাছ, ঘর বা পানি ছিল না—সেটিই আজকের পবিত্র মক্কা। সামান্য খেজুর ও এক মশক পানি রেখে তিনি ফিরে যেতে লাগলে হাজেরা (আ.) পেছন থেকে ডাকলেন: “হে ইবরাহীম, এই জনমানবহীন প্রান্তরে আমাদের রেখে কোথায় যাচ্ছেন?” কোনো উত্তর না পেয়ে শেষে তিনি জিজ্ঞাসা করলেন: “আল্লাহ কি আপনাকে এই আদেশ দিয়েছেন?” ইবরাহীম (আ.) বললেন: “হ্যাঁ।” সাথে সাথেই হাজেরা (আ.) অটল ঈমানে বললেন: “তাহলে তিনি আমাদের কখনো ধ্বংস করবেন না!”

                কয়েক দিন পর পানি ফুরিয়ে গেলে তৃষ্ণার্ত শিশু ইসমাঈলের জন্য হাজেরা (আ.) হাত গুটিয়ে বসে না থেকে সাফা ও মারওয়া পাহাড়ের মাঝে সাতবার দৌড়াদৌড়ি করে পানি খুঁজলেন এবং আল্লাহর কাছে সাহায্য চাইলেন। সপ্তম চক্করের পর তিনি দেখলেন জিবরীল (আ.)-এর ডানার আঘাতে শিশুর পায়ের নিচ থেকে স্বচ্ছ পানির ঝরনা প্রবাহিত হচ্ছে! তিনি বালু দিয়ে বাঁধ দিতে দিতে বললেন “যম, যম” (থামো, জমা হও)—সেই থেকেই অমর যমযম কূপের সূচনা, যা আজও লক্ষ লক্ষ হাজীদের তৃষ্ণা মেটায়।

                বহু বছর পর পিতা ইবরাহীম ও পুত্র ইসমাঈল (আ.) নিজ হাতে পাথর বয়ে পবিত্র কাবার দেয়াল নির্মাণ করলেন। এত মহান কাজের পরও তাঁদের মনে বিন্দুমাত্র অহংকার ছিল না; বরং তাঁরা কাঁদতে কাঁদতে দুআ করলেন: “রাব্বানা তাকাব্বাল মিন্না ইন্নাকা আনতাস-সামিউল আলিম—হে আমাদের রব, আমাদের পক্ষ থেকে কবুল করুন।” সেই সাথে তাঁরা দোয়া করেছিলেন যেন তাঁদের বংশ থেকে এক মহান রাসূল আসেন—যাঁর মাধ্যমে নবী মুহাম্মদ ﷺ-এর আগমন ঘটে।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Tawakkul + Action (Sa'y): Hajar (AS) represents the perfection of Islamic reliance on Allah: total trust in her heart ("Allah will never abandon us") paired with maximum physical effort (running 7 times between Safa and Marwah). Allah immortalized a believing woman's footsteps as a mandatory pillar of Hajj and Umrah for every man and woman until the Day of Judgment!
                2. Humility After Good Deeds: Notice that Ibrahim and Ismail did not celebrate their achievement; they begged Allah to accept it ("Rabbana taqabbal minna"). Scholars teach that worrying whether Allah accepted your worship is a sign of deep Ikhlas (sincerity).
                3. Long-Horizon Duas: Ibrahim's dua for a Prophet from Makkah (Quran 2:129) was answered over 2,500 years later in Muhammad ﷺ — teaching us never to underestimate a sincere dua made for future generations.
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. তাওয়াক্কুল ও প্রচেষ্টার সমন্বয়: হাজেরা (আ.) অন্তরে পূর্ণ ভরসা রেখেও হাত গুটিয়ে বসে থাকেননি; সাতবার সাফা-মারওয়ায় দৌড়ে চেষ্টা করেছেন। আল্লাহ একজন মুমিন নারীর সেই পদচিহ্নকে কিয়ামত পর্যন্ত হজ ও উমরাহর চিরন্তন ইবাদত বানিয়ে দিয়েছেন!
                ২. নেক আমলের পর বিনয়: কাবাঘর বানিয়েও ইবরাহীম ও ইসমাঈল (আ.) অহংকার না করে কবুল হওয়ার দুআ করেছেন—এটাই প্রকৃত ইখলাস।
                ৩. ভবিষ্যৎ প্রজন্মের জন্য দুআ: ইবরাহীম (আ.)-এর দুআ আড়াই হাজার বছর পর নবী মুহাম্মদ ﷺ-এর আগমনের মাধ্যমে পূর্ণ হয়েছিল।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"Our Lord, accept this from us. Indeed, You are the Hearing, the Knowing.\" — Quran 2:127",
            keyVerseOrHadithBn = "“হে আমাদের রব! আমাদের পক্ষ থেকে এটি কবুল করুন। নিশ্চয়ই আপনি সর্বশ্রোতা, সর্বজ্ঞ।” — কুরআন ২:১২৭",
            lessonEn = "Combine unshakable trust in Allah with tireless effort — and stay deeply humble even when accomplishing noble deeds.",
            lessonBn = "আল্লাহর ওপর অটল ভরসার সাথে সাধ্যমতো চেষ্টা চালিয়ে যান—আর মহৎ কাজ করেও বিনয়ী থাকুন।",
            sourceRef = "Quran 2:127–129 • Sahih al-Bukhari 3364",
            sourceUrl = "https://sunnah.com/bukhari:3364"
        ),
        NarratedIslamicStory(
            id = "story_06_yusuf_forgiveness",
            categoryEn = "Ahsanul-Qasas • Best of Stories",
            categoryBn = "আহসানুল কাসাস • শ্রেষ্ঠ কাহিনী",
            titleEn = "Prophet Yusuf (AS) — From the Dark Well to Egypt's Throne",
            titleBn = "নবী ইউসুফ (আ.) — অন্ধকার কূপ থেকে মিশরের শাসক ও মহাক্ষমা",
            arabicName = "يوسف عليه السلام",
            arabicNameTransliteration = "Yusuf Alayhis Salam",
            eraOrder = 6,
            eraLabelEn = "Era 6 • Resilience, Chastity & Forgiveness",
            eraLabelBn = "অধ্যায় ৬ • ধৈর্য, পবিত্রতা ও ক্ষমা",
            estimatedReadMinutes = 7,
            storyEn = """
                Allah Himself calls Surah Yusuf "Ahsanul-Qasas" — the Best of Stories. As a young boy, Prophet Yusuf (AS) saw a luminous dream: eleven stars, the sun, and the moon bowing before him. His father, Prophet Ya'qub (AS), immediately recognized that Allah was choosing Yusuf for prophethood and wisely cautioned him not to tell his older brothers lest jealousy spark in their hearts.

                Driven by envy, the ten brothers plotted to remove Yusuf, lured him out to play, stripped his shirt, and dropped him into the pitch-black bottom of a deep well, returning home with a shirt stained in false lamb's blood. Heartbroken yet dignified, Prophet Ya'qub declared: "Fa-sabrun jamil — Beautiful patience! And Allah is the One sought for help." A passing caravan pulled Yusuf from the well and sold him for a handful of coins in Egypt, where the Chief Minister (Al-Aziz) brought him into his palace.

                Gifted with extraordinary beauty, wisdom, and character, Yusuf faced his fiercest moral test when the minister's wife locked every door and tried to seduce him. With zero cameras, zero witnesses, and every worldly excuse available, Yusuf ran toward the locked door crying: "Ma'adhallah — I seek refuge in Allah!" Falsely accused and thrown into prison for years, Yusuf never grew bitter; he comforted fellow prisoners, taught them pure Tawhid, and remained a beacon of goodness even in chains.

                Years later, Egypt's King saw a troubling dream of seven lean cows devouring seven fat cows. Summoned from prison, Yusuf not only interpreted the dream — predicting seven years of abundance followed by seven years of severe famine — but also refused to walk free until his innocence was publicly cleared. Appointed Treasurer of Egypt, his wise stewardship saved the entire region from starvation. When his own brothers arrived desperate for grain, Yusuf recognized them immediately while they had no idea who he was. At the peak of his power, when they finally realized their brother stood before them trembling in guilt, Yusuf spoke the most healing words of forgiveness in human history: "La tathriba alaykumul-yawm — No blame will there be upon you today. May Allah forgive you, and He is the Most Merciful of the merciful." He reunited with his weeping father Ya'qub, and his childhood dream came true before his eyes.
            """.trimIndent(),
            storyBn = """
                মহান আল্লাহ সূরা ইউসুফকে “আহসানুল কাসাস” বা শ্রেষ্ঠ কাহিনী বলেছেন। শৈশবে নবী ইউসুফ (আ.) স্বপ্নে দেখলেন এগারোটি নক্ষত্র, সূর্য ও চাঁদ তাঁকে সিজদা করছে। তাঁর পিতা নবী ইয়াকুব (আ.) বুঝলেন আল্লাহ তাঁকে মহান মর্যাদার জন্য মনোনীত করবেন, তাই হিংসার আশঙ্কায় ভাইদের কাছে স্বপ্নটি না বলার পরামর্শ দিলেন।

                কিন্তু বৈমাত্রেয় ভাইয়েরা হিংসায় অন্ধ হয়ে তাঁকে খেলার ছলে নিয়ে গভীর অন্ধকার কূপে ফেলে দিল এবং জামায় মিথ্যা রক্ত মেখে পিতাকে জানাল যে নেকড়ে তাঁকে খেয়ে ফেলেছে। শোকে ভেঙে পড়েও নবী ইয়াকুব (আ.) বললেন: “ফাসাবরুন জামীল—উত্তম ধৈর্যই আমার অবলম্বন!” এক বাণিজ্য কাফেলা ইউসুফ (আ.)-কে কূপ থেকে তুলে মিশরের আযীযের কাছে বিক্রি করে দিল।

                যৌবনে পদার্পণ করে ইউসুফ (আ.) সবচেয়ে কঠিন নৈতিক পরীক্ষার মুখোমুখি হলেন যখন আযীযের স্ত্রী সব দরজা বন্ধ করে তাঁকে পাপের দিকে ডাকল। নির্জনে কোনো সাক্ষী না থাকা সত্ত্বেও তিনি বলে উঠলেন: “মাআযাল্লাহ! আমি আল্লাহর আশ্রয় চাই!” মিথ্যা অপবাদে বহু বছর কারাগারে বন্দী থেকেও তিনি নিরাশ হননি; বরং কয়েদিদের সান্ত্বনা দিয়েছেন এবং তাওহীদের দাওয়াত দিয়েছেন।

                বছর কয়েক পর মিশরের বাদশাহর স্বপ্নের সঠিক ব্যাখ্যা ও সাত বছরের দুর্ভিক্ষ মোকাবিলার অসাধারণ পরিকল্পনা দিয়ে ইউসুফ (আ.) নিজের নির্দোষিতা প্রমাণ করে কারামুক্ত হলেন এবং মিশরের অর্থমন্ত্রী নিযুক্ত হলেন। দুর্ভিক্ষের সময় সেই ভাইয়েরাই খাদ্য নিতে এলে ক্ষমতার শীর্ষে থেকেও ইউসুফ (আ.) প্রতিশোধ নিলেন না; বরং বললেন: “আজ তোমাদের বিরুদ্ধে কোনো অভিযোগ নেই! আল্লাহ তোমাদের ক্ষমা করুন, তিনি সর্বশ্রেষ্ঠ দয়ালু।” অতঃপর পিতা ইয়াকুব (আ.)-এর সাথে মিলিত হয়ে তাঁর শৈশবের স্বপ্ন সত্য হলো।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Hidden Mercy Inside Painful Twists: Every setback in Yusuf's life was actually an essential stepping stone — the well led to Egypt, the palace led to learning governance, the prison connected him to the King's cupbearer, and the cupbearer led him to the throne! Allah's plan works quietly behind the scenes even when life feels dark.
                2. "Sabrun Jamil" (Beautiful Patience): Defined by scholars as patience without complaining to creation — turning your grief directly to Allah ("I only complain of my suffering and grief to Allah," Quran 12:86).
                3. Choosing Purity in Secret: Yusuf is among the seven shaded beneath Allah's Throne on Judgment Day because he feared Allah when nobody was watching. Notice also how Prophet Muhammad ﷺ quoted Yusuf's exact words ("La tathriba alaykumul-yawm") when forgiving Makkah!
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. কষ্টের ভেতরেই লুকানো রহমত: ইউসুফ (আ.)-এর প্রতিটি বিপদ ছিল তাঁর উন্নতির সিঁড়ি—কূপ তাঁকে মিশরে নিয়ে গেল, কারাগার তাঁকে বাদশাহর দরবারে পৌঁছে দিল! আল্লাহর পরিকল্পনা সব সময় নিখুঁতভাবে কাজ করে।
                ২. সবরে জামীল (উত্তম ধৈর্য): মানুষের কাছে অভিযোগ না করে কেবল আল্লাহর কাছেই নিজের ব্যথা প্রকাশ করা।
                ৩. গোপন তাকওয়া ও মহাক্ষমা: নির্জনে গুনাহ থেকে বেঁচে থাকার কারণেই আল্লাহ তাঁকে বিশ্বজোড়া সম্মান দিলেন। আর মক্কা বিজয়ের দিন নবী মুহাম্মদ ﷺ ইউসুফ (আ.)-এর সেই ক্ষমার বাণীই উচ্চারণ করেছিলেন!
            """.trimIndent(),
            keyVerseOrHadithEn = "\"Indeed, he who fears Allah and is patient — then indeed, Allah does not allow the reward of the doers of good to be lost.\" — Quran 12:90",
            keyVerseOrHadithBn = "“নিশ্চয়ই যে ব্যক্তি তাকওয়া অবলম্বন করে ও ধৈর্য ধরে, আল্লাহ সৎকর্মশীলদের প্রতিদান কখনো বিনষ্ট করেন না।” — কুরআন ১২:৯০",
            lessonEn = "Stay pure when nobody is watching, trust Allah's hidden wisdom during dark seasons, and choose noble forgiveness even when you hold the power to retaliate.",
            lessonBn = "নির্জনেও পবিত্র থাকুন, অন্ধকার সময়ে আল্লাহর পরিকল্পনার ওপর আস্থা রাখুন এবং ক্ষমতা থাকা সত্ত্বেও ক্ষমার মহত্ত্ব দেখান।",
            sourceRef = "Quran 12:1–101 • Surah Yusuf",
            sourceUrl = "https://quran.com/12/90"
        ),
        NarratedIslamicStory(
            id = "story_07_ayyub_patience",
            categoryEn = "Steadfast Prophets",
            categoryBn = "ধৈর্যশীল নবীগণ",
            titleEn = "Prophet Ayyub (AS) — Unbroken Gratitude in 18 Years of Trial",
            titleBn = "নবী আইয়ুব (আ.) — দীর্ঘ ১৮ বছরের পরীক্ষায় অটল শুকরিয়া",
            arabicName = "أيوب عليه السلام",
            arabicNameTransliteration = "Ayyub Alayhis Salam",
            eraOrder = 7,
            eraLabelEn = "Era 7 • Model of Endurance & Healing",
            eraLabelBn = "অধ্যায় ৭ • ধৈর্য ও আরোগ্যের আদর্শ",
            estimatedReadMinutes = 5,
            storyEn = """
                Prophet Ayyub (AS) was once blessed with extraordinary abundance — vast flocks, fertile orchards, a large loving family, and radiant health — and he used every blessing to feed the poor, shelter orphans, and thank Allah constantly. Then, as a profound test of devotion, Allah gradually stripped away his wealth, his children, and finally his physical health, afflicting him with a severe, agonizing skin illness that lasted for eighteen long years (as recorded in authentic narrations cited by Ibn Kathir).

                One by one, old friends and neighbors drifted away until only his devoted wife remained at his side, working tirelessly day after day to earn their bread and nurse him with tenderness. Despite relentless pain, Ayyub's heart and tongue remained completely soaked in gratitude and Dhikr. When his wife gently asked him to supplicate for relief, Ayyub replied with astonishing fairness: "I lived in ease and health for seventy years; am I not ashamed before Allah to complain before my hardship even equals the years of His blessings?"

                Only when the illness grew so severe that it threatened to hinder his remembrance of Allah did he turn to his Lord with the most refined etiquette (Adab) ever spoken in supplication: "Anni massaniyad-durru wa Anta Arhamur-Rahimin — Indeed, adversity has touched me, and You are the Most Merciful of the merciful." Notice he did not even demand a cure or ask "Why me?" — he simply placed his fragility before Allah's infinite mercy.

                Instantly, Allah answered: "Strike the ground with your foot; this is a cool spring for bathing and for drinking." As Ayyub washed and drank from the miraculous spring, every trace of illness vanished, his youthful vigor returned, and Allah restored his family and doubled his blessings — even showering him with golden locusts as a joyful gift of divine generosity.
            """.trimIndent(),
            storyBn = """
                নবী আইয়ুব (আ.) একসময় বিপুল সম্পদ, সন্তানসন্ততি ও সুস্বাস্থ্যের অধিকারী ছিলেন এবং তাঁর সমস্ত নিয়ামত গরিব-এতিমদের সেবায় ব্যয় করতেন। অতঃপর কঠিন পরীক্ষার মাধ্যমে একে একে তাঁর সম্পদ, সন্তান এবং অবশেষে শারীরিক সুস্থতা চলে গেল। বিশুদ্ধ বর্ণনা অনুযায়ী দীর্ঘ আঠারো বছর তিনি তীব্র অসুস্থতায় ভুগেছিলেন।

                আত্মীয়স্বজন ও প্রতিবেশীরা একে একে দূরে সরে গেল, কেবল তাঁর পরম অনুগত স্ত্রী দিনরাত পরিশ্রম করে তাঁর সেবা করে গেলেন। অসহ্য যন্ত্রণার মাঝেও আইয়ুব (আ.)-এর জিহ্বা কখনো আল্লাহর বিরুদ্ধে অভিযোগ করেনি। স্ত্রী আরোগ্যের জন্য দুআ করতে বললে তিনি বললেন: “আমি সত্তর বছর সুখ ও সুস্থতায় কাটিয়েছি; তার তুলনায় অল্প কয়েক বছরের কষ্টেই কি আমি আল্লাহর কাছে অভিযোগ করতে লজ্জা পাব না?”

                অবশেষে অসুস্থতা যখন তাঁর ইবাদত ও যিকিরে বাধা সৃষ্টি করতে লাগল, তখন তিনি চরম বিনয় ও আদবের সাথে দুআ করলেন: “আন্নী মাসসানিআদ-দুররু ওয়া আনতা আরহামুর রাহিমীন—আমাকে কষ্ট স্পর্শ করেছে, আর আপনি তো সর্বশ্রেষ্ঠ দয়ালু।” তিনি ‘কেন আমাকে দিলেন’ বলেননি, কেবল নিজের অসহায়ত্ব দয়ালু রবের সামনে তুলে ধরলেন।

                সাথে সাথেই আল্লাহ আদেশ দিলেন: “তোমার পা দিয়ে মাটিতে আঘাত করো; এই হলো গোসল ও পান করার শীতল ঝরনা।” সেই পানিতে গোসল ও পান করার সাথে সাথে তাঁর সম্পূর্ণ সুস্থতা ফিরে এল, এবং আল্লাহ তাঁর পরিবার ও সম্পদ দ্বিগুণ করে ফিরিয়ে দিলেন।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. The Etiquette (Adab) of Making Dua in Pain: Ayyub's dua teaches us how to speak to Allah when exhausted: state your need honestly without anger, and praise Allah's mercy ("Anta Arhamur-Rahimin"). Notice Allah praised him directly in the Quran: "Indeed, We found him patient. An excellent servant!" (38:44).
                2. Loyalty in Marriage: Ayyub's wife is celebrated across Islamic scholarship for honoring her husband during poverty and illness — reminding families that true love shines brightest during hardship, not only in prosperity.
                3. Remembering Past Blessings: Comparing temporary hardship against decades of health, eyesight, breath, and love transforms resentment into resilience.
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. কষ্টে দুআর সর্বোচ্চ আদব: আইয়ুব (আ.)-এর দুআ শেখায়—অভিযোগ নয়, বরং নিজের দুর্বলতা স্বীকার করে আল্লাহর দয়ার প্রশংসা করাই সবচেয়ে দ্রুত কবুল হওয়ার মাধ্যম।
                ২. দাম্পত্যের বিশ্বস্ততা: দারিদ্র্য ও অসুস্থতায় আইয়ুব (আ.)-এর স্ত্রীর ত্যাগ মুসলিম পরিবারগুলোর জন্য অনন্য আদর্শ।
                ৩. পূর্বের নিয়ামত স্মরণ: কঠিন সময়ে বিগত বছরের সুস্থতা ও অনুগ্রহের কথা ভাবলে হৃদয়ে ধৈর্য ও কৃতজ্ঞতা জাগে।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"Indeed, adversity has touched me, and You are the Most Merciful of the merciful.\" — Quran 21:83",
            keyVerseOrHadithBn = "“নিশ্চয়ই আমাকে দুঃখ-কষ্ট স্পর্শ করেছে, আর আপনি তো সর্বশ্রেষ্ঠ দয়ালু।” — কুরআন ২১:৮৩",
            lessonEn = "Speak to Allah about your pain with hope and reverence — long seasons of healing are never wasted in the sight of Arhamur-Rahimin.",
            lessonBn = "কষ্টের কথা আল্লাহর কাছেই বিনয় ও আশার সাথে বলুন—দীর্ঘ পরীক্ষাতেও তাঁর দয়ার প্রতি আস্থা হারাবেন না।",
            sourceRef = "Quran 21:83–84 • 38:41–44 • Sahih al-Bukhari 279",
            sourceUrl = "https://quran.com/21/83"
        ),
        NarratedIslamicStory(
            id = "story_08_musa_sea",
            categoryEn = "Age of Bani Isra'il",
            categoryBn = "বনি ইসরাইলের যুগ",
            titleEn = "Prophet Musa (AS) — From the Nile River to Parting the Red Sea",
            titleBn = "নবী মূসা (আ.) — নীলনদের ভেলা থেকে লোহিত সাগর বিভাজন",
            arabicName = "موسى كليم الله عليه السلام",
            arabicNameTransliteration = "Musa Kalimullah Alayhis Salam",
            eraOrder = 8,
            eraLabelEn = "Era 8 • Deliverance From Pharaoh",
            eraLabelBn = "অধ্যায় ৮ • ফেরাউন থেকে মুক্তি",
            estimatedReadMinutes = 7,
            storyEn = """
                No prophet is mentioned more frequently in the Quran than Prophet Musa (AS), Kalimullah — the one to whom Allah spoke directly. Born in Egypt during Pharaoh's brutal decree to slaughter every newborn Israelite boy, Allah inspired Musa's mother with a breathtaking act of faith: place her infant inside a woven basket and cast it into the Nile River, trusting Allah's promise that He would return him to her arms and make him a Messenger.

                By divine irony, the river carried baby Musa straight into Pharaoh's own palace! Pharaoh's righteous wife Asiyah (RA) fell instantly in love with the child and persuaded Pharaoh to adopt him. Refusing every royal wet nurse, baby Musa only accepted milk from his own biological mother — fulfilling Allah's promise the very same day! Grown into a courageous young man, Musa later spent ten years in Madyan before witnessing a radiant fire on Mount Tur, where Allah called him directly: "Indeed, I am Allah. There is no deity except Me, so worship Me and establish prayer for My remembrance."

                Sent back alongside his brother Harun (AS) to confront the most arrogant tyrant on earth, Musa presented clear miracles — his staff transforming into a living serpent, his hand shining with pure white light — and called Pharaoh gently to free the oppressed and worship Allah. Pharaoh responded with torture, mockery, and arrogance, proclaiming himself supreme lord.

                Finally, Allah commanded Musa to lead Bani Isra'il out of Egypt by night. At sunrise, they stood completely cornered: the roaring Red Sea stretched endlessly ahead, while Pharaoh's massive armored army thundered down from behind. Panic erupted among the followers: "Inna lamudrakun — Indeed, we are surely overtaken!" Standing calm with towering certainty, Musa answered: "Kalla! Inna ma'iya Rabbi sayahdin — Never! Indeed, with me is my Lord; He will guide me!" Allah immediately commanded him to strike the sea with his staff. Instantly, the ocean parted into twelve dry roadways flanked by towering mountain-like walls of water. Musa and the believers crossed safely to freedom, while Pharaoh's pursuing army was swallowed by the returning sea — preserved as an eternal warning against tyranny.
            """.trimIndent(),
            storyBn = """
                কুরআনে সবচেয়ে বেশি আলোচিত নবী হলেন মূসা (আ.), কালীমুল্লাহ—যাঁর সাথে মহান আল্লাহ সরাসরি কথা বলেছেন। মিশরের জালিম শাসক ফেরাউন যখন বনি ইসরাইলের সকল নবজাতক পুত্রসন্তান হত্যার নির্দেশ দিল, আল্লাহ মূসা (আ.)-এর মাকে ওহী করলেন শিশুটিকে বাক্সে ভরে নীলনদে ভাসিয়ে দিতে এবং প্রতিশ্রুতি দিলেন যে তিনি তাঁকে ফিরিয়ে দেবেন ও রাসূল বানাবেন।

                আল্লাহর অদ্ভুত পরিকল্পনায় সেই বাক্স ফেরাউনের প্রাসাদেই পৌঁছাল! ফেরাউনের পুণ্যবতী স্ত্রী আসিয়া (রা.) শিশুটিকে দেখে মায়ায় পড়ে গেলেন। কোনো ধাত্রীর দুধ পান না করায় শেষ পর্যন্ত মূসা (আ.)-এর নিজ মাকেই দুধমা হিসেবে নিয়োগ দেওয়া হলো—সেদিনই আল্লাহর প্রতিশ্রুতি পূর্ণ হলো! যৌবনে মাদইয়ানে দশ বছর কাটানোর পর তূর পাহাড়ে আল্লাহ সরাসরি মূসা (আ.)-কে নবুওয়াত দান করলেন এবং ভাই হারুন (আ.)-কে সাথে নিয়ে ফেরাউনকে সত্যের দাওয়াত দেওয়ার নির্দেশ দিলেন।

                অবশেষে আল্লাহর নির্দেশে রাতের আঁধারে মূসা (আ.) বনি ইসরাইলকে নিয়ে মিশর ত্যাগ করলেন। ভোরবেলা তাঁরা চরম সংকটে পড়লেন: সামনে উত্তাল লোহিত সাগর, পেছনে ফেরাউনের বিশাল সশস্ত্র বাহিনী! ভয়ে লোকেরা চিৎকার করে উঠল: “আমরা তো ধরা পড়ে গেলাম!” কিন্তু মূসা (আ.) অটল বিশ্বাসে ঘোষণা করলেন: “কখনোই নয়! নিশ্চয়ই আমার রব আমার সাথে আছেন, তিনিই আমাকে পথ দেখাবেন!”

                আল্লাহর আদেশে লাঠির আঘাতে সাগর দ্বিখণ্ডিত হয়ে গেল; দুই পাশে পাহাড়ের মতো পানির দেয়াল দাঁড়িয়ে শুকনো পথ খুলে গেল। মূসা (আ.) ও মুমিনরা নিরাপদে পার হয়ে গেলেন, আর পেছনে ধাওয়া করা ফেরাউন ও তার বাহিনী সেই সাগরেই ডুবে ধ্বংস হলো।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. "With Me Is My Lord; He Will Guide Me": Notice Musa did NOT know how Allah would save them when he spoke those words (Quran 26:62) — he did not know the sea would split! Real Yaqin (certainty) is trusting Allah BEFORE seeing the escape route.
                2. The Courage of Four Righteous Women: Surah Al-Qasas highlights how Allah preserved Musa through four heroic women: his mother, his sister Maryam who bravely followed the basket, Queen Asiyah who stood up to Pharaoh, and Shu'ayb's modest daughter in Madyan.
                3. Ashura Fasting: The Prophet Muhammad ﷺ fasted the 10th of Muharram (Ashura) in joyful gratitude for Allah's rescue of Prophet Musa (AS), demonstrating the eternal brotherhood of all Prophets.
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. পথ না দেখেই অটল ভরসা: মূসা (আ.) যখন বললেন “আমার রব আমার সাথে আছেন”, তখনও তিনি জানতেন না সাগর দুভাগ হবে! কোনো উপায় না দেখেও আল্লাহর ওপর বিশ্বাস রাখাই প্রকৃত ইয়াকীন।
                ২. পুণ্যবতী নারীদের ভূমিকা: মূসা (আ.)-এর মা, বোন এবং ফেরাউনের স্ত্রী আসিয়া (রা.)-এর সাহস ও প্রজ্ঞা ইসলামের ইতিহাসে উজ্জ্বল হয়ে আছে।
                ৩. আশুরার রোজা: মূসা (আ.)-এর মুক্তির শুকরিয়া হিসেবে নবী মুহাম্মদ ﷺ ১০ই মহররম রোজা রেখেছেন, যা সকল নবীর ভ্রাতৃত্বের প্রমাণ।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"He said, 'No! Indeed, with me is my Lord; He will guide me.'\" — Quran 26:62",
            keyVerseOrHadithBn = "“তিনি বললেন, কখনোই নয়! নিশ্চয়ই আমার রব আমার সাথে আছেন, তিনিই আমাকে পথ দেখাবেন।” — কুরআন ২৬:৬২",
            lessonEn = "Certainty in Allah does not mean seeing the exit first — it means trusting He can split an entire ocean where no path existed.",
            lessonBn = "আল্লাহর ওপর ভরসার অর্থ হলো—সামনে কোনো পথ দেখা না গেলেও বিশ্বাস রাখা যে তিনি সাগরের বুকেও পথ তৈরি করে দিতে পারেন।",
            sourceRef = "Quran 26:61–66 • 28:7–13 • Sahih al-Bukhari 2004",
            sourceUrl = "https://quran.com/26/62"
        ),
        NarratedIslamicStory(
            id = "story_09_dawud_sulayman",
            categoryEn = "Prophet-Kings",
            categoryBn = "নবী-বাদশাহদের যুগ",
            titleEn = "Prophets Dawud & Sulayman (AS) — Power Grounded in Gratitude",
            titleBn = "নবী দাউদ ও সুলাইমান (আ.) — বিশাল ক্ষমতার মাঝে বিনয় ও শুকরিয়া",
            arabicName = "داود وسليمان عليهما السلام",
            arabicNameTransliteration = "Dawud wa Sulayman Alayhimas Salam",
            eraOrder = 9,
            eraLabelEn = "Era 9 • Kingdom of Humility & Justice",
            eraLabelBn = "অধ্যায় ৯ • কৃতজ্ঞ নেতৃত্ব",
            estimatedReadMinutes = 6,
            storyEn = """
                As a young shepherd armed with nothing more than a sling and unshakable faith in Allah, Dawud (AS) defeated the feared giant Jalut (Goliath), proving that victory belongs to sincere courage rather than sheer size. Allah honored Prophet Dawud (AS) with both prophethood and a just kingdom, revealed the Zabur (Psalms) to him, softened iron in his hands like wax so he could craft armor and earn his living by his own manual labor, and granted him a voice so melodious that mountains and wild birds stopped to echo his Tasbih every dawn and dusk.

                His son, Prophet Sulayman (AS), inherited wisdom and asked Allah for a kingdom unmatched after him — not for ego, but to showcase Allah's majesty and establish justice across the earth. Allah subjected the roaring winds to carry him across vast distances, commanded the Jinn to construct grand sanctuaries under his oversight, and taught him the speech of birds and even the smallest insects.

                One day, as Sulayman marched with his immense, disciplined army of humans, jinn, and birds across the Valley of the Ants, his miraculous hearing caught the anxious voice of a single tiny ant warning its colony: "O ants, enter your dwellings so that Sulayman and his soldiers do not crush you while they do not even realize!" Hearing the ant's concern — and even its fairness in excusing his soldiers ("while they do not perceive") — the mighty king smiled warmly, halted with care for the tiny creatures, and immediately turned his heart upward in gratitude: "My Lord, inspire me to be grateful for Your favor which You have bestowed upon me and upon my parents, and to do righteous deeds that please You."

                Later, when the Hoopoe bird brought news of Queen Bilqis of Saba (Sheba) and her sun-worshiping people, Sulayman invited her with dignity, wisdom, and grace rather than bloodshed. Witnessing the miracle of her throne brought in the blink of an eye and the purity of his message, Queen Bilqis declared with full conviction: "My Lord, indeed I have wronged myself, and I submit with Sulayman to Allah, Lord of the worlds."
            """.trimIndent(),
            storyBn = """
                কিশোর রাখাল হিসেবে কেবল একটি গুলতি ও আল্লাহর ওপর অটল ঈমান নিয়ে দাউদ (আ.) শক্তিশালী জালুতকে পরাজিত করেন। আল্লাহ তাঁকে নবুওয়াত, ন্যায়পরায়ণ রাষ্ট্রক্ষমতা এবং যাবূর কিতাব দান করেন। তাঁর হাতে লোহা মোমের মতো নরম করে দেওয়া হয়েছিল যাতে তিনি নিজ হাতে বর্ম তৈরি করে হালাল উপার্জন করতে পারেন। আর তাঁকে এমন মধুর কণ্ঠ দেওয়া হয়েছিল যে সকাল-সন্ধ্যায় পাহাড় ও পাখিরা তাঁর সাথে আল্লাহর তাসবিহ পাঠ করত।

                তাঁর পুত্র নবী সুলাইমান (আ.)-কে আল্লাহ এমন অনন্য সাম্রাজ্য দান করলেন যা পরে আর কাউকে দেওয়া হয়নি। বাতাস তাঁর অনুগত ছিল, জিন জাতি তাঁর অধীনে স্থাপনা নির্মাণ করত এবং তিনি পাখি ও পিঁপড়ার ভাষাও বুঝতে পারতেন।

                একদিন মানুষ, জিন ও পাখিদের বিশাল বাহিনী নিয়ে পিঁপড়ার উপত্যকা অতিক্রম করার সময় তিনি একটি ক্ষুদ্র পিঁপড়ার কথা শুনতে পেলেন—সে তার সঙ্গীদের বলছে: “হে পিঁপড়ারা, তোমাদের গর্তে ঢুকে যাও, যেন সুলাইমান ও তাঁর বাহিনী অজান্তে তোমাদের পায়ের নিচে পিষ্ট না করে!” ক্ষুদ্র পিঁপড়ার এই সচেতনতা ও সুন্দর ধারণা শুনে মহাপরাক্রমশালী বাদশাহ মুচকি হাসলেন, বাহিনীকে সতর্ক করলেন এবং তৎক্ষণাৎ বিনয়ে দুআ করলেন: “হে আমার রব, আমাকে আপনার নিয়ামতের শুকরিয়া আদায় করার ও আপনার সন্তুষ্টিমূলক সৎকর্ম করার তাওফিক দিন।”

                পরবর্তীতে হুদহুদ পাখির মাধ্যমে সাবার রাণী বিলকীসের সংবাদ পেয়ে তিনি রক্তপাত ছাড়াই প্রজ্ঞা ও মর্যাদার সাথে তাঁকে তাওহীদের দাওয়াত দিলেন। তাঁর সত্যনিষ্ঠা ও মুজিযা দেখে রাণী বিলকীস ইসলাম গ্রহণ করে ঘোষণা করলেন: “আমি সুলাইমানের সাথে বিশ্বজগতের প্রতিপালক আল্লাহর কাছে আত্মসমর্পণ করলাম।”
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Earning With One's Own Hands: Prophet Muhammad ﷺ praised Dawud (AS) in Sahih al-Bukhari (2072), saying the best food anyone eats is from the labor of their own hands — even as a king, Dawud forged armor to avoid taking from the public treasury.
                2. "This Is From the Favor of My Lord": When Sulayman saw Bilqis's throne materialize instantly, he did NOT say "Look at my power!" — he said: "Haza min fadli Rabbi li-yabluwani a-ashkuru am akfur" (This is from the grace of my Lord to test whether I am grateful or ungrateful — Quran 27:40). Wealth and success are just as much a test as poverty.
                3. Mercy Toward the Smallest Life: Halting an empire for a single ant teaches Islamic environmental ethics and compassionate leadership.
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. নিজ হাতে হালাল উপার্জন: সহীহ বুখারী (২০৭২)-এ নবীজি ﷺ দাউদ (আ.)-এর প্রশংসা করে বলেন—নিজ হাতের উপার্জিত খাদ্যই সর্বশ্রেষ্ঠ; বাদশাহ হয়েও তিনি নিজ শ্রমে জীবিকা নির্বাহ করতেন।
                ২. সাফল্যও একটি পরীক্ষা: চোখের পলকে বিলকীসের সিংহাসন উপস্থিত হতে দেখে সুলাইমান (আ.) অহংকার না করে বললেন—“এটি আমার রবের অনুগ্রহ, আমাকে পরীক্ষা করার জন্য যে আমি কৃতজ্ঞ হই না অকৃতজ্ঞ” (কুরআন ২৭:৪০)।
                ৩. ক্ষুদ্র প্রাণীর প্রতি দয়া: একটি পিঁপড়ার জন্য বিশাল সেনাবাহিনীকে সতর্ক করা ইসলামের মানবিক ও পরিবেশবান্ধব নেতৃত্বের শ্রেষ্ঠ নিদর্শন।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"My Lord, enable me to be grateful for Your favor which You have bestowed upon me and upon my parents.\" — Quran 27:19",
            keyVerseOrHadithBn = "“হে আমার রব, আমাকে তাওফিক দিন যাতে আমি আপনার নিয়ামতের শুকরিয়া আদায় করতে পারি।” — কুরআন ২৭:১৯",
            lessonEn = "True greatness never forgets the smallest creature — every promotion, talent, or victory is a test of your humility and gratitude.",
            lessonBn = "প্রকৃত মহত্ত্ব কখনো ক্ষুদ্রতম প্রাণীকেও অবহেলা করে না—প্রতিটি সাফল্য বিনয় ও কৃতজ্ঞতা বাড়ানো উচিত।",
            sourceRef = "Quran 27:15–44 • 34:10–13 • Sahih al-Bukhari 2072",
            sourceUrl = "https://quran.com/27/19"
        ),
        NarratedIslamicStory(
            id = "story_10_yunus_whale",
            categoryEn = "Stories of Prophets",
            categoryBn = "নবীদের কাহিনী",
            titleEn = "Prophet Yunus (AS) — The Rescue From Three Layers of Darkness",
            titleBn = "নবী ইউনুস (আ.) — তিন স্তরের অন্ধকার থেকে মুক্তির দুআ",
            arabicName = "يونس ذو النون عليه السلام",
            arabicNameTransliteration = "Yunus Dhun-Nun Alayhis Salam",
            eraOrder = 10,
            eraLabelEn = "Era 10 • Call of Nineveh & Deep Tawbah",
            eraLabelBn = "অধ্যায় ১০ • নিনাওয়া ও গভীর তাওবা",
            estimatedReadMinutes = 6,
            storyEn = """
                Allah sent Prophet Yunus (AS) to the great city of Nineveh (modern-day Mosul, Iraq), whose population of over 100,000 people was deeply immersed in idolatry and corruption. For years Yunus preached tirelessly, warning them of Allah's impending punishment if they refused to repent. Exhausted by their stubborn rejection, Yunus departed the city in frustration — without waiting for Allah's explicit permission to leave.

                Meanwhile, dark clouds of impending punishment gathered over Nineveh. Realizing Yunus had spoken the truth, the entire city — men, women, and children — poured out into the open plains weeping, abandoning their idols, and begging Allah for mercy. In a unique miracle of history, Allah lifted the punishment completely from all 100,000+ inhabitants because of their sincere repentance!

                Unaware of his people's sudden faith, Yunus boarded a heavily loaded ship. Mid-voyage, a violent storm battered the vessel, threatening to sink everyone aboard. Following maritime custom, the crew cast lots to lighten the load — and three times in a row, the lot fell upon Prophet Yunus (AS). Recognizing Allah's decree, he leapt into the raging sea, where Allah commanded a colossal whale to swallow him whole without crushing a single bone or tearing his flesh.

                Inside the pitch-black abyss — trapped beneath three suffocating layers of darkness: the darkness of night, the darkness of the deep ocean, and the darkness of the whale's belly — Yunus heard even the tiny pebbles of the ocean floor glorifying Allah. Without blaming his people, the storm, or anyone else, he whispered the most liberating prayer in times of grief: "La ilaha illa Anta, Subhanaka inni kuntu minaz-zalimin — There is no deity except You; exalted are You. Indeed, I have been of the wrongdoers." The Angels recognized his familiar, faithful voice rising from the deep. Because he had always been among those who glorified Allah in times of ease (Quran 37:143), Allah commanded the whale to gently carry him to a quiet shore, grew a healing gourd tree (Yaqtin) to shade and nourish him, and returned him to Nineveh to witness over 100,000 believers joyfully welcoming their prophet home!
            """.trimIndent(),
            storyBn = """
                মহান আল্লাহ নবী ইউনুস (আ.)-কে এক লক্ষাধিক মানুষের বিশাল শহর নিনাওয়ায় (বর্তমান ইরাকের মসুল অঞ্চল) প্রেরণ করেছিলেন। বহু বছর দাওয়াত দেওয়ার পরও অধিবাসীরা অবাধ্যতায় অটল থাকায় তিনি হতাশ হয়ে আল্লাহর অনুমতির অপেক্ষা না করেই শহর ছেড়ে চলে যান।

                এদিকে তাঁর চলে যাওয়ার পর আজাবের কালো মেঘ ঘনিয়ে এলে নিনাওয়ার সকল মানুষ—নারী, পুরুষ ও শিশু—খোলা প্রান্তরে বেরিয়ে এসে মূর্তি ভেঙে কাঁদতে কাঁদতে আল্লাহর কাছে তাওবা করল। ইতিহাসের অনন্য দৃষ্টান্ত হিসেবে আল্লাহ এক লক্ষাধিক মানুষের সেই আন্তরিক তাওবা কবুল করে আজাব সরিয়ে নিলেন!

                অন্যদিকে ইউনুস (আ.) একটি বোঝাই জাহাজে উঠলে মাঝসমুদ্রে প্রচণ্ড ঝড় শুরু হয়। ভার কমাতে লটারি করা হলে পরপর তিনবার ইউনুস (আ.)-এর নাম উঠে এল। আল্লাহর ফায়সালা মেনে তিনি সাগরে ঝাঁপ দিলে আল্লাহর আদেশে এক বিশাল তিমি তাঁকে অক্ষত অবস্থায় গিলে ফেলল।

                রাতের অন্ধকার, গভীর সমুদ্রের অন্ধকার এবং মাছের পেটের অন্ধকার—এই তিন স্তরের ঘোর আঁধারে আটকে পড়ে ইউনুস (আ.) কারও দোষ না দিয়ে গভীর বিনয়ে ডাকলেন: “লা ইলাহা ইল্লা আনতা সুবহানাকা ইন্নী কুনতু মিনায-যালিমীন—আপনি ছাড়া কোনো উপাস্য নেই, আপনি পবিত্র, নিশ্চয়ই আমি জালিমদের অন্তর্ভুক্ত ছিলাম।” যেহেতু তিনি সুখের দিনেও বেশি বেশি তাসবিহ পাঠ করতেন, আল্লাহ তিমিকে আদেশ দিলেন তাঁকে নিরাপদে তীরে উগরে দিতে। অতঃপর সুস্থ হয়ে নিনাওয়ায় ফিরে তিনি এক লক্ষাধিক ঈমানদারের আনন্দঘন সংবর্ধনা লাভ করলেন!
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. The Secret of Being Saved in Crisis: Surah As-Saffat (37:143–144) reveals a stunning insight: "Had he not been of those who exalt Allah [before the crisis], he would have remained inside its belly until the Day of Resurrection." Consistent Dhikr and Salah during normal, comfortable days become your lifeline during sudden emergencies!
                2. Universal Promise to Every Believer: After rescuing Yunus, Allah did not stop at his story — He added: "Wa kazalika nunjil-mu'minin — And thus do We save the believers!" (Quran 21:88). And the Prophet ﷺ confirmed in Jami' at-Tirmidhi (3505) that no Muslim calls upon Allah with the Dua of Yunus in any distress except that Allah answers them.
                3. Three Pillars of Yunus's Dua: (a) Tawhid ("La ilaha illa Anta"), (b) Glorifying Allah's perfection ("Subhanaka"), and (c) Honest humility ("Inni kuntu minaz-zalimin").
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. সুখের দিনের ইবাদতই বিপদের ঢাল: সূরা আস-সাফফাত (৩৭:১৪৩-১৪৪) জানায়—ইউনুস (আ.) যদি পূর্বে তাসবিহ পাঠকারী না হতেন, তবে কিয়ামত পর্যন্ত মাছের পেটেই থাকতেন! তাই স্বাভাবিক সময়ের নামাজ ও যিকিরই বিপদের দিনে রক্ষাকবচ হয়।
                ২. সকল মুমিনের জন্য চিরন্তন প্রতিশ্রুতি: আল্লাহ কেবল ইউনুস (আ.)-কেই নয়, বরং ঘোষণা করেছেন—“এভাবেই আমি মুমিনদের উদ্ধার করি” (কুরআন ২১:৮৮)। তিরমিযী (৩৫০৫)-এ নবীজি ﷺ বলেছেন, এই দুআ পাঠ করে কোনো মুসলিম বিপদ থেকে মুক্তি চাইলে আল্লাহ তা কবুল করেন।
                ৩. দুআর তিনটি স্তম্ভ: তাওহীদ, আল্লাহর পবিত্রতা ঘোষণা এবং নিজের ভুলের বিনীত স্বীকারোক্তি।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"There is no deity except You; exalted are You. Indeed, I have been of the wrongdoers.\" — Quran 21:87",
            keyVerseOrHadithBn = "“আপনি ছাড়া কোনো উপাস্য নেই, আপনি মহাপবিত্র; নিশ্চয়ই আমি অন্যায়কারীদের অন্তর্ভুক্ত ছিলাম।” — কুরআন ২১:৮৭",
            lessonEn = "Build your habit of Dhikr in calm days, and when life feels overwhelmingly dark, turn to the Dua of Yunus — Allah hears even from the bottom of the ocean.",
            lessonBn = "সুখের দিনে আল্লাহর যিকিরের অভ্যাস গড়ুন, আর গভীর সংকটে ইউনুস (আ.)-এর দুআয় আশ্রয় নিন—আল্লাহ গভীর অন্ধকার থেকেও ডাক শোনেন।",
            sourceRef = "Quran 21:87–88 • 37:139–148 • Tirmidhi 3505",
            sourceUrl = "https://quran.com/21/87"
        ),
        NarratedIslamicStory(
            id = "story_11_isa_mercy",
            categoryEn = "Prophet Before Final Seal",
            categoryBn = "শেষ নবীর পূর্ববর্তী নবী",
            titleEn = "Maryam & Prophet Isa (AS) — Purity, Miracles & Gentle Mercy",
            titleBn = "মারইয়াম ও নবী ঈসা (আ.) — পবিত্রতা, মুজিযা ও কোমল রহমত",
            arabicName = "مريم وعيسى عليهما السلام",
            arabicNameTransliteration = "Maryam wa Isa Alayhimas Salam",
            eraOrder = 11,
            eraLabelEn = "Era 11 • Message of Injil & Glad Tidings",
            eraLabelBn = "অধ্যায় ১১ • ইনজিল ও শেষ নবীর সুসংবাদ",
            estimatedReadMinutes = 6,
            storyEn = """
                Dedicated from birth to the service of Masjid Al-Aqsa and raised under the care of Prophet Zakariyya (AS), Maryam (AS) was chosen and purified by Allah above all women of the worlds — the only woman honored with an entire Surah named after her in the Noble Quran. Whenever Zakariyya entered her quiet sanctuary of worship, he found miraculous out-of-season fresh fruit beside her; she would calmly reply: "It is from Allah. Indeed, Allah provides for whom He wills without account."

                One day, Angel Jibril (AS) appeared before her in the form of a dignified man and delivered breathtaking news: Allah had chosen her to give birth to a pure, blessed son — Prophet Isa (AS) — by His creative word "Kun" (Be), without any human father, just as He had created Adam without father or mother. When the pains of childbirth overcame her alone beside the trunk of a dry palm tree, overwhelmed with grief at how people would falsely judge her honor, a reassuring voice called from beneath her: "Do not grieve! Your Lord has provided a stream beneath you; shake the trunk of the palm tree toward you, and it will drop fresh ripe dates upon you."

                Carrying newborn Isa back to her people, she faced shocked accusations. Following Allah's instruction, she observed a dignified vow of silence and pointed calmly to the infant in the cradle. Skeptics scoffed: "How can we speak to a child in the cradle?" Instantly, by Allah's miracle, infant Isa spoke with crystal clarity: "Inni Abdullah — Indeed, I am the servant of Allah. He has given me the Scripture (Injil), made me a prophet, blessed me wherever I am, enjoined upon me prayer and charity as long as I live, and made me dutiful to my mother."

                Throughout his earthly mission, Prophet Isa (AS) walked in gentle humility, calling people to pure Tawhid. By Allah's permission (Bi-idhnillah), he healed the blind and the leprous, breathed life into a bird of clay, and even brought the dead back to life. He also gave his followers clear glad tidings of the final Messenger to come after him, whose name would be Ahmad (Prophet Muhammad ﷺ). When enemies conspired to crucify him, Allah protected His noble Messenger and raised him honorably alive unto Himself.
            """.trimIndent(),
            storyBn = """
                জন্মের পর থেকেই মসজিদুল আকসার খেদমতে নিবেদিত এবং নবী যাকারিয়া (আ.)-এর তত্ত্বাবধানে লালিত পুণ্যবতী মারইয়াম (আ.)-কে মহান আল্লাহ সমগ্র বিশ্বের নারীদের ওপর মনোনীত করেছেন। পবিত্র কুরআনে একমাত্র তাঁর নামেই একটি পূর্ণাঙ্গ সূরা নাযিল হয়েছে।

                একদিন জিবরীল (আ.) মানবাকৃতিতে এসে তাঁকে এক পবিত্র পুত্রসন্তান—নবী ঈসা (আ.)-এর—অলৌকিক জন্মের সুসংবাদ দিলেন, যিনি পিতা ছাড়াই আল্লাহর ‘কুন’ (হও) আদেশে জন্ম নেবেন। নির্জনে একটি শুকনো খেজুর গাছের নিচে সন্তান প্রসবের যন্ত্রণায় ও মানুষের অপবাদের আশঙ্কায় তিনি ব্যথিত হলে আল্লাহ তাঁর নিচে পানির ঝরনা প্রবাহিত করে দিলেন এবং গাছ নাড়া দিতেই তাজা পাকা খেজুর ঝরে পড়ল।

                সদ্যোজাত শিশুকে কোলে নিয়ে লোকালয়ে ফিরলে মানুষ বিস্ময়ে অপবাদ দিতে লাগল। আল্লাহর আদেশে মারইয়াম (আ.) চুপ থেকে দোলনার দিকে ইশারা করলেন। সাথে সাথেই শিশু ঈসা (আ.) আল্লাহর মুজিযায় স্পষ্ট ভাষায় বলে উঠলেন: “ইন্নী আবদুল্লাহ—নিশ্চয়ই আমি আল্লাহর বান্দা! তিনি আমাকে কিতাব (ইনজিল) দিয়েছেন, নবী করেছেন, নামাজ ও যাকাতের আদেশ দিয়েছেন এবং আমার মায়ের প্রতি অনুগত করেছেন।”

                নবী ঈসা (আ.) মানুষকে এক আল্লাহর ইবাদতের দিকে ডাকলেন, আল্লাহর অনুমতিক্রমে জন্মান্ধ ও কুষ্ঠরোগী সুস্থ করলেন এবং তাঁর পর আগমনকারী শেষ নবী আহমদ (মুহাম্মদ ﷺ)-এর সুসংবাদ দিলেন। শত্রুরা তাঁকে শূলে চড়ানোর ষড়যন্ত্র করলে আল্লাহ তাঁকে রক্ষা করে সশরীরে আসমানে তুলে নিলেন।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Clarity of Tawhid From the Cradle: Notice the very first sentence infant Isa (AS) spoke was "Inni Abdullah" (Indeed, I am the servant of Allah — Quran 19:30), protecting his true identity as a noble Messenger of Allah, not a deity or son of God.
                2. Shake the Palm Tree (Divine Help Meets Human Effort): A woman in childbirth could never physically shake a massive date palm tree hard enough to drop fruit — yet Allah still asked her to reach out and try, teaching that Allah loves seeing our sincere effort even when the miracle is 100% His!
                3. Honoring Mothers: Alongside Salah and Zakah, Isa highlighted being "dutiful and gentle to my mother" — underscoring the towering rank of mothers in Islam.
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. দোলনা থেকেই তাওহীদের ঘোষণা: শিশু ঈসা (আ.)-এর প্রথম বাক্যই ছিল “আমি আল্লাহর বান্দা”—যা তাঁর নবুওয়াত ও তাওহীদের পরিচয় চিরতরে স্পষ্ট করে দিয়েছে।
                ২. খেজুর গাছ নাড়া দেওয়ার প্রজ্ঞা: প্রসূতি নারীর সামান্য স্পর্শে বিশাল খেজুর গাছ নড়ার কথা নয়, তবুও আল্লাহ তাঁকে হাত বাড়াতে বলেছিলেন—যাতে বান্দা বোঝে, রহমত আল্লাহর হলেও চেষ্টার সূচনা বান্দার পক্ষ থেকেই হতে হয়।
                ৩. মায়ের প্রতি সদাচরণ: নামাজ ও যাকাতের সাথেই মায়ের প্রতি আনুগত্যের উল্লেখ ইসলামে মায়ের সর্বোচ্চ মর্যাদা প্রকাশ করে।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"[Isa] said, 'Indeed, I am the servant of Allah. He has given me the Scripture and made me a prophet.'\" — Quran 19:30",
            keyVerseOrHadithBn = "“ঈসা (আ.) বললেন, নিশ্চয়ই আমি আল্লাহর বান্দা। তিনি আমাকে কিতাব দিয়েছেন এবং আমাকে নবী করেছেন।” — কুরআন ১৯:৩০",
            lessonEn = "Allah defends the honor of the sincere in ways human minds cannot imagine — take the first small step of effort and watch His mercy unfold.",
            lessonBn = "আল্লাহ সত্যনিষ্ঠ বান্দাদের সম্মান অকল্পনীয়ভাবে রক্ষা করেন—আপনি সামান্য চেষ্টার হাত বাড়ালেই তাঁর অসীম রহমত নেমে আসে।",
            sourceRef = "Quran 19:16–36 • 3:42–55 • 61:6",
            sourceUrl = "https://quran.com/19/30"
        ),
        NarratedIslamicStory(
            id = "story_12_hira_khadijah",
            categoryEn = "Prophetic Seerah",
            categoryBn = "সীরাতুন নবী ﷺ",
            titleEn = "Cave Hira & Khadijah (RA) — The Dawn of Revelation ('Iqra')",
            titleBn = "হেরা গুহা ও খাদীজা (রা.) — প্রথম ওহী ও ভালোবাসাময় সাহস",
            arabicName = "اقرأ باسم ربك • خديجة رضي الله عنها",
            arabicNameTransliteration = "Iqra bismi Rabbik • Khadijah Radiyallahu Anha",
            eraOrder = 12,
            eraLabelEn = "Era 12 • 610 CE • First Revelation",
            eraLabelBn = "অধ্যায় ১২ • ৬১০ খ্রি. • প্রথম ওহী",
            estimatedReadMinutes = 6,
            storyEn = """
                Before prophethood ever began, Muhammad ﷺ was already beloved across Makkah as "As-Sadiq Al-Amin" — the Truthful and the Trustworthy. Deeply pained by the idol worship, injustice toward orphans, and moral decay around him, he began retreating during the blessed month of Ramadan to the silent heights of Cave Hira atop Jabal an-Nur, spending nights in reflection and worship of the One True God of Ibrahim.

                On a sacred night in Ramadan (Laylatul-Qadr, 610 CE), when he was forty years old, Angel Jibril (AS) appeared inside the cave and commanded: "Iqra! (Read!)" Startled, the Prophet ﷺ replied: "I cannot read." Jibril embraced him firmly until his breath tightened, released him, and commanded a second time: "Read!" Again he answered: "I cannot read." After a third embrace, Jibril recited the historic opening verses of Surah Al-Alaq: "Read in the name of your Lord who created — created man from a clinging substance. Read, and your Lord is the Most Generous — who taught by the pen, taught man that which he knew not."

                Heart pounding with the awe of receiving the Word of Allah, the Prophet ﷺ descended the mountain and hurried home to his beloved wife Khadijah bint Khuwaylid (RA), crying: "Zammiluni, zammiluni — Cover me, cover me!" She wrapped him warmly without questioning or panicking, listened gently as he feared for himself, and then spoke some of the wisest, most comforting words ever recorded in human history: "Never! By Allah, Allah will never disgrace you! Indeed, you maintain ties of kinship, you carry the burdens of the weak, you earn for the destitute, you honor your guests, and you assist those afflicted by real calamities."

                She then took him to her elderly Christian cousin Waraqah ibn Nawfal, a scholar of the ancient scriptures. Hearing what happened, Waraqah declared with awe: "This is the same Namus (Angel Jibril) whom Allah sent to Musa! I wish I were young and alive when your people drive you out!" Surprised, the Prophet ﷺ asked: "Will they really drive me out?" Waraqah replied: "Yes — never has a man brought what you have brought except that he was met with hostility." Khadijah (RA) immediately became the very first believer in Islam, dedicating her heart, wisdom, and wealth to the Prophet ﷺ until her final breath.
            """.trimIndent(),
            storyBn = """
                নবুওয়াত লাভের পূর্বেই মুহাম্মদ ﷺ মক্কায় “আস-সাদিক আল-আমীন” (সত্যবাদী ও বিশ্বস্ত) হিসেবে পরিচিত ছিলেন। সমাজের মূর্তিপূজা ও অবিচার দেখে ব্যথিত হয়ে তিনি রমজান মাসে জাবালে নূরের চূড়ায় নির্জন হেরা গুহায় গভীর ধ্যান ও ইবাদতে মগ্ন থাকতেন।

                চল্লিশ বছর বয়সে রমজানের এক মহিমান্বিত রাতে (লাইলাতুল কদরে) ফেরেশতা জিবরীল (আ.) গুহায় এসে বললেন: “ইকরা! (পড়ো!)” নবীজি ﷺ বললেন: “আমি পড়তে জানি না।” জিবরীল (আ.) তাঁকে দৃঢ়ভাবে আলিঙ্গন করে ছেড়ে দিয়ে আবার বললেন: “পড়ো!” তৃতীয়বার আলিঙ্গনের পর তিনি সূরা আলাকের প্রথম পাঁচটি আয়াত তিলাওয়াত করলেন: “পড়ো তোমার রবের নামে, যিনি সৃষ্টি করেছেন... যিনি কলমের মাধ্যমে শিক্ষা দিয়েছেন।”

                ওহীর বিশাল ভারে কম্পিত হৃদয়ে নবীজি ﷺ দ্রুত ঘরে ফিরে প্রিয়তমা স্ত্রী খাদীজা (রা.)-কে বললেন: “যাম্মিলুনী, যাম্মিলুনী—আমাকে চাদর জড়িয়ে দাও!” খাদীজা (রা.) এক মুহূর্তও বিচলিত না হয়ে তাঁকে স্নেহে জড়িয়ে ধরলেন এবং ইতিহাসের অন্যতম প্রজ্ঞাপূর্ণ সান্ত্বনা দিলেন: “কখনোই না! আল্লাহর শপথ, তিনি আপনাকে কখনো অপমানিত করবেন না। আপনি তো আত্মীয়তার সম্পর্ক বজায় রাখেন, অসহায়ের বোঝা বহন করেন, অভাবীর উপার্জন জোগান, মেহমানের সম্মান করেন এবং সত্যের পথে বিপদগ্রস্তদের সাহায্য করেন!”

                অতঃপর তিনি নবীজি ﷺ-কে প্রাচীন কিতাবের পণ্ডিত ওয়ারাকা ইবনে নওফেলের কাছে নিয়ে যান। সব শুনে ওয়ারাকা বিস্ময়ে বললেন: “ইনি তো সেই নামুস (জিবরীল), যিনি মূসা (আ.)-এর কাছে এসেছিলেন!” খাদীজা (রা.) সাথে সাথেই ইসলামের প্রথম মুমিন হয়ে আজীবন নবীজি ﷺ-এর পাশে ঢাল হয়ে ছিলেন।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Islam Begins With "Read" & "The Pen": The very first divine command to this Ummah was not a sword or a ritual — it was "Iqra" (Read/Seek Knowledge) anchored "in the Name of your Lord," uniting intellect, literacy, and spirituality.
                2. Character Predicts Destiny: Notice Khadijah's brilliant theology — she knew Allah would never abandon Muhammad ﷺ because of his consistent kindness to family, guests, and the poor. Good character (Akhlaq) is spiritual armor.
                3. The Power of an Uplifting Spouse: Khadijah (RA) received a personal Salam (greeting of peace) from Allah Himself via Jibril and a palace of pearl in Paradise where there is neither noise nor fatigue (Sahih al-Bukhari 3820).
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. ইসলামের প্রথম আদেশ ‘পড়ো’: এই উম্মতের প্রথম ওহী হলো জ্ঞানার্জন ও কলমের মর্যাদা—যা আল্লাহর নামে পরিচালিত হলে মানুষকে আলোকিত করে।
                ২. উত্তম চরিত্রই রক্ষাকবচ: খাদীজা (রা.) নবীজির পূর্ববর্তী মানবসেবা ও সচ্চরিত্রকে আল্লাহর হেফাজতের প্রমাণ হিসেবে তুলে ধরেছিলেন।
                ৩. আদর্শ জীবনসঙ্গীর মর্যাদা: খাদীজা (রা.)-এর অসাধারণ ত্যাগের কারণে স্বয়ং আল্লাহ জিবরীল (আ.)-এর মাধ্যমে তাঁকে সালাম পাঠিয়েছেন এবং জান্নাতে মুক্তার প্রাসাদের সুসংবাদ দিয়েছেন (বুখারী ৩৮২০)।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"Read in the name of your Lord who created — taught man that which he knew not.\" — Quran 96:1, 5",
            keyVerseOrHadithBn = "“পড়ো তোমার রবের নামে যিনি সৃষ্টি করেছেন—তিনি মানুষকে তা শিখিয়েছেন যা সে জানত না।” — কুরআন ৯৬:১, ৫",
            lessonEn = "Pursue beneficial knowledge in the Name of Allah, nurture noble character, and be the calm, uplifting voice of strength for the people you love.",
            lessonBn = "আল্লাহর নামে জ্ঞান অর্জন করুন, উত্তম চরিত্র গড়ে তুলুন এবং প্রিয়জনদের কঠিন মুহূর্তে সাহস ও প্রশান্তির আশ্রয় হোন।",
            sourceRef = "Quran 96:1–5 • Sahih al-Bukhari 3 • 3820",
            sourceUrl = "https://sunnah.com/bukhari:3"
        ),
        NarratedIslamicStory(
            id = "story_13_muhammad_taif",
            categoryEn = "Prophetic Seerah",
            categoryBn = "সীরাতুন নবী ﷺ",
            titleEn = "Mercy at Ta'if — Choosing Forgiveness Over Vengeance",
            titleBn = "তায়েফের রক্তাক্ত ময়দানে ক্ষমা ও দয়ার অনন্য দৃষ্টান্ত",
            arabicName = "النبي محمد ﷺ • رحمة للعالمين",
            arabicNameTransliteration = "An-Nabiyy Muhammad ﷺ • Rahmatan lil-Alamin",
            eraOrder = 13,
            eraLabelEn = "Era 13 • 619 CE • Year of Sorrow",
            eraLabelBn = "অধ্যায় ১৩ • ৬১৯ খ্রি. • তায়েফের সফর",
            estimatedReadMinutes = 6,
            storyEn = """
                The tenth year of prophethood became known as the "Year of Sorrow" (Am al-Huzn). Within weeks of each other, Prophet Muhammad ﷺ lost his two greatest earthly supports: his beloved wife Khadijah (RA) and his protective uncle Abu Talib. Persecution in Makkah escalated brutally. Hoping to find an open heart elsewhere, the Prophet ﷺ walked roughly 60 miles on foot over rugged mountain terrain to the lush city of Ta'if, accompanied only by his adopted son Zayd ibn Harithah (RA).

                For ten days he met Ta'if's leaders, gently inviting them to worship Allah alone. Not only did they arrogantly reject and mock him, they incited crowds of street youths to line both sides of the exit road and hurl stones at him as he walked away. Zayd threw his own body as a shield and was struck repeatedly on the head, while stones gashed the Prophet's ankles until his sandals filled with blood and stuck to his feet. Whenever he collapsed to rest, they pulled him up and pelted him again.

                Finally reaching the shelter of a quiet grape orchard outside the city, bleeding and exhausted, the Prophet ﷺ did not curse them. Instead, he raised his hands to heaven in one of the most tender, soul-stirring prayers ever whispered: "O Allah, to You alone I complain of my weakness, my scarcity of resources, and my insignificance before people. O Most Merciful of the merciful... If You are not angry with me, then I do not care! Your well-being is vaster for me."

                Moments later, Angel Jibril (AS) descended alongside the Angel of the Mountains, who greeted the Prophet ﷺ and said: "O Muhammad, Allah has heard what your people said to you. If you wish, I will collapse the two great mountains (Al-Akhshabayn) upon them!" In what he later told Aishah (RA) was a day harder even than the Battle of Uhud, the Messenger of Mercy ﷺ shook his head and replied: "No! Rather, I hope that Allah will bring forth from their descendants people who will worship Allah alone and associate nothing with Him." Only a decade later, the entire tribe of Ta'if accepted Islam voluntarily — and their descendants carried Islam across continents!
            """.trimIndent(),
            storyBn = """
                নবুওয়াতের দশম বছর ছিল “আমূল হুযন” বা দুঃখের বছর। অল্প ব্যবধানে নবী মুহাম্মদ ﷺ হারালেন তাঁর প্রাণপ্রিয় স্ত্রী খাদীজা (রা.) ও আশ্রয়দাতা চাচা আবু তালিবকে। মক্কায় নির্যাতন চরমে পৌঁছালে সত্যের নতুন আশ্রয় খুঁজতে তিনি কেবল যায়েদ ইবনে হারিসা (রা.)-কে সাথে নিয়ে প্রায় ষাট মাইল পাহাড়ি পথ পায়ে হেঁটে তায়েফে গমন করেন।

                দশ দিন দাওয়াত দেওয়ার পর তায়েফের নেতারা কেবল উপহাসই করল না, বরং ফেরার পথে রাস্তার দুপাশে দুর্বৃত্ত ও কিশোরদের দাঁড় করিয়ে পাথর নিক্ষেপ করাল। যায়েদ (রা.) ঢাল হয়ে দাঁড়াতে গিয়ে মাথা ফেটে রক্তাক্ত হলেন, আর পাথরের আঘাতে নবীজি ﷺ-এর পা থেকে রক্ত ঝরে জুতার সাথে জমে গেল।

                অবশেষে শহরের বাইরে এক আঙুর বাগানে আশ্রয় নিয়ে ক্ষতবিক্ষত দেহেও তিনি তাদের বিরুদ্ধে বদদুআ করলেন না; বরং আকাশের দিকে হাত তুলে হৃদয়স্পর্শী ফরিয়াদ করলেন: “হে আল্লাহ! কেবল আপনার কাছেই আমার দুর্বলতা ও মানুষের কাছে আমার অসহায়ত্বের অভিযোগ করছি... আপনি যদি আমার ওপর অসন্তুষ্ট না হন, তবে আমার কোনো পরোয়া নেই!”

                তৎক্ষণাৎ জিবরীল (আ.) ও পাহাড়ের ফেরেশতা এসে বললেন: “হে মুহাম্মদ! আপনি চাইলে দুই পাহাড় একত্র করে এই শহর পিষে দিই!” রহমতের নবী ﷺ বিনয়ে মাথা নেড়ে বললেন: “না! বরং আমি আশা করি আল্লাহ তাদের বংশধরদের মধ্য থেকে এমন মানুষ সৃষ্টি করবেন যারা কেবল এক আল্লাহর ইবাদত করবে!” মাত্র এক দশক পরেই তায়েফের গোটা জনপদ স্বেচ্ছায় ইসলাম গ্রহণ করে!
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. "If You Are Not Angry With Me, I Do Not Care": This line is the pinnacle of spiritual maturity — measuring your worth purely by Allah's pleasure, never by people's applause or rejection.
                2. Immediately Rewarded With Hope: Right after Ta'if's rejection, three extraordinary gifts followed in rapid succession: (a) a Christian servant named Addas in the orchard embraced Islam on the spot; (b) a group of Jinn listened to his night Quran recitation and accepted Islam (Surah Al-Jinn); and (c) Allah honored him with the miraculous Night Journey of Al-Isra' wal-Mi'raj!
                3. Long-Term Mercy Beats Short-Term Anger: Had he chosen revenge, generations of future believers would never have existed.
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. আল্লাহর সন্তুষ্টিই চূড়ান্ত মাপকাঠি: মানুষের প্রত্যাখ্যান নয়, আল্লাহর সন্তুষ্টিই মুমিনের প্রকৃত সফলতা।
                ২. কষ্টের পরই অকল্পনীয় পুরস্কার: তায়েফের ঠিক পরপরই বাগানের দাস আদ্দাস ইসলাম গ্রহণ করলেন, জিনদের একটি দল কুরআন শুনে মুমিন হলো, এবং আল্লাহ নবীজি ﷺ-কে ইসরা ও মেরাজের মহা সম্মান দান করলেন!
                ৩. দূরদর্শী ক্ষমা: তাৎক্ষণিক রাগ সংবরণ করার ফলেই পরবর্তীতে তায়েফের প্রজন্ম ইসলামের পতাকাবাহী হয়েছিল।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"Rather, I hope that Allah will bring forth from their descendants people who will worship Allah alone.\" — Sahih al-Bukhari 3231",
            keyVerseOrHadithBn = "“বরং আমি আশা করি আল্লাহ তাদের বংশধরদের মধ্য থেকে এমন মানুষ বের করবেন যারা এক আল্লাহর ইবাদত করবে।” — সহীহ বুখারী ৩২৩১",
            lessonEn = "Real strength is refusing vengeance at your lowest moment and answering cruelty with long-sighted mercy and reliance on Allah.",
            lessonBn = "সবচেয়ে কঠিন সময়ে রাগ সংবরণ করে ক্ষমা ও দূরদর্শী আশার পথ বেছে নেওয়াই প্রকৃত শক্তি।",
            sourceRef = "Sahih al-Bukhari 3231 • Sahih Muslim 1795",
            sourceUrl = "https://sunnah.com/bukhari:3231"
        ),
        NarratedIslamicStory(
            id = "story_14_hijrah_cave",
            categoryEn = "Prophetic Seerah & Companions",
            categoryBn = "হিজরত ও সাহাবায়ে কেরাম",
            titleEn = "The Hijrah & Cave Thawr — 'Do Not Grieve, Allah Is With Us'",
            titleBn = "হিজরত ও সাওর গুহা — 'দুঃখ করো না, আল্লাহ আমাদের সাথে আছেন'",
            arabicName = "الهجرة • أبو بكر الصديق رضي الله عنه",
            arabicNameTransliteration = "Al-Hijrah • Abu Bakr As-Siddiq Radiyallahu Anhu",
            eraOrder = 14,
            eraLabelEn = "Era 14 • 622 CE • 1 AH Hijrah",
            eraLabelBn = "অধ্যায় ১৪ • ৬২২ খ্রি. • হিজরত",
            estimatedReadMinutes = 6,
            storyEn = """
                After thirteen years of patient endurance in Makkah, the Quraysh chiefs conspired to assassinate Prophet Muhammad ﷺ in his sleep. That night, Allah granted him permission to migrate (Hijrah) to Madinah — a turning point so foundational that the Islamic Hijri calendar begins from this very event.

                Displaying masterful strategic planning alongside absolute faith, the Prophet ﷺ left young Ali ibn Abi Talib (RA) in his bed not only as a decoy, but specifically to return all valuables that even his Makkah enemies had entrusted to him for safekeeping! He selected his closest companion Abu Bakr As-Siddiq (RA), hired an expert desert guide, arranged food deliveries by Asma' bint Abi Bakr (RA — earning her title "Dhat an-Nitaqayn"), intelligence updates by Abdullah ibn Abi Bakr, and grazing sheep by Amir ibn Fuhayrah to erase their tracks. Instead of heading north toward Madinah, they walked south and climbed into the rugged Cave Thawr for three days.

                Offering a bounty of 100 camels, armed Quraysh trackers climbed right up to the narrow mouth of Cave Thawr. Inside the dim cavern, Abu Bakr saw their sandals just inches away and trembled — not for his own life, but solely for the Messenger of Allah ﷺ. He whispered softly: "O Messenger of Allah, if any one of them merely looks down at his own feet, he will see us!"

                With serene, unshakable peace, the Prophet ﷺ replied: "Ya Aba Bakr, ma zannuka bi-ithnayni Allahu thalithuhuma? La tahzan innallaha ma'ana — O Abu Bakr, what do you think of two when Allah is their third? Do not grieve; indeed, Allah is with us!" Allah cast complete tranquility (Sakinah) upon their hearts and turned the trackers' gaze away. Days later, they entered Madinah to tears of joy, establishing Masjid an-Nabawi and uniting the Muhajirun and Ansar in historic brotherhood.
            """.trimIndent(),
            storyBn = """
                মক্কায় দীর্ঘ তেরো বছর ধৈর্যের পর কুরাইশ নেতারা নবী মুহাম্মদ ﷺ-কে হত্যার ষড়যন্ত্র করলে আল্লাহ তাঁকে মদিনায় হিজরতের অনুমতি দেন—যে ঘটনা থেকেই ইসলামী হিজরি সনের সূচনা।

                অসাধারণ কৌশল ও তাওয়াক্কুলের সমন্বয়ে নবীজি ﷺ মক্কাবাসীর গচ্ছিত আমানত ফেরত দেওয়ার জন্য তরুণ আলী (রা.)-কে বিছানায় রেখে বিশ্বস্ত সঙ্গী আবু বকর সিদ্দীক (রা.)-কে নিয়ে বের হলেন। আসমা (রা.)-এর খাবার সরবরাহ, আবদুল্লাহর সংবাদ সংগ্রহ এবং আমির ইবনে ফুহাইরার পায়ের ছাপ মোছার নিখুঁত পরিকল্পনায় তাঁরা উত্তর দিকের বদলে দক্ষিণের দুর্গম সাওর গুহায় তিন দিন আশ্রয় নিলেন।

                ১০০ উট পুরস্কারের লোভে সশস্ত্র কুরাইশ অনুসন্ধানকারীরা ঠিক গুহার মুখেই এসে দাঁড়াল! ভেতর থেকে তাদের পায়ের জুতা দেখে আবু বকর (রা.) নবীজির নিরাপত্তার চিন্তায় ফিসফিস করে বললেন: “ইয়া রাসূলাল্লাহ! ওদের কেউ নিজের পায়ের দিকে তাকালেই আমাদের দেখে ফেলবে!”

                অটল প্রশান্তিতে নবীজি ﷺ বললেন: “হে আবু বকর! সেই দুজনের ব্যাপারে তোমার কী ধারণা যাদের তৃতীয়জন স্বয়ং আল্লাহ? দুঃখ করো না, নিশ্চয়ই আল্লাহ আমাদের সাথে আছেন!” আল্লাহ তাঁদের অন্তরে গভীর প্রশান্তি (সাকীনাহ) নাযিল করলেন এবং শত্রুরা মুখ ফিরিয়ে চলে গেল। অতঃপর মদিনায় পৌঁছে নবীজি ﷺ মসজিদে নববী ও ভ্রাতৃত্বের অনন্য সমাজ গড়ে তুললেন।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Excellence in Planning + Total Tawakkul: The Hijrah refutes passive fatalism forever — the Prophet ﷺ planned routes, guides, timing, and logistics with brilliance, and THEN relied completely on Allah when human means reached their limit at the cave mouth.
                2. Trustworthiness Even Toward Enemies: Leaving Ali (RA) behind to return deposits to the very people trying to kill him proves Islamic ethics never bend for convenience.
                3. The Special Companionship ("Allah Is With Us"): Scholars highlight that Allah grants two types of Ma'iyyah (with-ness): His general knowledge of all creation, and His special protective companionship reserved for sincere, patient believers.
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. নিখুঁত পরিকল্পনা ও তাওয়াক্কুল: হিজরত প্রমাণ করে—ইসলাম অলসতা নয়; সর্বোচ্চ সতর্কতা ও পরিকল্পনা গ্রহণ করে অতঃপর ফলাফলের জন্য আল্লাহর ওপর ভরসা করার নামই তাওয়াক্কুল।
                ২. শত্রুর প্রতিও আমানতদারিতা: হত্যার ষড়যন্ত্রকারীদেরও গচ্ছিত সম্পদ ফিরিয়ে দেওয়ার জন্য আলী (রা.)-কে রেখে যাওয়া ইসলামের অতুলনীয় নৈতিকতার প্রমাণ।
                ৩. সাকীনাহ বা ঐশী প্রশান্তি: ভয়ংকর বিপদেও আল্লাহর সঙ্গের অনুভূতি অন্তর থেকে সমস্ত আতঙ্ক দূর করে দেয়।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"Do not grieve; indeed, Allah is with us.\" — Quran 9:40",
            keyVerseOrHadithBn = "“দুঃখ করো না; নিশ্চয়ই আল্লাহ আমাদের সাথে আছেন।” — কুরআন ৯:৪০",
            lessonEn = "Plan wisely with every skill you have, surround yourself with loyal companions, and remember that whenever Allah is with you, you are never outnumbered.",
            lessonBn = "বুদ্ধিমত্তার সাথে সর্বোচ্চ পরিকল্পনা করুন, বিশ্বস্ত সঙ্গী বেছে নিন এবং মনে রাখুন—আল্লাহ সাথে থাকলে আপনি কখনো একা নন।",
            sourceRef = "Quran 9:40 • Sahih al-Bukhari 3653 • 3905",
            sourceUrl = "https://quran.com/9/40"
        ),
        NarratedIslamicStory(
            id = "story_15_makkah_umar",
            categoryEn = "Legacy of Mercy & Companions",
            categoryBn = "মক্কা বিজয় ও খিলাফত",
            titleEn = "Conquest of Makkah & Caliph Umar (RA) — Humility & Servant Leadership",
            titleBn = "মক্কা বিজয়ের মহাক্ষমা ও খলিফা উমর (রা.)-এর রাতের সেবা",
            arabicName = "فتح مكة • عمر بن الخطاب رضي الله عنه",
            arabicNameTransliteration = "Fath Makkah • Umar ibn al-Khattab Radiyallahu Anhu",
            eraOrder = 15,
            eraLabelEn = "Era 15 • 8 AH & Rightly-Guided Era",
            eraLabelBn = "অধ্যায় ১৫ • মক্কা বিজয় ও খিলাফত",
            estimatedReadMinutes = 6,
            storyEn = """
                Eight years after being forced to flee his hometown by night, Prophet Muhammad ﷺ returned to Makkah in Ramadan (8 AH) at the head of ten thousand disciplined believers. Rather than marching in like a proud earthly conqueror, he lowered his head so deeply in gratitude and humility on his camel that his blessed beard nearly touched the saddle, reciting Surah Al-Fath softly.

                Entering the sanctuary peacefully without vengeful bloodshed, he purified the Sacred Ka'bah of all 360 idols while reciting: "Truth has come, and falsehood has vanished!" Then he stood at the doorway of the Ka'bah looking down at the very Quraysh leaders who had boycotted, tortured, mocked, and driven out the Muslims for twenty years. Expecting execution, they waited in silence as he asked: "O Quraysh, what do you expect I will do with you today?" They pleaded: "You are a noble brother, son of a noble brother!" Echoing Prophet Yusuf (AS), he declared universal amnesty: "No blame upon you today. Go, for you are all free!" Hearts melted overnight, and thousands embraced Islam in awe of his mercy.

                That Prophetic ethic of humble, accountable leadership shaped the Rightly-Guided Caliphs who followed. Years later, when Umar ibn al-Khattab (RA) led an empire stretching from Persia to Egypt, he walked Madinah's quiet outskirts at midnight with his servant Aslam to check on his people personally. Hearing crying children near a dim campfire, he approached and discovered a poor mother stirring a pot of water and pebbles just to lull her starving children to sleep with false hope of dinner.

                Tears streaming down his beard, the Caliph hurried straight back to the public treasury (Bayt al-Mal), loaded a heavy sack of flour and a jar of cooking oil, and insisted on carrying it upon his OWN shoulders. When Aslam begged to carry it for him, Umar answered sternly: "Will you carry my sins for me on the Day of Judgment, O Aslam?!" Returning to the tent, Caliph Umar knelt beside the fire, blew into the embers until smoke drifted through his beard, cooked the warm meal himself, and sat watching quietly until the children ate their fill and laughed again.
            """.trimIndent(),
            storyBn = """
                রাতের আঁধারে মাতৃভূমি ত্যাগের আট বছর পর রমজান মাসে (৮ হিজরি) নবী মুহাম্মদ ﷺ দশ হাজার সাহাবী নিয়ে শান্তিপূর্ণভাবে মক্কায় প্রবেশ করলেন। কোনো বিজয়ী সম্রাটের দম্ভ নয়—কৃতজ্ঞতা ও বিনয়ে তাঁর মাথা এত নিচু ছিল যে পবিত্র দাড়ি প্রায় বাহনের গদিতে স্পর্শ করছিল।

                কাবাঘরকে ৩৬০টি মূর্তি থেকে পবিত্র করে তিনি কাবার দরজায় দাঁড়িয়ে সেই কুরাইশ নেতাদের দিকে তাকালেন যাঁরা দীর্ঘ বিশ বছর মুসলিমদের নির্যাতন করেছিল। নবীজি ﷺ জিজ্ঞাসা করলেন: “হে কুরাইশরা, আজ আমি তোমাদের সাথে কেমন আচরণ করব বলে তোমরা মনে করো?” তারা বলল: “আপনি তো আমাদের উদার ভাই!” নবী ইউসুফ (আ.)-এর বাণী স্মরণ করিয়ে তিনি সাধারণ ক্ষমা ঘোষণা করলেন: “আজ তোমাদের বিরুদ্ধে কোনো অভিযোগ নেই! যাও, তোমরা সবাই মুক্ত!” এই অকল্পনীয় ক্ষমায় হাজার হাজার মানুষ ইসলামের ছায়াতলে চলে এল।

                সেই নববী শিক্ষাই খুলাফায়ে রাশেদীনকে গড়ে তুলেছিল। পারস্য থেকে মিশর পর্যন্ত বিশাল সাম্রাজ্যের খলিফা হয়েও উমর ইবনুল খাত্তাব (রা.) গভীর রাতে খাদেম আসলামকে নিয়ে মদিনার প্রান্তে প্রজাদের খোঁজ নিতে বের হতেন। এক রাতে এক অসহায় মাকে দেখলেন—ক্ষুধার্ত শিশুদের সান্ত্বনা দিতে হাঁড়িতে পানি ও পাথর সেদ্ধ করছেন!

                চোখের জলে বুক ভাসিয়ে খলিফা উমর (রা.) দ্রুত বাইতুল মালে ফিরে নিজ কাঁধে ভারী আটার বস্তা ও তেল তুলে নিলেন। আসলাম তা বইতে চাইলে তিনি বললেন: “হে আসলাম, কিয়ামতের দিন কি তুমি আমার বোঝা বহন করবে?” অতঃপর তাঁবুতে ফিরে নিজে চুলায় ফুঁ দিয়ে রান্না করে ক্ষুধার্ত শিশুদের খাইয়ে তাদের মুখে হাসি ফুটিয়ে তবেই ফিরলেন।
            """.trimIndent(),
            explanationEn = """
                Scholarly Explanation & Tafsir Insights:
                1. Victory Reveals Character: Anyone can speak of mercy when weak; true Prophetic nobility shines when you hold total power over those who wronged you — and still choose forgiveness and humility.
                2. Calling Bilal (RA) to the Roof of the Ka'bah: At the Conquest of Makkah, the Prophet ﷺ asked Bilal ibn Rabah (RA) — a formerly enslaved Abyssinian companion — to climb atop the Sacred Ka'bah and call the Adhan, shattering racial hierarchy forever.
                3. Accountability in Leadership: Caliph Umar's midnight service embodies the Prophet's teaching: "Each of you is a shepherd, and each of you is responsible for your flock" (Sahih al-Bukhari 893).
            """.trimIndent(),
            explanationBn = """
                তাফসীর ও প্রামাণ্য ব্যাখ্যা:
                ১. ক্ষমতাই চরিত্রের আসল পরীক্ষা: দুর্বল অবস্থায় নয়, সম্পূর্ণ ক্ষমতা হাতে পেয়েও প্রতিশোধ না নিয়ে ক্ষমা করাই প্রকৃত নববী মহত্ত্ব।
                ২. কাবার ছাদে বিলাল (রা.)-এর আযান: মক্কা বিজয়ের দিন একসময়ের নির্যাতিত হাবশী সাহাবী বিলাল (রা.)-কে কাবার ছাদে তুলে আযান দেওয়ার মাধ্যমে ইসলাম বর্ণবাদের মূলোৎপাটন করে।
                ৩. দায়িত্বশীল নেতৃত্ব: খলিফা উমর (রা.)-এর রাতের সেবা নবীজির হাদীস “তোমরা প্রত্যেকেই দায়িত্বশীল এবং প্রত্যেককে তার অধীনস্থদের সম্পর্কে জিজ্ঞাসা করা হবে” (বুখারী ৮৯৩)-এর জীবন্ত উদাহরণ।
            """.trimIndent(),
            keyVerseOrHadithEn = "\"Go, for you are free.\" — Conquest of Makkah (8 AH) • \"Each of you is a shepherd and responsible for your flock.\" — Sahih al-Bukhari 893",
            keyVerseOrHadithBn = "“যাও, তোমরা সবাই মুক্ত।” — মক্কা বিজয় • “তোমরা প্রত্যেকেই দায়িত্বশীল।” — সহীহ বুখারী ৮৯৩",
            lessonEn = "Victory is measured by humility and forgiveness, and true leadership is quiet service to the vulnerable when nobody else is watching.",
            lessonBn = "বিজয়ের প্রকৃত সৌন্দর্য হলো বিনয় ও ক্ষমা, আর প্রকৃত নেতৃত্ব হলো অসহায় মানুষের নীরব সেবা।",
            sourceRef = "Quran 17:81 • Sahih Muslim 1780 • Sahih al-Bukhari 893",
            sourceUrl = "https://sunnah.com/bukhari:893"
        )
    )
}
