package com.example.ruhzena.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ui.theme.LocalReducedMotion
import com.example.ui.theme.LocalRuhZenaPalette
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.launch

/**
 * Shared registry of live UI target bounds in root screen coordinates so the
 * Coach-Mark Spotlight Guide highlights exact real buttons, icons, and sections.
 */
class TutorialSpotlightRegistry {
    val targets = mutableStateMapOf<String, Rect>()

    fun register(key: String, rect: Rect) {
        if (rect.width > 1f && rect.height > 1f) {
            targets[key] = rect
        }
    }
}

val LocalTutorialTargets = compositionLocalOf<TutorialSpotlightRegistry?> { null }

/**
 * Registers any Composable button, icon, or section as a real-coordinate spotlight target.
 */
fun Modifier.tutorialTarget(key: String): Modifier = composed {
    val registry = LocalTutorialTargets.current
    if (registry == null) {
        this
    } else {
        this.onGloballyPositioned { coords ->
            if (coords.isAttached) {
                registry.register(key, coords.boundsInRoot())
            }
        }
    }
}

enum class TutorialPageId(
    val titleEn: String,
    val titleBn: String
) {
    HOME("Home Guide", "হোম গাইড"),
    DEEN_QURAN("Quran Guide", "কুরআন গাইড"),
    DEEN_SURAH_READER("Surah Reader Guide", "সূরা পাঠক গাইড"),
    DEEN_PRAYER("Prayer & Qibla Guide", "নামাজ ও কিবলা গাইড"),
    DEEN_ADHKAR_DUA("Adhkar & Duas Guide", "যিকির ও দুআ গাইড"),
    DEEN_TASBIH("Tasbih Guide", "তাসবিহ গাইড"),
    AI_CHAT("RuhZena AI Guide", "রূহযেনা এআই গাইড"),
    LEARN_GATE("Learning Mode Guide", "শিক্ষা মোড গাইড"),
    LEARN_HUB("Learning Hub Guide", "শিক্ষা গাইড"),
    LEARN_ARABIC("Arabic Studio Guide", "আরবি লেখা গাইড"),
    LIFE_WORKOUTS("Workouts Guide", "ব্যায়াম গাইড"),
    LIFE_HYDRATION("Hydration Guide", "পানি ট্র্যাকার গাইড"),
    LIFE_NUTRITION("Nutrition Guide", "খাবার ও পুষ্টি গাইড"),
    LIFE_HABITS("Habits Guide", "অভ্যাস গাইড"),
    LIFE_JOURNAL("Journal Guide", "জার্নাল গাইড")
}

object TutorialTargetKeys {
    // Home & Bottom Navigation Dock
    const val DOCK_HOME = "dock_home"
    const val BTN_SEARCH = "btn_search"
    const val BTN_SETTINGS = "btn_settings"
    const val CARD_NEXT_PRAYER = "card_next_prayer"
    const val DOCK_DEEN = "dock_deen"
    const val DOCK_CENTER_AI = "dock_center_ai"
    const val DOCK_LEARN = "dock_learn"
    const val DOCK_LIFE = "dock_life"

    // Deen shared switcher & Quran
    const val DEEN_SECTION_DROPDOWN = "deen_section_dropdown"
    const val QURAN_OFFLINE_CARD = "quran_offline_card"
    const val QURAN_SEARCH_BAR = "quran_search_bar"
    const val SURAH_READER_DISPLAY_BAR = "surah_reader_display_bar"
    const val SURAH_READER_RECITER_PLAY = "surah_reader_reciter_play"
    const val SURAH_READER_FIRST_AYAH = "surah_reader_first_ayah"

    // Prayer & Qibla
    const val PRAYER_HIJRI_CARD = "prayer_hijri_card"
    const val PRAYER_QIBLA_COMPASS = "prayer_qibla_compass"
    const val PRAYER_CALIBRATE_BTN = "prayer_calibrate_btn"

    // Adhkar & Duas
    const val ADHKAR_DUA_SWITCH = "adhkar_dua_switch"
    const val ADHKAR_DUA_SEARCH = "adhkar_dua_search"
    const val ADHKAR_DUA_CATEGORY = "adhkar_dua_category"

    // Tasbih
    const val TASBIH_DHIKR_SELECTOR = "tasbih_dhikr_selector"
    const val TASBIH_AUDIO_VIRTUES = "tasbih_audio_virtues"
    const val TASBIH_TAP_BEAD = "tasbih_tap_bead"
    const val TASBIH_TARGET_RESET = "tasbih_target_reset"

    // AI Chat
    const val AI_MEMORY_BTN = "ai_memory_btn"
    const val AI_INPUT_BAR = "ai_input_bar"

    // Learn Gate, Hub & Arabic Studio
    const val LEARN_GATE_BEGINNER = "learn_gate_beginner"
    const val LEARN_GATE_EXPERIENCED = "learn_gate_experienced"
    const val LEARN_MODE_CHIP = "learn_mode_chip"
    const val LEARN_SECTION_DROPDOWN = "learn_section_dropdown"
    const val ARABIC_LETTER_STRIP = "arabic_letter_strip"
    const val ARABIC_WRITING_CANVAS = "arabic_writing_canvas"
    const val ARABIC_MASTERED_BTN = "arabic_mastered_btn"

    // Life: Workouts, Hydration, Nutrition, Habits, Journal
    const val WORKOUT_SECTION_DROPDOWN = "workout_section_dropdown"
    const val WORKOUT_PROFILE_BTN = "workout_profile_btn"
    const val WORKOUT_RECOMMENDED_CARD = "workout_recommended_card"
    const val WORKOUT_SEARCH_INPUT = "workout_search_input"
    const val HYDRATION_GAUGE_CARD = "hydration_gauge_card"
    const val HYDRATION_QUICK_ADD_ROW = "hydration_quick_add_row"
    const val NUTRITION_SUMMARY_CARD = "nutrition_summary_card"
    const val NUTRITION_SCANNER_CARD = "nutrition_scanner_card"
    const val HABITS_URGE_RESET_BTN = "habits_urge_reset_btn"
    const val HABITS_ADD_CARD = "habits_add_card"
    const val JOURNAL_EXPORT_BTN = "journal_export_btn"
    const val JOURNAL_EDITOR_CARD = "journal_editor_card"
}

private data class CoachMarkStep(
    val targetKey: String,
    val titleEn: String,
    val titleBn: String,
    val infoEn: String,
    val infoBn: String,
    val setupCueEn: String? = null,
    val setupCueBn: String? = null,
    val offersQuickJumpDemo: Boolean = false
)

private fun stepsForPage(page: TutorialPageId): List<CoachMarkStep> = when (page) {
    TutorialPageId.HOME -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.DOCK_HOME,
            titleEn = "Home",
            titleBn = "হোম",
            infoEn = "Shows your next prayer time, Quran resume card, water, workouts, habits, and daily summary.",
            infoBn = "পরবর্তী নামাজের সময়, কুরআন রিজিউম, পানি, ব্যায়াম, অভ্যাস ও দৈনিক সারসংক্ষেপ দেখায়।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.BTN_SEARCH,
            titleEn = "Search",
            titleBn = "সার্চ",
            infoEn = "Find any Surah, Dua, Adhkar, Islamic lesson, or workout from one search bar.",
            infoBn = "এক জায়গায় যেকোনো সূরা, দুআ, আযকার, ইসলামিক পাঠ বা ব্যায়াম খুঁজুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.BTN_SETTINGS,
            titleEn = "Settings",
            titleBn = "সেটিংস",
            infoEn = "Change language, theme, Adhan Muezzin, voice, reminders, Quick Jump slots, or reset all page guides.",
            infoBn = "ভাষা, থিম, আযান মুয়াজ্জিন, ভয়েস, রিমাইন্ডার, কুইক জাম্প বদলান বা সব গাইড আবার দেখুন।",
            setupCueEn = "Setup: Open Settings anytime to choose your Muezzin, voice style, and Quick Jump shortcuts.",
            setupCueBn = "সেটআপ: মুয়াজ্জিন, ভয়েস ও কুইক জাম্প সাজাতে যেকোনো সময় সেটিংস খুলুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.CARD_NEXT_PRAYER,
            titleEn = "Prayer Times & Qibla",
            titleBn = "নামাজের সময় ও কিবলা",
            infoEn = "Shows your next Salah countdown and opens all 5 daily prayer times, Qibla compass, and Hijri calendar.",
            infoBn = "পরবর্তী নামাজের কাউন্টডাউন দেখায় এবং ৫ ওয়াক্ত সময়সূচি, কিবলা কম্পাস ও হিজরি ক্যালেন্ডার খোলে।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.DOCK_DEEN,
            titleEn = "Deen",
            titleBn = "দ্বীন",
            infoEn = "Contains Quran (114 Surahs with context & audio), Prayer & Qibla, Duas & Adhkar, and Tasbih.",
            infoBn = "এখানে কুরআন (১১৪ সূরা, তাফসির ও অডিও), নামাজ ও কিবলা, দুআ-আযকার এবং তাসবিহ আছে।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.DOCK_CENTER_AI,
            titleEn = "RuhZena AI & Quick Jump",
            titleBn = "রূহযেনা এআই ও কুইক জাম্প",
            infoEn = "Tap to open RuhZena AI and jump straight to any Surah, Dua, or tool. Long-press or swipe up to open Quick Jump.",
            infoBn = "ট্যাপ করলে এআই খুলবে। চেপে ধরলে বা ওপরে সোয়াইপ করলে কুইক জাম্প মেনু খুলবে।",
            setupCueEn = "Demo: Tap below to preview Quick Jump now, or press Next to continue.",
            setupCueBn = "ডেমো: এখনই কুইক জাম্প দেখতে নিচে ট্যাপ করুন, অথবা পরবর্তীতে যান।",
            offersQuickJumpDemo = true
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.DOCK_LEARN,
            titleEn = "Learn",
            titleBn = "শিক্ষা",
            infoEn = "Step-by-step Islamic path, Wudu & Salah guides, full Prophet stories, Arabic writing practice, and Hajj & Umrah.",
            infoBn = "ধাপে ধাপে ইসলাম শিক্ষা, ওযু ও নামাজ গাইড, নবীদের পূর্ণ গল্প, আরবি লেখা অনুশীলন এবং হজ-উমরাহ।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.DOCK_LIFE,
            titleEn = "Life",
            titleBn = "জীবন",
            infoEn = "Workouts, water tracker, meal scanner, daily habits, calm breathing reset, and personal journal.",
            infoBn = "ব্যায়াম, পানি ট্র্যাকার, খাবার স্ক্যানার, দৈনিক অভ্যাস, শান্ত শ্বাস রিসেট এবং জার্নাল।"
        )
    )

    TutorialPageId.DEEN_QURAN -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.DEEN_SECTION_DROPDOWN,
            titleEn = "Switch Deen Sections",
            titleBn = "দ্বীন বিভাগ পরিবর্তন",
            infoEn = "Switch between Quran, Prayer & Qibla, Adhkar & Duas, Tasbih, and Daily Lessons.",
            infoBn = "কুরআন, নামাজ ও কিবলা, যিকির ও দুআ, তাসবিহ এবং দৈনিক পাঠের মধ্যে পরিবর্তন করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.QURAN_OFFLINE_CARD,
            titleEn = "Offline Quran Library",
            titleBn = "অফলাইন কুরআন লাইব্রেরি",
            infoEn = "Shows how many of the 114 Surahs are saved offline. Download all Surahs once to read without internet.",
            infoBn = "১১৪ সূরার কতটি অফলাইনে সংরক্ষিত আছে দেখায়। ইন্টারনেট ছাড়া পড়তে সব সূরা ডাউনলোড করতে পারেন।",
            setupCueEn = "Setup: Tap 'Download All Surahs' after this guide if you want full offline access.",
            setupCueBn = "সেটআপ: পুরো কুরআন অফলাইনে রাখতে গাইড শেষে ডাউনলোড বাটনে ট্যাপ করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.QURAN_SEARCH_BAR,
            titleEn = "Find & Open Any Surah",
            titleBn = "সূরা খুঁজুন ও পড়ুন",
            infoEn = "Search by Surah name or number. Inside any Surah, tap an Ayah for audio recitation, bookmark, or full authentic context.",
            infoBn = "নাম বা নম্বর দিয়ে সূরা খুঁজুন। যেকোনো আয়াতে ট্যাপ করে তিলাওয়াত, বুকমার্ক ও পূর্ণ তাফসির দেখুন।"
        )
    )

    TutorialPageId.DEEN_PRAYER -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.PRAYER_HIJRI_CARD,
            titleEn = "Hijri Calendar",
            titleBn = "হিজরি ক্যালেন্ডার",
            infoEn = "Displays today's Hijri date. Opens the full monthly Islamic calendar and moon-sighting day adjustment.",
            infoBn = "আজকের হিজরি তারিখ দেখায়। পূর্ণ মাসিক ক্যালেন্ডার ও চাঁদ দেখার তারিখ সমন্বয় খোলে।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.PRAYER_QIBLA_COMPASS,
            titleEn = "Qibla Compass",
            titleBn = "কিবলা কম্পাস",
            infoEn = "Hold your phone flat and rotate until the Kaaba arrow aligns at the top. Scroll below to see all 5 daily Salah times and set your city or GPS.",
            infoBn = "ফোন সমতল রেখে ঘোরান যতক্ষণ না কাবা তীর ওপরে মিলে যায়। নিচে ৫ ওয়াক্ত সময় ও আপনার শহর/GPS সেট করুন।",
            setupCueEn = "Setup: Scroll down after this guide to refresh GPS or select your city for exact Adhan times.",
            setupCueBn = "সেটআপ: সঠিক আযানের সময়ের জন্য গাইড শেষে নিচে GPS আপডেট বা শহর নির্বাচন করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.PRAYER_CALIBRATE_BTN,
            titleEn = "Compass Calibration",
            titleBn = "কম্পাস ক্যালিব্রেশন",
            infoEn = "Check magnetometer accuracy and follow the figure-8 calibration guide if your compass drifts.",
            infoBn = "কম্পাসের নির্ভুলতা যাচাই করুন এবং প্রয়োজনে ফিগার-৮ ক্যালিব্রেশন গাইড দেখুন।"
        )
    )

    TutorialPageId.DEEN_ADHKAR_DUA -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.ADHKAR_DUA_SWITCH,
            titleEn = "Adhkar & Daily Duas",
            titleBn = "যিকির ও দৈনিক দুআ",
            infoEn = "Switch between timed Adhkar routines (Morning, Evening, After Prayer, Bedtime) and categorized Sunnah Duas with full authentic context.",
            infoBn = "সকাল-সন্ধ্যা ও নামাজের পরের যিকির এবং পূর্ণ প্রেক্ষাপটসহ দৈনিক মাসনুন দুআর মধ্যে পরিবর্তন করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.ADHKAR_DUA_SEARCH,
            titleEn = "Search Duas & Adhkar",
            titleBn = "দুআ ও যিকির খুঁজুন",
            infoEn = "Filter instantly by topic, Arabic word, or situation such as travel, anxiety, forgiveness, or protection.",
            infoBn = "বিষয় বা প্রয়োজনের শব্দ লিখে দ্রুত যেকোনো দুআ বা যিকির খুঁজে নিন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.ADHKAR_DUA_CATEGORY,
            titleEn = "Routine & Category Picker",
            titleBn = "সময় ও বিভাগ নির্বাচন",
            infoEn = "Pick a daily routine or Dua category. On any Adhkar routine you can launch Guided Tasbih step by step.",
            infoBn = "যিকিরের সময় বা দুআর বিভাগ বেছে নিন। যেকোনো যিকির থেকে সরাসরি ধাপে ধাপে তাসবিহ শুরু করা যায়।"
        )
    )

    TutorialPageId.DEEN_TASBIH -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.TASBIH_DHIKR_SELECTOR,
            titleEn = "Choose Dhikr",
            titleBn = "যিকির নির্বাচন",
            infoEn = "Pick from authentic Sunnah dhikrs with Arabic text, pronunciation, meaning, and recommended count.",
            infoBn = "আরবি, উচ্চারণ, অর্থ ও সুন্নাহ সংখ্যাসহ ১৮+ যিকিরের তালিকা থেকে পছন্দ করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.TASBIH_AUDIO_VIRTUES,
            titleEn = "Listen & Virtues",
            titleBn = "উচ্চারণ ও ফজিলত",
            infoEn = "Hear the Arabic pronunciation or open authentic Hadith virtues for the selected dhikr.",
            infoBn = "সঠিক আরবি উচ্চারণ শুনুন অথবা এই যিকিরের সহিহ হাদিসের ফজিলত পড়ুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.TASBIH_TAP_BEAD,
            titleEn = "Tasbih Counter",
            titleBn = "তাসবিহ কাউন্টার",
            infoEn = "Tap the center counter for each recitation. The outer ring tracks your round and notifies you when the target completes.",
            infoBn = "প্রতিবার পাঠের পর মাঝের কাউন্টারে ট্যাপ করুন। বাইরের রিং আপনার লক্ষ্য অগ্রগতি দেখাবে।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.TASBIH_TARGET_RESET,
            titleEn = "Target, Undo & Reset",
            titleBn = "লক্ষ্য, আনডু ও রিসেট",
            infoEn = "Switch targets (33, 99, 100), check total counts, undo an accidental tap, or reset the current round.",
            infoBn = "৩৩, ৯৯ বা ১০০ লক্ষ্য ঠিক করুন, ভুল ট্যাপ পেছনে নিন বা বর্তমান চক্র রিসেট করুন।"
        )
    )

    TutorialPageId.AI_CHAT -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.AI_MEMORY_BTN,
            titleEn = "Memory & Active Plans",
            titleBn = "মেমোরি ও সক্রিয় পরিকল্পনা",
            infoEn = "View or edit saved preferences and active multi-step plans. Private journal entries are never shared.",
            infoBn = "সংরক্ষিত মেমোরি ও চলমান পরিকল্পনা দেখুন বা সম্পাদনা করুন। ব্যক্তিগত জার্নাল কখনো শেয়ার হয় না।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.AI_INPUT_BAR,
            titleEn = "Ask & Jump Directly",
            titleBn = "প্রশ্ন করুন ও সরাসরি যান",
            infoEn = "Ask about any Surah, Dua, Islamic ruling, workout, or meal. When something exists in the app (like Surah Mulk or a Dua), RuhZena AI gives a direct jump button to open it.",
            infoBn = "যেকোনো সূরা, দুআ, মাসআলা, ব্যায়াম বা খাবার নিয়ে প্রশ্ন করুন। অ্যাপে থাকা সূরা বা দুআ চাইলে সরাসরি খোলার বাটন পাবেন।"
        )
    )

    TutorialPageId.DEEN_SURAH_READER -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.SURAH_READER_DISPLAY_BAR,
            titleEn = "Text Size & Pronunciation",
            titleBn = "ফন্ট সাইজ ও উচ্চারণ",
            infoEn = "Adjust Arabic script size with A- / A+ and toggle English or Bangla transliteration on or off while reading.",
            infoBn = "A- / A+ দিয়ে আরবি অক্ষরের আকার ছোট-বড় করুন এবং বাংলা বা ইংরেজি উচ্চারণ চালু বা বন্ধ করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.SURAH_READER_RECITER_PLAY,
            titleEn = "Reciter & Instant Playback",
            titleBn = "ক্বারী ও তাৎক্ষণিক তিলাওয়াত",
            infoEn = "Pick your preferred human Qari and tap Play Surah to listen with background controls in your phone's notification bar.",
            infoBn = "পছন্দের ক্বারী নির্বাচন করে সম্পূর্ণ সূরা শুনুন—ব্যাকগ্রাউন্ডে চলার সময় ফোনের নোটিফিকেশন বার থেকেই নিয়ন্ত্রণ করা যাবে।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.SURAH_READER_FIRST_AYAH,
            titleEn = "Surah Context, Tafsir & Verse Tools",
            titleBn = "সূরার প্রেক্ষাপট, তাফসীর ও আয়াত টুলস",
            infoEn = "Expand the top card for authentic revelation context, and use each verse's buttons to play audio, bookmark, share, or ask AI for Tafsir.",
            infoBn = "ওপরের কার্ডে সূরার শানে নুযূল ও প্রেক্ষাপট পড়ুন এবং প্রতিটি আয়াতের অডিও, বুকমার্ক, শেয়ার বা তাফসীর ব্যবহার করুন।"
        )
    )

    TutorialPageId.LEARN_GATE -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.LEARN_GATE_BEGINNER,
            titleEn = "Beginner Guided Path",
            titleBn = "বিগিনার গাইডেড পথ",
            infoEn = "Choose this if you want structured step-by-step Islamic foundations with interactive Wudu, Salah, and short knowledge checks.",
            infoBn = "ধাপে ধাপে ওযু, নামাজ, মৌলিক ইলম ও ছোট কুইজসহ শিখতে চাইলে এটি বেছে নিন।",
            setupCueEn = "Setup: Tap Beginner Path or Experienced Library after this guide to enter Learn.",
            setupCueBn = "সেটআপ: গাইড শেষে আপনার উপযোগী শেখার ধরনটি নির্বাচন করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.LEARN_GATE_EXPERIENCED,
            titleEn = "Experienced Open Library",
            titleBn = "অভিজ্ঞ ওপেন লাইব্রেরি",
            infoEn = "Unlocks all lessons, full Prophet stories, Arabic writing studio, Encyclopedia, and Hajj & Umrah immediately with zero locked steps.",
            infoBn = "কোনো ধাপ বা লক ছাড়াই সব পাঠ, নবীদের পূর্ণ গল্প, আরবি লেখা স্টুডিও, রেফারেন্স ও হজ-উমরাহ সাথে সাথে উন্মুক্ত থাকবে।"
        )
    )

    TutorialPageId.LEARN_HUB -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.LEARN_MODE_CHIP,
            titleEn = "Beginner Path or Open Library",
            titleBn = "বিগিনার বা ওপেন লাইব্রেরি",
            infoEn = "Switch anytime between guided step-by-step learning and full unlocked access to all lessons.",
            infoBn = "যেকোনো সময় ধাপে ধাপে শিক্ষা অথবা সব পাঠ উন্মুক্ত লাইব্রেরি মোডের মধ্যে পরিবর্তন করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.LEARN_SECTION_DROPDOWN,
            titleEn = "Learning Sections",
            titleBn = "শিক্ষার বিভাগসমূহ",
            infoEn = "Open Guided Path, How to Pray & Wudu demonstrations, Arabic Writing Studio, full Prophet Stories, Encyclopedia, or Hajj & Umrah.",
            infoBn = "ধাপে ধাপে পাঠ, নামাজ ও ওযু গাইড, আরবি লেখা স্টুডিও, নবীদের পূর্ণ গল্প, রেফারেন্স এবং হজ-উমরাহ খুলুন।"
        )
    )

    TutorialPageId.LEARN_ARABIC -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.ARABIC_LETTER_STRIP,
            titleEn = "28 Arabic Letters",
            titleBn = "২৮টি আরবি হরফ",
            infoEn = "Scroll and select any Arabic letter to hear its pronunciation and load its trace guide.",
            infoBn = "যেকোনো আরবি হরফ নির্বাচন করে উচ্চারণ শুনুন এবং লেখার অনুশীলন শুরু করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.ARABIC_WRITING_CANVAS,
            titleEn = "Writing Pad & Tools",
            titleBn = "লেখার প্যাড ও টুলস",
            infoEn = "Swipe right-to-left to write strokes and tap once to place dots (nuqta). Use the top icons to listen, hide/show the trace guide, undo, or clear.",
            infoBn = "ডান থেকে বামে আঙুল টেনে লিখুন এবং নুকতার জন্য একবার ট্যাপ করুন। ওপরের আইকন দিয়ে শুনুন, গাইড লুকান, আনডু বা পরিষ্কার করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.ARABIC_MASTERED_BTN,
            titleEn = "Track Letter Mastery",
            titleBn = "আয়ত্ত অগ্রগতি সংরক্ষণ",
            infoEn = "Mark letters as mastered to update your 28-letter progress bar, or ask RuhZena AI for Quranic word examples.",
            infoBn = "হরফটি শেখা হয়ে গেলে আয়ত্ত হিসেবে চিহ্নিত করুন, অথবা এআই থেকে কুরআনিক উদাহরণ জানুন।"
        )
    )

    TutorialPageId.LIFE_WORKOUTS -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.WORKOUT_SECTION_DROPDOWN,
            titleEn = "Life & Wellness Switcher",
            titleBn = "জীবন ও সুস্থতা বিভাগ",
            infoEn = "Switch between Workouts, Hydration, Nutrition Scanner, Daily Habits, and Private Journal from this selector.",
            infoBn = "এখান থেকে ব্যায়াম, পানি, খাবার স্ক্যানার, দৈনিক অভ্যাস ও ব্যক্তিগত জার্নালে যান।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.WORKOUT_PROFILE_BTN,
            titleEn = "Fitness Profile & Equipment",
            titleBn = "ফিটনেস প্রোফাইল ও সরঞ্জাম",
            infoEn = "Set your age, weight, height, level, goal, and whether you train with bodyweight or equipment (Dumbbells, Bands, Pull-Up Bar, Kettlebell, Gym).",
            infoBn = "বয়স, ওজন, উচ্চতা, স্তর ও সরঞ্জাম (ডাম্বেল, ব্যান্ড, পুল-আপ বার, জিম বা সরঞ্জামহীন) সেট করুন।",
            setupCueEn = "Setup: Tap Profile after the guide to choose your available workout equipment and match your plan.",
            setupCueBn = "সেটআপ: গাইড শেষে প্রোফাইলে ট্যাপ করে আপনার ব্যায়ামের সরঞ্জাম নির্বাচন করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.WORKOUT_RECOMMENDED_CARD,
            titleEn = "Matched Plan & Equipment Library",
            titleBn = "আপনার প্ল্যান ও পূর্ণ ব্যায়াম লাইব্রেরি",
            infoEn = "Start your equipment-matched routine with live anatomical form demos, build a custom session, or filter all bodyweight and equipment exercises right below.",
            infoBn = "আপনার সরঞ্জাম অনুযায়ী প্রস্তাবিত ওয়ার্কআউট শুরু করুন অথবা নিচের ফিল্টার থেকে সব বডিওয়েট ও সরঞ্জামভিত্তিক ব্যায়াম দেখুন।"
        )
    )

    TutorialPageId.LIFE_HYDRATION -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.HYDRATION_GAUGE_CARD,
            titleEn = "Daily Hydration Gauge",
            titleBn = "দৈনিক পানির পরিমাপক",
            infoEn = "Tracks today's water intake against your daily target and shows how much remains.",
            infoBn = "আজকের মোট পানি পান এবং দৈনিক লক্ষ্যের বাকি অংশ দেখায়।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.HYDRATION_QUICK_ADD_ROW,
            titleEn = "Quick Drink Log",
            titleBn = "দ্রুত পানি লগ",
            infoEn = "Select the beverage type above and tap a cup size to log intake instantly. Scroll down to adjust your daily goal.",
            infoBn = "পানীয়র ধরন বেছে নিয়ে কাপ সাইজে ট্যাপ করে পানি যোগ করুন। নিচে দৈনিক লক্ষ্য বদলাতে পারবেন।"
        )
    )

    TutorialPageId.LIFE_NUTRITION -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.NUTRITION_SUMMARY_CARD,
            titleEn = "Daily Calories & Macros",
            titleBn = "দৈনিক ক্যালোরি ও ম্যাক্রো",
            infoEn = "Displays today's logged calories, protein, carbs, and fat with one-tap AI nutrition feedback.",
            infoBn = "আজকের মোট ক্যালোরি, প্রোটিন, কার্বস ও ফ্যাট দেখায় এবং এআই থেকে পরামর্শ নেওয়ার সুযোগ দেয়।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.NUTRITION_SCANNER_CARD,
            titleEn = "AI Meal Photo Scanner",
            titleBn = "এআই খাবার স্ক্যানার",
            infoEn = "Take or choose a meal photo to estimate calories, macros, and suitability for your goal, or scroll down to pick quick halal presets.",
            infoBn = "খাবারের ছবি তুলে বা গ্যালারি থেকে বেছে ক্যালোরি ও পুষ্টিগুণ জানুন, অথবা নিচের তালিকা থেকে যোগ করুন।"
        )
    )

    TutorialPageId.LIFE_HABITS -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.HABITS_URGE_RESET_BTN,
            titleEn = "Urge Reset",
            titleBn = "প্রলোভন ও শান্তি রিসেট",
            infoEn = "Opens a guided breathing timer, grounding reminders, and Duas whenever you need immediate calm.",
            infoBn = "অস্থিরতা বা দুর্বল মুহূর্তে তাৎক্ষণিক শ্বাস-প্রশ্বাস, স্থিরতা ও দুআ গাইড খোলে।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.HABITS_ADD_CARD,
            titleEn = "Daily Habits & Streaks",
            titleBn = "দৈনিক অভ্যাস ও স্ট্রিক",
            infoEn = "Create custom spiritual, health, or study habits and check them off below to build streaks.",
            infoBn = "দ্বীন, স্বাস্থ্য বা শৃঙ্খলার নতুন অভ্যাস যোগ করুন এবং নিচে প্রতিদিন টিক দিয়ে স্ট্রিক গড়ুন।"
        )
    )

    TutorialPageId.LIFE_JOURNAL -> listOf(
        CoachMarkStep(
            targetKey = TutorialTargetKeys.JOURNAL_EXPORT_BTN,
            titleEn = "Private Export",
            titleBn = "ব্যক্তিগত এক্সপোর্ট",
            infoEn = "Your journal stays private on your device. Export entries as JSON whenever you want a personal copy.",
            infoBn = "আপনার জার্নাল সম্পূর্ণ ব্যক্তিগত থাকে। প্রয়োজনে যেকোনো সময় JSON হিসেবে এক্সপোর্ট করুন।"
        ),
        CoachMarkStep(
            targetKey = TutorialTargetKeys.JOURNAL_EDITOR_CARD,
            titleEn = "Mood & Daily Reflection",
            titleBn = "অনুভূতি ও দৈনিক প্রতিফলন",
            infoEn = "Select your current mood, write reflections or gratitude notes, and save them to your private timeline below.",
            infoBn = "বর্তমান অনুভূতি বেছে নিন, দিনের চিন্তা ও শোকরিয়া লিখে নিচে সংরক্ষণ করুন।"
        )
    )
}

/**
 * Contextual Per-Page Spotlight Guide with Liquid-Glass Focus Veil.
 * - Highlights real visible UI controls using exact root coordinates.
 * - Strictly locks all background touches, drags, scrolls, and back presses during tutorial time.
 * - No floating "Click here" badge; only shows setup/demo cues inside the card on actual setup/demo steps.
 */
@Composable
fun FirstTimeTutorialOverlay(
    page: TutorialPageId,
    activeQuickJumpShortcuts: List<PortalQuickLaunch> = PortalQuickLaunch.defaultUrgentShortcuts,
    onFinish: () -> Unit,
    onTryQuickJumpNow: () -> Unit = {}
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val reducedMotion = LocalReducedMotion.current
    val registry = LocalTutorialTargets.current
    val density = LocalDensity.current

    val steps = remember(page) { stepsForPage(page) }
    var stepIndex by remember(page) { mutableIntStateOf(0) }
    var navDirection by remember(page) { mutableIntStateOf(1) }
    var showQuickJumpDemoWindow by remember(page) { mutableStateOf(false) }

    // Smooth overlay & card entrance animation whenever a page guide launches
    val veilAlpha = remember(page) { Animatable(if (reducedMotion) 1f else 0f) }
    val cardScale = remember(page) { Animatable(if (reducedMotion) 1f else 0.90f) }
    val cardLiftY = remember(page) { Animatable(if (reducedMotion) 0f else 42f) }
    LaunchedEffect(page, reducedMotion) {
        if (reducedMotion) {
            veilAlpha.snapTo(1f)
            cardScale.snapTo(1f)
            cardLiftY.snapTo(0f)
        } else {
            launch { veilAlpha.animateTo(1f, tween(300, easing = FastOutSlowInEasing)) }
            launch {
                cardScale.animateTo(
                    1f,
                    spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow)
                )
            }
            launch {
                cardLiftY.animateTo(
                    0f,
                    spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow)
                )
            }
        }
    }

    // Block Android Back button/gesture while tutorial is active; if preview window is open, return to the tutorial step
    BackHandler(enabled = true) {
        if (showQuickJumpDemoWindow) {
            showQuickJumpDemoWindow = false
        }
    }

    val safeIndex = stepIndex.coerceIn(0, steps.lastIndex)
    val currentStep = steps[safeIndex]
    val isLast = safeIndex == steps.lastIndex

    val pulseTransition = rememberInfiniteTransition(label = "spotlightPulse")
    val ringGlow by pulseTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ringGlow"
    )
    val shimmerAngle by pulseTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.283185f,
        animationSpec = infiniteRepeatable(
            animation = tween(4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerAngle"
    )

    val rawTarget = registry?.targets?.get(currentStep.targetKey)

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = veilAlpha.value }
            .testTag("first_time_tutorial_overlay")
    ) {
        val rootWidthPx = with(density) { maxWidth.toPx() }
        val rootHeightPx = with(density) { maxHeight.toPx() }
        val padPx = with(density) { 8.dp.toPx() }
        val cornerPx = with(density) { 20.dp.toPx() }

        // Only highlight target if it is currently visible inside the viewport bounds
        val targetSpotRect: Rect? = rawTarget?.takeIf { r ->
            r.width > 4f && r.height > 4f &&
                r.bottom > 0f && r.top < rootHeightPx &&
                r.right > 0f && r.left < rootWidthPx
        }?.let { r ->
            Rect(
                left = (r.left - padPx).coerceAtLeast(4f),
                top = (r.top - padPx).coerceAtLeast(4f),
                right = (r.right + padPx).coerceAtMost(rootWidthPx - 4f),
                bottom = (r.bottom + padPx).coerceAtMost(rootHeightPx - 4f)
            )
        }

        // Smoothly gliding & morphing spotlight rectangle across steps!
        val spotLeft = remember(page) { Animatable(0f) }
        val spotTop = remember(page) { Animatable(0f) }
        val spotRight = remember(page) { Animatable(0f) }
        val spotBottom = remember(page) { Animatable(0f) }
        val spotVisibility = remember(page) { Animatable(0f) }
        var hasSnappedSpot by remember(page) { mutableStateOf(false) }

        LaunchedEffect(targetSpotRect, reducedMotion) {
            if (targetSpotRect == null) {
                spotVisibility.animateTo(0f, tween(180))
            } else if (!hasSnappedSpot || reducedMotion) {
                hasSnappedSpot = true
                spotLeft.snapTo(targetSpotRect.left)
                spotTop.snapTo(targetSpotRect.top)
                spotRight.snapTo(targetSpotRect.right)
                spotBottom.snapTo(targetSpotRect.bottom)
                spotVisibility.animateTo(1f, tween(240, easing = FastOutSlowInEasing))
            } else {
                val glideSpec = spring<Float>(
                    dampingRatio = 0.80f,
                    stiffness = Spring.StiffnessMediumLow
                )
                launch { spotLeft.animateTo(targetSpotRect.left, glideSpec) }
                launch { spotTop.animateTo(targetSpotRect.top, glideSpec) }
                launch { spotRight.animateTo(targetSpotRect.right, glideSpec) }
                launch { spotBottom.animateTo(targetSpotRect.bottom, glideSpec) }
                launch { spotVisibility.animateTo(1f, tween(200)) }
            }
        }

        val animatedSpotRect: Rect? = if (spotVisibility.value > 0.02f && (spotRight.value - spotLeft.value) > 4f && (spotBottom.value - spotTop.value) > 4f) {
            Rect(spotLeft.value, spotTop.value, spotRight.value, spotBottom.value)
        } else {
            null
        }

        // Layer 1: Full-screen strict touch/scroll/drag blocker + Liquid-Glass Frosted Veil
        val glassAccent = palette.accentSoft
        val glassGold = palette.gold
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(page) {
                    // Consumes ALL pointer events (taps, long presses, drags, scrolls) so nothing beneath can ever be clicked
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            event.changes.forEach { it.consume() }
                        }
                    }
                }
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
            ) {
                // Frosted dark liquid-glass scrim
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xD8060E18),
                            Color(0xE20A1626),
                            Color(0xE6050B14)
                        )
                    ),
                    size = size
                )

                // Softly drifting liquid-glass frosted bokeh sheen
                val driftX = if (reducedMotion) 0f else cos(shimmerAngle) * size.width * 0.04f
                val driftY = if (reducedMotion) 0f else sin(shimmerAngle) * size.height * 0.03f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glassAccent.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(size.width * 0.18f + driftX, size.height * 0.25f + driftY),
                        radius = size.width * 0.62f
                    ),
                    radius = size.width * 0.62f,
                    center = Offset(size.width * 0.18f + driftX, size.height * 0.25f + driftY)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glassGold.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(size.width * 0.84f - driftX, size.height * 0.72f - driftY),
                        radius = size.width * 0.56f
                    ),
                    radius = size.width * 0.56f,
                    center = Offset(size.width * 0.84f - driftX, size.height * 0.72f - driftY)
                )

                // Crystal-clear smoothly gliding cutout over the focused icon/section
                val spot = animatedSpotRect
                val vis = spotVisibility.value
                if (spot != null) {
                    drawRoundRect(
                        color = Color.Transparent,
                        topLeft = Offset(spot.left, spot.top),
                        size = Size(spot.width, spot.height),
                        cornerRadius = CornerRadius(cornerPx, cornerPx),
                        blendMode = BlendMode.Clear
                    )

                    // Expanding breathing outer liquid-glass halo
                    val haloExpand = 5f + 4f * ringGlow
                    drawRoundRect(
                        color = glassAccent.copy(alpha = 0.34f * ringGlow * vis),
                        topLeft = Offset(spot.left - haloExpand, spot.top - haloExpand),
                        size = Size(spot.width + haloExpand * 2f, spot.height + haloExpand * 2f),
                        cornerRadius = CornerRadius(cornerPx + haloExpand, cornerPx + haloExpand),
                        style = Stroke(width = 6.5f)
                    )

                    // Orbiting specular liquid-glass highlight border
                    val cx = spot.center.x
                    val cy = spot.center.y
                    val halfW = spot.width * 0.65f
                    val halfH = spot.height * 0.65f
                    val gx = cos(shimmerAngle) * halfW
                    val gy = sin(shimmerAngle) * halfH
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.92f * vis),
                                glassGold.copy(alpha = 0.94f * vis),
                                glassAccent.copy(alpha = 0.94f * vis)
                            ),
                            start = Offset(cx - gx, cy - gy),
                            end = Offset(cx + gx, cy + gy)
                        ),
                        topLeft = Offset(spot.left, spot.top),
                        size = Size(spot.width, spot.height),
                        cornerRadius = CornerRadius(cornerPx, cornerPx),
                        style = Stroke(width = 3.4f)
                    )
                }
            }
        }

        // Layer 2: Liquid-Glass Info Card positioned cleanly away from the highlighted element
        val targetInLowerHalf = targetSpotRect != null && targetSpotRect.center.y > rootHeightPx * 0.52f
        val targetInVeryBottom = targetSpotRect != null && targetSpotRect.top > rootHeightPx * 0.72f

        val cardAlignment = when {
            targetSpotRect == null -> Alignment.Center
            targetInVeryBottom -> Alignment.Center
            targetInLowerHalf -> Alignment.TopCenter
            else -> Alignment.BottomCenter
        }
        val topExtraPad by animateDpAsState(
            targetValue = if (cardAlignment == Alignment.TopCenter) 8.dp else 0.dp,
            animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow),
            label = "cardTopPad"
        )
        val bottomExtraPad by animateDpAsState(
            targetValue = when (cardAlignment) {
                Alignment.Center -> if (targetInVeryBottom) 82.dp else 0.dp
                Alignment.BottomCenter -> 24.dp
                else -> 0.dp
            },
            animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow),
            label = "cardBottomPad"
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Column(
                modifier = Modifier
                    .align(cardAlignment)
                    .padding(top = topExtraPad, bottom = bottomExtraPad)
                    .fillMaxWidth()
                    .widthIn(max = 440.dp)
                    .graphicsLayer {
                        scaleX = cardScale.value
                        scaleY = cardScale.value
                        translationY = cardLiftY.value
                    }
                    .shadow(
                        elevation = 24.dp,
                        shape = RoundedCornerShape(26.dp),
                        spotColor = palette.accentPrimary.copy(alpha = 0.35f)
                    )
                    .clip(RoundedCornerShape(26.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xEB15253A),
                                Color(0xF00D1929)
                            )
                        )
                    )
                    .border(
                        width = 1.2.dp,
                        brush = Brush.linearGradient(
                            listOf(
                                Color.White.copy(alpha = 0.38f),
                                palette.accentSoft.copy(alpha = 0.55f),
                                palette.gold.copy(alpha = 0.45f)
                            )
                        ),
                        shape = RoundedCornerShape(26.dp)
                    )
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header: Page guide label + animated step counter + Skip
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(palette.gold)
                                .graphicsLayer {
                                    val s = 0.85f + 0.3f * ringGlow
                                    scaleX = s
                                    scaleY = s
                                }
                        )
                        Text(
                            text = "${if (isBn) page.titleBn else page.titleEn} • ${safeIndex + 1} / ${steps.size}",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.gold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    TextButton(
                        onClick = onFinish,
                        modifier = Modifier
                            .heightIn(min = 44.dp)
                            .testTag("tutorial_skip_btn")
                    ) {
                        Text(
                            text = if (isBn) "বাদ দিন" else "Skip",
                            color = Color(0xFFCBD5E1),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                // Spring-animated step progress bars
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    steps.indices.forEach { idx ->
                        val segWeight by animateFloatAsState(
                            targetValue = if (idx == safeIndex) 2.4f else 1f,
                            animationSpec = spring(
                                dampingRatio = 0.76f,
                                stiffness = Spring.StiffnessMedium
                            ),
                            label = "stepSegWeight_$idx"
                        )
                        val segColor by animateColorAsState(
                            targetValue = when {
                                idx == safeIndex -> palette.gold
                                idx < safeIndex -> palette.accentSoft
                                else -> Color.White.copy(alpha = 0.16f)
                            },
                            animationSpec = tween(260),
                            label = "stepSegColor_$idx"
                        )
                        Box(
                            modifier = Modifier
                                .weight(segWeight.coerceAtLeast(0.5f))
                                .height(4.5.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(segColor)
                        )
                    }
                }

                // Directional Slide + Scale + Fade step content
                AnimatedContent(
                    targetState = safeIndex,
                    transitionSpec = {
                        if (reducedMotion) {
                            fadeIn(tween(120)) togetherWith fadeOut(tween(100))
                        } else {
                            val dir = navDirection
                            (slideInHorizontally(
                                animationSpec = tween(280, easing = FastOutSlowInEasing),
                                initialOffsetX = { fullWidth -> dir * (fullWidth / 3) }
                            ) + fadeIn(tween(240, easing = FastOutSlowInEasing)) + scaleIn(
                                initialScale = 0.95f,
                                animationSpec = tween(260, easing = FastOutSlowInEasing)
                            )) togetherWith (slideOutHorizontally(
                                animationSpec = tween(200, easing = FastOutSlowInEasing),
                                targetOffsetX = { fullWidth -> -dir * (fullWidth / 4) }
                            ) + fadeOut(tween(160)) + scaleOut(
                                targetScale = 0.96f,
                                animationSpec = tween(160)
                            ))
                        }
                    },
                    label = "coachMarkInfo"
                ) { animatedIdx ->
                    val step = steps[animatedIdx.coerceIn(0, steps.lastIndex)]
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (isBn) step.titleBn else step.titleEn,
                            style = MaterialTheme.typography.titleLarge,
                            color = Color(0xFFF8FAFC),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isBn) step.infoBn else step.infoEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFDCE6F2),
                            lineHeight = 21.sp
                        )
                        val cue = if (isBn) step.setupCueBn else step.setupCueEn
                        if (!cue.isNullOrBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(palette.gold.copy(alpha = 0.14f))
                                    .border(0.8.dp, palette.gold.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = null,
                                    tint = palette.gold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = cue,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFFFDF3D0),
                                    lineHeight = 17.sp
                                )
                            }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = currentStep.offersQuickJumpDemo,
                    enter = fadeIn(tween(220)) + expandVertically(spring(dampingRatio = 0.82f)),
                    exit = fadeOut(tween(150)) + shrinkVertically()
                ) {
                    OutlinedButton(
                        onClick = { showQuickJumpDemoWindow = true },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("tutorial_try_quick_jump_btn")
                    ) {
                        Text(
                            text = if (isBn) "কুইক জাম্প খোলার ডেমো দেখুন" else "Preview Quick Jump Window",
                            color = palette.gold,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Manual Back / Next / Done controls with smooth animated transitions
                val primaryBtnColor by animateColorAsState(
                    targetValue = if (isLast) palette.gold else palette.accentPrimary,
                    animationSpec = tween(260),
                    label = "tutorialNextBtnColor"
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AnimatedVisibility(
                        visible = safeIndex > 0,
                        enter = fadeIn(tween(200)) + expandHorizontally(tween(220)),
                        exit = fadeOut(tween(150)) + shrinkHorizontally(tween(180))
                    ) {
                        OutlinedButton(
                            onClick = {
                                navDirection = -1
                                stepIndex = (safeIndex - 1).coerceAtLeast(0)
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("tutorial_prev_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = null,
                                tint = Color(0xFFE2E8F0),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isBn) "পেছনে" else "Back", color = Color(0xFFE2E8F0))
                        }
                    }

                    Button(
                        onClick = {
                            if (isLast) {
                                onFinish()
                            } else {
                                navDirection = 1
                                stepIndex = safeIndex + 1
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = primaryBtnColor,
                            contentColor = Color(0xFF06111B)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag(if (isLast) "tutorial_finish_btn" else "tutorial_next_btn")
                    ) {
                        AnimatedContent(
                            targetState = isLast,
                            transitionSpec = {
                                (fadeIn(tween(200)) + scaleIn(initialScale = 0.92f)) togetherWith
                                    fadeOut(tween(140))
                            },
                            label = "tutorialActionLabel"
                        ) { finalStep ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (finalStep) {
                                        if (isBn) "সম্পন্ন" else "Done"
                                    } else {
                                        if (isBn) "পরবর্তী" else "Next"
                                    },
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = if (finalStep) Icons.Default.Check else Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Animated In-Tutorial Quick Jump Demo Window: demonstrates gesture + deck visually WITHOUT cancelling tutorial
            AnimatedVisibility(
                visible = showQuickJumpDemoWindow,
                enter = fadeIn(tween(220)),
                exit = fadeOut(tween(170)),
                modifier = Modifier.fillMaxSize()
            ) {
                val gestureAnim = rememberInfiniteTransition(label = "quickJumpGestureDemo")
                val swipeLift by gestureAnim.animateFloat(
                    initialValue = 0f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1400, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "swipeLift"
                )
                val previewItems = remember(activeQuickJumpShortcuts) {
                    activeQuickJumpShortcuts.ifEmpty { PortalQuickLaunch.defaultUrgentShortcuts }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xC8040B14)),
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedVisibility(
                        visible = showQuickJumpDemoWindow,
                        enter = scaleIn(
                            initialScale = 0.88f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        ) + slideInVertically(tween(260, easing = FastOutSlowInEasing)) { it / 8 } + fadeIn(tween(220)),
                        exit = scaleOut(targetScale = 0.92f, animationSpec = tween(160)) + fadeOut(tween(150))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 430.dp)
                                .shadow(
                                    elevation = 28.dp,
                                    shape = RoundedCornerShape(28.dp),
                                    spotColor = palette.accentPrimary.copy(alpha = 0.42f)
                                )
                                .clip(RoundedCornerShape(28.dp))
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(0xF515263D), Color(0xFA0A1524))
                                    )
                                )
                                .border(
                                    width = 1.25.dp,
                                    brush = Brush.linearGradient(
                                        listOf(
                                            Color.White.copy(alpha = 0.42f),
                                            palette.gold.copy(alpha = 0.65f),
                                            palette.accentSoft.copy(alpha = 0.55f)
                                        )
                                    ),
                                    shape = RoundedCornerShape(28.dp)
                                )
                                .verticalScroll(rememberScrollState())
                                .padding(18.dp)
                                .testTag("tutorial_quick_jump_demo_window"),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isBn) "কুইক জাম্প খোলার পদ্ধতি" else "How to Open Quick Jump",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = palette.gold,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isBn) "যেকোনো পেজ থেকে এক মুহূর্তে খুলুন" else "Accessible from any screen in one gesture",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFFCBD5E1)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(palette.accentPrimary.copy(alpha = 0.18f))
                                        .border(0.8.dp, palette.accentSoft.copy(alpha = 0.5f), RoundedCornerShape(999.dp))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (isBn) "ডেমো উইন্ডো" else "Demo",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.accentSoft,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Visual Gesture Guide Box (Animated Long-Press or Swipe-Up on center AI orb)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(Color.White.copy(alpha = 0.06f))
                                    .border(0.9.dp, palette.accentSoft.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(palette.accentPrimary.copy(alpha = 0.14f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowUp,
                                            contentDescription = null,
                                            tint = palette.gold.copy(alpha = 0.35f + 0.65f * (1f - swipeLift)),
                                            modifier = Modifier
                                                .size(18.dp)
                                                .graphicsLayer {
                                                    translationY = -swipeLift * 8f
                                                }
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .graphicsLayer {
                                                    translationY = -swipeLift * 6f
                                                    val s = 1f + 0.08f * (1f - swipeLift)
                                                    scaleX = s
                                                    scaleY = s
                                                }
                                                .clip(CircleShape)
                                                .background(
                                                    Brush.linearGradient(listOf(palette.accentPrimary, palette.gold))
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.AutoAwesome,
                                                contentDescription = null,
                                                tint = Color(0xFF06111B),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.TouchApp,
                                            contentDescription = null,
                                            tint = palette.gold,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Text(
                                            text = if (isBn) "লং-প্রেস বা ওপরে সোয়াইপ করুন" else "Long-Press or Swipe Up",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = Color(0xFFF8FAFC),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = if (isBn) {
                                            "নিচের মাঝখানের AI আইকনটি ১ সেকেন্ড চেপে ধরে রাখুন অথবা ওপরে সোয়াইপ করুন। সাথে সাথে আপনার কুইক জাম্প মেনু ভেসে উঠবে।"
                                        } else {
                                            "Press and hold the center AI emblem at the bottom dock—or swipe upward on it—to launch your Quick Jump deck instantly."
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFFDCE6F2),
                                        lineHeight = 18.sp
                                    )
                                }
                            }

                            // Live Visual Preview of User's Active Quick Jump Deck (non-cancelling preview)
                            Text(
                                text = if (isBn) "আপনার বর্তমান কুইক জাম্প শর্টকাট (${previewItems.size}টি)"
                                else "Your Current Quick Jump Deck (${previewItems.size} shortcuts)",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.accentSoft,
                                fontWeight = FontWeight.SemiBold
                            )
                            val rows = previewItems.chunked(3)
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                rows.forEach { rowItems ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        rowItems.forEach { action ->
                                            Column(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(14.dp))
                                                    .background(Color.White.copy(alpha = 0.06f))
                                                    .border(0.8.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(14.dp))
                                                    .padding(horizontal = 6.dp, vertical = 8.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Icon(
                                                    imageVector = action.icon,
                                                    contentDescription = null,
                                                    tint = palette.gold,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Text(
                                                    text = if (isBn) action.titleBn else action.titleEn,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Color(0xFFF1F5F9),
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                        repeat(3 - rowItems.size) {
                                            Spacer(modifier = Modifier.weight(1f))
                                        }
                                    }
                                }
                            }

                            Text(
                                text = if (isBn) "পরে সেটিংস → কুইক জাম্প থেকে ৪–৮টি শর্টকাট বদলাতে ও সাজাতে পারবেন।"
                                else "You can reorder or customize 4–8 shortcuts anytime in Settings → Quick Jump.",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF94A3B8),
                                lineHeight = 16.sp
                            )

                            Button(
                                onClick = { showQuickJumpDemoWindow = false },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.gold,
                                    contentColor = Color(0xFF06111B)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .testTag("tutorial_back_to_guide_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isBn) "গাইডে ফিরে যান" else "Back to Guide",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
