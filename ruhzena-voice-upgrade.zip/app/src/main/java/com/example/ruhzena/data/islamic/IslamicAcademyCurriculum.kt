package com.example.ruhzena.data.islamic

data class ModuleLessonPoint(
    val headingEn: String,
    val headingBn: String,
    val bodyEn: String,
    val bodyBn: String,
    val arabicSnippet: String = "",
    val arabicTransliteration: String = "",
    val sourceRef: String,
    val sourceUrl: String
)

data class ModuleQuizQuestion(
    val questionEn: String,
    val questionBn: String,
    val optionsEn: List<String>,
    val optionsBn: List<String>,
    val correctIndex: Int,
    val explanationEn: String,
    val explanationBn: String
)

data class GuidedLearningModule(
    val stepNumber: Int,
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val subtitleEn: String,
    val subtitleBn: String,
    val arabicTitle: String,
    val arabicTitleTransliteration: String = "",
    val durationMinutes: Int,
    val points: List<ModuleLessonPoint>,
    val quiz: List<ModuleQuizQuestion>,
    val relatedActionTag: String? = null // "PRAYER_GUIDE" or "ARABIC_STUDIO"
)

data class DetailedPrayerGuideStep(
    val id: String,
    val isWudu: Boolean,
    val stepNumber: Int,
    /** 0 = Qiyam (Standing), 1 = Ruku (Bowing), 2 = Sujud (Prostrating), 3 = Tashahhud/Sitting */
    val posturePanelIndex: Int,
    val titleEn: String,
    val titleBn: String,
    val whenToSayEn: String,
    val whenToSayBn: String,
    val arabicPhrase: String,
    val transliteration: String,
    val meaningEn: String,
    val meaningBn: String,
    val postureCueEn: String,
    val postureCueBn: String,
    val rulingBadge: String,
    val sourceRef: String,
    val sourceUrl: String
)

data class NarratedIslamicStory(
    val id: String,
    val categoryEn: String,
    val categoryBn: String,
    val titleEn: String,
    val titleBn: String,
    val arabicName: String,
    val arabicNameTransliteration: String = "",
    val eraOrder: Int = 1,
    val eraLabelEn: String = "",
    val eraLabelBn: String = "",
    val estimatedReadMinutes: Int = 5,
    val storyEn: String,
    val storyBn: String,
    val explanationEn: String = "",
    val explanationBn: String = "",
    val keyVerseOrHadithEn: String = "",
    val keyVerseOrHadithBn: String = "",
    val lessonEn: String,
    val lessonBn: String,
    val sourceRef: String,
    val sourceUrl: String
)

object IslamicAcademyCurriculum {

    val guidedModules: List<GuidedLearningModule> = listOf(
        GuidedLearningModule(
            stepNumber = 1,
            id = "mod_1_tawhid",
            titleEn = "Knowing Allah & The Six Articles of Faith",
            titleBn = "আল্লাহর পরিচয় ও ঈমানের ৬টি ভিত্তি",
            subtitleEn = "Start here: Tawhid, Allah's mercy, and the core beliefs of a believer.",
            subtitleBn = "এখান থেকে শুরু: তাওহীদ, আল্লাহর দয়া ও ঈমানের মূল বিশ্বাস।",
            arabicTitle = "التوحيد والإيمان",
            durationMinutes = 5,
            points = listOf(
                ModuleLessonPoint(
                    headingEn = "1. Absolute Oneness of Allah (Tawhid)",
                    headingBn = "১. আল্লাহর একত্ববাদ (তাওহীদ)",
                    bodyEn = "Islam begins with knowing that Allah is One—without partner, rival, or equal. He alone creates, sustains, hears every whisper of your heart, and deserves all worship.",
                    bodyBn = "ইসলামের সূচনা হলো এই বিশ্বাসে যে আল্লাহ এক ও অদ্বিতীয়। তাঁর কোনো শরিক নেই। তিনিই একমাত্র সৃষ্টিকর্তা, রিজিকদাতা এবং কেবল তিনিই ইবাদতের যোগ্য।",
                    arabicSnippet = "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ",
                    sourceRef = "Quran 112:1–4",
                    sourceUrl = "https://quran.com/112"
                ),
                ModuleLessonPoint(
                    headingEn = "2. The Six Articles of Faith (Arkan al-Iman)",
                    headingBn = "২. ঈমানের ৬টি রুকন",
                    bodyEn = "True faith rests on six pillars: believing in Allah, His Angels, His Revealed Books (culminating in the preserved Quran), His Messengers (from Adam to Muhammad ﷺ), the Last Day, and Divine Decree (Al-Qadr) with both effort and trust.",
                    bodyBn = "ঈমানের ছয়টি স্তম্ভ হলো: আল্লাহ, ফেরেশতাগণ, আসমানী কিতাবসমূহ, নবী-রাসূলগণ, আখিরাত এবং তাকদীরের ভালো-মন্দের প্রতি দৃঢ় বিশ্বাস।",
                    sourceRef = "Sahih Muslim 8a",
                    sourceUrl = "https://sunnah.com/muslim:8a"
                ),
                ModuleLessonPoint(
                    headingEn = "3. Direct Relationship Without Middlemen",
                    headingBn = "৩. আল্লাহর সাথে সরাসরি সম্পর্ক",
                    bodyEn = "You never need an intermediary to speak to Allah. Whenever you turn to Him sincerely—in any language, day or night—He is nearer than your jugular vein and answers.",
                    bodyBn = "আল্লাহকে ডাকার জন্য কোনো মাধ্যমের প্রয়োজন নেই। দিন বা রাতের যেকোনো মুহূর্তে আন্তরিকভাবে ডাকলে তিনি সরাসরি শোনেন ও সাড়া দেন।",
                    arabicSnippet = "وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ",
                    sourceRef = "Quran 2:186",
                    sourceUrl = "https://quran.com/2/186"
                )
            ),
            quiz = listOf(
                ModuleQuizQuestion(
                    questionEn = "What does Tawhid mean in Islam?",
                    questionBn = "ইসলামে তাওহীদ অর্থ কী?",
                    optionsEn = listOf(
                        "Affirming the absolute Oneness of Allah in Lordship and Worship",
                        "Praying only on Fridays",
                        "Memorizing the entire Arabic dictionary"
                    ),
                    optionsBn = listOf(
                        "সৃষ্টি ও ইবাদতে আল্লাহর একত্ববাদ স্বীকার করা",
                        "শুধুমাত্র শুক্রবারে নামাজ পড়া",
                        "সম্পূর্ণ আরবি অভিধান মুখস্থ করা"
                    ),
                    correctIndex = 0,
                    explanationEn = "Tawhid is the foundation of Islam: Allah alone is Creator and worthy of worship (Quran 112:1–4).",
                    explanationBn = "তাওহীদ ইসলামের মূল ভিত্তি—আল্লাহ এক ও একমাত্র ইবাদতের যোগ্য।"
                ),
                ModuleQuizQuestion(
                    questionEn = "How many Articles of Faith (Iman) did the Prophet ﷺ teach in Hadith Jibril?",
                    questionBn = "হাদিসে জিবরীলে ঈমানের কয়টি রুকনের কথা বলা হয়েছে?",
                    optionsEn = listOf("Four", "Six", "Ten"),
                    optionsBn = listOf("৪টি", "৬টি", "১০টি"),
                    correctIndex = 1,
                    explanationEn = "There are six articles: Allah, Angels, Books, Messengers, the Last Day, and Al-Qadr (Sahih Muslim 8a).",
                    explanationBn = "ঈমানের রুকন ৬টি (সহীহ মুসলিম ৮a)।"
                ),
                ModuleQuizQuestion(
                    questionEn = "According to Quran 2:186, what do you need in order to call upon Allah?",
                    questionBn = "কুরআন ২:১৮৬ অনুযায়ী আল্লাহকে ডাকার জন্য কী প্রয়োজন?",
                    optionsEn = listOf(
                        "A human intermediary to pass your message",
                        "Sincere direct Dua — Allah is near and responds directly",
                        "Waiting until a specific month of the year"
                    ),
                    optionsBn = listOf(
                        "অন্য কোনো মানুষের মাধ্যম",
                        "আন্তরিকভাবে সরাসরি দুআ করা — আল্লাহ অত্যন্ত নিকটবর্তী",
                        "বছরের নির্দিষ্ট মাসের অপেক্ষা করা"
                    ),
                    correctIndex = 1,
                    explanationEn = "Allah states 'Indeed I am near; I respond to the call of the supplicant when they call upon Me.'",
                    explanationBn = "আল্লাহ বলেছেন: 'নিশ্চয়ই আমি নিকটবর্তী; আহ্বানকারী যখন আমাকে ডাকে, আমি তার ডাকে সাড়া দিই।'"
                )
            )
        ),

        GuidedLearningModule(
            stepNumber = 2,
            id = "mod_2_pillars",
            titleEn = "The Five Pillars & Daily Muslim Rhythm",
            titleBn = "ইসলামের ৫টি স্তম্ভ ও দৈনন্দিন জীবনধারা",
            subtitleEn = "How belief becomes calm daily action: Shahadah, Salah, Zakah, Sawm & Hajj.",
            subtitleBn = "বিশ্বাস কীভাবে দৈনন্দিন আমলে রূপ নেয়: শাহাদাহ, সালাত, যাকাত, সিয়াম ও হজ।",
            arabicTitle = "أركان الإسلام الخمسة",
            durationMinutes = 5,
            points = listOf(
                ModuleLessonPoint(
                    headingEn = "1. Shahadah & The Five Daily Prayers",
                    headingBn = "১. শাহাদাহ ও পাঁচ ওয়াক্ত সালাত",
                    bodyEn = "Shahadah testifies that none deserves worship except Allah and Muhammad ﷺ is His Messenger. Salah anchors the day five times—Fajr, Dhuhr, Asr, Maghrib, and Isha—bringing peace to the heart.",
                    bodyBn = "শাহাদাহ ঈমানের ঘোষণা, আর ফজর, যোহর, আসর, মাগরিব ও এশা—এই পাঁচ ওয়াক্ত সালাত প্রতিদিন হৃদয়কে আল্লাহর সাথে যুক্ত রাখে।",
                    arabicSnippet = "أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا رَسُولُ اللَّهِ",
                    sourceRef = "Sahih al-Bukhari 8",
                    sourceUrl = "https://sunnah.com/bukhari:8"
                ),
                ModuleLessonPoint(
                    headingEn = "2. Zakah (Purifying Wealth) & Sawm (Fasting)",
                    headingBn = "২. যাকাত ও রমজানের সিয়াম",
                    bodyEn = "Zakah gives 2.5% of qualifying annual savings above Nisab to lift the poor and purify wealth. Sawm in Ramadan trains self-control, gratitude, and empathy from dawn to sunset.",
                    bodyBn = "নিসাব পরিমাণ সঞ্চিত সম্পদের ২.৫% যাকাত আদায় সম্পদকে পবিত্র করে। আর রমজানের রোজা তাকওয়া, আত্মনিয়ন্ত্রণ ও সহমর্মিতা শেখায়।",
                    sourceRef = "Quran 2:183 • 9:103",
                    sourceUrl = "https://quran.com/2/183"
                ),
                ModuleLessonPoint(
                    headingEn = "3. Hajj (Pilgrimage Once in a Lifetime)",
                    headingBn = "৩. সামর্থ্যবানদের জন্য জীবনে একবার হজ",
                    bodyEn = "Required only once in a lifetime for those who are physically and financially able, uniting believers of every race in humility before Allah in Makkah.",
                    bodyBn = "শারীরিক ও আর্থিকভাবে সামর্থ্যবানদের জন্য জীবনে একবার মক্কায় হজ আদায় ফরজ—যা বিশ্ব মুসলিমের সাম্য ও বিনয়ের প্রতীক।",
                    sourceRef = "Quran 3:97",
                    sourceUrl = "https://quran.com/3/97"
                )
            ),
            quiz = listOf(
                ModuleQuizQuestion(
                    questionEn = "Which pillar anchors a Muslim's connection with Allah five times every day?",
                    questionBn = "কোন স্তম্ভটি প্রতিদিন পাঁচবার মুসলিমকে আল্লাহর সাথে যুক্ত রাখে?",
                    optionsEn = listOf("Salah (Five Daily Prayers)", "Hajj", "Zakah"),
                    optionsBn = listOf("সালাত (পাঁচ ওয়াক্ত নামাজ)", "হজ", "যাকাত"),
                    correctIndex = 0,
                    explanationEn = "Salah (Fajr, Dhuhr, Asr, Maghrib, Isha) is the daily pillar of worship.",
                    explanationBn = "পাঁচ ওয়াক্ত সালাত প্রতিদিনের ফরজ ইবাদত।"
                ),
                ModuleQuizQuestion(
                    questionEn = "What is the standard annual Zakah rate on qualifying savings above Nisab?",
                    questionBn = "নিসাব পরিমাণ বার্ষিক সঞ্চয়ের ওপর যাকাতের হার কত?",
                    optionsEn = listOf("10%", "2.5%", "25%"),
                    optionsBn = listOf("১০%", "২.৫%", "২৫%"),
                    correctIndex = 1,
                    explanationEn = "Zakah on qualifying cash/gold/savings held for one lunar year is 2.5%.",
                    explanationBn = "সঞ্চিত নিসাব সম্পদের ওপর বার্ষিক ২.৫% যাকাত ফরজ।"
                ),
                ModuleQuizQuestion(
                    questionEn = "Who is required to perform Hajj?",
                    questionBn = "হজ কার ওপর ফরজ?",
                    optionsEn = listOf(
                        "Everyone every year regardless of health or money",
                        "Once in a lifetime for those physically and financially able",
                        "Only scholars"
                    ),
                    optionsBn = listOf(
                        "সামর্থ্য থাকুক বা না থাকুক প্রতি বছর সবার ওপর",
                        "শারীরিক ও আর্থিকভাবে সামর্থ্যবানদের ওপর জীবনে একবার",
                        "শুধুমাত্র আলেমদের ওপর"
                    ),
                    correctIndex = 1,
                    explanationEn = "Quran 3:97 specifies Hajj is upon whoever is able to find a way.",
                    explanationBn = "কুরআন ৩:৯৭ অনুযায়ী সামর্থ্যবানদের জন্য জীবনে একবার হজ ফরজ।"
                )
            )
        ),

        GuidedLearningModule(
            stepNumber = 3,
            id = "mod_3_wudu",
            titleEn = "Purification: Step-by-Step Wudu & Ghusl",
            titleBn = "পবিত্রতা: ধাপে ধাপে অজু ও ফরজ গোসল",
            subtitleEn = "How to purify cleanly before prayer, what breaks Wudu, and exact Duas.",
            subtitleBn = "নামাজের আগে সঠিকভাবে অজু করার নিয়ম, অজু ভঙ্গের কারণ ও দুআ।",
            arabicTitle = "الطهارة والوضوء",
            durationMinutes = 6,
            relatedActionTag = "PRAYER_GUIDE",
            points = listOf(
                ModuleLessonPoint(
                    headingEn = "1. The 4 Obligatory (Fard) Parts of Wudu",
                    headingBn = "১. অজুর ৪টি ফরজ কাজ",
                    bodyEn = "Quran 5:6 defines the four obligatory parts: (1) washing the entire face, (2) washing both arms including the elbows, (3) wiping the head with wet hands, and (4) washing both feet including the ankles.",
                    bodyBn = "কুরআন ৫:৬ অনুযায়ী অজুর ৪টি ফরজ: ১) সম্পূর্ণ মুখ ধোয়া, ২) কনুইসহ দুই হাত ধোয়া, ৩) ভেজা হাতে মাথা মাসাহ করা, ৪) টাখনুসহ দুই পা ধোয়া।",
                    arabicSnippet = "فَاغْسِلُوا وُجُوهَكُمْ وَأَيْدِيَكُمْ إِلَى الْمَرَافِقِ",
                    sourceRef = "Quran 5:6",
                    sourceUrl = "https://quran.com/5/6"
                ),
                ModuleLessonPoint(
                    headingEn = "2. Complete Prophetic Sequence & Conservation of Water",
                    headingBn = "২. সুন্নাহ পদ্ধতি ও পানির অপচয় রোধ",
                    bodyEn = "Intention in the heart → Say Bismillah → Wash hands 3× → Rinse mouth 3× & nose 3× → Wash face 3× → Wash right then left forearm to elbow 3× → Wipe head & ears once → Wash right then left foot to ankle 3× → Recite the Shahadah Dua. Never waste water.",
                    bodyBn = "নিয়ত → বিসমিল্লাহ → হাত ধোয়া ৩× → কুলি ও নাক ৩× → মুখ ৩× → কনুইসহ হাত ৩× → মাথা ও কান মাসাহ ১× → টাখনুসহ পা ৩× → শাহাদাত দুআ। পানি অপচয় করবেন না।",
                    sourceRef = "Sahih al-Bukhari 159 • Muslim 234",
                    sourceUrl = "https://sunnah.com/muslim:234"
                ),
                ModuleLessonPoint(
                    headingEn = "3. What Breaks Wudu & When Ghusl Is Needed",
                    headingBn = "৩. অজু ভঙ্গের কারণ ও ফরজ গোসল",
                    bodyEn = "Wudu is broken by using the restroom, passing gas, or deep sleep. Ghusl (full body wash reaching hair roots and all skin) is required after major ritual impurity or end of menstruation.",
                    bodyBn = "পায়খানা-প্রস্রাব, বায়ু নির্গত হওয়া বা গভীর ঘুমে অজু ভেঙে যায়। আর জানাবাত বা হায়েয শেষে পুরো শরীর ধুয়ে ফরজ গোসল করতে হয়।",
                    sourceRef = "Sahih al-Bukhari 248",
                    sourceUrl = "https://sunnah.com/bukhari:248"
                )
            ),
            quiz = listOf(
                ModuleQuizQuestion(
                    questionEn = "Which of these is one of the 4 Fard (obligatory) parts of Wudu in Quran 5:6?",
                    questionBn = "কুরআন ৫:৬ অনুযায়ী নিচের কোনটি অজুর ফরজ অংশ?",
                    optionsEn = listOf(
                        "Washing both arms up to and including the elbows",
                        "Using warm scented soap",
                        "Washing the back of the neck three times"
                    ),
                    optionsBn = listOf(
                        "কনুইসহ উভয় হাত ধোয়া",
                        "সুগন্ধি সাবান ব্যবহার করা",
                        "ঘাড় তিনবার ধোয়া"
                    ),
                    correctIndex = 0,
                    explanationEn = "Washing the face, arms including elbows, wiping the head, and washing feet including ankles are the 4 Fard acts.",
                    explanationBn = "মুখ, কনুইসহ হাত, মাথা মাসাহ ও টাখনুসহ পা ধোয়া অজুর ৪টি ফরজ।"
                ),
                ModuleQuizQuestion(
                    questionEn = "How many times do you wipe the head during Wudu?",
                    questionBn = "অজুতে মাথা কয়বার মাসাহ করতে হয়?",
                    optionsEn = listOf("Once", "Five times", "Seven times"),
                    optionsBn = listOf("১ বার", "৫ বার", "৭ বার"),
                    correctIndex = 0,
                    explanationEn = "The Prophet ﷺ wiped his head once from front to back and back to front (Bukhari 185).",
                    explanationBn = "নবীজি ﷺ মাথা একবার মাসাহ করেছেন।"
                ),
                ModuleQuizQuestion(
                    questionEn = "What should you say right after completing Wudu?",
                    questionBn = "অজু শেষ করে কোন দুআ পাঠ করা সুন্নাহ?",
                    optionsEn = listOf(
                        "Ashhadu an la ilaha illallah... (Shahadah Dua)",
                        "Nothing at all",
                        "Surah Al-Baqarah in full"
                    ),
                    optionsBn = listOf(
                        "আশহাদু আল্লা ইলাহা ইল্লাল্লাহ... (কালিমা শাহাদাত দুআ)",
                        "কিছুই না",
                        "সম্পূর্ণ সূরা বাকারা"
                    ),
                    correctIndex = 0,
                    explanationEn = "Sahih Muslim 234 narrates that reciting the Shahadah after Wudu opens all eight gates of Paradise.",
                    explanationBn = "সহীহ মুসলিম ২৩৪ অনুযায়ী অজুর পর শাহাদাত পাঠের অসাধারণ ফজিলত রয়েছে।"
                )
            )
        ),

        GuidedLearningModule(
            stepNumber = 4,
            id = "mod_4_salah",
            titleEn = "How to Pray Salah & When to Say What",
            titleBn = "সালাত আদায়ের নিয়ম ও কখন কী বলবেন",
            subtitleEn = "Master every posture (Qiyam, Ruku, Sujud, Tashahhud) with exact timing cues.",
            subtitleBn = "কিয়াম, রুকু, সিজদা ও বৈঠকের প্রতিটি ধাপে কখন কী পড়বেন তা শিখুন।",
            arabicTitle = "صفة الصلاة",
            durationMinutes = 7,
            relatedActionTag = "PRAYER_GUIDE",
            points = listOf(
                ModuleLessonPoint(
                    headingEn = "1. Entering Salah & Standing (Qiyam)",
                    headingBn = "১. তাকবীরে তাহরীমা ও কিয়াম (দাঁড়ানো)",
                    bodyEn = "Face Qibla, intend the prayer in your heart, raise hands saying 'Allahu Akbar', fold hands calmly, recite opening Dua (Sana), Surah Al-Fatihah, and a short Surah.",
                    bodyBn = "কিবলামুখী হয়ে নিয়ত করুন, 'আল্লাহু আকবার' বলে হাত বেঁধে ছানা, সূরা ফাতিহা এবং অন্য একটি সূরা পাঠ করুন।",
                    arabicSnippet = "اللَّهُ أَكْبَرُ • الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
                    sourceRef = "Sahih al-Bukhari 757",
                    sourceUrl = "https://sunnah.com/bukhari:757"
                ),
                ModuleLessonPoint(
                    headingEn = "2. Bowing (Ruku) → Standing → Two Prostrations (Sujud)",
                    headingBn = "২. রুকু, কাওমা এবং দুই সিজদা",
                    bodyEn = "Say 'Allahu Akbar' into Ruku (flat back, hands on knees) and say 'Subhana Rabbiyal-Azim' 3×. Rise saying 'Sami'Allahu liman hamidah, Rabbana wa lakal-hamd'. Prostrate on 7 points saying 'Subhana Rabbiyal-A'la' 3×, sit briefly saying 'Rabbighfir li', then do the second Sujud.",
                    bodyBn = "রুকুতে ৩ বার 'সুবহানা রাব্বিয়াল আযীম', উঠে 'সামিআল্লাহু লিমান হামিদাহ—রাব্বানা ওয়া লাকাল হামদ', সিজদায় ৩ বার 'সুবহানা রাব্বিয়াল আ'লা' এবং দুই সিজদার মাঝে 'রাব্বিগফির লী' বলুন।",
                    arabicSnippet = "سُبْحَانَ رَبِّيَ الْعَظِيمِ • سُبْحَانَ رَبِّيَ الْأَعْلَى",
                    sourceRef = "Sahih Muslim 772 • Bukhari 812",
                    sourceUrl = "https://sunnah.com/bukhari:812"
                ),
                ModuleLessonPoint(
                    headingEn = "3. Sitting (Tashahhud), Durood & Closing Salam (Taslim)",
                    headingBn = "৩. বৈঠক (তাশাহহুদ), দরুদ ও সালাম",
                    bodyEn = "In the final sitting, recite At-Tahiyyat, Durood Ibrahim, and a personal Dua, then conclude by turning right and left saying 'Assalamu Alaikum wa Rahmatullah'. Tip: Open the 'Pray' tab for full photorealistic posture portraits & audio!",
                    bodyBn = "শেষ বৈঠকে তাশাহহুদ, দরুদে ইব্রাহিম ও দুআ পড়ে ডান ও বাম কাঁধে 'আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহ' বলে সালাত শেষ করুন।",
                    arabicSnippet = "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ",
                    sourceRef = "Sahih al-Bukhari 831",
                    sourceUrl = "https://sunnah.com/bukhari:831"
                )
            ),
            quiz = listOf(
                ModuleQuizQuestion(
                    questionEn = "What do you say while bowing in Ruku?",
                    questionBn = "রুকু অবস্থায় কী বলতে হয়?",
                    optionsEn = listOf(
                        "Subhana Rabbiyal-Azim (Glory be to my Lord, the Most Great)",
                        "Subhana Rabbiyal-A'la",
                        "Assalamu Alaikum wa Rahmatullah"
                    ),
                    optionsBn = listOf(
                        "সুবহানা রাব্বিয়াল আযীম",
                        "সুবহানা রাব্বিয়াল আ'লা",
                        "আসসালামু আলাইকুম ওয়া রাহমাতুল্লাহ"
                    ),
                    correctIndex = 0,
                    explanationEn = "In Ruku we say 'Subhana Rabbiyal-Azim' (3×); 'Subhana Rabbiyal-A'la' is said in Sujud.",
                    explanationBn = "রুকুতে 'সুবহানা রাব্বিয়াল আযীম' এবং সিজদায় 'সুবহানা রাব্বিয়াল আ'লা' পড়তে হয়।"
                ),
                ModuleQuizQuestion(
                    questionEn = "When do you say 'Sami'Allahu liman hamidah'?",
                    questionBn = "'সামিআল্লাহু লিমান হামিদাহ' কখন বলতে হয়?",
                    optionsEn = listOf(
                        "When entering the first Sujud",
                        "When rising upright from Ruku (bowing)",
                        "When ending the prayer"
                    ),
                    optionsBn = listOf(
                        "প্রথম সিজদায় যাওয়ার সময়",
                        "রুকু থেকে সোজা হয়ে দাঁড়ানোর সময়",
                        "নামাজ শেষ করার সময়"
                    ),
                    correctIndex = 1,
                    explanationEn = "As you rise from Ruku you say 'Sami'Allahu liman hamidah', and once upright say 'Rabbana wa lakal-hamd'.",
                    explanationBn = "রুকু থেকে উঠতে উঠতে 'সামিআল্লাহু লিমান হামিদাহ' এবং সোজা হয়ে 'রাব্বানা ওয়া লাকাল হামদ' বলতে হয়।"
                ),
                ModuleQuizQuestion(
                    questionEn = "How many body parts touch the ground during Sujud (prostration)?",
                    questionBn = "সিজদায় শরীরের কয়টি অঙ্গ জমিনে স্পর্শ করে?",
                    optionsEn = listOf("3 parts", "7 parts (forehead+nose, 2 palms, 2 knees, toes of 2 feet)", "Only the forehead"),
                    optionsBn = listOf("৩টি অঙ্গ", "৭টি অঙ্গ (কপাল-নাক, ২ হাত, ২ হাঁটু ও ২ পায়ের আঙুল)", "শুধু কপাল"),
                    correctIndex = 1,
                    explanationEn = "Sahih al-Bukhari 812 teaches prostrating on seven bones: forehead/nose, both hands, both knees, and the toes of both feet.",
                    explanationBn = "সহীহ বুখারী ৮১২ অনুযায়ী ৭টি অঙ্গের ওপর সিজদা করা সুন্নাহ।"
                )
            )
        ),

        GuidedLearningModule(
            stepNumber = 5,
            id = "mod_5_quran",
            titleEn = "Surah Al-Fatihah & Reading the Noble Quran",
            titleBn = "সূরা ফাতিহা ও পবিত্র কুরআন তিলাওয়াতের ভিত্তি",
            subtitleEn = "Understand the Opening Chapter recited in every rak'ah and start Arabic letters.",
            subtitleBn = "প্রতি রাকাতে পঠিত সূরা ফাতিহার অর্থ এবং আরবি হরফ শেখার সূচনা।",
            arabicTitle = "سورة الفاتحة والقرآن",
            durationMinutes = 5,
            relatedActionTag = "ARABIC_STUDIO",
            points = listOf(
                ModuleLessonPoint(
                    headingEn = "1. Surah Al-Fatihah — A Conversation With Allah",
                    headingBn = "১. সূরা ফাতিহা — আল্লাহর সাথে সরাসরি কথোপকথন",
                    bodyEn = "In Hadith Qudsi (Sahih Muslim 395), Allah responds to every verse as you recite Al-Fatihah calmly—praising Him, acknowledging His mercy, asking solely for His help, and begging for the Straight Path.",
                    bodyBn = "হাদিসে কুদসী (মুসলিম ৩৯৫) অনুযায়ী বান্দা যখন শান্তভাবে সূরা ফাতিহার প্রতিটি আয়াত পড়ে, আল্লাহ প্রতিটি আয়াতের জবাব দেন।",
                    arabicSnippet = "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ",
                    sourceRef = "Quran 1:1–7 • Sahih Muslim 395",
                    sourceUrl = "https://quran.com/1"
                ),
                ModuleLessonPoint(
                    headingEn = "2. Double Reward for Struggling Learners",
                    headingBn = "২. নতুন শিক্ষার্থী ও কষ্ট করে পড়ার দ্বিগুণ সওয়াব",
                    bodyEn = "Never feel embarrassed if your Arabic reading is slow. The Prophet ﷺ promised that the one who recites the Quran with difficulty and stumbles receives a DOUBLE reward.",
                    bodyBn = "আরবি পড়তে কষ্ট হলে হতাশ হবেন না। নবীজি ﷺ সুসংবাদ দিয়েছেন—যিনি কষ্ট করে থেমে থেমে কুরআন পড়েন, তাঁর জন্য দ্বিগুণ সওয়াব রয়েছে।",
                    sourceRef = "Sahih al-Bukhari 4937 • Muslim 798",
                    sourceUrl = "https://sunnah.com/muslim:798"
                )
            ),
            quiz = listOf(
                ModuleQuizQuestion(
                    questionEn = "Which Surah is recited in every single rak'ah of Salah?",
                    questionBn = "নামাজের প্রতিটি রাকাতে কোন সূরা পাঠ করতে হয়?",
                    optionsEn = listOf("Surah Al-Fatihah", "Surah Yasin", "Surah Al-Kahf"),
                    optionsBn = listOf("সূরা আল-ফাতিহা", "সূরা ইয়াসীন", "সূরা আল-কাহফ"),
                    correctIndex = 0,
                    explanationEn = "Surah Al-Fatihah is essential in every unit (rak'ah) of prayer.",
                    explanationBn = "প্রতি রাকাতে সূরা আল-ফাতিহা পাঠ করা আবশ্যক।"
                ),
                ModuleQuizQuestion(
                    questionEn = "What did the Prophet ﷺ promise to someone who struggles while learning to read the Quran?",
                    questionBn = "যিনি কষ্ট করে কুরআন পড়া শেখেন, তাঁর জন্য নবীজি ﷺ কী পুরস্কারের কথা বলেছেন?",
                    optionsEn = listOf("They must stop until fluent", "They receive a double reward", "No reward until memorized"),
                    optionsBn = listOf("সাবলীল না হওয়া পর্যন্ত পড়া বন্ধ রাখা", "তাঁর জন্য দ্বিগুণ সওয়াব রয়েছে", "মুখস্থ না হওয়া পর্যন্ত সওয়াব নেই"),
                    correctIndex = 1,
                    explanationEn = "Sahih Muslim 798 confirms a double reward—one for recitation and one for the sincere effort.",
                    explanationBn = "তিলাওয়াত এবং আন্তরিক চেষ্টার জন্য দ্বিগুণ সওয়াব (সহীহ মুসলিম ৭৯৮)।"
                ),
                ModuleQuizQuestion(
                    questionEn = "What is the central plea at the heart of Surah Al-Fatihah?",
                    questionBn = "সূরা ফাতিহার মূল প্রার্থনা কী?",
                    optionsEn = listOf("Guide us to the Straight Path", "Grant us worldly fame", "Give us endless wealth"),
                    optionsBn = listOf("আমাদের সরল সঠিক পথ দেখান", "দুনিয়ার খ্যাতি দিন", "অসীম সম্পদ দিন"),
                    correctIndex = 0,
                    explanationEn = "'Ihdinas-Siratal-Mustaqim' — Guide us to the Straight Path (Quran 1:6).",
                    explanationBn = "'ইহদিনাস সিরাতাল মুস্তাকীম' — আমাদের সরল পথ প্রদর্শন করুন।"
                )
            )
        ),

        GuidedLearningModule(
            stepNumber = 6,
            id = "mod_6_character",
            titleEn = "Daily Sunnah, Character & Adab",
            titleBn = "দৈনন্দিন সুন্নাহ, উত্তম চরিত্র ও আদব",
            subtitleEn = "Honoring parents, guarding speech, gratitude, and Prophetic mercy.",
            subtitleBn = "পিতা-মাতার সম্মান, জবানের সংযম, কৃতজ্ঞতা ও নববী আখলাক।",
            arabicTitle = "الأخلاق والآداب",
            durationMinutes = 5,
            points = listOf(
                ModuleLessonPoint(
                    headingEn = "1. Excellence of Character (Husn al-Khuluq)",
                    headingBn = "১. উত্তম চরিত্রের মর্যাদা",
                    bodyEn = "The Prophet ﷺ said: 'The heaviest thing placed on the believer's scale on the Day of Resurrection is good character.' Kindness, honesty, patience, and smiling are acts of worship.",
                    bodyBn = "নবীজি ﷺ বলেছেন: 'কিয়ামতের দিন মুমিনের পাল্লায় সবচেয়ে ভারী আমল হবে উত্তম চরিত্র।' সত্যবাদিতা, ধৈর্য, হাসিমুখে কথা বলা ও বিনয় ইবাদতের অংশ।",
                    sourceRef = "Jami' at-Tirmidhi 2002",
                    sourceUrl = "https://sunnah.com/tirmidhi:2002"
                ),
                ModuleLessonPoint(
                    headingEn = "2. Honoring Parents & Guarding the Tongue",
                    headingBn = "২. পিতা-মাতার প্রতি সদাচরণ ও জবানের হেফাজত",
                    bodyEn = "Speak to parents with gentleness and never utter even 'Uff' in frustration (Quran 17:23). Guard your tongue from backbiting, sarcasm, and spreading unverified rumors (Quran 49:12).",
                    bodyBn = "পিতা-মাতার সাথে নম্র আচরণ করুন এবং বিরক্ত হয়ে 'উফ' শব্দটিও বলবেন না। গীবত, বিদ্রূপ ও যাচাইহীন কথা বলা থেকে বিরত থাকুন।",
                    sourceRef = "Quran 17:23 • 49:12",
                    sourceUrl = "https://quran.com/17/23"
                )
            ),
            quiz = listOf(
                ModuleQuizQuestion(
                    questionEn = "What will be the heaviest deed on the believer's scale on the Day of Judgment?",
                    questionBn = "কিয়ামতের দিন মুমিনের আমলনামার পাল্লায় সবচেয়ে ভারী কোনটি হবে?",
                    optionsEn = listOf("Good character (Husn al-Khuluq)", "Expensive clothes", "Winning debates online"),
                    optionsBn = listOf("উত্তম চরিত্র (হুসনুল খুলুক)", "দামি পোশাক", "অনলাইনে তর্কে জেতা"),
                    correctIndex = 0,
                    explanationEn = "At-Tirmidhi 2002: Nothing is heavier on the scale than good character.",
                    explanationBn = "তিরমিযী ২০০২ অনুযায়ী উত্তম চরিত্র সবচেয়ে ভারী আমল।"
                ),
                ModuleQuizQuestion(
                    questionEn = "What does the Prophet ﷺ advise regarding speech (Bukhari 6018)?",
                    questionBn = "কথা বলার বিষয়ে নবীজি ﷺ কী উপদেশ দিয়েছেন (বুখারী ৬০১৮)?",
                    optionsEn = listOf("Speak good or remain silent", "Share every rumor quickly", "Mock others for laughs"),
                    optionsBn = listOf("ভালো কথা বলো অথবা নীরব থাকো", "সব গুজব দ্রুত ছড়িয়ে দাও", "হাসির জন্য অন্যকে উপহাস করো"),
                    correctIndex = 0,
                    explanationEn = "Whoever believes in Allah and the Last Day should speak good or remain silent.",
                    explanationBn = "যে আল্লাহ ও আখিরাতে ঈমান রাখে সে যেন ভালো কথা বলে অথবা চুপ থাকে।"
                ),
                ModuleQuizQuestion(
                    questionEn = "How does Quran 17:23 instruct believers to treat parents?",
                    questionBn = "কুরআন ১৭:২৩-এ পিতা-মাতার সাথে কেমন আচরণের নির্দেশ দেওয়া হয়েছে?",
                    optionsEn = listOf("Speak gently and never even say 'Uff'", "Only talk on holidays", "Ignore them when busy"),
                    optionsBn = listOf("নম্র ও সম্মানজনক কথা বলা এবং 'উফ' পর্যন্ত না বলা", "শুধু ছুটির দিনে কথা বলা", "ব্যস্ত থাকলে এড়িয়ে চলা"),
                    correctIndex = 0,
                    explanationEn = "Respecting parents is placed directly after worshipping Allah alone.",
                    explanationBn = "আল্লাহর ইবাদতের পরপরই পিতা-মাতার প্রতি সদাচরণের নির্দেশ এসেছে।"
                )
            )
        ),

        GuidedLearningModule(
            stepNumber = 7,
            id = "mod_7_halal",
            titleEn = "Halal, Haram & Sunnah vs. Bid'ah",
            titleBn = "হালাল-হারাম এবং সুন্নাহ বনাম বিদ'আত",
            subtitleEn = "Practical ethics for food, earnings, contracts, and authentic worship.",
            subtitleBn = "খাদ্য, হালাল উপার্জন, লেনদেন এবং সহীহ ইবাদতের মানদণ্ড।",
            arabicTitle = "الحلال والحرام والسنة",
            durationMinutes = 5,
            points = listOf(
                ModuleLessonPoint(
                    headingEn = "1. Halal & Tayyib Sustenance",
                    headingBn = "১. হালাল ও পবিত্র (তাইয়্যিব) রিজিক",
                    bodyEn = "Eat what is lawful and wholesome, avoiding pork, alcohol, and intoxicants. Earn honestly without interest (Riba), fraud, or cheating—pure income brings barakah and answered Dua.",
                    bodyBn = "হালাল ও স্বাস্থ্যকর খাদ্য গ্রহণ করুন এবং মদ, মাদক ও হারাম মাংস বর্জন করুন। সুদ ও প্রতারণামুক্ত হালাল উপার্জন দুআ কবুলের শর্ত।",
                    sourceRef = "Quran 2:168 • 2:275 • Muslim 1015",
                    sourceUrl = "https://quran.com/2/168"
                ),
                ModuleLessonPoint(
                    headingEn = "2. Sunnah vs. Bid'ah & Respecting Valid Ikhtilaf",
                    headingBn = "২. সুন্নাহ বনাম বিদ'আত ও স্বীকৃত ফিকহী মতভেদ",
                    bodyEn = "Worldly tools (phones, cars, apps) are permissible unless harmful. Religious rituals require Quran & Sunnah proof. At the same time, recognized juristic differences among classical schools deserve respect, not division.",
                    bodyBn = "দুনিয়াবি প্রযুক্তি বিদ'আত নয়; বরং দলিলবিহীন নতুন ধর্মীয় ইবাদত উদ্ভাবন বিদ'আত। আর ফিকহী মাযহাবগুলোর স্বীকৃত মতভেদকে শ্রদ্ধার সাথে দেখতে হয়।",
                    sourceRef = "Sahih al-Bukhari 2697 • Quran 16:125",
                    sourceUrl = "https://sunnah.com/bukhari:2697"
                )
            ),
            quiz = listOf(
                ModuleQuizQuestion(
                    questionEn = "Are modern worldly tools like smartphones and educational apps considered Bid'ah?",
                    questionBn = "স্মার্টফোন বা শিক্ষামূলক অ্যাপের মতো দুনিয়াবি প্রযুক্তি কি বিদ'আত?",
                    optionsEn = listOf("Yes, all technology is forbidden", "No — Bid'ah applies to inventing ungrounded religious rituals", "Only on Mondays"),
                    optionsBn = listOf("হ্যাঁ, সব প্রযুক্তি নিষিদ্ধ", "না — দলিলবিহীন নতুন ধর্মীয় ইবাদত উদ্ভাবনই বিদ'আত", "শুধু সোমবারে"),
                    correctIndex = 1,
                    explanationEn = "Worldly innovations are permissible by default unless they cause harm or violate Islamic ethics.",
                    explanationBn = "উপকারী দুনিয়াবি প্রযুক্তি বৈধ; বিদ'আত হলো দ্বীনের মধ্যে দলিলবিহীন নতুন ইবাদত সংযোজন।"
                ),
                ModuleQuizQuestion(
                    questionEn = "What does 'Halalan Tayyiban' (Quran 2:168) encourage?",
                    questionBn = "কুরআন ২:১৬৮-এর 'হালালান তাইয়্যিবান' কী নির্দেশ করে?",
                    optionsEn = listOf("Lawful AND wholesome/clean nourishment", "Eating as much as possible", "Avoiding all fruit"),
                    optionsBn = listOf("বৈধ এবং স্বাস্থ্যকর ও পবিত্র খাদ্য গ্রহণ", "অতিরিক্ত ভোজন করা", "ফলমূল বর্জন করা"),
                    correctIndex = 0,
                    explanationEn = "Islam combines legality (Halal) with wholesomeness and moderation (Tayyib).",
                    explanationBn = "হালাল ও স্বাস্থ্যকর পরিমিত খাবার গ্রহণই ইসলামের নির্দেশনা।"
                ),
                ModuleQuizQuestion(
                    questionEn = "How should Muslims handle recognized scholarly differences (Ikhtilaf) among the four Sunni schools?",
                    questionBn = "স্বীকৃত ফিকহী মাযহাবগুলোর মতভেদের ক্ষেত্রে মুসলিমদের মনোভাব কেমন হওয়া উচিত?",
                    optionsEn = listOf("Hostility and insulting others", "Mutual respect and wisdom (Adab al-Khilaf)", "Ignoring prayer altogether"),
                    optionsBn = listOf("ঝগড়া ও অন্যকে অপমান করা", "পারস্পরিক শ্রদ্ধা ও প্রজ্ঞা (আদাবুল খিলাফ)", "নামাজ ছেড়ে দেওয়া"),
                    correctIndex = 1,
                    explanationEn = "Classical jurists differed on secondary details with deep evidence and remained united in brotherhood.",
                    explanationBn = "ইমামগণ দলিলের ভিত্তিতে মতভেদ করেছেন কিন্তু ভ্রাতৃত্ব ও শ্রদ্ধা অটুট রেখেছেন।"
                )
            )
        ),

        GuidedLearningModule(
            stepNumber = 8,
            id = "mod_8_history",
            titleEn = "Prophets, Companions & Living Heritage",
            titleBn = "নবী-রাসূল, সাহাবা ও ইসলামের ইতিহাস",
            subtitleEn = "Timeless courage from Seerah, Companions, and the Golden Age of knowledge.",
            subtitleBn = "সীরাত, সাহাবায়ে কেরাম এবং জ্ঞান-বিজ্ঞানের সোনালি অধ্যায়।",
            arabicTitle = "السيرة والتاريخ الإسلامي",
            durationMinutes = 6,
            points = listOf(
                ModuleLessonPoint(
                    headingEn = "1. Makkah to Madinah — Patience & Brotherhood",
                    headingBn = "১. মক্কা থেকে মদিনা — ধৈর্য ও ভ্রাতৃত্ব",
                    bodyEn = "From the first revelation 'Iqra' (Read!) in Cave Hira through 13 years of resilience in Makkah to the Charter of Madinah, the Prophet ﷺ transformed society with mercy, justice, and literacy.",
                    bodyBn = "হেরা গুহায় 'ইকরা' (পড়ো) ওহী থেকে শুরু করে মক্কায় ধৈর্য এবং মদিনায় ন্যায়বিচার ও আনসার-মুহাজির ভ্রাতৃত্বের মাধ্যমে নবীজি ﷺ আদর্শ সমাজ গড়ে তোলেন।",
                    sourceRef = "Quran 96:1–5 • Seerah",
                    sourceUrl = "https://quran.com/96"
                ),
                ModuleLessonPoint(
                    headingEn = "2. Seeking Beneficial Knowledge (Spiritual & Scientific)",
                    headingBn = "২. উপকারী জ্ঞান অন্বেষণের ঐতিহ্য",
                    bodyEn = "Inspired by the Quran, pioneers like Fatima al-Fihri (Al-Qarawiyyin University), Al-Khwarizmi (Algebra), Ibn al-Haytham (Scientific Method), and Ibn Sina (Medicine) showed that faith and reason flourish together.",
                    bodyBn = "ফাতিমা আল-ফিহরি, আল-খাওয়ারিজমি, ইবনুল হাইসাম ও ইবনে সিনার মতো মনীষীরা প্রমাণ করেছেন যে ঈমান ও বিজ্ঞান পরস্পরের পরিপূরক।",
                    sourceRef = "Quran 20:114",
                    sourceUrl = "https://quran.com/20/114"
                )
            ),
            quiz = listOf(
                ModuleQuizQuestion(
                    questionEn = "What was the very first word revealed to Prophet Muhammad ﷺ in Cave Hira?",
                    questionBn = "হেরা গুহায় নবী মুহাম্মদ ﷺ-এর ওপর অবতীর্ণ প্রথম শব্দ কোনটি?",
                    optionsEn = listOf("Iqra (Read!)", "Safar (Travel)", "Mal (Wealth)"),
                    optionsBn = listOf("ইকরা (পড়ো!)", "সফর (ভ্রমণ)", "মাল (সম্পদ)"),
                    correctIndex = 0,
                    explanationEn = "Surah Al-Alaq 96:1 begins with 'Iqra bismi Rabbika' — Read in the name of your Lord.",
                    explanationBn = "সূরা আলাকের প্রথম বাণী ছিল 'ইকরা' (পড়ো)।"
                ),
                ModuleQuizQuestion(
                    questionEn = "Who founded Al-Qarawiyyin, widely recognized as the world's oldest continually operating university?",
                    questionBn = "বিশ্বের প্রাচীনতম চলমান বিশ্ববিদ্যালয় আল-কারাউইয়্যিন কে প্রতিষ্ঠা করেন?",
                    optionsEn = listOf("Fatima al-Fihri", "Pharaoh", "Julius Caesar"),
                    optionsBn = listOf("ফাতিমা আল-ফিহরি", "ফেরাউন", "জুলিয়াস সিজার"),
                    correctIndex = 0,
                    explanationEn = "Fatima al-Fihri established Al-Qarawiyyin in Fez in 859 CE as a mosque and center of scholarship.",
                    explanationBn = "৮৫৯ খ্রিস্টাব্দে ফাতিমা আল-ফিহরি মরক্কোর ফেজে এটি প্রতিষ্ঠা করেন।"
                ),
                ModuleQuizQuestion(
                    questionEn = "What Quranic Dua asks Allah for beneficial knowledge (Quran 20:114)?",
                    questionBn = "কুরআন ২০:১১৪-এ জ্ঞান বৃদ্ধির কোন দুআ শেখানো হয়েছে?",
                    optionsEn = listOf("Rabbi zidni 'ilma (My Lord, increase me in knowledge)", "No Dua exists for knowledge", "Only asking for sleep"),
                    optionsBn = listOf("রাব্বি যিদনী ইলমা (হে আমার রব, আমার জ্ঞান বৃদ্ধি করুন)", "জ্ঞানের কোনো দুআ নেই", "শুধু ঘুমের দুআ"),
                    correctIndex = 0,
                    explanationEn = "'Rabbi zidni 'ilma' — My Lord, increase me in knowledge (Quran 20:114).",
                    explanationBn = "'রাব্বি যিদনী ইলমা' — হে আমার রব, আমার জ্ঞান বাড়িয়ে দিন।"
                )
            )
        )
    )

    val detailedSalahSteps: List<DetailedPrayerGuideStep> = listOf(
        DetailedPrayerGuideStep(
            id = "salah_step_1",
            isWudu = false,
            stepNumber = 1,
            posturePanelIndex = 0,
            titleEn = "1. Intention & Opening Takbir (Takbiratul Ihram)",
            titleBn = "১. নিয়ত ও তাকবীরে তাহরীমা",
            whenToSayEn = "WHEN TO SAY: Stand facing Qibla, make intention in your heart, raise both hands to ear/shoulder level and say this to begin Salah.",
            whenToSayBn = "কখন বলবেন: কিবলামুখী হয়ে দাঁড়িয়ে মনে মনে নিয়ত করে দুই হাত কান/কাঁধ বরাবর তুলে নামাজ শুরুর মুহূর্তে বলুন।",
            arabicPhrase = "اللَّهُ أَكْبَرُ",
            transliteration = "Allahu Akbar",
            meaningEn = "Allah is the Greatest.",
            meaningBn = "আল্লাহ সর্বশ্রেষ্ঠ।",
            postureCueEn = "Stand upright facing Qibla, eyes toward the place of Sujud. Raise open palms facing Qibla (Men: up to earlobes; Women: up to shoulder height).",
            postureCueBn = "কিবলামুখী হয়ে সোজা দাঁড়ান, দৃষ্টি সিজদার স্থানে। খোলা হাত কিবলামুখী করে তুলুন (পুরুষ: কানের লতি পর্যন্ত; নারী: কাঁধ বরাবর)।",
            rulingBadge = "Fard Pillar",
            sourceRef = "Sahih al-Bukhari 757",
            sourceUrl = "https://sunnah.com/bukhari:757"
        ),
        DetailedPrayerGuideStep(
            id = "salah_step_2",
            isWudu = false,
            stepNumber = 2,
            posturePanelIndex = 0,
            titleEn = "2. Standing (Qiyam) — Opening Dua, Al-Fatihah & Short Surah",
            titleBn = "২. কিয়াম (দাঁড়ানো) — ছানা, সূরা ফাতিহা ও অন্য সূরা",
            whenToSayEn = "WHEN TO SAY: Immediately after folding your right hand over your left hand while standing in Qiyam.",
            whenToSayBn = "কখন বলবেন: ডান হাত বাম হাতের ওপর বাঁধার পর পরই দাঁড়ানো অবস্থায় প্রথমে ছানা, তারপর সূরা ফাতিহা ও একটি ছোট সূরা পড়ুন।",
            arabicPhrase = "سُبْحَانَكَ اللَّهُمَّ وَبِحَمْدِكَ وَتَبَارَكَ اسْمُكَ وَتَعَالَىٰ جَدُّكَ وَلَا إِلَٰهَ غَيْرُكَ ۝ بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
            transliteration = "Subhanaka Allahumma wa bihamdika... then A'udhu billah, Bismillah, Surah Al-Fatihah, Amin, and a short Surah (e.g. Al-Ikhlas).",
            meaningEn = "Glory be to You, O Allah, and praise be to You... All praise belongs to Allah, Lord of all worlds.",
            meaningBn = "হে আল্লাহ! আপনি পবিত্র ও প্রশংসিত... সমস্ত প্রশংসা জগতসমূহের প্রতিপালক আল্লাহর জন্য।",
            postureCueEn = "Keep shoulders relaxed, back upright, right hand over left, and recite unhurriedly with presence of heart.",
            postureCueBn = "কাঁধ শিথিল, পিঠ সোজা ও ডান হাত বাম হাতের ওপর রেখে ধীরস্থিরভাবে মনোযোগসহ তিলাওয়াত করুন।",
            rulingBadge = "Fard Pillar",
            sourceRef = "Sahih al-Bukhari 756 • Abu Dawud 775",
            sourceUrl = "https://sunnah.com/bukhari:756"
        ),
        DetailedPrayerGuideStep(
            id = "salah_step_3",
            isWudu = false,
            stepNumber = 3,
            posturePanelIndex = 1,
            titleEn = "3. Bowing (Ruku)",
            titleBn = "৩. রুকু (মাথা ও পিঠ সমান্তরাল করে ঝুঁকে পড়া)",
            whenToSayEn = "WHEN TO SAY: Say 'Allahu Akbar' as you bend into bowing. Once your back is flat and hands grip your knees, recite this 3 times calmly.",
            whenToSayBn = "কখন বলবেন: 'আল্লাহু আকবার' বলে রুকুতে যান। পিঠ সোজা ও হাত হাঁটুর ওপর স্থির হলে শান্তভাবে ৩ বার পড়ুন।",
            arabicPhrase = "سُبْحَانَ رَبِّيَ الْعَظِيمِ",
            transliteration = "Subhana Rabbiyal-Azim (3×)",
            meaningEn = "Glory be to my Lord, the Most Great.",
            meaningBn = "আমার মহান প্রতিপালক পবিত্র ও মহিমাময়।",
            postureCueEn = "Keep back flat at 90° like a tabletop, head aligned with spine, hands gripping knees (Men: elbows bowed gently out; Women: arms kept closer and compact).",
            postureCueBn = "পিঠ ও মাথা সমান্তরাল রেখে দুই হাতে হাঁটু ধরুন (পুরুষ: কনুই কিছুটা ফাঁকা; নারী: বাহু শরীরের কাছাকাছি সংযত রাখবেন)।",
            rulingBadge = "Fard Pillar",
            sourceRef = "Sahih Muslim 772",
            sourceUrl = "https://sunnah.com/muslim:772"
        ),
        DetailedPrayerGuideStep(
            id = "salah_step_4",
            isWudu = false,
            stepNumber = 4,
            posturePanelIndex = 0,
            titleEn = "4. Rising Upright From Ruku (Qawmah)",
            titleBn = "৪. রুকু থেকে সোজা হয়ে দাঁড়ানো (কাওমা)",
            whenToSayEn = "WHEN TO SAY: Say the first phrase WHILE rising up from Ruku. Once completely upright and still, say the second phrase.",
            whenToSayBn = "কখন বলবেন: রুকু থেকে উঠতে উঠতে প্রথম বাক্য বলুন। সম্পূর্ণ সোজা হয়ে দাঁড়ানোর পর দ্বিতীয় বাক্য বলুন।",
            arabicPhrase = "سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ ۝ رَبَّنَا وَلَكَ الْحَمْدُ",
            transliteration = "Sami'Allahu liman hamidah  →  Rabbana wa lakal-hamd",
            meaningEn = "Allah hears whoever praises Him. Our Lord, to You belongs all praise.",
            meaningBn = "যে আল্লাহর প্রশংসা করে আল্লাহ তার কথা শোনেন। হে আমাদের রব, সমস্ত প্রশংসা কেবল আপনারই।",
            postureCueEn = "Rise fully upright and release BOTH arms calmly straight down at your sides — do NOT fold hands back onto the chest (for both Men and Women). Pause calmly before descending to Sujud.",
            postureCueBn = "সম্পূর্ণ সোজা হয়ে দাঁড়িয়ে দুই হাত স্বাভাবিকভাবে দুই পাশে ছেড়ে দিন — পুনরায় বুকে বা নাভিতে বাঁধবেন না (পুরুষ ও নারী উভয়ের জন্য)। এক মুহূর্ত স্থির হয়ে তারপর সিজদায় যান।",
            rulingBadge = "Fard Pillar",
            sourceRef = "Sahih al-Bukhari 789",
            sourceUrl = "https://sunnah.com/bukhari:789"
        ),
        DetailedPrayerGuideStep(
            id = "salah_step_5",
            isWudu = false,
            stepNumber = 5,
            posturePanelIndex = 2,
            titleEn = "5. First Prostration (Sujud)",
            titleBn = "৫. প্রথম সিজদা",
            whenToSayEn = "WHEN TO SAY: Say 'Allahu Akbar' while going down to the floor. Once forehead, nose, palms, knees, and toes rest on the mat, say this 3 times (and make personal Dua!).",
            whenToSayBn = "কখন বলবেন: 'আল্লাহু আকবার' বলে সিজদায় যান। কপাল-নাক, দুই হাত, দুই হাঁটু ও পায়ের আঙুল জমিনে স্থির হলে ৩ বার পড়ুন।",
            arabicPhrase = "سُبْحَانَ رَبِّيَ الْأَعْلَى",
            transliteration = "Subhana Rabbiyal-A'la (3×)",
            meaningEn = "Glory be to my Lord, the Most High.",
            meaningBn = "আমার সর্বোচ্চ প্রতিপালক পবিত্র ও মহিমাময়।",
            postureCueEn = "7 body points touch the mat (forehead+nose, 2 palms, 2 knees, toes of 2 feet). Men lift elbows off the mat away from ribs; Women maintain a compact modest posture.",
            postureCueBn = "৭টি অঙ্গ জমিনে থাকবে (কপাল-নাক, দুই হাত, দুই হাঁটু ও পায়ের আঙুল)। পুরুষ কনুই জমিন থেকে উঁচু রাখবেন; নারী সংযত ও সংকুচিত ভঙ্গিতে সিজদা করবেন।",
            rulingBadge = "Fard Pillar",
            sourceRef = "Sahih al-Bukhari 812 • Muslim 482",
            sourceUrl = "https://sunnah.com/muslim:482"
        ),
        DetailedPrayerGuideStep(
            id = "salah_step_6",
            isWudu = false,
            stepNumber = 6,
            posturePanelIndex = 3,
            titleEn = "6. Brief Sitting Between Two Sujud (Jalsa) & Second Sujud",
            titleBn = "৬. দুই সিজদার মাঝের বৈঠক (জালসা) ও দ্বিতীয় সিজদা",
            whenToSayEn = "WHEN TO SAY: Say 'Allahu Akbar' rising into a brief calm seated posture, say this Dua twice, then say 'Allahu Akbar' for your second Sujud.",
            whenToSayBn = "কখন বলবেন: 'আল্লাহু আকবার' বলে সোজা বসে শান্তভাবে এই দুআটি ২ বার বলুন, তারপর 'আল্লাহু আকবার' বলে দ্বিতীয় সিজদা করুন।",
            arabicPhrase = "رَبِّ اغْفِرْ لِي، رَبِّ اغْفِرْ لِي",
            transliteration = "Rabbighfir li, Rabbighfir li",
            meaningEn = "My Lord, forgive me; my Lord, forgive me.",
            meaningBn = "হে আমার রব, আমাকে ক্ষমা করুন; হে আমার রব, আমাকে ক্ষমা করুন।",
            postureCueEn = "Sit upright calmly with both palms resting flat on your thighs before entering the second Sujud.",
            postureCueBn = "দুই হাত উরুর ওপর স্বাভাবিকভাবে রেখে শান্তভাবে সোজা বসে তারপর দ্বিতীয় সিজদায় যান।",
            rulingBadge = "Fard Pillar",
            sourceRef = "Sunan Abi Dawud 874",
            sourceUrl = "https://sunnah.com/abudawud:874"
        ),
        DetailedPrayerGuideStep(
            id = "salah_step_7",
            isWudu = false,
            stepNumber = 7,
            posturePanelIndex = 3,
            titleEn = "7. Final Sitting — Tashahhud & Durood Ibrahim",
            titleBn = "৭. শেষ বৈঠক — তাশাহহুদ ও দরুদে ইব্রাহিম",
            whenToSayEn = "WHEN TO SAY: After the 2nd rak'ah (recite At-Tahiyyat) and in the final sitting of prayer (recite At-Tahiyyat + Durood Ibrahim + personal Dua).",
            whenToSayBn = "কখন বলবেন: দ্বিতীয় রাকাতের পর তাশাহহুদ এবং শেষ বৈঠকে তাশাহহুদ, দরুদে ইব্রাহিম ও দুআ মাসূরা পাঠ করুন।",
            arabicPhrase = "التَّحِيَّاتُ لِلَّهِ وَالصَّلَوَاتُ وَالطَّيِّبَاتُ، السَّلَامُ عَلَيْكَ أَيُّهَا النَّبِيُّ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ، السَّلَامُ عَلَيْنَا وَعَلَىٰ عِبَادِ اللَّهِ الصَّالِحِينَ، أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ",
            transliteration = "At-Tahiyyatu lillahi was-salawatu wat-tayyibat... Ashhadu an la ilaha illallah wa ashhadu anna Muhammadan 'abduhu wa rasuluh. (Then Durood Ibrahim in final sitting.)",
            meaningEn = "All compliments, prayers, and pure words are due to Allah. Peace be upon you, O Prophet, and the mercy and blessings of Allah. Peace be upon us and upon the righteous servants of Allah. I testify none deserves worship except Allah, and Muhammad is His servant and Messenger.",
            meaningBn = "সকল মৌখিক, শারীরিক ও আর্থিক ইবাদত আল্লাহর জন্য। হে নবী, আপনার ওপর শান্তি ও আল্লাহর রহমত-বরকত বর্ষিত হোক। আমাদের ও নেক বান্দাদের ওপর শান্তি বর্ষিত হোক। আমি সাক্ষ্য দিচ্ছি আল্লাহ ছাড়া কোনো ইলাহ নেই এবং মুহাম্মদ (সা.) তাঁর বান্দা ও রাসূল।",
            postureCueEn = "Sit calmly with hands on thighs, clearly raising the right index finger during the Shahadah ('Ashhadu an la ilaha illallah') with eyes resting on it.",
            postureCueBn = "স্থির হয়ে বসে থাকুন এবং শাহাদাতের ('আশহাদু আল্লা ইলাহা ইল্লাল্লাহ') সময় ডান হাতের শাহাদাত আঙুল তুলে ইশারা করুন।",
            rulingBadge = "Fard Sitting",
            sourceRef = "Sahih al-Bukhari 831 • 3370",
            sourceUrl = "https://sunnah.com/bukhari:831"
        ),
        DetailedPrayerGuideStep(
            id = "salah_step_8",
            isWudu = false,
            stepNumber = 8,
            posturePanelIndex = 3,
            titleEn = "8. Concluding Salam (Taslim)",
            titleBn = "৮. সালাম ফিরিয়ে সালাত সম্পন্ন করা",
            whenToSayEn = "WHEN TO SAY: After finishing Tashahhud, Durood, and final Dua, turn your head gently to the RIGHT saying Salam, then to the LEFT saying Salam.",
            whenToSayBn = "কখন বলবেন: তাশাহহুদ, দরুদ ও দুআ শেষে প্রথমে ডান কাঁধের দিকে মুখ ঘুরিয়ে এবং পরে বাম কাঁধের দিকে মুখ ঘুরিয়ে বলুন।",
            arabicPhrase = "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ",
            transliteration = "Assalamu Alaikum wa Rahmatullah (Right, then Left)",
            meaningEn = "May the peace and mercy of Allah be upon you.",
            meaningBn = "আপনাদের ওপর শান্তি ও আল্লাহর রহমত বর্ষিত হোক।",
            postureCueEn = "Keep shoulders steady while turning your head smoothly to the RIGHT, then smoothly to the LEFT, concluding prayer with serenity and post-prayer Adhkar.",
            postureCueBn = "কাঁধ স্থির রেখে প্রথমে ডানে ও পরে বামে মাথা ঘুরিয়ে প্রশান্তির সাথে নামাজ শেষ করুন।",
            rulingBadge = "Fard Closing",
            sourceRef = "Sahih Muslim 582",
            sourceUrl = "https://sunnah.com/muslim:582"
        )
    )

    val detailedWuduSteps: List<DetailedPrayerGuideStep> = listOf(
        DetailedPrayerGuideStep(
            id = "wudu_step_1",
            isWudu = true,
            stepNumber = 1,
            posturePanelIndex = 0,
            titleEn = "1. Intention (Niyyah), Bismillah & Wash Hands (3×)",
            titleBn = "১. নিয়ত, বিসমিল্লাহ ও কবজি পর্যন্ত হাত ধোয়া (৩×)",
            whenToSayEn = "WHEN TO SAY: Before turning on the water or right as you begin washing both hands to the wrists.",
            whenToSayBn = "কখন বলবেন: অজু শুরু করার মুহূর্তে মনে মনে নিয়ত করে মুখে বলুন।",
            arabicPhrase = "بِسْمِ اللَّهِ",
            transliteration = "Bismillah",
            meaningEn = "In the name of Allah.",
            meaningBn = "আল্লাহর নামে শুরু করছি।",
            postureCueEn = "Wash right hand then left hand up to the wrists 3 times, interlacing fingers cleanly.",
            postureCueBn = "ডান হাত ও বাম হাত কবজি পর্যন্ত আঙুলের ফাঁকসহ ৩ বার ধৌত করুন।",
            rulingBadge = "Sunnah Start",
            sourceRef = "Sunan Abi Dawud 101 • Bukhari 159",
            sourceUrl = "https://sunnah.com/bukhari:159"
        ),
        DetailedPrayerGuideStep(
            id = "wudu_step_2",
            isWudu = true,
            stepNumber = 2,
            posturePanelIndex = 0,
            titleEn = "2. Rinse Mouth (3×), Clean Nose (3×) & Wash Face (3×)",
            titleBn = "২. কুলি (৩×), নাক পরিষ্কার (৩×) ও মুখমণ্ডল ধোয়া (৩×)",
            whenToSayEn = "NO SPOKEN DUA PRESCRIBED: Perform silently with calm focus while rinsing mouth, cleaning nostrils, and washing the entire face.",
            whenToSayBn = "কোনো নির্দিষ্ট দুআ নেই: নীরবে ও মনোযোগের সাথে কুলি, নাক পরিষ্কার এবং সম্পূর্ণ মুখমণ্ডল ধৌত করুন।",
            arabicPhrase = "",
            transliteration = "",
            meaningEn = "",
            meaningBn = "",
            postureCueEn = "Swish water gently in mouth (3×), sniff softly into nostrils and blow out with left hand (3×), then wash the entire face from hairline to chin, ear to ear (3×, Fard).",
            postureCueBn = "৩ বার কুলি, ৩ বার নাকে পানি দিয়ে বাম হাতে পরিষ্কার এবং কপালের গোড়া থেকে থুতনি ও কান থেকে কান পর্যন্ত সম্পূর্ণ মুখমণ্ডল ৩ বার ধুয়ে নিন (ফরজ)।",
            rulingBadge = "Fard (Face)",
            sourceRef = "Quran 5:6 • Bukhari 159",
            sourceUrl = "https://quran.com/5/6"
        ),
        DetailedPrayerGuideStep(
            id = "wudu_step_3",
            isWudu = true,
            stepNumber = 3,
            posturePanelIndex = 0,
            titleEn = "3. Forearms to Elbows (3×), Head & Ears Wipe (1×), Feet (3×)",
            titleBn = "৩. কনুইসহ হাত (৩×), মাথা-কান মাসাহ (১×) ও টাখনুসহ পা (৩×)",
            whenToSayEn = "NO SPOKEN DUA PRESCRIBED: Perform silently in order, making sure water reaches every spot on the elbows and heels.",
            whenToSayBn = "কোনো নির্দিষ্ট দুআ নেই: নীরবে ধারাবাহিকভাবে কনুই ও গোড়ালিতে যেন শুকনো অংশ না থাকে সেদিকে খেয়াল রেখে ধৌত করুন।",
            arabicPhrase = "",
            transliteration = "",
            meaningEn = "",
            meaningBn = "",
            postureCueEn = "Wash right arm then left arm past elbows (3×). Wipe wet palms from front hairline to nape and back once, plus inside/behind ears. Wash right foot then left foot past ankles including between toes (3×).",
            postureCueBn = "ডান ও বাম হাত কনুইসহ ৩ বার, ভেজা হাতে মাথা ও কান ১ বার মাসাহ এবং ডান ও বাম পা টাখনুসহ আঙুলের ফাঁকসহ ৩ বার ধুয়ে নিন।",
            rulingBadge = "Fard Pillars",
            sourceRef = "Quran 5:6 • Bukhari 185",
            sourceUrl = "https://sunnah.com/bukhari:185"
        ),
        DetailedPrayerGuideStep(
            id = "wudu_step_4",
            isWudu = true,
            stepNumber = 4,
            posturePanelIndex = 0,
            titleEn = "4. Dua Immediately After Completing Wudu",
            titleBn = "৪. অজু শেষ করার পরের দুআ",
            whenToSayEn = "WHEN TO SAY: Right after finishing your left foot and stepping away from the sink.",
            whenToSayBn = "কখন বলবেন: বাম পা ধোয়া শেষ করে অজু সম্পন্ন করার সাথে সাথে পড়ুন।",
            arabicPhrase = "أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ، اللَّهُمَّ اجْعَلْنِي مِنَ التَّوَّابِينَ وَاجْعَلْنِي مِنَ الْمُتَطَهِّرِينَ",
            transliteration = "Ashhadu an la ilaha illallahu wahdahu la sharika lah, wa ashhadu anna Muhammadan 'abduhu wa rasuluh. Allahummaj'alni minat-tawwabina waj'alni minal-mutatahhirin.",
            meaningEn = "I testify that none deserves worship except Allah alone without partner, and Muhammad is His servant and Messenger. O Allah, make me among those who repent and those who purify themselves.",
            meaningBn = "আমি সাক্ষ্য দিচ্ছি এক আল্লাহ ছাড়া কোনো ইলাহ নেই, তাঁর কোনো শরিক নেই, এবং মুহাম্মদ (সা.) তাঁর বান্দা ও রাসূল। হে আল্লাহ, আমাকে তাওবাকারী ও পবিত্রতা অর্জনকারীদের অন্তর্ভুক্ত করুন।",
            postureCueEn = "Whoever recites this with sincerity after perfecting Wudu has all eight gates of Paradise opened for them.",
            postureCueBn = "উত্তমরূপে অজু করে এই দুআ পাঠ করলে জান্নাতের আটটি দরজা খুলে দেওয়া হয়।",
            rulingBadge = "Authentic Sunnah",
            sourceRef = "Sahih Muslim 234 • Tirmidhi 55",
            sourceUrl = "https://sunnah.com/muslim:234"
        )
    )

    /**
     * Strictly chronological & contextual 15-chapter authentic Islamic timeline:
     * Creation -> Adam (AS) -> Nuh (AS) -> Ibrahim (AS) -> Ismail (AS) -> Yusuf (AS) -> Ayyub (AS) ->
     * Musa (AS) -> Dawud & Sulayman (AS) -> Yunus (AS) -> Isa (AS) -> Muhammad (ﷺ) -> Noble Companions (RA).
     */
    val narratedStories: List<NarratedIslamicStory>
        get() = ExpandedIslamicStoriesCatalog.allDetailedStories
}
