package com.example.ruhzena.ai.agent

import android.graphics.Bitmap
import android.util.Base64
import com.example.ruhzena.ai.FirebaseGeminiService
import com.example.ruhzena.ai.MealPhotoAnalysis
import com.example.ruhzena.data.local.UserPreferences
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.ConnectionPool
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Unified inference adapter contract for RuhZena AI's 4 core providers:
 * Groq, OpenRouter, Cloudflare Workers AI, and Firebase AI Logic (Google Gemini).
 */
interface AiProviderAdapter {
    val providerId: AiProviderId
    fun isConfigured(): Boolean
    fun streamCompletion(model: AiModelSpec, payload: AgentRequestPayload): Flow<String>
    suspend fun analyzeMealImage(
        model: AiModelSpec,
        bitmap: Bitmap,
        prefs: UserPreferences,
        mealType: String
    ): MealPhotoAnalysis
}

/**
 * Classifies HTTP status codes, headers, and error bodies across all cloud AI providers
 * into accurate failover failure kinds for instant, intelligent switching.
 */
object HttpFailureClassifier {
    fun classifyHttpFailure(
        statusCode: Int,
        errorBody: String,
        retryAfterHeader: String? = null
    ): AiProviderException {
        val lower = errorBody.lowercase()
        val retryAfterSec = parseRetryAfterSeconds(retryAfterHeader, errorBody)

        val kind = when {
            statusCode == 402 ||
                lower.contains("payment required") ||
                lower.contains("insufficient_quota") ||
                lower.contains("insufficient balance") ||
                lower.contains("credit") && (lower.contains("exhausted") || lower.contains("exceeded") || lower.contains("insufficient")) ||
                lower.contains("quota exceeded") ||
                lower.contains("daily limit") ||
                lower.contains("neurons") && lower.contains("limit") -> AiFailureKind.QUOTA_EXHAUSTED
            statusCode == 401 || statusCode == 403 -> AiFailureKind.AUTH_INVALID
            statusCode == 404 ||
                lower.contains("model_not_found") ||
                lower.contains("decommissioned") ||
                lower.contains("does not exist") ||
                lower.contains("no endpoints found") ||
                lower.contains("invalid model") -> AiFailureKind.MODEL_UNAVAILABLE
            statusCode == 429 ||
                lower.contains("rate_limit") ||
                lower.contains("rate limit") ||
                lower.contains("too many requests") -> AiFailureKind.RATE_LIMIT_429
            statusCode == 529 ||
                lower.contains("overloaded") ||
                lower.contains("high demand") ||
                lower.contains("capacity") ||
                lower.contains("busy") -> AiFailureKind.HIGH_DEMAND_OVERLOAD
            statusCode in 500..599 -> AiFailureKind.SERVER_OUTAGE_5XX
            statusCode == 408 -> AiFailureKind.TIMEOUT_OR_STALL
            else -> AiFailureKind.UNKNOWN
        }
        return AiProviderException(
            kind = kind,
            httpCode = statusCode,
            retryAfterSeconds = retryAfterSec,
            message = "HTTP $statusCode ($kind): ${errorBody.take(180)}"
        )
    }

    fun classifyThrowable(t: Throwable, hadPartialStream: Boolean = false): AiProviderException {
        if (t is AiProviderException) return t
        val msg = t.message.orEmpty().lowercase()
        val kind = when {
            hadPartialStream -> AiFailureKind.MID_STREAM_INTERRUPT
            t is TimeoutCancellationException || t is SocketTimeoutException || msg.contains("timeout") || msg.contains("timed out") ->
                AiFailureKind.TIMEOUT_OR_STALL
            t is UnknownHostException || t is IOException || msg.contains("unable to resolve") || msg.contains("connection") ->
                AiFailureKind.NETWORK_ERROR
            msg.contains("402") || msg.contains("payment required") || msg.contains("insufficient_quota") ->
                AiFailureKind.QUOTA_EXHAUSTED
            msg.contains("429") || msg.contains("rate") || msg.contains("resource_exhausted") || msg.contains("quota") ->
                AiFailureKind.RATE_LIMIT_429
            msg.contains("overloaded") || msg.contains("high demand") || msg.contains("529") ->
                AiFailureKind.HIGH_DEMAND_OVERLOAD
            msg.contains("503") || msg.contains("502") || msg.contains("500") || msg.contains("unavailable") ->
                AiFailureKind.SERVER_OUTAGE_5XX
            msg.contains("404") || msg.contains("not found") || msg.contains("decommissioned") ->
                AiFailureKind.MODEL_UNAVAILABLE
            msg.contains("401") || msg.contains("403") || msg.contains("app check") ->
                AiFailureKind.AUTH_INVALID
            else -> AiFailureKind.UNKNOWN
        }
        return AiProviderException(
            kind = kind,
            message = t.message ?: kind.name,
            cause = t
        )
    }

    private fun parseRetryAfterSeconds(headerVal: String?, body: String): Long? {
        headerVal?.trim()?.toLongOrNull()?.let { return it }
        val secMatch = Regex("""(?:retry[- ]after|try again in|reset[^0-9]{0,12})(\d+)\s*(?:s|sec|seconds)?""", RegexOption.IGNORE_CASE)
            .find(headerVal.orEmpty() + " " + body)
        return secMatch?.groupValues?.getOrNull(1)?.toLongOrNull()
    }
}

/**
 * Fast, low-latency OpenAI-compatible HTTP/SSE adapter serving the 3 existing HTTP providers:
 * Groq, OpenRouter, and Cloudflare Workers AI (all original endpoints & headers preserved).
 */
class OpenAiCompatibleProviderAdapter(
    override val providerId: AiProviderId,
    private val credentialProvider: AiCredentialProvider,
    private val httpClient: OkHttpClient = defaultHttpClient(),
    private val endpointOverride: String? = null
) : AiProviderAdapter {

    override fun isConfigured(): Boolean {
        val creds = credentialProvider.getSnapshot()
        return when (providerId) {
            AiProviderId.GROQ -> creds.hasGroq
            AiProviderId.OPENROUTER -> creds.hasOpenRouter
            AiProviderId.CLOUDFLARE -> creds.hasCloudflare
            else -> false
        }
    }

    internal fun resolveEndpointAndHeaders(): Pair<String, Map<String, String>> {
        val creds = credentialProvider.getSnapshot()
        val proxyBase = creds.customProxyBaseUrl
        val baseHeaders = mutableMapOf("Content-Type" to "application/json")

        val url = endpointOverride ?: when (providerId) {
            AiProviderId.GROQ -> {
                baseHeaders["Authorization"] = "Bearer ${creds.groqApiKey}"
                if (proxyBase.isNotBlank()) "$proxyBase/groq/v1/chat/completions"
                else "https://api.groq.com/openai/v1/chat/completions"
            }
            AiProviderId.OPENROUTER -> {
                baseHeaders["Authorization"] = "Bearer ${creds.openRouterApiKey}"
                baseHeaders["HTTP-Referer"] = "https://ruhzena.app"
                baseHeaders["X-Title"] = "RuhZena AI"
                if (proxyBase.isNotBlank()) "$proxyBase/openrouter/v1/chat/completions"
                else "https://openrouter.ai/api/v1/chat/completions"
            }
            AiProviderId.CLOUDFLARE -> {
                baseHeaders["Authorization"] = "Bearer ${creds.cloudflareApiToken}"
                if (proxyBase.isNotBlank()) "$proxyBase/cloudflare/ai/v1/chat/completions"
                else "https://api.cloudflare.com/client/v4/accounts/${creds.cloudflareAccountId}/ai/v1/chat/completions"
            }
            else -> throw AiProviderException(AiFailureKind.UNKNOWN, message = "Unsupported OpenAI-compatible provider: $providerId")
        }

        if (endpointOverride != null) {
            val key = creds.apiKeyFor(providerId)
            if (key.isNotBlank()) baseHeaders["Authorization"] = "Bearer $key"
        }

        return url to baseHeaders
    }

    override fun streamCompletion(model: AiModelSpec, payload: AgentRequestPayload): Flow<String> = flow {
        val (endpointUrl, headers) = resolveEndpointAndHeaders()

        val messagesJson = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", payload.systemPrompt))
            payload.messages.forEach { turn ->
                put(
                    JSONObject()
                        .put("role", if (turn.isUser) "user" else "assistant")
                        .put("content", turn.content)
                )
            }
        }

        val bodyJson = JSONObject().apply {
            put("model", model.modelId)
            put("messages", messagesJson)
            put("temperature", payload.temperature)
            put("max_tokens", payload.maxOutputTokens.coerceAtMost(model.maxOutputTokens))
            put("stream", model.supportsStreaming && !payload.expectJson)
            if (payload.expectJson) {
                put("response_format", JSONObject().put("type", "json_object"))
            }
        }

        val reqBuilder = Request.Builder()
            .url(endpointUrl)
            .post(bodyJson.toString().toRequestBody(JSON_MEDIA_TYPE))
        headers.forEach { (k, v) -> reqBuilder.header(k, v) }

        val call = httpClient.newCall(reqBuilder.build())
        var emittedAny = false

        try {
            withTimeout(payload.streamTimeoutMs.coerceIn(15_000L, 45_000L)) {
                call.execute().use { response ->
                    if (!response.isSuccessful) {
                        val errText = response.body?.string().orEmpty()
                        val retryHeader = response.header("Retry-After")
                            ?: response.header("x-ratelimit-reset-requests")
                        throw HttpFailureClassifier.classifyHttpFailure(response.code, errText, retryHeader)
                    }

                    val responseBody = response.body
                        ?: throw AiProviderException(AiFailureKind.EMPTY_RESPONSE, message = "Null response body")

                    val contentType = response.header("Content-Type").orEmpty().lowercase()
                    if (contentType.contains("text/event-stream") || (model.supportsStreaming && !payload.expectJson && !contentType.contains("application/json"))) {
                        val source = responseBody.source()
                        while (currentCoroutineContext().isActive && !source.exhausted()) {
                            val line = source.readUtf8Line() ?: break
                            val trimmed = line.trim()
                            if (trimmed.isEmpty() || trimmed.startsWith(":")) continue
                            if (trimmed == "data: [DONE]" || trimmed == "[DONE]") break
                            val dataPayload = if (trimmed.startsWith("data:")) {
                                trimmed.removePrefix("data:").trim()
                            } else {
                                trimmed
                            }
                            if (dataPayload.isEmpty() || dataPayload == "[DONE]") continue
                            val delta = extractSseDelta(dataPayload)
                            if (delta.isNotEmpty()) {
                                emittedAny = true
                                emit(delta)
                            }
                        }
                    } else {
                        val fullStr = responseBody.string()
                        val text = extractNonStreamContent(fullStr)
                        if (text.isNotEmpty()) {
                            emittedAny = true
                            emit(text)
                        }
                    }
                }
            }
        } catch (e: CancellationException) {
            call.cancel()
            if (e is TimeoutCancellationException) {
                throw AiProviderException(
                    kind = if (emittedAny) AiFailureKind.MID_STREAM_INTERRUPT else AiFailureKind.TIMEOUT_OR_STALL,
                    message = "Provider stream timed out",
                    cause = e
                )
            }
            throw e
        } catch (e: AiProviderException) {
            throw e
        } catch (e: Exception) {
            throw HttpFailureClassifier.classifyThrowable(e, hadPartialStream = emittedAny)
        }

        if (!emittedAny) {
            throw AiProviderException(AiFailureKind.EMPTY_RESPONSE, message = "Provider returned empty completion")
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun analyzeMealImage(
        model: AiModelSpec,
        bitmap: Bitmap,
        prefs: UserPreferences,
        mealType: String
    ): MealPhotoAnalysis = withContext(Dispatchers.IO) {
        val (endpointUrl, headers) = resolveEndpointAndHeaders()
        val isBn = prefs.language == com.example.ruhzena.core.i18n.AppLanguage.BANGLA
        val base64Jpeg = encodeBitmapToJpegBase64(bitmap)

        val promptText = buildString {
            append("Analyze this meal photo carefully and return ONLY valid JSON with exact keys: ")
            append("dishName (string), detectedItems (array of strings), calories (int), proteinGrams (int), carbsGrams (int), fatGrams (int), ")
            append("healthVerdict (one of GOOD_CHOICE, MODERATE, LIMIT), recommendationReason (string), improvementTip (string).\n")
            append("Language for text values: ${if (isBn) "Bangla (বাংলা)" else "English"}.\n")
            append("Meal slot: $mealType | User goal: ${prefs.fitnessGoal} | Level: ${prefs.fitnessLevel} | Weight: ${prefs.weightKg}kg | Limitations: ${prefs.fitnessLimitation}.")
        }

        val contentArray = JSONArray().apply {
            put(JSONObject().put("type", "text").put("text", promptText))
            put(
                JSONObject()
                    .put("type", "image_url")
                    .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$base64Jpeg"))
            )
        }

        val messagesJson = JSONArray().apply {
            put(
                JSONObject()
                    .put("role", "system")
                    .put("content", "You are an accurate nutritionist evaluating real meal photos. Always return raw JSON only.")
            )
            put(JSONObject().put("role", "user").put("content", contentArray))
        }

        val bodyJson = JSONObject().apply {
            put("model", model.modelId)
            put("messages", messagesJson)
            put("temperature", 0.2)
            put("max_tokens", 700)
            put("stream", false)
        }

        val reqBuilder = Request.Builder()
            .url(endpointUrl)
            .post(bodyJson.toString().toRequestBody(JSON_MEDIA_TYPE))
        headers.forEach { (k, v) -> reqBuilder.header(k, v) }

        val call = httpClient.newCall(reqBuilder.build())
        try {
            withTimeout(30_000L) {
                call.execute().use { response ->
                    if (!response.isSuccessful) {
                        val errText = response.body?.string().orEmpty()
                        throw HttpFailureClassifier.classifyHttpFailure(
                            response.code,
                            errText,
                            response.header("Retry-After")
                        )
                    }
                    val rawResp = response.body?.string().orEmpty()
                    val text = extractNonStreamContent(rawResp)
                    parseMealAnalysisJson(text, isBn)
                }
            }
        } catch (e: CancellationException) {
            call.cancel()
            if (e is TimeoutCancellationException) {
                throw AiProviderException(AiFailureKind.TIMEOUT_OR_STALL, message = "Vision timeout", cause = e)
            }
            throw e
        } catch (e: AiProviderException) {
            throw e
        } catch (e: Exception) {
            throw HttpFailureClassifier.classifyThrowable(e)
        }
    }

    private fun extractSseDelta(jsonChunk: String): String {
        val obj = runCatching { JSONObject(jsonChunk) }.getOrNull() ?: return ""
        obj.optJSONObject("error")?.let { errObj ->
            val msg = errObj.optString("message", "Stream provider error")
            val code = errObj.optInt("code", 503)
            throw HttpFailureClassifier.classifyHttpFailure(code, msg)
        }
        val choices = obj.optJSONArray("choices")
        if (choices != null && choices.length() > 0) {
            val first = choices.optJSONObject(0)
            val delta = first?.optJSONObject("delta")
            val content = delta?.optString("content").orEmpty()
            if (content.isNotEmpty()) return content
            val msgContent = first?.optJSONObject("message")?.optString("content").orEmpty()
            if (msgContent.isNotEmpty()) return msgContent
        }
        return obj.optString("response").orEmpty()
    }

    private fun extractNonStreamContent(rawJson: String): String {
        val obj = JSONObject(rawJson)
        val choices = obj.optJSONArray("choices")
        if (choices != null && choices.length() > 0) {
            val msg = choices.optJSONObject(0)?.optJSONObject("message")
            val content = msg?.optString("content").orEmpty()
            if (content.isNotBlank()) return content
        }
        val resultObj = obj.optJSONObject("result")
        if (resultObj != null) {
            val cfText = resultObj.optString("response")
            if (cfText.isNotBlank()) return cfText
        }
        return obj.optString("response").orEmpty()
    }

    private fun parseMealAnalysisJson(rawText: String, isBn: Boolean): MealPhotoAnalysis {
        val cleaned = rawText.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        val startIdx = cleaned.indexOf('{')
        val endIdx = cleaned.lastIndexOf('}')
        if (startIdx < 0 || endIdx <= startIdx) {
            throw AiProviderException(AiFailureKind.EMPTY_RESPONSE, message = "Vision response lacked valid JSON")
        }
        val obj = JSONObject(cleaned.substring(startIdx, endIdx + 1))
        val itemsArr = obj.optJSONArray("detectedItems")
        val items = buildList {
            if (itemsArr != null) {
                for (i in 0 until itemsArr.length()) {
                    itemsArr.optString(i).takeIf { it.isNotBlank() }?.let(::add)
                }
            }
        }
        val rawVerdict = obj.optString("healthVerdict", "MODERATE").uppercase()
        val verdict = if (rawVerdict in setOf("GOOD_CHOICE", "MODERATE", "LIMIT")) rawVerdict else "MODERATE"
        return MealPhotoAnalysis(
            dishName = obj.optString("dishName").ifBlank { if (isBn) "শনাক্তকৃত খাবার" else "Analyzed Meal" },
            detectedItems = items,
            calories = obj.optInt("calories", 350).coerceAtLeast(10),
            proteinGrams = obj.optInt("proteinGrams", 15).coerceAtLeast(0),
            carbsGrams = obj.optInt("carbsGrams", 35).coerceAtLeast(0),
            fatGrams = obj.optInt("fatGrams", 12).coerceAtLeast(0),
            healthVerdict = verdict,
            recommendationReason = obj.optString("recommendationReason"),
            improvementTip = obj.optString("improvementTip")
        )
    }

    private fun encodeBitmapToJpegBase64(bitmap: Bitmap): String {
        val maxDim = 900
        val longest = max(bitmap.width, bitmap.height)
        val scaled = if (longest > maxDim) {
            val ratio = maxDim.toFloat() / longest.toFloat()
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * ratio).roundToInt().coerceAtLeast(1),
                (bitmap.height * ratio).roundToInt().coerceAtLeast(1),
                true
            )
        } else {
            bitmap
        }
        val baos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        /**
         * Speed-optimized shared OkHttpClient with HTTP/2 keep-alive pooling and fail-fast
         * timeouts (`retryOnConnectionFailure = false` so RuhZena's failover router switches
         * immediately to the next healthy provider instead of stalling on silent socket retries).
         */
        fun defaultHttpClient(): OkHttpClient = OkHttpClient.Builder()
            .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }
}

/**
 * Keyless Firebase AI Logic adapter (App Check attested) preserving Gemini 3.x Flash models
 * (`gemini-3.8-flash` & `gemini-3.5-flash-lite`) with bounded model-instance caching to avoid
 * repeated SDK initialization overhead between consecutive turns.
 */
class FirebaseAiLogicProviderAdapter : AiProviderAdapter {
    override val providerId: AiProviderId = AiProviderId.FIREBASE_GEMINI

    private val modelCacheLock = Any()
    private val modelCache = object : LinkedHashMap<String, GenerativeModel>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, GenerativeModel>?): Boolean =
            size > 6
    }

    override fun isConfigured(): Boolean = true

    private fun getOrCreateModel(modelId: String, systemPrompt: String): GenerativeModel {
        val cacheKey = "$modelId::${systemPrompt.hashCode()}::${systemPrompt.length}"
        synchronized(modelCacheLock) {
            modelCache[cacheKey]?.let { return it }
            val created = Firebase.ai.generativeModel(
                modelName = modelId,
                systemInstruction = content { text(systemPrompt) }
            )
            modelCache[cacheKey] = created
            return created
        }
    }

    override fun streamCompletion(model: AiModelSpec, payload: AgentRequestPayload): Flow<String> = flow {
        val generativeModel = getOrCreateModel(model.modelId, payload.systemPrompt)

        val historyTurns = payload.messages.dropLast(1)
        val latestUserPrompt = payload.messages.lastOrNull()?.content.orEmpty()
        val history: List<Content> = historyTurns
            .filter { it.content.isNotBlank() }
            .map { turn ->
                content(role = if (turn.isUser) "user" else "model") {
                    text(turn.content)
                }
            }

        val chat = generativeModel.startChat(history = history)
        var emittedAny = false

        try {
            withTimeout(payload.streamTimeoutMs.coerceIn(15_000L, 45_000L)) {
                chat.sendMessageStream(latestUserPrompt).collect { chunk ->
                    val part = chunk.text.orEmpty()
                    if (part.isNotEmpty()) {
                        emittedAny = true
                        emit(part)
                    }
                }
            }
        } catch (e: CancellationException) {
            if (e is TimeoutCancellationException) {
                throw AiProviderException(
                    kind = if (emittedAny) AiFailureKind.MID_STREAM_INTERRUPT else AiFailureKind.TIMEOUT_OR_STALL,
                    message = "Firebase AI stream timed out",
                    cause = e
                )
            }
            throw e
        } catch (e: Exception) {
            throw HttpFailureClassifier.classifyThrowable(e, hadPartialStream = emittedAny)
        }

        if (!emittedAny) {
            throw AiProviderException(AiFailureKind.EMPTY_RESPONSE, message = "Firebase AI returned empty text")
        }
    }

    override suspend fun analyzeMealImage(
        model: AiModelSpec,
        bitmap: Bitmap,
        prefs: UserPreferences,
        mealType: String
    ): MealPhotoAnalysis {
        return try {
            FirebaseGeminiService.analyzeMealPhoto(bitmap, prefs, mealType, modelOverride = model.modelId)
        } catch (e: CancellationException) {
            if (e is TimeoutCancellationException) {
                throw AiProviderException(AiFailureKind.TIMEOUT_OR_STALL, message = "Firebase meal vision timed out", cause = e)
            }
            throw e
        } catch (e: Exception) {
            throw HttpFailureClassifier.classifyThrowable(e)
        }
    }
}
