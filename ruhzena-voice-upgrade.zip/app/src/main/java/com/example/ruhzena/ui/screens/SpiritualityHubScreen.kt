package com.example.ruhzena.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.core.i18n.LocalStrings
import com.example.ruhzena.core.sensors.LocationFetchResult
import com.example.ruhzena.core.ui.FoldedDropdownOption
import com.example.ruhzena.core.ui.FoldedPageDropdown
import com.example.ruhzena.data.islamic.AdhkarCategory
import com.example.ruhzena.data.islamic.CityPreset
import com.example.ruhzena.data.islamic.DailyPrayerSchedule
import com.example.ruhzena.data.islamic.NextPrayerInfo
import com.example.ruhzena.data.islamic.PrayerCalcMethod
import com.example.ruhzena.data.islamic.QuranAudioRef
import com.example.ruhzena.data.islamic.QuranAyah
import com.example.ruhzena.data.islamic.QuranReciter
import com.example.ruhzena.data.local.BookmarkEntity
import com.example.ruhzena.data.local.UserPreferences
import com.example.ruhzena.media.AudioPlaybackState
import com.example.ruhzena.ui.AyahExplanationState
import com.example.ruhzena.ui.QuranReaderUiState
import com.example.ruhzena.ui.components.TutorialTargetKeys
import com.example.ruhzena.ui.components.tutorialTarget
import com.example.ui.theme.LocalRuhZenaPalette

enum class SpiritualitySubTab { QURAN, PRAYER_QIBLA, ADHKAR_DUA, TASBIH, LESSONS }

private data class DeenSectionOption(
    val tab: SpiritualitySubTab,
    val title: String,
    val subtitleEn: String,
    val subtitleBn: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
fun SpiritualityHubScreen(
    selectedTab: SpiritualitySubTab,
    onSelectTab: (SpiritualitySubTab) -> Unit,
    openQuranReader: Boolean,
    onSetQuranReaderOpen: (Boolean) -> Unit,
    initialShowDua: Boolean = false,
    pendingDuaId: String? = null,
    pendingDuaQuery: String? = null,
    onConsumedPendingDua: () -> Unit = {},
    pendingScrollAyah: Int? = null,
    onConsumedScrollAyah: () -> Unit = {},
    prefs: UserPreferences,
    quranState: QuranReaderUiState,
    ayahExplanationState: AyahExplanationState,
    cachedSurahs: List<Int>,
    audioState: AudioPlaybackState,
    bookmarks: List<BookmarkEntity>,
    isOnline: Boolean,
    prayerSchedule: DailyPrayerSchedule,
    nextPrayer: NextPrayerInfo,
    citySearchResults: List<CityPreset>,
    isSearchingCity: Boolean,
    tasbihCount: Int,
    activeTasbihCategory: AdhkarCategory? = null,
    returnAdhkarCategory: AdhkarCategory? = null,
    onStartGuidedTasbih: (AdhkarCategory) -> Unit = {},
    onCompleteGuidedTasbih: (AdhkarCategory) -> Unit = {},
    onClearGuidedTasbih: () -> Unit = {},
    speakingItemId: String? = null,
    onSpeakArabic: (itemId: String, arabicText: String, fallback: String) -> Unit = { _, _, _ -> },
    onSpeakLocalized: (itemId: String, text: String) -> Unit = { _, _ -> },
    onSelectSurah: (Int) -> Unit,
    onPlaySurahAyah: (Int, Int) -> Unit,
    onTogglePlayPause: () -> Unit,
    onSelectReciter: (QuranReciter) -> Unit,
    onChangeFontSize: (Int) -> Unit,
    onTogglePronunciation: (Boolean) -> Unit,
    onDownloadAllOffline: () -> Unit,
    onToggleBookmark: (BookmarkEntity, Boolean) -> Unit,
    onMarkLastRead: (Int, Int) -> Unit,
    onLoadAyahExplanation: (QuranAyah) -> Unit,
    onRetryAyahExplanation: (QuranAyah) -> Unit = onLoadAyahExplanation,
    onClearAyahExplanation: () -> Unit,
    onSearchCity: (String) -> Unit,
    onSelectCity: (CityPreset) -> Unit,
    onSelectCalcMethod: (PrayerCalcMethod) -> Unit,
    onSelectAsrMethod: (String) -> Unit = {},
    onAdjustHijriOffset: (Int) -> Unit = {},
    onRefreshGps: ((LocationFetchResult) -> Unit) -> Unit,
    onPlayHumanDhikrOrDua: (String, String, String, QuranAudioRef?, Int?, String) -> Unit,
    onTapTasbih: (Int) -> Unit,
    onUndoTasbih: () -> Unit = {},
    onResetTasbih: () -> Unit,
    onOpenGlobalSearch: () -> Unit = {},
    onOpenBookmarksHub: () -> Unit = {},
    onOpenLearningHub: () -> Unit = {},
    onAskRuhZebaAi: (String, String) -> Unit = { _, _ -> }
) {
    val strings = LocalStrings.current
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA

    val sectionOptions = remember(strings) {
        listOf(
            DeenSectionOption(
                SpiritualitySubTab.QURAN,
                strings.tabQuran,
                "114 Surahs • Recitation & Tafsir",
                "১১৪ সূরা • তিলাওয়াত ও তাফসির",
                Icons.AutoMirrored.Filled.MenuBook,
                "spirituality_tab_quran"
            ),
            DeenSectionOption(
                SpiritualitySubTab.PRAYER_QIBLA,
                strings.tabPrayerQibla,
                "Prayer Times & Qibla Compass",
                "নামাজের সময়সূচি ও কিবলা কম্পাস",
                Icons.Default.Explore,
                "spirituality_tab_prayer_qibla"
            ),
            DeenSectionOption(
                SpiritualitySubTab.ADHKAR_DUA,
                strings.tabAdhkarDua,
                "Step-by-Step Adhkar & Sunnah Duas",
                "ধাপে ধাপে যিকির ও মাসনুন দুআ",
                Icons.Default.Favorite,
                "spirituality_tab_adhkar_dua"
            ),
            DeenSectionOption(
                SpiritualitySubTab.TASBIH,
                strings.tabTasbih,
                "Tactile Dhikr & Audio Counter",
                "তাসবিহ ও ধাপে ধাপে যিকির গণনা",
                Icons.Default.RadioButtonChecked,
                "spirituality_tab_tasbih"
            ),
            DeenSectionOption(
                SpiritualitySubTab.LESSONS,
                strings.tabLessons,
                "Hourly Knowledge & Daily Wisdom",
                "ঘণ্টায় ঘণ্টায় ইসলামিক জ্ঞান ও হিকমাহ",
                Icons.Default.Lightbulb,
                "spirituality_tab_lessons"
            )
        )
    }

    val dropdownOptions = remember(sectionOptions, isBn) {
        sectionOptions.map { opt ->
            FoldedDropdownOption(
                value = opt.tab,
                label = opt.title,
                subtitle = if (isBn) opt.subtitleBn else opt.subtitleEn,
                icon = opt.icon,
                testTag = opt.testTag
            )
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Header with quick actions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (isBn) "দ্বীন ও ইবাদত" else "Deen Sanctuary",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onOpenLearningHub,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .size(40.dp)
                        .testTag("spirituality_learning_hub_button")
                ) {
                    Icon(Icons.Default.School, contentDescription = "Islamic Learning Academy", tint = palette.accentSoft, modifier = Modifier.size(20.dp))
                }
                IconButton(
                    onClick = onOpenGlobalSearch,
                    modifier = Modifier.size(40.dp).testTag("spirituality_search_button")
                ) {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = palette.textPrimary, modifier = Modifier.size(20.dp))
                }
                IconButton(
                    onClick = onOpenBookmarksHub,
                    modifier = Modifier.size(40.dp).testTag("spirituality_bookmarks_button")
                ) {
                    Icon(
                        Icons.Default.Bookmark,
                        contentDescription = strings.bookmarksFilter,
                        tint = if (bookmarks.isNotEmpty()) palette.gold else palette.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Folded-Page Falling Dropdown replacing horizontal sliding tab strip
        Box(
            modifier = Modifier
                .padding(horizontal = 14.dp, vertical = 4.dp)
                .tutorialTarget(TutorialTargetKeys.DEEN_SECTION_DROPDOWN)
        ) {
            FoldedPageDropdown(
                options = dropdownOptions,
                selected = selectedTab,
                onSelect = onSelectTab,
                sectionLabel = if (isBn) "বিভাগ নির্বাচন করুন" else "Deen Section",
                triggerTestTag = "spirituality_section_dropdown"
            )
        }

        Spacer(modifier = Modifier.height(2.dp))

        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = {
                val forward = targetState.ordinal >= initialState.ordinal
                (fadeIn(tween(220, easing = FastOutSlowInEasing)) +
                    slideInHorizontally(tween(240, easing = FastOutSlowInEasing)) { if (forward) it / 14 else -it / 14 } +
                    scaleIn(initialScale = 0.98f, animationSpec = tween(220))) togetherWith
                    (fadeOut(tween(150)) + slideOutHorizontally(tween(160)) { if (forward) -it / 16 else it / 16 })
            },
            modifier = Modifier.weight(1f),
            label = "spiritualityTabTransition"
        ) { activeDeenTab ->
        when (activeDeenTab) {
            SpiritualitySubTab.QURAN -> QuranReaderSection(
                prefs = prefs,
                quranState = quranState,
                ayahExplanationState = ayahExplanationState,
                cachedSurahNumbers = cachedSurahs,
                audioState = audioState,
                bookmarks = bookmarks,
                isOnline = isOnline,
                openSurahDirect = openQuranReader,
                onSetReaderOpen = onSetQuranReaderOpen,
                onSelectSurah = onSelectSurah,
                onPlaySurahAyah = onPlaySurahAyah,
                onTogglePlayPause = onTogglePlayPause,
                onSelectReciter = onSelectReciter,
                onChangeFontSize = onChangeFontSize,
                onTogglePronunciation = onTogglePronunciation,
                onDownloadAllOffline = onDownloadAllOffline,
                onToggleBookmark = onToggleBookmark,
                onMarkLastRead = onMarkLastRead,
                onLoadAyahExplanation = onLoadAyahExplanation,
                onRetryAyahExplanation = onRetryAyahExplanation,
                onClearAyahExplanation = onClearAyahExplanation,
                onAskRuhZebaAi = onAskRuhZebaAi,
                targetScrollAyah = pendingScrollAyah,
                onConsumedTargetScroll = onConsumedScrollAyah
            )
            SpiritualitySubTab.PRAYER_QIBLA -> PrayerAndQiblaSection(
                prefs = prefs,
                schedule = prayerSchedule,
                nextPrayer = nextPrayer,
                citySearchResults = citySearchResults,
                isSearchingCity = isSearchingCity,
                onSearchCity = onSearchCity,
                onSelectCity = onSelectCity,
                onSelectMethod = onSelectCalcMethod,
                onSelectAsrMethod = onSelectAsrMethod,
                onAdjustHijriOffset = onAdjustHijriOffset,
                onRefreshGpsLocation = onRefreshGps
            )
            SpiritualitySubTab.ADHKAR_DUA -> AdhkarAndDuaSection(
                bookmarks = bookmarks,
                audioState = audioState,
                initialShowDua = initialShowDua,
                initialAdhkarCategory = returnAdhkarCategory,
                pendingDuaId = pendingDuaId,
                pendingDuaQuery = pendingDuaQuery,
                onConsumedPendingDua = onConsumedPendingDua,
                speakingItemId = speakingItemId,
                onSpeakArabic = onSpeakArabic,
                onPlayHumanAudio = onPlayHumanDhikrOrDua,
                onToggleBookmark = onToggleBookmark,
                onAskRuhZebaAi = onAskRuhZebaAi,
                onStartGuidedTasbih = onStartGuidedTasbih
            )
            SpiritualitySubTab.TASBIH -> TasbihSection(
                prefs = prefs,
                currentCount = tasbihCount,
                onTapCount = onTapTasbih,
                onUndo = onUndoTasbih,
                onReset = onResetTasbih,
                guidedCategory = activeTasbihCategory,
                speakingItemId = speakingItemId,
                onSpeakArabic = onSpeakArabic,
                onCompleteGuidedCategory = onCompleteGuidedTasbih
            )
            SpiritualitySubTab.LESSONS -> DailyLessonsSection(
                speakingItemId = speakingItemId,
                onSpeakLocalized = onSpeakLocalized,
                onAskRuhZebaAi = onAskRuhZebaAi
            )
        }
        }
    }
}
