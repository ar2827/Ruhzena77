package com.example.ruhzena.ui.exercises

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.example.ruhzena.ui.components.FkPose
import com.example.ruhzena.ui.components.GroundContactMode
import com.example.ruhzena.ui.components.HandStyle
import com.example.ruhzena.ui.components.IkTargetLocks

/**
 * Stationary world-space studio prop geometry (fixed relative to canvas & floorY — NEVER bounces!).
 */
data class StationaryBenchSpec(
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float
)

/**
 * Complete 27-Exercise Biomechanical Choreography & Analytical 2-Bone IK Target Library.
 * Covers all 12 original exercises + 15 hardcore & calisthenics exercises with exact joint articulation,
 * flexible lumbar/thoracic spine curves, heel-lift foot physics, and stationary prop IK locks.
 */
object ExerciseChoreographyLibrary {

    fun scaleMultiplier(exerciseId: String): Float = when (exerciseId) {
        "push_up", "diamond_push_up", "military_push_up", "decline_push_up", "pike_push_up",
        "forearm_plank", "side_plank", "mountain_climbers", "superman_hold", "cobra_stretch",
        "hollow_body_hold", "lying_leg_raises", "v_ups", "bicycle_crunch", "glute_bridge",
        "childs_pose_stretch", "db_chest_press", "bb_bench_press" -> 0.88f
        "incline_push_up", "cat_cow", "burpee", "bulgarian_split_squat", "db_bulgarian_split_squat",
        "bar_pull_up", "bar_chin_up", "bar_scapular_pull", "bar_hanging_knee_raise" -> 0.88f
        "wide_push_up", "archer_push_up", "jumping_jack", "db_overhead_press", "band_overhead_press", "kb_clean_and_press" -> 0.90f
        else -> 0.95f
    }

    /**
     * Returns FIXED stationary bench/box world coordinates for exercises using an elevated surface.
     * Because coordinates depend ONLY on canvasSize, floorY, and head-unit `u`, the prop is 100% immovable.
     */
    fun stationaryBenchFor(exerciseId: String, canvasSize: Size, floorY: Float): StationaryBenchSpec? {
        val u = (canvasSize.minDimension * 0.106f * scaleMultiplier(exerciseId)).coerceAtLeast(18f)
        return when (exerciseId) {
            "incline_push_up" -> {
                val left = canvasSize.width * 0.62f
                val top = floorY - u * 1.56f
                StationaryBenchSpec(
                    left = left,
                    top = top,
                    width = (canvasSize.width * 0.90f - left).coerceAtLeast(u * 1.8f),
                    height = (floorY - top).coerceAtLeast(18f)
                )
            }
            "decline_push_up" -> {
                val left = canvasSize.width * 0.10f
                val width = (canvasSize.width * 0.22f).coerceAtLeast(u * 1.6f)
                val top = floorY - u * 1.32f
                StationaryBenchSpec(
                    left = left,
                    top = top,
                    width = width,
                    height = (floorY - top).coerceAtLeast(18f)
                )
            }
            "bulgarian_split_squat", "db_bulgarian_split_squat" -> {
                val left = canvasSize.width * 0.12f
                val width = (canvasSize.width * 0.22f).coerceAtLeast(u * 1.6f)
                val top = floorY - u * 1.46f
                StationaryBenchSpec(
                    left = left,
                    top = top,
                    width = width,
                    height = (floorY - top).coerceAtLeast(18f)
                )
            }
            "db_chest_press", "bb_bench_press" -> {
                val left = canvasSize.width * 0.22f
                val width = canvasSize.width * 0.48f
                val top = floorY - u * 0.85f
                StationaryBenchSpec(
                    left = left,
                    top = top,
                    width = width,
                    height = (floorY - top).coerceAtLeast(16f)
                )
            }
            else -> null
        }
    }

    /**
     * Computes exact analytical 2-bone IK world locks for hands & feet so palms stay glued to
     * stationary floors/benches and feet stay planted on floors/boxes with ZERO sliding or bouncing!
     */
    fun ikLocksFor(
        exerciseId: String,
        canvasSize: Size,
        floorY: Float,
        bench: StationaryBenchSpec?
    ): IkTargetLocks? {
        val u = (canvasSize.minDimension * 0.106f * scaleMultiplier(exerciseId)).coerceAtLeast(18f)
        return when (exerciseId) {
            "incline_push_up" -> {
                val b = bench ?: return null
                val handTarget = Offset(b.left + u * 0.46f, b.top - u * 0.08f)
                val farHandTarget = Offset(b.left + u * 0.68f, b.top - u * 0.08f)
                IkTargetLocks(
                    nearHand = handTarget,
                    farHand = farHandTarget,
                    nearElbowBendSign = 1f,  // Bends elbow cleanly down/back toward ribs!
                    farElbowBendSign = 1f,
                    pinNearToeToWorld = Offset(canvasSize.width * 0.20f, floorY - u * 0.07f)
                )
            }
            "decline_push_up" -> {
                val b = bench ?: return null
                val handTarget = Offset(canvasSize.width * 0.72f, floorY - u * 0.09f)
                val farHandTarget = Offset(canvasSize.width * 0.76f, floorY - u * 0.09f)
                IkTargetLocks(
                    nearHand = handTarget,
                    farHand = farHandTarget,
                    nearElbowBendSign = 1f,
                    farElbowBendSign = 1f,
                    pinNearToeToWorld = Offset(b.left + b.width * 0.76f, b.top - u * 0.06f)
                )
            }
            "push_up" -> {
                val handTarget = Offset(canvasSize.width * 0.71f, floorY - u * 0.09f)
                val farHandTarget = Offset(canvasSize.width * 0.75f, floorY - u * 0.09f)
                IkTargetLocks(
                    nearHand = handTarget,
                    farHand = farHandTarget,
                    nearElbowBendSign = 1f,
                    farElbowBendSign = 1f,
                    pinNearToeToWorld = Offset(canvasSize.width * 0.18f, floorY - u * 0.07f)
                )
            }
            "military_push_up" -> {
                val handTarget = Offset(canvasSize.width * 0.70f, floorY - u * 0.09f)
                val farHandTarget = Offset(canvasSize.width * 0.72f, floorY - u * 0.09f)
                IkTargetLocks(
                    nearHand = handTarget,
                    farHand = farHandTarget,
                    nearElbowBendSign = 1f,
                    farElbowBendSign = 1f,
                    pinNearToeToWorld = Offset(canvasSize.width * 0.18f, floorY - u * 0.07f)
                )
            }
            "diamond_push_up" -> {
                // Hands placed tightly together right beneath lower sternum!
                val handTarget = Offset(canvasSize.width * 0.64f, floorY - u * 0.09f)
                val farHandTarget = Offset(canvasSize.width * 0.65f, floorY - u * 0.09f)
                IkTargetLocks(
                    nearHand = handTarget,
                    farHand = farHandTarget,
                    nearElbowBendSign = 1f,
                    farElbowBendSign = 1f,
                    pinNearToeToWorld = Offset(canvasSize.width * 0.17f, floorY - u * 0.07f)
                )
            }
            "pike_push_up" -> {
                val handTarget = Offset(canvasSize.width * 0.69f, floorY - u * 0.09f)
                val farHandTarget = Offset(canvasSize.width * 0.73f, floorY - u * 0.09f)
                IkTargetLocks(
                    nearHand = handTarget,
                    farHand = farHandTarget,
                    nearElbowBendSign = 1f,
                    farElbowBendSign = 1f,
                    pinNearToeToWorld = Offset(canvasSize.width * 0.24f, floorY - u * 0.07f)
                )
            }
            "bulgarian_split_squat" -> {
                val b = bench ?: return null
                IkTargetLocks(
                    farFoot = Offset(b.left + b.width * 0.72f, b.top - u * 0.12f),
                    farKneeBendSign = -1f
                )
            }
            "cat_cow" -> {
                IkTargetLocks(
                    nearHand = Offset(canvasSize.width * 0.63f, floorY - u * 0.09f),
                    farHand = Offset(canvasSize.width * 0.67f, floorY - u * 0.09f),
                    nearElbowBendSign = 1f,
                    farElbowBendSign = 1f
                )
            }
            "cobra_stretch" -> {
                IkTargetLocks(
                    nearHand = Offset(canvasSize.width * 0.64f, floorY - u * 0.09f),
                    farHand = Offset(canvasSize.width * 0.68f, floorY - u * 0.09f),
                    nearElbowBendSign = 1f,
                    farElbowBendSign = 1f
                )
            }
            else -> null
        }
    }

    /**
     * Exact 4-phase anatomical keyframes for ALL 27 exercises.
     */
    fun keyframesFor(exerciseId: String): List<FkPose> = when (exerciseId) {
        // 1. Standard Push-Up (IK-locked hands & pinned toes)
        "push_up" -> {
            val top = FkPose(
                rootXNorm = 0.44f,
                pelvisTiltDeg = -20f, spineFlexDeg = 0f, neckBendDeg = 10f,
                nearShoulderDeg = 92f, nearElbowFlexDeg = -4f, nearWristBendDeg = -88f,
                farShoulderDeg = 88f, farElbowFlexDeg = -4f, farWristBendDeg = -86f,
                nearHipDeg = 160f, nearKneeFlexDeg = 0f, nearAnkleDeg = 82f, nearHeelLift = 1f,
                farHipDeg = 162f, farKneeFlexDeg = 0f, farAnkleDeg = 82f, farHeelLift = 1f,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val mid = top.copy(
                pelvisTiltDeg = -12f, neckBendDeg = 6f,
                nearHipDeg = 168f, farHipDeg = 170f
            )
            val bottom = top.copy(
                pelvisTiltDeg = -4f, neckBendDeg = 3f,
                nearHipDeg = 176f, farHipDeg = 177f
            )
            listOf(top, mid, bottom, mid)
        }

        // 2. Incline Push-Up (Stationary right bench + IK-locked palms + pinned toes!)
        "incline_push_up" -> {
            val top = FkPose(
                rootXNorm = 0.44f,
                pelvisTiltDeg = -37f, spineFlexDeg = 0f, neckBendDeg = 10f,
                nearShoulderDeg = 82f, nearElbowFlexDeg = -4f, nearWristBendDeg = -78f,
                farShoulderDeg = 78f, farElbowFlexDeg = -4f, farWristBendDeg = -74f,
                nearHipDeg = 143f, nearKneeFlexDeg = 0f, nearAnkleDeg = 72f, nearHeelLift = 1f,
                farHipDeg = 145f, farKneeFlexDeg = 0f, farAnkleDeg = 72f, farHeelLift = 1f,
                contactMode = GroundContactMode.MANUAL_WORLD_ANCHOR,
                handStyle = HandStyle.FLAT_PRESS
            )
            val mid = top.copy(
                pelvisTiltDeg = -30f, neckBendDeg = 6f,
                nearHipDeg = 150f, farHipDeg = 152f
            )
            val bottom = top.copy(
                pelvisTiltDeg = -22f, neckBendDeg = 3f,
                nearHipDeg = 158f, farHipDeg = 160f
            )
            listOf(top, mid, bottom, mid)
        }

        // 3. Diamond Push-Up (Close narrow hands right under sternum + tight triceps bend)
        "diamond_push_up" -> {
            val top = FkPose(
                rootXNorm = 0.43f,
                pelvisTiltDeg = -21f, spineFlexDeg = 0f, neckBendDeg = 12f,
                nearShoulderDeg = 104f, nearElbowFlexDeg = -4f, nearWristBendDeg = -90f,
                farShoulderDeg = 102f, farElbowFlexDeg = -4f, farWristBendDeg = -90f,
                nearHipDeg = 159f, nearKneeFlexDeg = 0f, nearAnkleDeg = 82f, nearHeelLift = 1f,
                farHipDeg = 160f, farKneeFlexDeg = 0f, farAnkleDeg = 82f, farHeelLift = 1f,
                shoulderSpanBias = 0.5f,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val mid = top.copy(
                pelvisTiltDeg = -13f, neckBendDeg = 7f,
                nearHipDeg = 167f, farHipDeg = 168f
            )
            val bottom = top.copy(
                pelvisTiltDeg = -4.5f, neckBendDeg = 3f,
                nearHipDeg = 175.5f, farHipDeg = 176f
            )
            listOf(top, mid, bottom, mid)
        }

        // 4. Army / Military Push-Up (Feet together, strict rigid horizontal chest-to-deck)
        "military_push_up" -> {
            val top = FkPose(
                rootXNorm = 0.44f,
                pelvisTiltDeg = -22f, spineFlexDeg = 0f, neckBendDeg = 8f,
                nearShoulderDeg = 92f, nearElbowFlexDeg = -2f, nearWristBendDeg = -90f,
                farShoulderDeg = 91f, farElbowFlexDeg = -2f, farWristBendDeg = -90f,
                nearHipDeg = 158f, nearKneeFlexDeg = 0f, nearAnkleDeg = 84f, nearHeelLift = 1f,
                farHipDeg = 159f, farKneeFlexDeg = 0f, farAnkleDeg = 84f, farHeelLift = 1f,
                shoulderSpanBias = 0.72f,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val mid = top.copy(
                pelvisTiltDeg = -12f, neckBendDeg = 4f,
                nearHipDeg = 168f, farHipDeg = 169f
            )
            val bottom = top.copy(
                pelvisTiltDeg = -2.5f, neckBendDeg = 1f,
                nearHipDeg = 177.5f, farHipDeg = 178f
            )
            listOf(top, mid, bottom, mid)
        }

        // 5. Wide-Grip Push-Up (Frontal athletic view clearly demonstrating 1.5x wide hand stance!)
        "wide_push_up" -> {
            val top = FkPose(
                rootXNorm = 0.50f, rootYBias = -0.75f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 56f, nearElbowFlexDeg = 22f, nearWristBendDeg = 10f,
                farShoulderDeg = 124f, farElbowFlexDeg = -22f, farWristBendDeg = -10f,
                nearHipDeg = 82f, nearKneeFlexDeg = 12f, nearAnkleDeg = 18f,
                farHipDeg = 98f, farKneeFlexDeg = -12f, farAnkleDeg = 162f,
                isFrontalView = true,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val mid = top.copy(
                rootYBias = -0.36f,
                nearShoulderDeg = 28f, nearElbowFlexDeg = 58f,
                farShoulderDeg = 152f, farElbowFlexDeg = -58f
            )
            val bottom = top.copy(
                rootYBias = 0f,
                nearShoulderDeg = 4f, nearElbowFlexDeg = 86f,
                farShoulderDeg = 176f, farElbowFlexDeg = -86f
            )
            listOf(top, mid, bottom, mid)
        }

        // 6. Decline Push-Up (Toes locked atop stationary LEFT box, hands IK-locked on floor!)
        "decline_push_up" -> {
            val top = FkPose(
                rootXNorm = 0.45f,
                pelvisTiltDeg = -2f, spineFlexDeg = 0f, neckBendDeg = 8f,
                nearShoulderDeg = 90f, nearElbowFlexDeg = -4f, nearWristBendDeg = -86f,
                farShoulderDeg = 88f, farElbowFlexDeg = -4f, farWristBendDeg = -84f,
                nearHipDeg = 178f, nearKneeFlexDeg = 0f, nearAnkleDeg = 96f, nearHeelLift = 1f,
                farHipDeg = 180f, farKneeFlexDeg = 0f, farAnkleDeg = 96f, farHeelLift = 1f,
                contactMode = GroundContactMode.MANUAL_WORLD_ANCHOR,
                handStyle = HandStyle.FLAT_PRESS
            )
            val mid = top.copy(
                pelvisTiltDeg = 7f, neckBendDeg = 4f,
                nearHipDeg = 187f, farHipDeg = 189f
            )
            val bottom = top.copy(
                pelvisTiltDeg = 15f, neckBendDeg = 2f,
                nearHipDeg = 195f, farHipDeg = 197f
            )
            listOf(top, mid, bottom, mid)
        }

        // 7. Pike Push-Up (High inverted-V hip hinge with overhead shoulder dive!)
        "pike_push_up" -> {
            val pikeTop = FkPose(
                rootXNorm = 0.45f,
                pelvisTiltDeg = 42f, spineFlexDeg = 2f, neckBendDeg = 6f,
                nearShoulderDeg = 62f, nearElbowFlexDeg = -4f, nearWristBendDeg = -60f,
                farShoulderDeg = 58f, farElbowFlexDeg = -4f, farWristBendDeg = -58f,
                nearHipDeg = 122f, nearKneeFlexDeg = 4f, nearAnkleDeg = 52f, nearHeelLift = 1f,
                farHipDeg = 124f, farKneeFlexDeg = 4f, farAnkleDeg = 52f, farHeelLift = 1f,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val mid = pikeTop.copy(
                pelvisTiltDeg = 50f, neckBendDeg = 10f,
                nearHipDeg = 128f, farHipDeg = 130f
            )
            val bottom = pikeTop.copy(
                pelvisTiltDeg = 59f, neckBendDeg = 12f,
                nearHipDeg = 134f, farHipDeg = 136f
            )
            listOf(pikeTop, mid, bottom, mid)
        }

        // 8. Archer Push-Up (Frontal unilateral side-to-side shift: one arm straight, one deep bend!)
        "archer_push_up" -> {
            val centerTop = FkPose(
                rootXNorm = 0.50f, rootYBias = -0.68f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 52f, nearElbowFlexDeg = 24f,
                farShoulderDeg = 128f, farElbowFlexDeg = -24f,
                nearHipDeg = 82f, nearKneeFlexDeg = 10f, nearAnkleDeg = 16f,
                farHipDeg = 98f, farKneeFlexDeg = -10f, farAnkleDeg = 164f,
                isFrontalView = true,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val loadRight = centerTop.copy(
                rootXNorm = 0.59f, rootYBias = 0f,
                nearShoulderDeg = 2f, nearElbowFlexDeg = 92f,    // Working arm deeply bent under chest
                farShoulderDeg = 158f, farElbowFlexDeg = -4f      // Assisting arm straight out wide!
            )
            val loadLeft = centerTop.copy(
                rootXNorm = 0.41f, rootYBias = 0f,
                nearShoulderDeg = 22f, nearElbowFlexDeg = 4f,     // Assisting arm straight out wide!
                farShoulderDeg = 178f, farElbowFlexDeg = -92f     // Working arm deeply bent under chest
            )
            listOf(centerTop, loadRight, centerTop, loadLeft)
        }

        // 9. Bodyweight Squat
        "bodyweight_squat" -> {
            val stand = FkPose(
                rootXNorm = 0.50f,
                pelvisTiltDeg = -89f, spineFlexDeg = 0f, neckBendDeg = 2f,
                nearShoulderDeg = 82f, nearElbowFlexDeg = -18f,
                farShoulderDeg = 78f, farElbowFlexDeg = -16f,
                nearHipDeg = 90f, nearKneeFlexDeg = 2f, nearAnkleDeg = 0f,
                farHipDeg = 92f, farKneeFlexDeg = 2f, farAnkleDeg = 0f,
                contactMode = GroundContactMode.FEET_ONLY
            )
            val half = stand.copy(
                rootXNorm = 0.46f,
                pelvisTiltDeg = -68f, spineFlexDeg = 3f, neckBendDeg = -12f,
                nearShoulderDeg = 34f, nearElbowFlexDeg = -12f,
                farShoulderDeg = 30f, farElbowFlexDeg = -12f,
                nearHipDeg = 44f, nearKneeFlexDeg = 60f,
                farHipDeg = 48f, farKneeFlexDeg = 56f
            )
            val deep = stand.copy(
                rootXNorm = 0.43f,
                pelvisTiltDeg = -56f, spineFlexDeg = 4f, neckBendDeg = -20f,
                nearShoulderDeg = 6f, nearElbowFlexDeg = -8f,
                farShoulderDeg = 2f, farElbowFlexDeg = -8f,
                nearHipDeg = 6f, nearKneeFlexDeg = 104f,
                farHipDeg = 10f, farKneeFlexDeg = 100f
            )
            listOf(stand, half, deep, half)
        }

        // 10. Reverse Lunge (real rear heel-lift!)
        "reverse_lunge" -> {
            val stand = FkPose(
                rootXNorm = 0.54f,
                pelvisTiltDeg = -89f, spineFlexDeg = 0f, neckBendDeg = 2f,
                nearShoulderDeg = 84f, nearElbowFlexDeg = -20f,
                farShoulderDeg = 80f, farElbowFlexDeg = -18f,
                nearHipDeg = 90f, nearKneeFlexDeg = 2f, nearAnkleDeg = 0f,
                farHipDeg = 92f, farKneeFlexDeg = 2f, farAnkleDeg = 0f,
                contactMode = GroundContactMode.FEET_ONLY
            )
            val stepBack = stand.copy(
                rootXNorm = 0.50f,
                pelvisTiltDeg = -84f, spineFlexDeg = 2f, neckBendDeg = -2f,
                nearShoulderDeg = 76f, nearElbowFlexDeg = -56f,
                farShoulderDeg = 72f, farElbowFlexDeg = -52f,
                nearHipDeg = 54f, nearKneeFlexDeg = 42f, nearAnkleDeg = 0f,
                farHipDeg = 114f, farKneeFlexDeg = 32f, farAnkleDeg = 44f, farHeelLift = 0.8f
            )
            val bottom = stand.copy(
                rootXNorm = 0.48f,
                pelvisTiltDeg = -82f, spineFlexDeg = 2f, neckBendDeg = -4f,
                nearShoulderDeg = 72f, nearElbowFlexDeg = -78f,
                farShoulderDeg = 68f, farElbowFlexDeg = -74f,
                nearHipDeg = 6f, nearKneeFlexDeg = 88f, nearAnkleDeg = 0f,
                farHipDeg = 98f, farKneeFlexDeg = 82f, farAnkleDeg = 86f, farHeelLift = 1.0f
            )
            listOf(stand, stepBack, bottom, stepBack)
        }

        // 11. Explosive Jump Squat (Deep load -> vertical airtime -> soft landing)
        "jump_squat" -> {
            val deepLoad = FkPose(
                rootXNorm = 0.45f, rootYBias = 0f,
                pelvisTiltDeg = -56f, spineFlexDeg = 4f, neckBendDeg = -16f,
                nearShoulderDeg = 136f, nearElbowFlexDeg = -18f,
                farShoulderDeg = 132f, farElbowFlexDeg = -16f,
                nearHipDeg = 12f, nearKneeFlexDeg = 96f, nearAnkleDeg = 0f,
                farHipDeg = 16f, farKneeFlexDeg = 92f, farAnkleDeg = 0f,
                contactMode = GroundContactMode.FEET_ONLY
            )
            val launch = FkPose(
                rootXNorm = 0.50f, rootYBias = -0.58f,
                pelvisTiltDeg = -86f, spineFlexDeg = -4f, neckBendDeg = 2f,
                nearShoulderDeg = -34f, nearElbowFlexDeg = -10f,
                farShoulderDeg = -38f, farElbowFlexDeg = -10f,
                nearHipDeg = 86f, nearKneeFlexDeg = 8f, nearAnkleDeg = 32f, nearHeelLift = 1f,
                farHipDeg = 88f, farKneeFlexDeg = 8f, farAnkleDeg = 32f, farHeelLift = 1f,
                contactMode = GroundContactMode.FEET_ONLY
            )
            val apex = FkPose(
                rootXNorm = 0.51f, rootYBias = -1.24f,
                pelvisTiltDeg = -90f, spineFlexDeg = -6f, neckBendDeg = 0f,
                nearShoulderDeg = -76f, nearElbowFlexDeg = -8f,
                farShoulderDeg = -80f, farElbowFlexDeg = -8f,
                nearHipDeg = 92f, nearKneeFlexDeg = 4f, nearAnkleDeg = 48f, nearHeelLift = 1f,
                farHipDeg = 94f, farKneeFlexDeg = 4f, farAnkleDeg = 48f, farHeelLift = 1f,
                contactMode = GroundContactMode.FEET_ONLY
            )
            val softLand = FkPose(
                rootXNorm = 0.48f, rootYBias = 0f,
                pelvisTiltDeg = -66f, spineFlexDeg = 4f, neckBendDeg = -10f,
                nearShoulderDeg = 34f, nearElbowFlexDeg = -16f,
                farShoulderDeg = 30f, farElbowFlexDeg = -16f,
                nearHipDeg = 40f, nearKneeFlexDeg = 64f, nearAnkleDeg = 0f,
                farHipDeg = 44f, farKneeFlexDeg = 60f, farAnkleDeg = 0f,
                contactMode = GroundContactMode.FEET_ONLY
            )
            listOf(deepLoad, launch, apex, softLand)
        }

        // 12. Bulgarian Split Squat (Rear foot IK-locked onto stationary LEFT bench!)
        "bulgarian_split_squat" -> {
            val top = FkPose(
                rootXNorm = 0.56f,
                pelvisTiltDeg = -84f, spineFlexDeg = 2f, neckBendDeg = 2f,
                nearShoulderDeg = 76f, nearElbowFlexDeg = -68f,
                farShoulderDeg = 72f, farElbowFlexDeg = -64f,
                nearHipDeg = 82f, nearKneeFlexDeg = 10f, nearAnkleDeg = 0f,
                farHipDeg = 122f, farKneeFlexDeg = 40f, farAnkleDeg = 148f,
                contactMode = GroundContactMode.FEET_ONLY
            )
            val mid = top.copy(
                rootXNorm = 0.54f,
                pelvisTiltDeg = -78f,
                nearHipDeg = 44f, nearKneeFlexDeg = 52f
            )
            val deep = top.copy(
                rootXNorm = 0.52f,
                pelvisTiltDeg = -74f,
                nearHipDeg = 10f, nearKneeFlexDeg = 86f
            )
            listOf(top, mid, deep, mid)
        }

        // 13. Standing Calf Raises (Full ankle plantarflexion & heel lift!)
        "calf_raises" -> {
            val flat = FkPose(
                rootXNorm = 0.50f, rootYBias = 0f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 2f,
                nearShoulderDeg = 88f, nearElbowFlexDeg = -12f,
                farShoulderDeg = 85f, farElbowFlexDeg = -10f,
                nearHipDeg = 90f, nearKneeFlexDeg = 1f, nearAnkleDeg = 0f, nearHeelLift = 0f,
                farHipDeg = 92f, farKneeFlexDeg = 1f, farAnkleDeg = 0f, farHeelLift = 0f,
                contactMode = GroundContactMode.FEET_ONLY
            )
            val rise = flat.copy(
                rootYBias = -0.22f,
                nearAnkleDeg = 22f, nearHeelLift = 0.60f,
                farAnkleDeg = 22f, farHeelLift = 0.60f
            )
            val peak = flat.copy(
                rootYBias = -0.44f,
                nearAnkleDeg = 40f, nearHeelLift = 1.0f,
                farAnkleDeg = 40f, farHeelLift = 1.0f
            )
            listOf(flat, rise, peak, rise)
        }

        // 14. Full Athletic Burpee (Squat Plant -> Plank -> Frog Tuck -> Vertical Jump!)
        "burpee" -> {
            val squatPlant = FkPose(
                rootXNorm = 0.46f, rootYBias = 0f,
                pelvisTiltDeg = -32f, spineFlexDeg = 14f, neckBendDeg = -12f,
                nearShoulderDeg = 82f, nearElbowFlexDeg = -4f, nearWristBendDeg = -78f,
                farShoulderDeg = 78f, farElbowFlexDeg = -4f, farWristBendDeg = -74f,
                nearHipDeg = -8f, nearKneeFlexDeg = 128f, nearAnkleDeg = 24f, nearHeelLift = 0.8f,
                farHipDeg = -4f, farKneeFlexDeg = 124f, farAnkleDeg = 24f, farHeelLift = 0.8f,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val plankSnap = FkPose(
                rootXNorm = 0.44f, rootYBias = 0f,
                pelvisTiltDeg = -17f, spineFlexDeg = 1f, neckBendDeg = 8f,
                nearShoulderDeg = 92f, nearElbowFlexDeg = -4f, nearWristBendDeg = -88f,
                farShoulderDeg = 88f, farElbowFlexDeg = -4f, farWristBendDeg = -84f,
                nearHipDeg = 163f, nearKneeFlexDeg = 0f, nearAnkleDeg = 84f, nearHeelLift = 1f,
                farHipDeg = 165f, farKneeFlexDeg = 0f, farAnkleDeg = 84f, farHeelLift = 1f,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val verticalJump = FkPose(
                rootXNorm = 0.50f, rootYBias = -1.10f,
                pelvisTiltDeg = -90f, spineFlexDeg = -6f, neckBendDeg = 0f,
                nearShoulderDeg = -86f, nearElbowFlexDeg = -4f,
                farShoulderDeg = -90f, farElbowFlexDeg = -4f,
                nearHipDeg = 90f, nearKneeFlexDeg = 4f, nearAnkleDeg = 44f, nearHeelLift = 1f,
                farHipDeg = 92f, farKneeFlexDeg = 4f, farAnkleDeg = 44f, farHeelLift = 1f,
                contactMode = GroundContactMode.FEET_ONLY
            )
            listOf(squatPlant, plankSnap, squatPlant, verticalJump)
        }

        // 15. Glute Bridge
        "glute_bridge" -> {
            val rest = FkPose(
                rootXNorm = 0.50f,
                pelvisTiltDeg = 179f, spineFlexDeg = 0f, neckBendDeg = -4f,
                nearShoulderDeg = 6f, nearElbowFlexDeg = -4f,
                farShoulderDeg = 8f, farElbowFlexDeg = -4f,
                nearHipDeg = -48f, nearKneeFlexDeg = 138f, nearAnkleDeg = 0f,
                farHipDeg = -45f, farKneeFlexDeg = 136f, farAnkleDeg = 0f,
                contactMode = GroundContactMode.SUPINE_BACK
            )
            val lift = rest.copy(
                pelvisTiltDeg = 166f, spineFlexDeg = 4f, neckBendDeg = -8f,
                nearHipDeg = -36f, nearKneeFlexDeg = 128f,
                farHipDeg = -33f, farKneeFlexDeg = 126f
            )
            val peak = rest.copy(
                pelvisTiltDeg = 152f, spineFlexDeg = 6f, neckBendDeg = -10f,
                nearHipDeg = -24f, nearKneeFlexDeg = 116f,
                farHipDeg = -21f, farKneeFlexDeg = 114f
            )
            listOf(rest, lift, peak, lift)
        }

        // 16. Forearm Plank
        "forearm_plank" -> {
            val braceA = FkPose(
                rootXNorm = 0.45f,
                pelvisTiltDeg = -7f, spineFlexDeg = 1f, neckBendDeg = 8f,
                nearShoulderDeg = 92f, nearElbowFlexDeg = -92f,
                farShoulderDeg = 88f, farElbowFlexDeg = -88f,
                nearHipDeg = 173f, nearKneeFlexDeg = 0f, nearAnkleDeg = 86f, nearHeelLift = 1f,
                farHipDeg = 175f, farKneeFlexDeg = 0f, farAnkleDeg = 86f, farHeelLift = 1f,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FIST
            )
            val braceB = braceA.copy(
                pelvisTiltDeg = -9f, spineFlexDeg = 2f,
                nearHipDeg = 171f, farHipDeg = 173f
            )
            listOf(braceA, braceB, braceA, braceB)
        }

        // 17. Side Plank Hip Lift
        "side_plank" -> {
            val topHold = FkPose(
                rootXNorm = 0.46f,
                pelvisTiltDeg = -15f, spineFlexDeg = -4f, neckBendDeg = 6f,
                nearShoulderDeg = -86f, nearElbowFlexDeg = -4f,   // Top arm reaching cleanly skyward!
                farShoulderDeg = 94f, farElbowFlexDeg = -90f,     // Bottom forearm braced firmly on mat
                nearHipDeg = 164f, nearKneeFlexDeg = 0f, nearAnkleDeg = 84f,
                farHipDeg = 166f, farKneeFlexDeg = 0f, farAnkleDeg = 84f,
                contactMode = GroundContactMode.FEET_AND_HANDS
            )
            val hipDip = topHold.copy(
                pelvisTiltDeg = -3f, spineFlexDeg = 10f, lumbarFlexBias = 8f,
                nearShoulderDeg = -76f,
                nearHipDeg = 178f, farHipDeg = 180f
            )
            val highDrive = topHold.copy(
                pelvisTiltDeg = -20f, spineFlexDeg = -10f, lumbarFlexBias = -6f,
                nearShoulderDeg = -92f,
                nearHipDeg = 158f, farHipDeg = 160f
            )
            listOf(topHold, hipDip, highDrive, topHold)
        }

        // 18. Hollow Body Hold (True curved lumbar/thoracic gymnastics banana lock!)
        "hollow_body_hold" -> {
            val imprint = FkPose(
                rootXNorm = 0.48f,
                pelvisTiltDeg = 178f, spineFlexDeg = 14f, lumbarFlexBias = 4f, thoracicFlexBias = 12f, neckBendDeg = 14f,
                nearShoulderDeg = -168f, nearElbowFlexDeg = -4f,
                farShoulderDeg = -170f, farElbowFlexDeg = -4f,
                nearHipDeg = -8f, nearKneeFlexDeg = 2f, nearAnkleDeg = 14f,
                farHipDeg = -6f, farKneeFlexDeg = 2f, farAnkleDeg = 14f,
                contactMode = GroundContactMode.SUPINE_BACK
            )
            val hollowPeak = FkPose(
                rootXNorm = 0.48f,
                pelvisTiltDeg = 172f, spineFlexDeg = 28f, lumbarFlexBias = 10f, thoracicFlexBias = 18f, neckBendDeg = 16f,
                nearShoulderDeg = -148f, nearElbowFlexDeg = -4f,
                farShoulderDeg = -150f, farElbowFlexDeg = -4f,
                nearHipDeg = -22f, nearKneeFlexDeg = 0f, nearAnkleDeg = 22f,
                farHipDeg = -20f, farKneeFlexDeg = 0f, farAnkleDeg = 22f,
                contactMode = GroundContactMode.SUPINE_BACK
            )
            val rockSlight = hollowPeak.copy(
                pelvisTiltDeg = 169f,
                nearHipDeg = -25f, farHipDeg = -23f
            )
            listOf(imprint, hollowPeak, rockSlight, hollowPeak)
        }

        // 19. Lying Straight-Leg Raises
        "lying_leg_raises" -> {
            val lowHover = FkPose(
                rootXNorm = 0.48f,
                pelvisTiltDeg = 180f, spineFlexDeg = 2f, neckBendDeg = 4f,
                nearShoulderDeg = 6f, nearElbowFlexDeg = -2f,
                farShoulderDeg = 8f, farElbowFlexDeg = -2f,
                nearHipDeg = -10f, nearKneeFlexDeg = 2f, nearAnkleDeg = 16f,
                farHipDeg = -8f, farKneeFlexDeg = 2f, farAnkleDeg = 16f,
                contactMode = GroundContactMode.SUPINE_BACK
            )
            val midSweep = lowHover.copy(
                nearHipDeg = -48f, farHipDeg = -46f, nearAnkleDeg = -22f, farAnkleDeg = -22f
            )
            val verticalPeak = lowHover.copy(
                pelvisTiltDeg = 176f, lumbarFlexBias = 6f,
                nearHipDeg = -88f, farHipDeg = -86f, nearAnkleDeg = -68f, farAnkleDeg = -68f
            )
            listOf(lowHover, midSweep, verticalPeak, midSweep)
        }

        // 20. V-Up Jackknife (Explosive full-spine & straight-leg fold!)
        "v_ups" -> {
            val extended = FkPose(
                rootXNorm = 0.48f,
                pelvisTiltDeg = 176f, spineFlexDeg = 12f, neckBendDeg = 8f,
                nearShoulderDeg = -168f, nearElbowFlexDeg = -4f,
                farShoulderDeg = -170f, farElbowFlexDeg = -4f,
                nearHipDeg = -10f, nearKneeFlexDeg = 2f, nearAnkleDeg = 18f,
                farHipDeg = -8f, farKneeFlexDeg = 2f, farAnkleDeg = 18f,
                contactMode = GroundContactMode.SUPINE_BACK
            )
            val midFold = FkPose(
                rootXNorm = 0.48f,
                pelvisTiltDeg = 152f, spineFlexDeg = 22f, lumbarFlexBias = 10f, thoracicFlexBias = 12f, neckBendDeg = 14f,
                nearShoulderDeg = -82f, nearElbowFlexDeg = -6f,
                farShoulderDeg = -86f, farElbowFlexDeg = -6f,
                nearHipDeg = -34f, nearKneeFlexDeg = 2f, nearAnkleDeg = -10f,
                farHipDeg = -32f, farKneeFlexDeg = 2f, farAnkleDeg = -10f,
                contactMode = GroundContactMode.SUPINE_BACK
            )
            val vPeak = FkPose(
                rootXNorm = 0.48f,
                pelvisTiltDeg = 126f, spineFlexDeg = 20f, lumbarFlexBias = 12f, thoracicFlexBias = 12f, neckBendDeg = 16f,
                nearShoulderDeg = -34f, nearElbowFlexDeg = -4f,
                farShoulderDeg = -38f, farElbowFlexDeg = -4f,
                nearHipDeg = -56f, nearKneeFlexDeg = 2f, nearAnkleDeg = -32f,
                farHipDeg = -54f, farKneeFlexDeg = 2f, farAnkleDeg = -32f,
                contactMode = GroundContactMode.SUPINE_BACK
            )
            listOf(extended, midFold, vPeak, midFold)
        }

        // 21. Jumping Jack (Frontal star)
        "jumping_jack" -> {
            val closed = FkPose(
                rootXNorm = 0.50f, rootYBias = 0f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 76f, nearElbowFlexDeg = 8f,
                farShoulderDeg = 104f, farElbowFlexDeg = -8f,
                nearHipDeg = 87f, nearKneeFlexDeg = 0f, nearAnkleDeg = 12f,
                farHipDeg = 93f, farKneeFlexDeg = 0f, farAnkleDeg = 168f,
                isFrontalView = true,
                contactMode = GroundContactMode.FEET_ONLY
            )
            val midJump = FkPose(
                rootXNorm = 0.50f, rootYBias = -0.34f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 2f, nearElbowFlexDeg = -14f,
                farShoulderDeg = 178f, farElbowFlexDeg = 14f,
                nearHipDeg = 76f, nearKneeFlexDeg = 6f, nearAnkleDeg = 28f,
                farHipDeg = 104f, farKneeFlexDeg = -6f, farAnkleDeg = 152f,
                isFrontalView = true,
                contactMode = GroundContactMode.FEET_ONLY
            )
            val openStar = FkPose(
                rootXNorm = 0.50f, rootYBias = 0f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = -66f, nearElbowFlexDeg = -18f,
                farShoulderDeg = -114f, farElbowFlexDeg = 18f,
                nearHipDeg = 68f, nearKneeFlexDeg = 2f, nearAnkleDeg = 18f,
                farHipDeg = 112f, farKneeFlexDeg = -2f, farAnkleDeg = 162f,
                isFrontalView = true,
                contactMode = GroundContactMode.FEET_ONLY
            )
            listOf(closed, midJump, openStar, midJump)
        }

        // 22. Mountain Climbers
        "mountain_climbers" -> {
            val plankBase = FkPose(
                rootXNorm = 0.44f,
                pelvisTiltDeg = -17f, spineFlexDeg = 2f, neckBendDeg = 10f,
                nearShoulderDeg = 94f, nearElbowFlexDeg = -4f, nearWristBendDeg = -90f,
                farShoulderDeg = 90f, farElbowFlexDeg = -4f, farWristBendDeg = -86f,
                nearHipDeg = 163f, nearKneeFlexDeg = 0f, nearAnkleDeg = 84f, nearHeelLift = 1f,
                farHipDeg = 165f, farKneeFlexDeg = 0f, farAnkleDeg = 84f, farHeelLift = 1f,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val driveNear = plankBase.copy(
                pelvisTiltDeg = -14f, spineFlexDeg = 5f,
                nearHipDeg = 36f, nearKneeFlexDeg = 106f, nearAnkleDeg = 70f,
                farHipDeg = 164f, farKneeFlexDeg = 0f, farAnkleDeg = 84f
            )
            val driveFar = plankBase.copy(
                pelvisTiltDeg = -14f, spineFlexDeg = 5f,
                nearHipDeg = 164f, nearKneeFlexDeg = 0f, nearAnkleDeg = 84f,
                farHipDeg = 36f, farKneeFlexDeg = 106f, farAnkleDeg = 70f
            )
            listOf(plankBase, driveNear, plankBase, driveFar)
        }

        // 23. Bicycle Crunch
        "bicycle_crunch" -> {
            val neutral = FkPose(
                rootXNorm = 0.48f,
                pelvisTiltDeg = 172f, spineFlexDeg = 24f, lumbarFlexBias = 8f, thoracicFlexBias = 12f, neckBendDeg = 12f,
                nearShoulderDeg = -138f, nearElbowFlexDeg = -112f,
                farShoulderDeg = -142f, farElbowFlexDeg = -108f,
                nearHipDeg = -46f, nearKneeFlexDeg = 86f, nearAnkleDeg = 10f,
                farHipDeg = -42f, farKneeFlexDeg = 84f, farAnkleDeg = 10f,
                contactMode = GroundContactMode.SUPINE_BACK
            )
            val crunchNear = neutral.copy(
                spineFlexDeg = 34f, thoracicFlexBias = 18f,
                nearShoulderDeg = -110f, nearElbowFlexDeg = -124f,
                nearHipDeg = -74f, nearKneeFlexDeg = 104f,
                farHipDeg = -14f, farKneeFlexDeg = 14f
            )
            val crunchFar = neutral.copy(
                spineFlexDeg = 34f, thoracicFlexBias = 18f,
                farShoulderDeg = -110f, farElbowFlexDeg = -124f,
                nearHipDeg = -14f, nearKneeFlexDeg = 14f,
                farHipDeg = -74f, farKneeFlexDeg = 104f
            )
            listOf(neutral, crunchNear, neutral, crunchFar)
        }

        // 24. Superman Back Extension (Multi-segment spine extension!)
        "superman_hold" -> {
            val rest = FkPose(
                rootXNorm = 0.48f,
                pelvisTiltDeg = -1f, spineFlexDeg = 0f, lumbarFlexBias = 0f, thoracicFlexBias = 0f, neckBendDeg = 4f,
                nearShoulderDeg = 2f, nearElbowFlexDeg = -2f,
                farShoulderDeg = 0f, farElbowFlexDeg = -2f,
                nearHipDeg = 179f, nearKneeFlexDeg = 0f, nearAnkleDeg = 170f,
                farHipDeg = 180f, farKneeFlexDeg = 0f, farAnkleDeg = 170f,
                contactMode = GroundContactMode.PRONE_FLOOR
            )
            val lift = rest.copy(
                pelvisTiltDeg = -8f, spineFlexDeg = -12f, lumbarFlexBias = -8f, thoracicFlexBias = -8f, neckBendDeg = -6f,
                nearShoulderDeg = -20f, farShoulderDeg = -22f,
                nearHipDeg = 192f, nearKneeFlexDeg = -2f, nearAnkleDeg = 186f,
                farHipDeg = 194f, farKneeFlexDeg = -2f, farAnkleDeg = 188f
            )
            val peak = rest.copy(
                pelvisTiltDeg = -12f, spineFlexDeg = -18f, lumbarFlexBias = -12f, thoracicFlexBias = -12f, neckBendDeg = -8f,
                nearShoulderDeg = -30f, farShoulderDeg = -32f,
                nearHipDeg = 200f, nearKneeFlexDeg = -3f, nearAnkleDeg = 195f,
                farHipDeg = 202f, farKneeFlexDeg = -3f, farAnkleDeg = 197f
            )
            listOf(rest, lift, peak, lift)
        }

        // 25. Cobra Spine Extension (Flexible multi-vertebrae arch + IK-locked hands on mat!)
        "cobra_stretch" -> {
            val prone = FkPose(
                rootXNorm = 0.44f,
                pelvisTiltDeg = -2f, spineFlexDeg = 0f, lumbarFlexBias = 0f, thoracicFlexBias = 0f, neckBendDeg = 4f,
                nearShoulderDeg = 148f, nearElbowFlexDeg = -96f, nearWristBendDeg = -40f,
                farShoulderDeg = 144f, farElbowFlexDeg = -94f, farWristBendDeg = -40f,
                nearHipDeg = 178f, nearKneeFlexDeg = 0f, nearAnkleDeg = 172f,
                farHipDeg = 180f, farKneeFlexDeg = 0f, farAnkleDeg = 172f,
                contactMode = GroundContactMode.PRONE_FLOOR,
                handStyle = HandStyle.FLAT_PRESS
            )
            val babyCobra = prone.copy(
                pelvisTiltDeg = -8f, spineFlexDeg = -24f, lumbarFlexBias = -14f, thoracicFlexBias = -14f, neckBendDeg = -10f
            )
            val fullCobra = prone.copy(
                pelvisTiltDeg = -12f, spineFlexDeg = -44f, lumbarFlexBias = -24f, thoracicFlexBias = -22f, neckBendDeg = -16f
            )
            listOf(prone, babyCobra, fullCobra, babyCobra)
        }

        // 26. Cat-Cow Spine Mobility (True lumbar + thoracic multi-segment curvature + IK-locked palms!)
        "cat_cow" -> {
            val tabletop = FkPose(
                rootXNorm = 0.42f,
                pelvisTiltDeg = 0f, spineFlexDeg = 0f, lumbarFlexBias = 0f, thoracicFlexBias = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 90f, nearElbowFlexDeg = -2f, nearWristBendDeg = -88f,
                farShoulderDeg = 88f, farElbowFlexDeg = -2f, farWristBendDeg = -86f,
                nearHipDeg = 90f, nearKneeFlexDeg = 90f, nearAnkleDeg = 178f,
                farHipDeg = 92f, farKneeFlexDeg = 88f, farAnkleDeg = 178f,
                contactMode = GroundContactMode.FEET_AND_HANDS,
                handStyle = HandStyle.FLAT_PRESS
            )
            val cow = tabletop.copy(
                pelvisTiltDeg = 14f, spineFlexDeg = -28f, lumbarFlexBias = -14f, thoracicFlexBias = -12f, neckBendDeg = -24f
            )
            val cat = tabletop.copy(
                pelvisTiltDeg = -16f, spineFlexDeg = 34f, lumbarFlexBias = 16f, thoracicFlexBias = 16f, neckBendDeg = 32f
            )
            listOf(tabletop, cow, tabletop, cat)
        }

        // 27. Child's Pose Stretch
        "childs_pose_stretch" -> {
            val kneel = FkPose(
                rootXNorm = 0.36f,
                pelvisTiltDeg = -38f, spineFlexDeg = 18f, lumbarFlexBias = 6f, thoracicFlexBias = 8f, neckBendDeg = 16f,
                nearShoulderDeg = 46f, nearElbowFlexDeg = -8f, nearWristBendDeg = -30f,
                farShoulderDeg = 42f, farElbowFlexDeg = -8f, farWristBendDeg = -28f,
                nearHipDeg = 32f, nearKneeFlexDeg = 146f, nearAnkleDeg = 178f,
                farHipDeg = 34f, farKneeFlexDeg = 144f, farAnkleDeg = 178f,
                contactMode = GroundContactMode.KNEELING_SUJUD,
                handStyle = HandStyle.FLAT_PRESS
            )
            val deepStretch = FkPose(
                rootXNorm = 0.34f,
                pelvisTiltDeg = 12f, spineFlexDeg = 14f, lumbarFlexBias = 6f, thoracicFlexBias = 8f, neckBendDeg = 10f,
                nearShoulderDeg = 10f, nearElbowFlexDeg = -4f, nearWristBendDeg = -6f,
                farShoulderDeg = 8f, farElbowFlexDeg = -4f, farWristBendDeg = -4f,
                nearHipDeg = 22f, nearKneeFlexDeg = 156f, nearAnkleDeg = 178f,
                farHipDeg = 24f, farKneeFlexDeg = 154f, farAnkleDeg = 178f,
                contactMode = GroundContactMode.KNEELING_SUJUD,
                handStyle = HandStyle.FLAT_PRESS
            )
            val inhaleExpand = deepStretch.copy(pelvisTiltDeg = 8f, spineFlexDeg = 10f)
            listOf(kneel, deepStretch, inhaleExpand, deepStretch)
        }

        // ==================== AUTHENTIC EQUIPMENT BIOMECHANICS CHOREOGRAPHY ====================

        // Goblet Squats (Dumbbell & Kettlebell) — upright torso holding load tightly at sternum
        "db_goblet_squat", "kb_goblet_squat" -> {
            val stand = FkPose(
                rootXNorm = 0.50f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 76f, nearElbowFlexDeg = -112f, nearWristBendDeg = 8f,
                farShoulderDeg = 72f, farElbowFlexDeg = -110f, farWristBendDeg = 8f,
                nearHipDeg = 90f, nearKneeFlexDeg = 4f, nearAnkleDeg = 0f,
                farHipDeg = 92f, farKneeFlexDeg = 4f, farAnkleDeg = 0f,
                handStyle = HandStyle.FIST
            )
            val half = stand.copy(
                pelvisTiltDeg = -76f, spineFlexDeg = 4f,
                nearShoulderDeg = 82f, nearElbowFlexDeg = -116f,
                farShoulderDeg = 78f, farElbowFlexDeg = -114f,
                nearHipDeg = 42f, nearKneeFlexDeg = 68f,
                farHipDeg = 44f, farKneeFlexDeg = 66f
            )
            val deep = stand.copy(
                pelvisTiltDeg = -68f, spineFlexDeg = 6f,
                nearShoulderDeg = 86f, nearElbowFlexDeg = -120f,
                farShoulderDeg = 82f, farElbowFlexDeg = -118f,
                nearHipDeg = 6f, nearKneeFlexDeg = 114f,
                farHipDeg = 8f, farKneeFlexDeg = 112f
            )
            listOf(stand, half, deep, half)
        }

        // Barbell Back Squat — bar resting across upper traps, hands gripping back near shoulders
        "bb_back_squat" -> {
            val stand = FkPose(
                rootXNorm = 0.50f,
                pelvisTiltDeg = -88f, spineFlexDeg = -2f, neckBendDeg = 0f,
                nearShoulderDeg = 128f, nearElbowFlexDeg = -128f, nearWristBendDeg = -10f,
                farShoulderDeg = 124f, farElbowFlexDeg = -126f, farWristBendDeg = -10f,
                nearHipDeg = 90f, nearKneeFlexDeg = 4f, nearAnkleDeg = 0f,
                farHipDeg = 92f, farKneeFlexDeg = 4f, farAnkleDeg = 0f,
                handStyle = HandStyle.FIST
            )
            val mid = stand.copy(
                pelvisTiltDeg = -66f, spineFlexDeg = 2f,
                nearHipDeg = 40f, nearKneeFlexDeg = 68f,
                farHipDeg = 42f, farKneeFlexDeg = 66f
            )
            val parallel = stand.copy(
                pelvisTiltDeg = -54f, spineFlexDeg = 4f,
                nearHipDeg = 8f, nearKneeFlexDeg = 112f,
                farHipDeg = 10f, farKneeFlexDeg = 110f
            )
            listOf(stand, mid, parallel, mid)
        }

        // Romanian Deadlift (Dumbbell & Barbell) — crisp flat-back hip hinge with soft knees
        "db_romanian_deadlift", "bb_romanian_deadlift" -> {
            val stand = FkPose(
                rootXNorm = 0.50f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 88f, nearElbowFlexDeg = -4f,
                farShoulderDeg = 90f, farElbowFlexDeg = -4f,
                nearHipDeg = 90f, nearKneeFlexDeg = 8f,
                farHipDeg = 92f, farKneeFlexDeg = 8f,
                handStyle = HandStyle.FIST
            )
            val midHinge = stand.copy(
                pelvisTiltDeg = -44f, spineFlexDeg = 0f, neckBendDeg = -10f,
                nearShoulderDeg = 86f, farShoulderDeg = 88f,
                nearHipDeg = 76f, nearKneeFlexDeg = 18f,
                farHipDeg = 78f, farKneeFlexDeg = 18f
            )
            val deepHinge = stand.copy(
                pelvisTiltDeg = -12f, spineFlexDeg = 0f, neckBendDeg = -14f,
                nearShoulderDeg = 84f, farShoulderDeg = 86f,
                nearHipDeg = 70f, nearKneeFlexDeg = 22f,
                farHipDeg = 72f, farKneeFlexDeg = 22f
            )
            listOf(stand, midHinge, deepHinge, midHinge)
        }

        // Dumbbell & Barbell Bench Press — supine on bench pressing load vertically over chest
        "db_chest_press", "bb_bench_press" -> {
            val topLock = FkPose(
                rootXNorm = 0.44f, rootYBias = -0.68f,
                pelvisTiltDeg = -180f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = -88f, nearElbowFlexDeg = -4f,
                farShoulderDeg = -92f, farElbowFlexDeg = -4f,
                nearHipDeg = 18f, nearKneeFlexDeg = 78f, nearAnkleDeg = 0f,
                farHipDeg = 20f, farKneeFlexDeg = 76f, farAnkleDeg = 0f,
                contactMode = GroundContactMode.SUPINE_BACK,
                handStyle = HandStyle.FIST
            )
            val mid = topLock.copy(
                nearShoulderDeg = -48f, nearElbowFlexDeg = -64f,
                farShoulderDeg = -52f, farElbowFlexDeg = -60f
            )
            val chestBottom = topLock.copy(
                nearShoulderDeg = -12f, nearElbowFlexDeg = -102f,
                farShoulderDeg = -16f, farElbowFlexDeg = -98f
            )
            listOf(topLock, mid, chestBottom, mid)
        }

        // Standing Overhead Presses (Dumbbell, Resistance Band, Kettlebell Clean & Press)
        "db_overhead_press", "band_overhead_press", "kb_clean_and_press" -> {
            val rack = FkPose(
                rootXNorm = 0.50f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 68f, nearElbowFlexDeg = -128f,
                farShoulderDeg = 72f, farElbowFlexDeg = -126f,
                nearHipDeg = 89f, nearKneeFlexDeg = 4f,
                farHipDeg = 92f, farKneeFlexDeg = 4f,
                handStyle = HandStyle.FIST
            )
            val drive = rack.copy(
                nearShoulderDeg = -22f, nearElbowFlexDeg = -64f,
                farShoulderDeg = -18f, farElbowFlexDeg = -62f
            )
            val lockout = rack.copy(
                nearShoulderDeg = -86f, nearElbowFlexDeg = -6f,
                farShoulderDeg = -90f, farElbowFlexDeg = -6f
            )
            listOf(rack, drive, lockout, drive)
        }

        // Bent-Over Rows (Single-Arm Dumbbell & Barbell)
        "db_single_arm_row", "bb_bent_over_row" -> {
            val hang = FkPose(
                rootXNorm = 0.48f,
                pelvisTiltDeg = -34f, spineFlexDeg = 0f, neckBendDeg = -10f,
                nearShoulderDeg = 86f, nearElbowFlexDeg = -6f,
                farShoulderDeg = 88f, farElbowFlexDeg = -6f,
                nearHipDeg = 74f, nearKneeFlexDeg = 22f,
                farHipDeg = 78f, farKneeFlexDeg = 20f,
                handStyle = HandStyle.FIST
            )
            val pullMid = hang.copy(
                nearShoulderDeg = 122f, nearElbowFlexDeg = -58f,
                farShoulderDeg = if (exerciseId == "bb_bent_over_row") 120f else 88f,
                farElbowFlexDeg = if (exerciseId == "bb_bent_over_row") -56f else -6f
            )
            val squeezeTop = hang.copy(
                nearShoulderDeg = 152f, nearElbowFlexDeg = -102f,
                farShoulderDeg = if (exerciseId == "bb_bent_over_row") 150f else 88f,
                farElbowFlexDeg = if (exerciseId == "bb_bent_over_row") -100f else -6f
            )
            listOf(hang, pullMid, squeezeTop, pullMid)
        }

        // Dumbbell Bulgarian Split Squat (uses rear bench just like bodyweight Bulgarian split squat)
        "db_bulgarian_split_squat" -> {
            keyframesFor("bulgarian_split_squat").map { pose ->
                pose.copy(
                    nearShoulderDeg = 92f, nearElbowFlexDeg = -6f,
                    farShoulderDeg = 88f, farElbowFlexDeg = -6f,
                    handStyle = HandStyle.FIST
                )
            }
        }

        // Dumbbell Hammer Curl — elbows quietly pinned to ribs
        "db_hammer_curl" -> {
            val bottom = FkPose(
                rootXNorm = 0.50f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 92f, nearElbowFlexDeg = -8f,
                farShoulderDeg = 88f, farElbowFlexDeg = -8f,
                nearHipDeg = 89f, nearKneeFlexDeg = 4f,
                farHipDeg = 92f, farKneeFlexDeg = 4f,
                handStyle = HandStyle.FIST
            )
            val mid = bottom.copy(
                nearShoulderDeg = 88f, nearElbowFlexDeg = -68f,
                farShoulderDeg = 86f, farElbowFlexDeg = -66f
            )
            val peak = bottom.copy(
                nearShoulderDeg = 84f, nearElbowFlexDeg = -132f,
                farShoulderDeg = 82f, farElbowFlexDeg = -130f
            )
            listOf(bottom, mid, peak, mid)
        }

        // Banded Chest Press & Pallof Press — athletic split stance pushing forward
        "band_chest_press", "band_pallof_press" -> {
            val ready = FkPose(
                rootXNorm = 0.46f,
                pelvisTiltDeg = -84f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 112f, nearElbowFlexDeg = -114f,
                farShoulderDeg = 108f, farElbowFlexDeg = -112f,
                nearHipDeg = 76f, nearKneeFlexDeg = 18f,
                farHipDeg = 104f, farKneeFlexDeg = 14f,
                handStyle = HandStyle.FIST
            )
            val halfPress = ready.copy(
                nearShoulderDeg = 46f, nearElbowFlexDeg = -58f,
                farShoulderDeg = 42f, farElbowFlexDeg = -56f
            )
            val fullPress = ready.copy(
                nearShoulderDeg = 4f, nearElbowFlexDeg = -6f,
                farShoulderDeg = 0f, farElbowFlexDeg = -6f
            )
            listOf(ready, halfPress, fullPress, halfPress)
        }

        // Banded Seated/Anchored Row & Face Pull — pulling elbows cleanly behind torso
        "band_seated_row", "band_face_pull" -> {
            val highTarget = exerciseId == "band_face_pull"
            val reach = FkPose(
                rootXNorm = 0.52f,
                pelvisTiltDeg = -88f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = if (highTarget) -12f else 8f, nearElbowFlexDeg = -6f,
                farShoulderDeg = if (highTarget) -16f else 4f, farElbowFlexDeg = -6f,
                nearHipDeg = 82f, nearKneeFlexDeg = 14f,
                farHipDeg = 98f, farKneeFlexDeg = 12f,
                handStyle = HandStyle.FIST
            )
            val pullMid = reach.copy(
                nearShoulderDeg = if (highTarget) 28f else 62f, nearElbowFlexDeg = -66f,
                farShoulderDeg = if (highTarget) 24f else 58f, farElbowFlexDeg = -64f
            )
            val squeeze = reach.copy(
                nearShoulderDeg = if (highTarget) 54f else 124f, nearElbowFlexDeg = -112f,
                farShoulderDeg = if (highTarget) 50f else 120f, farElbowFlexDeg = -110f
            )
            listOf(reach, pullMid, squeeze, pullMid)
        }

        // Pull-Up, Chin-Up & Scapular Pull — suspended vertical bar hang with realistic vertical ascent!
        "bar_pull_up", "bar_chin_up", "bar_scapular_pull" -> {
            val isScap = exerciseId == "bar_scapular_pull"
            val deadHang = FkPose(
                rootXNorm = 0.50f, rootYBias = -0.35f,
                pelvisTiltDeg = -90f, spineFlexDeg = -2f, neckBendDeg = 0f,
                nearShoulderDeg = -88f, nearElbowFlexDeg = -4f,
                farShoulderDeg = -92f, farElbowFlexDeg = -4f,
                nearHipDeg = 88f, nearKneeFlexDeg = 10f,
                farHipDeg = 92f, farKneeFlexDeg = 10f,
                contactMode = GroundContactMode.MANUAL_WORLD_ANCHOR,
                handStyle = HandStyle.FIST
            )
            val midPull = deadHang.copy(
                rootYBias = if (isScap) -0.58f else -0.92f,
                nearShoulderDeg = if (isScap) -86f else -42f,
                nearElbowFlexDeg = if (isScap) -6f else -68f,
                farShoulderDeg = if (isScap) -94f else -48f,
                farElbowFlexDeg = if (isScap) -6f else -66f
            )
            val topBar = deadHang.copy(
                rootYBias = if (isScap) -0.72f else -1.52f,
                nearShoulderDeg = if (isScap) -84f else 28f,
                nearElbowFlexDeg = if (isScap) -8f else -132f,
                farShoulderDeg = if (isScap) -96f else 24f,
                farElbowFlexDeg = if (isScap) -8f else -130f
            )
            listOf(deadHang, midPull, topBar, midPull)
        }

        // Hanging Knee / Leg Raise — suspended bar hang curling pelvis & knees toward chest
        "bar_hanging_knee_raise" -> {
            val hang = FkPose(
                rootXNorm = 0.48f, rootYBias = -0.45f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = -88f, nearElbowFlexDeg = -4f,
                farShoulderDeg = -92f, farElbowFlexDeg = -4f,
                nearHipDeg = 90f, nearKneeFlexDeg = 6f,
                farHipDeg = 92f, farKneeFlexDeg = 6f,
                contactMode = GroundContactMode.MANUAL_WORLD_ANCHOR,
                handStyle = HandStyle.FIST
            )
            val halfTuck = hang.copy(
                pelvisTiltDeg = -80f, spineFlexDeg = 12f,
                nearHipDeg = 28f, nearKneeFlexDeg = 76f,
                farHipDeg = 32f, farKneeFlexDeg = 74f
            )
            val peakTuck = hang.copy(
                pelvisTiltDeg = -68f, spineFlexDeg = 24f,
                nearHipDeg = -22f, nearKneeFlexDeg = 106f,
                farHipDeg = -18f, farKneeFlexDeg = 104f
            )
            listOf(hang, halfTuck, peakTuck, halfTuck)
        }

        // Two-Hand Kettlebell Swing — ballistic hip hinge to crisp standing chest-float plank
        "kb_two_hand_swing" -> {
            val hike = FkPose(
                rootXNorm = 0.50f,
                pelvisTiltDeg = -22f, spineFlexDeg = 0f, neckBendDeg = -12f,
                nearShoulderDeg = 112f, nearElbowFlexDeg = -6f,
                farShoulderDeg = 110f, farElbowFlexDeg = -6f,
                nearHipDeg = 66f, nearKneeFlexDeg = 28f,
                farHipDeg = 70f, farKneeFlexDeg = 26f,
                handStyle = HandStyle.FIST
            )
            val drive = hike.copy(
                pelvisTiltDeg = -62f, neckBendDeg = -4f,
                nearShoulderDeg = 46f, farShoulderDeg = 44f,
                nearHipDeg = 82f, nearKneeFlexDeg = 12f,
                farHipDeg = 84f, farKneeFlexDeg = 12f
            )
            val topFloat = hike.copy(
                pelvisTiltDeg = -90f, neckBendDeg = 0f,
                nearShoulderDeg = 2f, farShoulderDeg = 0f,
                nearHipDeg = 90f, nearKneeFlexDeg = 4f,
                farHipDeg = 92f, farKneeFlexDeg = 4f
            )
            listOf(hike, drive, topFloat, drive)
        }

        // Kettlebell Halo — tall upright core bracing while orbiting bell closely around head
        "kb_halo" -> {
            val front = FkPose(
                rootXNorm = 0.50f,
                pelvisTiltDeg = -90f, spineFlexDeg = 0f, neckBendDeg = 0f,
                nearShoulderDeg = 62f, nearElbowFlexDeg = -118f,
                farShoulderDeg = 66f, farElbowFlexDeg = -116f,
                nearHipDeg = 89f, nearKneeFlexDeg = 4f,
                farHipDeg = 92f, farKneeFlexDeg = 4f,
                handStyle = HandStyle.FIST
            )
            val sideOrbit = front.copy(
                nearShoulderDeg = -34f, nearElbowFlexDeg = -92f,
                farShoulderDeg = 24f, farElbowFlexDeg = -118f
            )
            val behindHead = front.copy(
                nearShoulderDeg = -108f, nearElbowFlexDeg = -96f,
                farShoulderDeg = -112f, farElbowFlexDeg = -94f
            )
            listOf(front, sideOrbit, behindHead, sideOrbit)
        }

        else -> keyframesFor("bodyweight_squat")
    }
}
