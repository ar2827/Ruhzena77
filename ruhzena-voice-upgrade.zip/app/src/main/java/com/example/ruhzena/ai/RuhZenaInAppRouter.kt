package com.example.ruhzena.ai

import com.example.ruhzena.data.islamic.AdhkarCategory
import com.example.ruhzena.data.islamic.DuaItem
import com.example.ruhzena.data.islamic.IslamicContentData
import com.example.ruhzena.data.islamic.SurahCatalog
import com.example.ruhzena.data.islamic.SurahMeta

/**
 * Deterministic + AI-assisted in-app deep-link router for RuhZena AI.
 *
 * Whenever a user asks RuhZena AI about a Surah (e.g. Surah Al-Mulk, Yasin, Kahf, Ayat al-Kursi,
 * or any of the 114 Surahs), any daily Sunnah Dua (washroom, home, stairs, bazaar, travel, sleep,
 * anxiety, forgiveness, etc.), Adhkar, Tasbih, Prayer/Qibla, Wudu/Salah guides, Arabic Studio,
 * Workouts, Hydration, Nutrition, Habits, Journal, or Hifz, this router generates structured
 * deep-link action tags so the user can jump directly to that exact content inside RuhZena in 1 tap.
 */
object RuhZenaInAppRouter {

    data class ActionDescriptor(
        val tag: String,
        val labelEn: String,
        val labelBn: String,
        val kind: ActionKind
    )

    enum class ActionKind {
        QURAN, DUA, ADHKAR, TASBIH, PRAYER_QIBLA, LEARNING, WUDU_SALAH, WORKOUT, WELLNESS, DISCIPLINE, BREATHING, GENERAL
    }

    private val STATIC_ALLOWED_TAGS = setOf(
        "QIBLA", "PRAYER_TIMES", "ADHKAR", "DUA", "TASBIH",
        "WUDU_GUIDE", "SALAH_GUIDE", "ARABIC_STUDIO", "STORIES", "HAJJ_UMRAH", "LESSONS",
        "HIFZ", "WORKOUTS", "HYDRATION", "NUTRITION",
        "HABITS", "JOURNAL", "HABIT_RECOVERY", "BREATHING", "BOOKMARKS", "MY_DAY"
    )

    // Common phonetic / spelling aliases for widely requested Surahs
    private val SURAH_ALIASES: Map<String, Int> = mapOf(
        "fatiha" to 1, "fatihah" to 1, "fateha" to 1, "al fatiha" to 1, "সূরা ফাতিহা" to 1, "ফাতিহা" to 1,
        "baqara" to 2, "baqarah" to 2, "bakara" to 2, "al baqarah" to 2, "সূরা বাকারা" to 2, "বাকারা" to 2,
        "imran" to 3, "ale imran" to 3, "aal imran" to 3, "ali imran" to 3,
        "nisa" to 4, "nisaa" to 4,
        "maidah" to 5, "maida" to 5,
        "tawbah" to 9, "taubah" to 9, "tauba" to 9,
        "yusuf" to 12, "yousuf" to 12, "ইউসুফ" to 12,
        "ibrahim" to 14,
        "isra" to 17, "bani israel" to 17,
        "kahf" to 18, "al kahf" to 18, "kahaf" to 18, "কাহফ" to 18, "কাহাফ" to 18,
        "maryam" to 19, "mariam" to 19, "মারইয়াম" to 19,
        "taha" to 20, "ta ha" to 20,
        "nur" to 24, "noor" to 24,
        "luqman" to 31, "lukman" to 31,
        "sajdah" to 32, "sajda" to 32,
        "yasin" to 36, "yaseen" to 36, "ya sin" to 36, "ya-sin" to 36, "ইয়াসীন" to 36, "ইয়াসিন" to 36,
        "rahman" to 55, "ar rahman" to 55, "rehman" to 55, "রহমান" to 55, "আর-রহমান" to 55,
        "waqiah" to 56, "waqia" to 56, "wakia" to 56, "al waqiah" to 56, "ওয়াকিয়া" to 56, "ওয়াকিয়াহ" to 56,
        "hashr" to 59, "হাশর" to 59,
        "jumuah" to 62, "juma" to 62, "jumma" to 62, "জুমুআ" to 62,
        "mulk" to 67, "al mulk" to 67, "tabarak" to 67, "মুলক" to 67, "আল-মুলক" to 67, "সূরা মুলক" to 67,
        "qalam" to 68,
        "jinn" to 72, "jin" to 72,
        "muzzammil" to 73, "muzammil" to 73, "মুযযাম্মিল" to 73,
        "muddaththir" to 74, "mudassir" to 74,
        "qiyamah" to 75, "qiyama" to 75,
        "naba" to 78, "নাবা" to 78,
        "ala" to 87, "a'la" to 87,
        "fajr" to 89,
        "shams" to 91,
        "layl" to 92, "lail" to 92,
        "duha" to 93, "duhaa" to 93, "zuha" to 93, "দুহা" to 93,
        "sharh" to 94, "inshirah" to 94, "alam nashrah" to 94, "ইনশিরাহ" to 94,
        "tin" to 95, "teen" to 95,
        "alaq" to 96, "iqra" to 96,
        "qadr" to 97, "qadar" to 97, "কদর" to 97, "ক্বদর" to 97,
        "zalzalah" to 99, "zilzal" to 99,
        "asr" to 103, "আসর" to 103,
        "fil" to 105, "feel" to 105,
        "quraysh" to 106, "quraish" to 106,
        "maun" to 107, "ma'un" to 107,
        "kawthar" to 108, "kawsar" to 108, "kausar" to 108, "কাউসার" to 108,
        "kafirun" to 109, "kafiroon" to 109, "কাফিরুন" to 109,
        "nasr" to 110,
        "masad" to 111, "lahab" to 111,
        "ikhlas" to 112, "ekhlas" to 112, "ইখলাস" to 112,
        "falaq" to 113, "falak" to 113, "ফালাক" to 113,
        "nas" to 114, "naas" to 114, "নাস" to 114
    )

    private val DUA_KEYWORD_TO_ID: List<Pair<List<String>, String>> = listOf(
        listOf("entering washroom", "enter washroom", "entering bathroom", "enter bathroom", "entering toilet", "enter toilet", "washroom dua", "bathroom dua", "toilet dua", "টয়লেট", "বাথরুম", "ওয়াশরুম") to "dua_entering_washroom",
        listOf("leaving washroom", "exit washroom", "exiting washroom", "leaving bathroom", "exit bathroom", "leaving toilet", "exit toilet", "ghufranaka", "গুফরানাকা", "বাথরুম থেকে বের") to "dua_leaving_washroom",
        listOf("entering home", "enter home", "entering house", "enter house", "ঘরে প্রবেশ", "বাসায় ঢোকা") to "dua_entering_home",
        listOf("leaving home", "leave home", "exiting home", "leaving house", "exit house", "ঘর থেকে বের", "বাসা থেকে বের") to "dua_leaving_home",
        listOf("ascending stairs", "going upstairs", "climb stairs", "upstairs", "সিঁড়ি বেয়ে উপরে", "উপরে ওঠার") to "dua_ascending_stairs",
        listOf("descending stairs", "going downstairs", "downstairs", "সিঁড়ি বেয়ে নিচে", "নিচে নামার") to "dua_descending_stairs",
        listOf("bazaar", "bazar", "market", "marketplace", "shopping", "বাজারে প্রবেশ", "বাজারের দুআ") to "dua_entering_market",
        listOf("entering mosque", "enter mosque", "entering masjid", "enter masjid", "মসজিদে প্রবেশ") to "dua_entering_masjid",
        listOf("leaving mosque", "leave mosque", "leaving masjid", "exit masjid", "মসজিদ থেকে বের") to "dua_leaving_masjid",
        listOf("travel", "journey", "riding", "car", "vehicle", "flight", "সফর", "ভ্রমণ", "যানবাহন") to "dua_travel",
        listOf("before eating", "eating", "food", "meal", "খাওয়ার আগে", "খাবারের আগে") to "dua_before_eating",
        listOf("after eating", "finished eating", "খাওয়ার পর", "খাবারের পর") to "dua_after_eating",
        listOf("before sleep", "sleeping", "bedtime", "sleep dua", "ঘুমানোর আগে", "ঘুমের দুআ") to "dua_before_sleep",
        listOf("waking up", "wake up", "morning wake", "ঘুম থেকে ওঠা", "জেগে ওঠা") to "dua_waking_up",
        listOf("anxiety", "stress", "depressed", "sad", "grief", "worry", "দুশ্চিন্তা", "হতাশা", "অস্থিরতা") to "dua_anxiety_grief",
        listOf("forgiveness", "istighfar", "sayyidul istighfar", "taubah", "ক্ষমা", "ইস্তিগফার", "তাওবা") to "dua_sayyidul_istighfar",
        listOf("parents", "mother", "father", "মা বাবা", "পিতামাতা") to "dua_parents",
        listOf("exam", "study", "knowledge", "memorize", "পরীক্ষা", "পড়াশোনা", "জ্ঞান") to "dua_knowledge",
        listOf("rain", "raining", "বৃষ্টি") to "dua_rain",
        listOf("sick", "illness", "healing", "shifa", "রোগ", "সুস্থতা", "শিফা") to "dua_healing",
        listOf("debt", "rizq", "sustenance", "provision", "ঋণ", "রিযিক") to "dua_debt_rizq",
        listOf("istikhara", "istikharah", "decision", "ইস্তিখারা") to "dua_istikhara"
    )

    fun isValidActionTag(rawTag: String): Boolean {
        val tag = rawTag.trim().uppercase()
        if (tag in STATIC_ALLOWED_TAGS) return true
        if (tag.startsWith("SURAH:")) {
            val parts = tag.removePrefix("SURAH:").split(":")
            val num = parts.firstOrNull()?.toIntOrNull() ?: return false
            return num in 1..114
        }
        if (tag.startsWith("DUA_ID:")) {
            val id = rawTag.trim().substringAfter("DUA_ID:", "").trim()
            return id.isNotBlank() && IslamicContentData.duaList.any { it.id.equals(id, ignoreCase = true) }
        }
        if (tag.startsWith("DUA:")) {
            return tag.removePrefix("DUA:").trim().isNotBlank()
        }
        if (tag.startsWith("ADHKAR:")) {
            val cat = tag.removePrefix("ADHKAR:").trim()
            return AdhkarCategory.entries.any { it.name == cat }
        }
        return false
    }

    /**
     * Merges LLM-emitted tags with deterministic matches from the user's query (and reply) so
     * whenever the user searches for a Surah, Dua, Adhkar, Guide, or built-in tool, RuhZena AI
     * reliably provides direct 1-tap buttons to open it inside the app.
     */
    fun detectInAppActions(
        userQuery: String,
        aiReply: String = "",
        llmEmittedTags: List<String> = emptyList()
    ): List<String> {
        val results = LinkedHashSet<String>()
        val qLower = userQuery.lowercase().trim()
        val combinedLower = "$qLower\n${aiReply.lowercase()}"

        // 1. Preserve valid LLM-emitted tags first (normalized)
        llmEmittedTags.forEach { raw ->
            val cleaned = normalizeTag(raw)
            if (cleaned != null && isValidActionTag(cleaned)) {
                results.add(cleaned)
            }
        }

        // 2. Famous verse shortcuts (Ayat al-Kursi, last 2 ayahs of Baqarah)
        if (containsAny(qLower, "ayat al-kursi", "ayatul kursi", "ayat ul kursi", "ayat kursi", "আয়াতুল কুরসি", "আয়াতুল কুরসী")) {
            results.add("SURAH:2:255")
        }
        if (containsAny(qLower, "amanar rasul", "last two verses of baqarah", "last 2 ayahs of baqarah", "আমানার রাসূল")) {
            results.add("SURAH:2:285")
        }

        // 3. Explicit Surah:Ayah pattern in user query (e.g., "67:1", "2:255", "Surah 67")
        val surahAyahRegex = Regex("""(?:surah|sura|quran|সূরা|সুরা)\s*(?:no\.?|number|#)?\s*(\d{1,3})(?:\s*[:\-]\s*(\d{1,3}))?""", RegexOption.IGNORE_CASE)
        surahAyahRegex.findAll(userQuery).forEach { m ->
            val sNum = m.groupValues[1].toIntOrNull()
            val aNum = m.groupValues[2].toIntOrNull()
            if (sNum != null && sNum in 1..114) {
                results.add(if (aNum != null && aNum > 0) "SURAH:$sNum:$aNum" else "SURAH:$sNum")
            }
        }
        val bareRefRegex = Regex("""\b(\d{1,3}):(\d{1,3})\b""")
        bareRefRegex.findAll(userQuery).forEach { m ->
            val sNum = m.groupValues[1].toIntOrNull()
            val aNum = m.groupValues[2].toIntOrNull()
            if (sNum != null && sNum in 1..114 && aNum != null && aNum in 1..286) {
                results.add("SURAH:$sNum:$aNum")
            }
        }

        // 4. Named Surah detection in user query (all 114 Surahs + common spellings & Bangla/Arabic)
        val matchedSurahs = findMatchingSurahs(userQuery)
        matchedSurahs.take(2).forEach { surah ->
            if (results.none { it.startsWith("SURAH:${surah.number}") }) {
                results.add("SURAH:${surah.number}")
            }
        }

        // Also detect if user specifically asked about "quran" / "recite" / "read surah" without naming one
        if (results.none { it.startsWith("SURAH:") } &&
            containsAny(qLower, "read quran", "open quran", "quran reader", "কুরআন পড়", "কুরআন খুল")) {
            results.add("SURAH:1")
        }

        // 5. Specific Dua detection from the full in-app Dua catalog
        val asksAboutDua = containsAny(
            qLower,
            "dua", "du'a", "duaa", "supplication", "prayer for", "prayer when", "prayer before", "prayer after",
            "দোয়া", "দুআ", "দু'আ", "washroom", "bathroom", "toilet", "stairs", "bazaar", "bazar", "market",
            "entering home", "leaving home", "masjid", "mosque", "before sleep", "waking up", "istikhara", "istighfar"
        )
        if (asksAboutDua) {
            val matchedDua = findBestMatchingDua(userQuery)
            if (matchedDua != null) {
                results.add("DUA_ID:${matchedDua.id}")
            } else {
                results.add("DUA")
            }
        }

        // 6. Adhkar categories
        when {
            containsAny(qLower, "morning adhkar", "morning azkar", "morning dhikr", "সকালের যিকির", "সকালের জিকির") ->
                results.add("ADHKAR:MORNING")
            containsAny(qLower, "evening adhkar", "evening azkar", "evening dhikr", "সন্ধ্যার যিকির", "বিকালের যিকির") ->
                results.add("ADHKAR:EVENING")
            containsAny(qLower, "after prayer adhkar", "after salah", "after namaz", "নামাজের পর", "সালাতের পর") ->
                results.add("ADHKAR:AFTER_PRAYER")
            containsAny(qLower, "bedtime adhkar", "before sleep adhkar", "ঘুমানোর যিকির") ->
                results.add("ADHKAR:BEDTIME")
            containsAny(qLower, "adhkar", "azkar", "dhikr", "zikr", "যিকির", "জিকির") ->
                results.add("ADHKAR")
        }

        // 7. Tasbih
        if (containsAny(qLower, "tasbih", "tasbeeh", "subhanallah", "alhamdulillah", "allahu akbar", "তাসবিহ", "তাসবীহ")) {
            results.add("TASBIH")
        }

        // 8. Prayer times & Qibla
        if (containsAny(qLower, "qibla", "kaaba direction", "compass", "কিবলা")) {
            results.add("QIBLA")
        } else if (containsAny(qLower, "prayer time", "salah time", "namaz time", "fajr time", "maghrib time", "isha time", "asr time", "dhuhr time", "নামাজের সময়", "ওয়াক্ত")) {
            results.add("PRAYER_TIMES")
        }

        // 9. Learning Hub: Wudu, Salah, Arabic, Stories, Hajj/Umrah, Hifz
        if (containsAny(qLower, "wudu", "wudhu", "ablution", "অজু", "ওযু", "ওজু")) {
            results.add("WUDU_GUIDE")
        }
        if (containsAny(qLower, "how to pray", "pray salah", "pray namaz", "ruku", "sujud", "tashahhud", "taslim", "নামাজ শিক্ষা", "নামাজ পড়ার নিয়ম", "সালাত শিক্ষা")) {
            results.add("SALAH_GUIDE")
        }
        if (containsAny(qLower, "arabic alphabet", "arabic letter", "learn arabic", "write arabic", "makharij", "আরবি হরফ", "আরবি লেখা")) {
            results.add("ARABIC_STUDIO")
        }
        if (containsAny(qLower, "prophet story", "stories of the prophets", "sahaba", "seerah", "নবীদের গল্প", "সাহাবা")) {
            results.add("STORIES")
        }
        if (containsAny(qLower, "hajj", "umrah", "tawaf", "ihram", "talbiyah", "হজ", "হজ্জ", "উমরাহ", "ওমরাহ")) {
            results.add("HAJJ_UMRAH")
        }
        if (containsAny(qLower, "hifz", "memorize quran", "memorizing surah", "হিফয", "মুখস্থ")) {
            results.add("HIFZ")
        }

        // 10. Wellness & Discipline features
        if (containsAny(qLower, "workout", "exercise", "pushup", "push-up", "squat", "plank", "stretch", "fitness", "training", "ব্যায়াম", "ওয়ার্কআউট")) {
            results.add("WORKOUTS")
        }
        if (containsAny(qLower, "water", "hydration", "drink water", "পানি পান")) {
            results.add("HYDRATION")
        }
        if (containsAny(qLower, "calorie", "protein", "meal", "nutrition", "diet", "food scan", "ক্যালোরি", "খাবার")) {
            results.add("NUTRITION")
        }
        if (containsAny(qLower, "urge", "temptation", "relapse", "breathe", "breathing", "panic", "calm down", "শ্বাস")) {
            results.add("BREATHING")
        } else if (containsAny(qLower, "habit", "discipline", "routine", "অভ্যাস")) {
            results.add("HABITS")
        }
        if (containsAny(qLower, "journal", "diary", "reflection", "জার্নাল")) {
            results.add("JOURNAL")
        }

        // 11. Secondary pass on AI reply if query was vague ("which surah protects from grave?")
        if (results.none { it.startsWith("SURAH:") } && aiReply.isNotBlank()) {
            val replySurahs = findMatchingSurahs(aiReply)
            replySurahs.firstOrNull()?.let { results.add("SURAH:${it.number}") }
            if (containsAny(combinedLower, "ayat al-kursi", "ayatul kursi", "2:255") && results.none { it.startsWith("SURAH:2") }) {
                results.add("SURAH:2:255")
            }
        }

        return results.take(4)
    }

    /**
     * Generates a compact system-prompt note telling RuhZena AI which exact built-in screens/Surahs/Duas
     * match the user's current message so the AI naturally directs the user to tap the button below.
     */
    fun buildPromptAvailabilityNote(userQuery: String, isBn: Boolean): String {
        val detected = detectInAppActions(userQuery)
        if (detected.isEmpty()) return ""
        val descriptions = detected.map { tag ->
            val d = describeActionTag(tag, isBn)
            "- ${if (isBn) d.labelBn else d.labelEn} (tag: [[ACTION:$tag]])"
        }
        return buildString {
            appendLine("AVAILABLE RIGHT INSIDE RUHZENA FOR THIS REQUEST:")
            descriptions.forEach { appendLine(it) }
            append("Mention naturally that this is available directly inside RuhZena and invite them to tap the direct button below, and include the matching [[ACTION:...]] tag(s) on the final line.")
        }
    }

    fun describeActionTag(rawTag: String, isBn: Boolean): ActionDescriptor {
        val trimmed = rawTag.trim()
        val upper = trimmed.uppercase()

        if (upper.startsWith("SURAH:")) {
            val parts = upper.removePrefix("SURAH:").split(":")
            val surahNum = parts.getOrNull(0)?.toIntOrNull() ?: 1
            val ayahNum = parts.getOrNull(1)?.toIntOrNull()
            val meta = SurahCatalog.allSurahs.find { it.number == surahNum }
            val nameEn = meta?.englishName ?: "Surah $surahNum"
            val nameBn = meta?.banglaName ?: "সূরা $surahNum"
            val enLabel = if (ayahNum != null) "Read $nameEn ($surahNum:$ayahNum)" else "Open Surah $nameEn ($surahNum)"
            val bnLabel = if (ayahNum != null) "সূরা $nameBn ($surahNum:$ayahNum) পড়ুন" else "সূরা $nameBn ($surahNum) খুলুন"
            return ActionDescriptor(trimmed, enLabel, bnLabel, ActionKind.QURAN)
        }

        if (upper.startsWith("DUA_ID:")) {
            val id = trimmed.substringAfter("DUA_ID:", "").trim()
            val dua = IslamicContentData.duaList.find { it.id.equals(id, ignoreCase = true) }
            if (dua != null) {
                return ActionDescriptor(
                    tag = "DUA_ID:${dua.id}",
                    labelEn = "Open Dua: ${dua.titleEn}",
                    labelBn = "দুআ খুলুন: ${dua.titleBn}",
                    kind = ActionKind.DUA
                )
            }
        }

        if (upper.startsWith("DUA:")) {
            val q = trimmed.substringAfter(":", "").trim()
            return ActionDescriptor(
                tag = trimmed,
                labelEn = "Open Duas: $q",
                labelBn = "দুআ খুঁজুন: $q",
                kind = ActionKind.DUA
            )
        }

        if (upper.startsWith("ADHKAR:")) {
            val cat = upper.removePrefix("ADHKAR:")
            val (en, bn) = when (cat) {
                "MORNING" -> "Open Morning Adhkar" to "সকালের যিকির খুলুন"
                "EVENING" -> "Open Evening Adhkar" to "সন্ধ্যার যিকির খুলুন"
                "AFTER_PRAYER" -> "Open After-Salah Adhkar" to "নামাজের পরের যিকির খুলুন"
                "BEDTIME" -> "Open Bedtime Adhkar" to "ঘুমানোর যিকির খুলুন"
                "PROTECTION" -> "Open Protection Adhkar" to "নিরাপত্তার যিকির খুলুন"
                else -> "Open Adhkar" to "যিকির খুলুন"
            }
            return ActionDescriptor(upper, en, bn, ActionKind.ADHKAR)
        }

        return when (upper) {
            "QIBLA" -> ActionDescriptor(upper, "Open Qibla & Prayer", "কিবলা ও নামাজ খুলুন", ActionKind.PRAYER_QIBLA)
            "PRAYER_TIMES" -> ActionDescriptor(upper, "Open Prayer Times", "নামাজের সময়সূচি খুলুন", ActionKind.PRAYER_QIBLA)
            "ADHKAR" -> ActionDescriptor(upper, "Open Adhkar", "যিকির খুলুন", ActionKind.ADHKAR)
            "DUA" -> ActionDescriptor(upper, "Open Daily Duas", "দৈনন্দিন দুআ খুলুন", ActionKind.DUA)
            "TASBIH" -> ActionDescriptor(upper, "Open Tasbih Counter", "তাসবিহ কাউন্টার খুলুন", ActionKind.TASBIH)
            "WUDU_GUIDE" -> ActionDescriptor(upper, "Open 3D Wudu Guide", "৩ডি অজু গাইড খুলুন", ActionKind.WUDU_SALAH)
            "SALAH_GUIDE" -> ActionDescriptor(upper, "Open 3D Salah Guide", "৩ডি নামাজ গাইড খুলুন", ActionKind.WUDU_SALAH)
            "ARABIC_STUDIO" -> ActionDescriptor(upper, "Open Arabic Studio", "আরবি লেখা স্টুডিও খুলুন", ActionKind.LEARNING)
            "STORIES" -> ActionDescriptor(upper, "Open Prophet Stories", "নবীদের গল্প খুলুন", ActionKind.LEARNING)
            "HAJJ_UMRAH" -> ActionDescriptor(upper, "Open Hajj & Umrah Guide", "হজ ও উমরাহ গাইড খুলুন", ActionKind.LEARNING)
            "LESSONS" -> ActionDescriptor(upper, "Open Learning Hub", "ইসলামিক শিক্ষা খুলুন", ActionKind.LEARNING)
            "HIFZ" -> ActionDescriptor(upper, "Open Hifz Companion", "হিফয সহায়ক খুলুন", ActionKind.QURAN)
            "WORKOUTS" -> ActionDescriptor(upper, "Open Guided Workouts", "ব্যায়াম ও প্রদর্শনী খুলুন", ActionKind.WORKOUT)
            "HYDRATION" -> ActionDescriptor(upper, "Open Water Tracker", "পানি পান ট্র্যাকার খুলুন", ActionKind.WELLNESS)
            "NUTRITION" -> ActionDescriptor(upper, "Open Meal & Nutrition", "খাবার ও পুষ্টি খুলুন", ActionKind.WELLNESS)
            "HABITS", "HABIT_RECOVERY" -> ActionDescriptor(upper, "Open Habits & Recovery", "অভ্যাস ও পুনরুদ্ধার খুলুন", ActionKind.DISCIPLINE)
            "BREATHING" -> ActionDescriptor(upper, "Start Calm Breathing", "শান্ত শ্বাস-প্রশ্বাস শুরু করুন", ActionKind.BREATHING)
            "JOURNAL" -> ActionDescriptor(upper, "Open Reflection Journal", "জার্নাল খুলুন", ActionKind.DISCIPLINE)
            "BOOKMARKS" -> ActionDescriptor(upper, "Open Saved Bookmarks", "সংরক্ষিত বুকমার্ক খুলুন", ActionKind.QURAN)
            "MY_DAY" -> ActionDescriptor(upper, "Open My Day Dashboard", "আজকের ড্যাশবোর্ড খুলুন", ActionKind.GENERAL)
            else -> ActionDescriptor(trimmed, trimmed, trimmed, ActionKind.GENERAL)
        }
    }

    private fun normalizeTag(raw: String): String? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        val upper = t.uppercase()
        if (upper.startsWith("DUA_ID:")) {
            // Preserve lowercase dua id while normalizing prefix
            return "DUA_ID:${t.substringAfter(':').trim().lowercase()}"
        }
        return upper
    }

    private fun findMatchingSurahs(text: String): List<SurahMeta> {
        val lower = text.lowercase()
        val foundIds = LinkedHashSet<Int>()
        val hasSurahContext = containsAny(lower, "surah", "sura", "sorah", "সূরা", "সুরা", "সুরাহ", "quran", "কুরআন", "recite", "read", "tilawat", "তিলাওয়াত")

        // 1. Check alias dictionary with word-boundary safety
        for ((alias, surahNum) in SURAH_ALIASES) {
            val isShortAmbiguous = alias in setOf("nas", "tin", "ala", "nur", "fil", "asr", "fajr", "nisa")
            if (isShortAmbiguous && !hasSurahContext) continue
            if (matchesWholeTerm(lower, alias)) {
                foundIds.add(surahNum)
            }
        }

        // 2. Check all 114 SurahCatalog entries (English, stripped Al-/An-/Ar- prefix, Bangla, Arabic)
        for (surah in SurahCatalog.allSurahs) {
            val enNorm = normalizeSurahToken(surah.englishName)
            val enBare = enNorm.removePrefix("al ").removePrefix("an ").removePrefix("ar ")
                .removePrefix("as ").removePrefix("ash ").removePrefix("at ").removePrefix("az ").removePrefix("ad ").trim()
            val bnName = surah.banglaName.lowercase()
            if (matchesWholeTerm(lower, enNorm) ||
                (enBare.length >= 4 && (hasSurahContext || enBare.length >= 5) && matchesWholeTerm(lower, enBare)) ||
                (bnName.length >= 3 && lower.contains(bnName)) ||
                (surah.arabicName.length >= 3 && text.contains(surah.arabicName))
            ) {
                foundIds.add(surah.number)
            }
        }

        return foundIds.mapNotNull { id -> SurahCatalog.allSurahs.find { it.number == id } }
    }

    private fun findBestMatchingDua(query: String): DuaItem? {
        val lower = query.lowercase()
        val allDuas = IslamicContentData.duaList

        // 1. Direct curated keyword map
        for ((keywords, targetId) in DUA_KEYWORD_TO_ID) {
            if (keywords.any { lower.contains(it) }) {
                allDuas.find { it.id == targetId }?.let { return it }
            }
        }

        // 2. Token overlap score across all Duas in IslamicContentData
        val stopWords = setOf(
            "dua", "duas", "du'a", "for", "the", "a", "an", "of", "in", "to", "when", "before", "after",
            "give", "me", "tell", "what", "is", "how", "read", "recite", "please", "can", "you", "open", "show",
            "দোয়া", "দুআ", "কি", "কী", "বলুন", "দিন"
        )
        val queryTokens = lower.split(Regex("""[^\p{L}\p{N}]+"""))
            .filter { it.length >= 3 && it !in stopWords }
            .distinct()
        if (queryTokens.isEmpty()) return null

        var bestDua: DuaItem? = null
        var bestScore = 0
        for (dua in allDuas) {
            val titleHay = "${dua.titleEn} ${dua.titleBn} ${dua.categoryEn} ${dua.categoryBn}".lowercase()
            val bodyHay = "${dua.translationEn} ${dua.translationBn} ${dua.transliterationEn}".lowercase()
            var score = 0
            for (tok in queryTokens) {
                if (titleHay.contains(tok)) score += 4
                else if (bodyHay.contains(tok)) score += 1
            }
            if (score > bestScore) {
                bestScore = score
                bestDua = dua
            }
        }
        return if (bestScore >= 4) bestDua else null
    }

    private fun normalizeSurahToken(name: String): String = name.lowercase()
        .replace("-", " ")
        .replace("'", "")
        .replace("’", "")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun matchesWholeTerm(haystack: String, needle: String): Boolean {
        if (needle.isBlank()) return false
        val isAscii = needle.all { it.code < 128 }
        return if (isAscii) {
            Regex("""(?<![a-z0-9])${Regex.escape(needle)}(?![a-z0-9])""").containsMatchIn(haystack)
        } else {
            haystack.contains(needle)
        }
    }

    private fun containsAny(text: String, vararg terms: String): Boolean =
        terms.any { text.contains(it) }
}
