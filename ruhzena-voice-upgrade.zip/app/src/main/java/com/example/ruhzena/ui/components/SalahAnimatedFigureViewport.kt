package com.example.ruhzena.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalRuhZenaPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Live 60fps Animated Articulated Salah & Wudu Posture Viewport.
 * Renders the unified 3D-shaded realistic human model in authentic modest Prayer attire
 * (Male: Crisp Ivory Thobe & Kufi; Female: Pearl-Silver Abaya & Khimar) with blank sculpted head
 * and precise Sunnah kinematics for every step (including releasing arms straight down at the
 * sides in Qawmah after Ruku for BOTH Male and Female).
 */
@Composable
fun SalahAnimatedFigureViewport(
    stepId: String,
    isWudu: Boolean,
    isFemale: Boolean,
    caption: String,
    height: Dp = 295.dp,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    var isPlaying by remember(stepId) { mutableStateOf(true) }
    var isSlowMotion by remember(stepId) { mutableStateOf(false) }
    var cycleTime by remember(stepId) { mutableFloatStateOf(0f) }

    LaunchedEffect(stepId, isPlaying, isSlowMotion) {
        if (!isPlaying) return@LaunchedEffect
        var lastNanos = 0L
        val speed = if (isSlowMotion) 0.48f else 1.0f
        while (isPlaying) {
            withFrameNanos { frameNanos ->
                if (lastNanos != 0L) {
                    val dt = ((frameNanos - lastNanos) / 1_000_000_000f).coerceAtMost(0.08f)
                    cycleTime = (cycleTime + dt * speed) % 5.2f
                }
                lastNanos = frameNanos
            }
        }
    }

    val floorYNorm = 0.84f
    val currentPose = remember(stepId, isFemale, cycleTime) {
        evaluateSalahOrWuduPose(
            stepId = stepId,
            isFemale = isFemale,
            cycleTime = cycleTime
        )
    }

    val stageGradient = if (palette.isLight) {
        listOf(Color(0xFFF3F5F8), Color(0xFFE4E8EF), Color(0xFFD7DCE5))
    } else {
        listOf(Color(0xFF1A1E26), Color(0xFF11141A), Color(0xFF0A0C10))
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.radialGradient(stageGradient))
            .border(1.dp, palette.borderAccent.copy(alpha = 0.58f), RoundedCornerShape(18.dp))
            .semantics { contentDescription = caption }
            .testTag("salah_animated_figure_viewport")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRealisticHumanFigure(
                pose = currentPose,
                floorYNorm = floorYNorm,
                wardrobe = FigureWardrobe.PRAYER,
                isFemale = isFemale,
                palette = palette,
                showMuscleFocus = false,
                showPrayerMat = !isWudu,
                showWaterEffect = isWudu,
                animTimeSec = cycleTime
            )
        }

        // Top-left live step posture label
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
                .background(palette.surfaceBg.copy(alpha = 0.86f), RoundedCornerShape(8.dp))
                .border(0.7.dp, palette.borderAccent.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(
                text = caption,
                style = MaterialTheme.typography.labelSmall,
                color = palette.gold,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Top-right attire / gender indicator
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp)
                .background(palette.surfaceBg.copy(alpha = 0.84f), RoundedCornerShape(8.dp))
                .border(0.6.dp, palette.borderNeutral, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = if (isFemale) "Modest Prayer Abaya" else "Thobe & Kufi",
                style = MaterialTheme.typography.labelSmall,
                color = palette.textSecondary
            )
        }

        // Bottom-right playback controls (Play/Pause + Slow-Motion 0.5x)
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { isSlowMotion = !isSlowMotion },
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        if (isSlowMotion) palette.accentContainer else palette.surfaceBg.copy(alpha = 0.86f),
                        CircleShape
                    )
                    .border(
                        0.8.dp,
                        if (isSlowMotion) palette.borderAccent else palette.borderNeutral,
                        CircleShape
                    )
                    .testTag("salah_slow_motion_button")
            ) {
                Icon(
                    imageVector = Icons.Default.SlowMotionVideo,
                    contentDescription = if (isSlowMotion) "Normal speed" else "Slow motion",
                    tint = if (isSlowMotion) palette.gold else palette.textSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
            IconButton(
                onClick = { isPlaying = !isPlaying },
                modifier = Modifier
                    .size(40.dp)
                    .background(palette.accentPrimary, CircleShape)
                    .testTag("salah_play_pause_button")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause posture motion" else "Play posture motion",
                    tint = palette.onAccent,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

private fun smoothEase(t: Float): Float {
    val c = t.coerceIn(0f, 1f)
    return ((1f - cos(c * PI)) * 0.5f).toFloat()
}

private fun evaluateSalahOrWuduPose(
    stepId: String,
    isFemale: Boolean,
    cycleTime: Float
): HumanRigPose {
    // Natural calm breathing pulse
    val breath = sin(cycleTime * 2.1f) * 0.0045f
    // Normalized transition progress (0 -> 1 over first 1.8s, hold 1.8s..4.0s, ease subtly)
    val tEnter = smoothEase(cycleTime / 1.75f)
    val tCycle = smoothEase(if (cycleTime < 2.6f) cycleTime / 2.2f else (5.2f - cycleTime) / 2.2f)

    return when (stepId) {
        // ---------------------------------------------------------------------
        // SALAH STEP 1: Takbiratul Ihram
        // Hands raise smoothly from sides with open palms facing Qibla (Right)
        // Male: hands raise up to earlobes; Female: hands raise to shoulder height
        // ---------------------------------------------------------------------
        "salah_step_1" -> {
            val start = standingArmsReleasedPose(isFemale, breath)
            val raised = takbirRaisedPose(isFemale, breath)
            val p = interpolateHumanPose(start, raised, tEnter)
            p.copy(palmsOpenQibla = tEnter > 0.35f)
        }

        // ---------------------------------------------------------------------
        // SALAH STEP 2: Qiyam (Standing — hands folded right over left)
        // Eyes lowered subtly toward Sujud spot
        // ---------------------------------------------------------------------
        "salah_step_2" -> {
            val fromTakbir = takbirRaisedPose(isFemale, breath)
            val qiyam = qiyamFoldedPose(isFemale, breath)
            interpolateHumanPose(fromTakbir, qiyam, smoothEase((cycleTime / 1.4f).coerceAtMost(1f)))
        }

        // ---------------------------------------------------------------------
        // SALAH STEP 3: Ruku (Bowing — smooth hinge to flat 90° horizontal tabletop back)
        // Hands firmly gripping knees; Male elbows bowed slightly out, Female compact
        // ---------------------------------------------------------------------
        "salah_step_3" -> {
            val fromQiyam = qiyamFoldedPose(isFemale, breath)
            val ruku = rukuBowingPose(isFemale, breath)
            interpolateHumanPose(fromQiyam, ruku, tEnter)
        }

        // ---------------------------------------------------------------------
        // SALAH STEP 4: Qawmah (Rising Upright From Ruku)
        // CRITICAL FIQH DETAIL: Rises from Ruku to calm upright standing with
        // BOTH ARMS COMPLETELY RELEASED STRAIGHT DOWN AT THE SIDES (NOT folded
        // back onto the chest!) — applied accurately for BOTH Male AND Female.
        // ---------------------------------------------------------------------
        "salah_step_4" -> {
            val fromRuku = rukuBowingPose(isFemale, breath)
            val uprightReleased = standingArmsReleasedPose(isFemale, breath)
            interpolateHumanPose(fromRuku, uprightReleased, tEnter)
        }

        // ---------------------------------------------------------------------
        // SALAH STEP 5: Sujud (7-Point Prostration on Prayer Mat)
        // Forehead+nose, 2 palms, 2 knees, toes of both feet on mat.
        // Male: elbows lifted off ground & away from ribs; Female: compact modest posture
        // ---------------------------------------------------------------------
        "salah_step_5" -> {
            val kneelingDescent = jalsaSeatedPose(isFemale, breath)
            val sujud = sujudProstrationPose(isFemale, breath)
            interpolateHumanPose(kneelingDescent, sujud, tEnter).copy(isProstrating = tEnter > 0.45f)
        }

        // ---------------------------------------------------------------------
        // SALAH STEP 6: Jalsa (Brief Sitting Between Two Sujud)
        // Rises calmly from Sujud to upright sitting with flat palms on thighs
        // ---------------------------------------------------------------------
        "salah_step_6" -> {
            val fromSujud = sujudProstrationPose(isFemale, breath)
            val jalsa = jalsaSeatedPose(isFemale, breath)
            interpolateHumanPose(fromSujud, jalsa, tEnter)
        }

        // ---------------------------------------------------------------------
        // SALAH STEP 7: Tashahhud & Durood Ibrahim
        // Calm upright sitting with RIGHT INDEX FINGER CLEARLY RAISED during Shahadah
        // ---------------------------------------------------------------------
        "salah_step_7" -> {
            val base = jalsaSeatedPose(isFemale, breath)
            base.copy(
                nearHand = Offset(base.nearWrist.x + 0.032f, base.nearWrist.y - 0.004f),
                indexFingerRaised = true,
                headPitchDeg = 14f
            )
        }

        // ---------------------------------------------------------------------
        // SALAH STEP 8: Taslim (Concluding Salam — Head smoothly turns RIGHT then LEFT)
        // ---------------------------------------------------------------------
        "salah_step_8" -> {
            val base = jalsaSeatedPose(isFemale, breath)
            val yaw = when {
                cycleTime < 1.3f -> lerpFloat(0f, 55f, smoothEase(cycleTime / 1.1f))
                cycleTime < 2.2f -> 55f
                cycleTime < 3.6f -> lerpFloat(55f, -55f, smoothEase((cycleTime - 2.2f) / 1.2f))
                cycleTime < 4.5f -> -55f
                else -> lerpFloat(-55f, 0f, smoothEase((cycleTime - 4.5f) / 0.7f))
            }
            base.copy(headYawDeg = yaw, headPitchDeg = 4f)
        }

        // ---------------------------------------------------------------------
        // WUDU STEPS 1–4: Animated purification postures with flowing water droplets
        // ---------------------------------------------------------------------
        "wudu_step_1" -> wuduWashingHandsPose(isFemale, tCycle, breath)
        "wudu_step_2" -> wuduWashingFacePose(isFemale, tCycle, breath)
        "wudu_step_3" -> wuduWashingArmsPose(isFemale, tCycle, breath)
        "wudu_step_4" -> wuduAfterDuaPose(isFemale, tEnter, breath)
        else -> standingArmsReleasedPose(isFemale, breath)
    }
}

/**
 * Upright standing with BOTH ARMS RELEASED NATURALLY STRAIGHT DOWN AT THE SIDES.
 * Used as the starting pose before Takbir AND as the final Qawmah posture after rising from Ruku
 * (never folding arms back on chest after Ruku — for BOTH Male and Female!).
 */
private fun standingArmsReleasedPose(isFemale: Boolean, breath: Float): HumanRigPose {
    val cx = 0.48f
    val shoulderDrop = if (isFemale) 0.01f else 0f
    return HumanRigPose(
        head = Offset(cx + 0.012f, 0.165f + breath),
        neck = Offset(cx + 0.005f, 0.235f + breath),
        chest = Offset(cx + 0.006f, 0.300f + shoulderDrop + breath),
        waist = Offset(cx + 0.002f, 0.420f + breath * 0.5f),
        pelvis = Offset(cx, 0.505f),
        // Near arm relaxed straight down along side of thigh
        nearShoulder = Offset(cx - 0.015f, 0.285f + shoulderDrop + breath),
        nearElbow = Offset(cx - 0.018f, 0.425f + breath * 0.5f),
        nearWrist = Offset(cx - 0.008f, 0.555f),
        nearHand = Offset(cx - 0.002f, 0.598f),
        // Far arm relaxed straight down along opposite side
        farShoulder = Offset(cx + 0.025f, 0.285f + shoulderDrop + breath),
        farElbow = Offset(cx + 0.028f, 0.422f + breath * 0.5f),
        farWrist = Offset(cx + 0.036f, 0.550f),
        farHand = Offset(cx + 0.040f, 0.592f),
        // Legs standing steady, facing right (Qibla)
        nearHip = Offset(cx - 0.008f, 0.510f),
        nearKnee = Offset(cx + 0.002f, 0.675f),
        nearAnkle = Offset(cx - 0.004f, 0.822f),
        nearFoot = Offset(cx + 0.055f, 0.834f),
        farHip = Offset(cx + 0.018f, 0.508f),
        farKnee = Offset(cx + 0.026f, 0.672f),
        farAnkle = Offset(cx + 0.020f, 0.818f),
        farFoot = Offset(cx + 0.076f, 0.830f),
        headPitchDeg = 12f
    )
}

/**
 * Takbiratul Ihram: Open palms raised facing Qibla (Right).
 * Male raises to earlobes (y ~ 0.19f); Female raises to shoulder level (y ~ 0.26f).
 */
private fun takbirRaisedPose(isFemale: Boolean, breath: Float): HumanRigPose {
    val base = standingArmsReleasedPose(isFemale, breath)
    val handY = if (isFemale) 0.258f else 0.188f
    val elbowY = if (isFemale) 0.360f else 0.325f
    return base.copy(
        nearElbow = Offset(0.510f, elbowY + breath),
        nearWrist = Offset(0.545f, handY + 0.032f + breath),
        nearHand = Offset(0.555f, handY + breath),
        farElbow = Offset(0.545f, elbowY - 0.008f + breath),
        farWrist = Offset(0.578f, handY + 0.024f + breath),
        farHand = Offset(0.588f, handY - 0.008f + breath),
        palmsOpenQibla = true,
        headPitchDeg = 10f
    )
}

/**
 * Qiyam (Standing): Calm upright posture with right hand placed gracefully over left hand.
 */
private fun qiyamFoldedPose(isFemale: Boolean, breath: Float): HumanRigPose {
    val base = standingArmsReleasedPose(isFemale, breath)
    // Chest/upper-mid torso folding height (female slightly higher/compact on chest)
    val handY = if (isFemale) 0.355f else 0.388f
    val elbowX = if (isFemale) 0.455f else 0.448f
    return base.copy(
        nearElbow = Offset(elbowX, handY + 0.022f + breath),
        nearWrist = Offset(0.530f, handY + breath),
        nearHand = Offset(0.558f, handY - 0.004f + breath),
        farElbow = Offset(0.495f, handY + 0.016f + breath),
        farWrist = Offset(0.548f, handY - 0.004f + breath),
        farHand = Offset(0.562f, handY - 0.006f + breath),
        headPitchDeg = 16f
    )
}

/**
 * Ruku (Bowing): Exact 90° flat horizontal tabletop back, head aligned with spine,
 * hands firmly gripping knees. Male keeps elbows slightly bowed out; Female keeps arms closer.
 */
private fun rukuBowingPose(isFemale: Boolean, breath: Float): HumanRigPose {
    val hipX = 0.38f
    val hipY = 0.505f
    val backY = 0.478f + breath
    val elbowSpread = if (isFemale) 0.0f else 0.016f
    return HumanRigPose(
        head = Offset(0.688f, backY + 0.006f),
        neck = Offset(0.625f, backY + 0.004f),
        chest = Offset(0.560f, backY + 0.006f),
        waist = Offset(0.465f, backY + 0.014f),
        pelvis = Offset(hipX, hipY),
        // Straight arms down gripping knees
        nearShoulder = Offset(0.568f, backY + 0.020f),
        nearElbow = Offset(0.532f - elbowSpread, 0.592f),
        nearWrist = Offset(0.445f, 0.668f),
        nearHand = Offset(0.428f, 0.682f),
        farShoulder = Offset(0.588f, backY + 0.014f),
        farElbow = Offset(0.558f + elbowSpread * 0.5f, 0.585f),
        farWrist = Offset(0.472f, 0.662f),
        farHand = Offset(0.455f, 0.676f),
        // Legs vertical & firm
        nearHip = Offset(hipX, hipY + 0.006f),
        nearKnee = Offset(0.415f, 0.674f),
        nearAnkle = Offset(0.398f, 0.822f),
        nearFoot = Offset(0.456f, 0.834f),
        farHip = Offset(hipX + 0.024f, hipY),
        farKnee = Offset(0.440f, 0.670f),
        farAnkle = Offset(0.422f, 0.818f),
        farFoot = Offset(0.478f, 0.830f),
        headPitchDeg = 22f
    )
}

/**
 * Sujud (7-Point Prostration on Prayer Mat):
 * Forehead + nose, both palms flat beside head/shoulders, both knees, toes tucked facing Qibla.
 * Male lifts elbows clearly off the floor; Female maintains a compact modest posture.
 */
private fun sujudProstrationPose(isFemale: Boolean, breath: Float): HumanRigPose {
    val elbowY = if (isFemale) 0.772f else 0.715f
    val hipY = if (isFemale) 0.642f else 0.585f
    return HumanRigPose(
        head = Offset(0.715f, 0.785f),
        neck = Offset(0.650f, 0.742f + breath),
        chest = Offset(0.580f, 0.705f + breath),
        waist = Offset(0.495f, 0.640f + breath),
        pelvis = Offset(0.415f, hipY + breath),
        // Palms flat on mat parallel to head/ears; Male elbows lifted, Female compact
        nearShoulder = Offset(0.592f, 0.712f + breath),
        nearElbow = Offset(0.608f, elbowY),
        nearWrist = Offset(0.678f, 0.822f),
        nearHand = Offset(0.718f, 0.826f),
        farShoulder = Offset(0.612f, 0.702f + breath),
        farElbow = Offset(0.635f, elbowY - 0.008f),
        farWrist = Offset(0.702f, 0.816f),
        farHand = Offset(0.742f, 0.820f),
        // Knees grounded, shins angled back, toes planted facing Qibla
        nearHip = Offset(0.410f, hipY + 0.012f),
        nearKnee = Offset(0.468f, 0.822f),
        nearAnkle = Offset(0.322f, 0.805f),
        nearFoot = Offset(0.305f, 0.834f),
        farHip = Offset(0.432f, hipY + 0.004f),
        farKnee = Offset(0.490f, 0.816f),
        farAnkle = Offset(0.344f, 0.798f),
        farFoot = Offset(0.328f, 0.828f),
        headPitchDeg = 35f,
        isProstrating = true
    )
}

/**
 * Jalsa / Tashahhud / Taslim (Calm Seated Posture on Prayer Mat):
 * Upright torso, resting gracefully on folded legs, palms resting gently on thighs.
 */
private fun jalsaSeatedPose(isFemale: Boolean, breath: Float): HumanRigPose {
    val cx = 0.42f
    return HumanRigPose(
        head = Offset(cx + 0.015f, 0.352f + breath),
        neck = Offset(cx + 0.006f, 0.422f + breath),
        chest = Offset(cx + 0.008f, 0.488f + breath),
        waist = Offset(cx + 0.002f, 0.605f + breath * 0.5f),
        pelvis = Offset(cx - 0.005f, 0.715f),
        // Hands resting peacefully on knees/thighs
        nearShoulder = Offset(cx - 0.008f, 0.478f + breath),
        nearElbow = Offset(cx + 0.018f, 0.618f + breath * 0.4f),
        nearWrist = Offset(0.548f, 0.712f),
        nearHand = Offset(0.585f, 0.722f),
        farShoulder = Offset(cx + 0.024f, 0.474f + breath),
        farElbow = Offset(cx + 0.048f, 0.612f + breath * 0.4f),
        farWrist = Offset(0.572f, 0.706f),
        farHand = Offset(0.606f, 0.716f),
        // Folded legs resting flat on the prayer mat
        nearHip = Offset(cx, 0.725f),
        nearKnee = Offset(0.585f, 0.805f),
        nearAnkle = Offset(0.395f, 0.820f),
        nearFoot = Offset(0.348f, 0.828f),
        farHip = Offset(cx + 0.022f, 0.718f),
        farKnee = Offset(0.606f, 0.798f),
        farAnkle = Offset(0.415f, 0.812f),
        farFoot = Offset(0.372f, 0.822f),
        headPitchDeg = 12f,
        isSeatedOrKneeling = true
    )
}

private fun wuduWashingHandsPose(isFemale: Boolean, tCycle: Float, breath: Float): HumanRigPose {
    val base = standingArmsReleasedPose(isFemale, breath)
    val rubShift = sin(tCycle * PI * 2.0).toFloat() * 0.016f
    return base.copy(
        nearElbow = Offset(0.495f, 0.432f + breath),
        nearWrist = Offset(0.585f + rubShift, 0.455f),
        nearHand = Offset(0.620f + rubShift, 0.460f),
        farElbow = Offset(0.520f, 0.425f + breath),
        farWrist = Offset(0.602f - rubShift, 0.448f),
        farHand = Offset(0.630f - rubShift, 0.455f),
        waterFlowTarget = Offset(0.620f, 0.458f),
        headPitchDeg = 20f
    )
}

private fun wuduWashingFacePose(isFemale: Boolean, tCycle: Float, breath: Float): HumanRigPose {
    val base = standingArmsReleasedPose(isFemale, breath)
    val lift = tCycle
    val wristY = lerpFloat(0.410f, 0.215f, lift)
    val handY = lerpFloat(0.400f, 0.185f, lift)
    return base.copy(
        nearElbow = Offset(0.525f, lerpFloat(0.435f, 0.345f, lift)),
        nearWrist = Offset(0.562f, wristY),
        nearHand = Offset(0.535f, handY),
        farElbow = Offset(0.548f, lerpFloat(0.428f, 0.338f, lift)),
        farWrist = Offset(0.582f, wristY - 0.008f),
        farHand = Offset(0.555f, handY - 0.008f),
        waterFlowTarget = Offset(0.532f, 0.195f),
        headPitchDeg = 8f
    )
}

private fun wuduWashingArmsPose(isFemale: Boolean, tCycle: Float, breath: Float): HumanRigPose {
    val base = standingArmsReleasedPose(isFemale, breath)
    val scrubX = lerpFloat(0.530f, 0.615f, tCycle)
    return base.copy(
        nearElbow = Offset(0.520f, 0.415f + breath),
        nearWrist = Offset(0.625f, 0.425f),
        nearHand = Offset(0.660f, 0.428f),
        farElbow = Offset(0.505f, 0.398f + breath),
        farWrist = Offset(scrubX, 0.412f),
        farHand = Offset(scrubX + 0.025f, 0.416f),
        waterFlowTarget = Offset(scrubX + 0.015f, 0.418f),
        headPitchDeg = 18f
    )
}

private fun wuduAfterDuaPose(isFemale: Boolean, tEnter: Float, breath: Float): HumanRigPose {
    val base = standingArmsReleasedPose(isFemale, breath)
    val raised = base.copy(
        nearElbow = Offset(0.505f, 0.410f + breath),
        nearWrist = Offset(0.585f, 0.345f + breath),
        nearHand = Offset(0.618f, 0.328f + breath),
        farElbow = Offset(0.530f, 0.402f + breath),
        farWrist = Offset(0.608f, 0.338f + breath),
        farHand = Offset(0.638f, 0.322f + breath),
        palmsOpenQibla = true,
        headPitchDeg = -6f
    )
    return interpolateHumanPose(base, raised, tEnter)
}
