package com.example.ruhzena.data.local

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Serializable
data class RuhZenaBackupBundle(
    val formatVersion: Int = 1,
    val exportedAtMillis: Long = System.currentTimeMillis(),
    val preferences: UserPreferences,
    val waterLogs: List<WaterLogEntity> = emptyList(),
    val mealLogs: List<MealLogEntity> = emptyList(),
    val sleepLogs: List<SleepLogEntity> = emptyList(),
    val workoutLogs: List<WorkoutLogEntity> = emptyList(),
    val habits: List<HabitEntity> = emptyList(),
    val habitChecks: List<HabitCheckEntity> = emptyList(),
    val journalEntries: List<JournalEntryEntity> = emptyList(),
    val bookmarks: List<BookmarkEntity> = emptyList()
)

data class BackupRestoreSummary(
    val habitsRestored: Int,
    val journalRestored: Int,
    val wellnessLogsRestored: Int,
    val bookmarksRestored: Int
)

class RuhZenaDataRepository(private val db: RuhZenaDatabase) {

    private val backupJson = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun todayDateKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun dateKeyDaysAgo(daysAgo: Int): String {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, -daysAgo)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    // Water
    fun observeWaterLogsToday(): Flow<List<WaterLogEntity>> =
        db.waterLogDao().getLogsForDate(todayDateKey())

    fun observeWaterLogsLast7Days(): Flow<List<WaterLogEntity>> =
        db.waterLogDao().getLogsSince(dateKeyDaysAgo(6))

    fun observeWaterLogsLast30Days(): Flow<List<WaterLogEntity>> =
        db.waterLogDao().getLogsSince(dateKeyDaysAgo(29))

    fun observeWaterMlToday(): Flow<Int> =
        db.waterLogDao().getTotalMlForDate(todayDateKey())

    suspend fun getWaterMlTodaySnapshot(): Int =
        db.waterLogDao().getTotalMlForDateSnapshot(todayDateKey())

    suspend fun addWater(amountMl: Int) {
        db.waterLogDao().insert(WaterLogEntity(amountMl = amountMl, dateKey = todayDateKey()))
    }

    suspend fun deleteWaterLog(id: Long) = db.waterLogDao().deleteById(id)

    // Meals
    fun observeMealsToday(): Flow<List<MealLogEntity>> =
        db.mealLogDao().getMealsForDate(todayDateKey())

    fun observeMealsLast7Days(): Flow<List<MealLogEntity>> =
        db.mealLogDao().getMealsSince(dateKeyDaysAgo(6))

    fun observeMealsLast30Days(): Flow<List<MealLogEntity>> =
        db.mealLogDao().getMealsSince(dateKeyDaysAgo(29))

    suspend fun addMeal(meal: MealLogEntity) = db.mealLogDao().insert(meal)

    suspend fun deleteMeal(id: Long) = db.mealLogDao().deleteById(id)

    // Sleep
    fun observeSleepLogs(): Flow<List<SleepLogEntity>> =
        db.sleepLogDao().getRecentSleepLogs()

    suspend fun addSleepLog(log: SleepLogEntity) = db.sleepLogDao().insert(log)

    suspend fun deleteSleepLog(id: Long) = db.sleepLogDao().deleteById(id)

    // Workouts
    fun observeRecentWorkouts(): Flow<List<WorkoutLogEntity>> =
        db.workoutLogDao().getRecentWorkouts()

    fun observeWorkoutsLast7Days(): Flow<List<WorkoutLogEntity>> =
        db.workoutLogDao().getWorkoutsSince(dateKeyDaysAgo(6))

    fun observeWorkoutsLast30Days(): Flow<List<WorkoutLogEntity>> =
        db.workoutLogDao().getWorkoutsSince(dateKeyDaysAgo(29))

    fun observeWorkoutsTodayCount(): Flow<Int> =
        db.workoutLogDao().getWorkoutCountForDate(todayDateKey())

    suspend fun logWorkout(routineTitle: String, exercises: Int, durationMinutes: Int, calories: Int) {
        db.workoutLogDao().insert(
            WorkoutLogEntity(
                routineTitle = routineTitle,
                exercisesCompleted = exercises,
                durationMinutes = durationMinutes,
                estimatedCalories = calories,
                dateKey = todayDateKey()
            )
        )
    }

    // Habits
    fun observeHabits(): Flow<List<HabitEntity>> = db.habitDao().getAllHabits()

    fun observeHabitChecksToday(): Flow<List<HabitCheckEntity>> =
        db.habitDao().getChecksForDate(todayDateKey())

    fun observeHabitChecksLast30Days(): Flow<List<HabitCheckEntity>> =
        db.habitDao().getChecksSince(dateKeyDaysAgo(29))

    suspend fun seedStarterHabitsIfEmpty(current: List<HabitEntity>) {
        if (current.isNotEmpty()) return
        val starters = listOf(
            HabitEntity(title = "Pray 5 Daily Prayers on Time", category = "Spirituality", reminderEnabled = true, reminderTime = "05:15"),
            HabitEntity(title = "Read 10 Minutes of Quran", category = "Spirituality", reminderEnabled = true, reminderTime = "06:00"),
            HabitEntity(title = "Drink Daily Water Goal", category = "Health", reminderEnabled = true, reminderTime = "10:00"),
            HabitEntity(title = "20-Min Mobility or Strength", category = "Health", reminderEnabled = false, reminderTime = "17:30")
        )
        starters.forEach { db.habitDao().insertHabit(it) }
    }

    suspend fun addHabit(title: String, category: String, reminderEnabled: Boolean, reminderTime: String) {
        db.habitDao().insertHabit(
            HabitEntity(
                title = title,
                category = category,
                reminderEnabled = reminderEnabled,
                reminderTime = reminderTime
            )
        )
    }

    suspend fun toggleHabitToday(habit: HabitEntity, currentlyCompleted: Boolean) {
        val today = todayDateKey()
        if (currentlyCompleted) {
            db.habitDao().removeCheck(habit.id, today)
            val newStreak = (habit.currentStreak - 1).coerceAtLeast(0)
            db.habitDao().updateHabit(habit.copy(currentStreak = newStreak))
        } else {
            db.habitDao().insertCheck(HabitCheckEntity(habitId = habit.id, dateKey = today))
            val newStreak = if (habit.lastCompletedDate == today) habit.currentStreak else habit.currentStreak + 1
            val best = maxOf(habit.bestStreak, newStreak)
            db.habitDao().updateHabit(
                habit.copy(
                    currentStreak = newStreak,
                    bestStreak = best,
                    lastCompletedDate = today
                )
            )
        }
    }

    suspend fun saveHabitRecovery(habit: HabitEntity, note: String) {
        db.habitDao().updateHabit(habit.copy(recoveryNote = note))
    }

    suspend fun deleteHabit(id: Long) = db.habitDao().deleteHabit(id)

    // Journal
    fun observeJournalEntries(): Flow<List<JournalEntryEntity>> = db.journalDao().getAllEntries()

    suspend fun addJournalEntry(title: String, content: String, mood: String, achievement: String) {
        db.journalDao().insert(
            JournalEntryEntity(
                title = title,
                content = content,
                mood = mood,
                achievement = achievement,
                dateKey = todayDateKey()
            )
        )
    }

    suspend fun deleteJournalEntry(id: Long) = db.journalDao().deleteById(id)

    suspend fun exportJournalAsJson(): String {
        val entries = db.journalDao().getAllEntriesSnapshot()
        return backupJson.encodeToString(entries)
    }

    // Full App Backup & Restore
    suspend fun exportFullBackupJson(prefs: UserPreferences): String {
        val bundle = RuhZenaBackupBundle(
            preferences = prefs,
            waterLogs = db.waterLogDao().getAllSnapshot(),
            mealLogs = db.mealLogDao().getAllSnapshot(),
            sleepLogs = db.sleepLogDao().getAllSnapshot(),
            workoutLogs = db.workoutLogDao().getAllSnapshot(),
            habits = db.habitDao().getAllHabitsSnapshot(),
            habitChecks = db.habitDao().getAllChecksSnapshot(),
            journalEntries = db.journalDao().getAllEntriesSnapshot(),
            bookmarks = db.bookmarkDao().getAllSnapshot()
        )
        return backupJson.encodeToString(bundle)
    }

    suspend fun importFullBackupJson(
        rawJson: String,
        prefsRepo: UserPreferencesRepository
    ): Result<BackupRestoreSummary> = runCatching {
        val bundle = backupJson.decodeFromString<RuhZenaBackupBundle>(rawJson)
        db.withTransaction {
            db.waterLogDao().deleteAll()
            db.mealLogDao().deleteAll()
            db.sleepLogDao().deleteAll()
            db.workoutLogDao().deleteAll()
            db.habitDao().deleteAllChecks()
            db.habitDao().deleteAllHabits()
            db.journalDao().deleteAll()
            db.bookmarkDao().deleteAll()

            if (bundle.waterLogs.isNotEmpty()) db.waterLogDao().insertAll(bundle.waterLogs)
            if (bundle.mealLogs.isNotEmpty()) db.mealLogDao().insertAll(bundle.mealLogs)
            if (bundle.sleepLogs.isNotEmpty()) db.sleepLogDao().insertAll(bundle.sleepLogs)
            if (bundle.workoutLogs.isNotEmpty()) db.workoutLogDao().insertAll(bundle.workoutLogs)
            if (bundle.habits.isNotEmpty()) db.habitDao().insertHabits(bundle.habits)
            if (bundle.habitChecks.isNotEmpty()) db.habitDao().insertChecks(bundle.habitChecks)
            if (bundle.journalEntries.isNotEmpty()) db.journalDao().insertAll(bundle.journalEntries)
            if (bundle.bookmarks.isNotEmpty()) db.bookmarkDao().insertAll(bundle.bookmarks)
        }
        prefsRepo.restoreFromBackup(bundle.preferences.copy(onboardingCompleted = true))
        BackupRestoreSummary(
            habitsRestored = bundle.habits.size,
            journalRestored = bundle.journalEntries.size,
            wellnessLogsRestored = bundle.waterLogs.size + bundle.mealLogs.size + bundle.sleepLogs.size + bundle.workoutLogs.size,
            bookmarksRestored = bundle.bookmarks.size
        )
    }

    // Bookmarks
    fun observeBookmarks(): Flow<List<BookmarkEntity>> = db.bookmarkDao().getAllBookmarks()

    suspend fun toggleBookmark(bookmark: BookmarkEntity, currentlySaved: Boolean) {
        if (currentlySaved) {
            db.bookmarkDao().deleteByKey(bookmark.key)
        } else {
            db.bookmarkDao().insert(bookmark)
        }
    }

    // AI Messages (Unified + Legacy Mode Support)
    fun observeAllAiMessages(): Flow<List<AiMessageEntity>> =
        db.aiMessageDao().getAllMessages()

    suspend fun getAllAiMessagesSnapshot(): List<AiMessageEntity> =
        db.aiMessageDao().getAllMessagesSnapshot()

    fun observeAiMessages(mode: String): Flow<List<AiMessageEntity>> =
        db.aiMessageDao().getMessagesForMode(mode)

    suspend fun saveAiMessage(message: AiMessageEntity): Long = db.aiMessageDao().insert(message)

    suspend fun clearAiHistory(mode: String) = db.aiMessageDao().clearModeHistory(mode)

    suspend fun clearAllAiHistory() {
        db.withTransaction {
            db.aiMessageDao().clearAllHistory()
            db.aiConversationSummaryDao().clearAll()
        }
    }

    // Persistent AI Long-Term Memories (User-Approved)
    fun observeAiMemories(): Flow<List<AiMemoryEntity>> = db.aiMemoryDao().getAllMemories()

    suspend fun getActiveApprovedMemoriesSnapshot(): List<AiMemoryEntity> =
        db.aiMemoryDao().getActiveApprovedMemoriesSnapshot()

    suspend fun saveAiMemory(memory: AiMemoryEntity): Long = db.aiMemoryDao().insert(memory)

    suspend fun updateAiMemory(memory: AiMemoryEntity) = db.aiMemoryDao().update(memory)

    suspend fun deleteAiMemory(id: Long) = db.aiMemoryDao().deleteById(id)

    suspend fun clearAllAiMemories() = db.aiMemoryDao().clearAll()

    // Rolling Conversation Summary
    fun observeConversationSummary(sessionId: String = "unified"): Flow<AiConversationSummaryEntity?> =
        db.aiConversationSummaryDao().observeSummary(sessionId)

    suspend fun getConversationSummary(sessionId: String = "unified"): AiConversationSummaryEntity? =
        db.aiConversationSummaryDao().getSummary(sessionId)

    suspend fun upsertConversationSummary(summary: AiConversationSummaryEntity) =
        db.aiConversationSummaryDao().upsert(summary)

    // Persistent Multi-Step Agent Task State
    fun observeAiTasks(): Flow<List<AiTaskStateEntity>> = db.aiTaskStateDao().observeAllTasks()

    fun observeActiveAiTask(): Flow<AiTaskStateEntity?> = db.aiTaskStateDao().observeActiveTask()

    suspend fun getActiveAiTaskSnapshot(): AiTaskStateEntity? = db.aiTaskStateDao().getActiveTaskSnapshot()

    suspend fun upsertAiTask(task: AiTaskStateEntity): Long = db.aiTaskStateDao().upsert(task)

    suspend fun updateAiTaskStatus(id: Long, status: String) = db.aiTaskStateDao().updateStatus(id, status)

    suspend fun deleteAiTask(id: Long) = db.aiTaskStateDao().deleteById(id)

    // Persisted Provider Health & Cooldowns
    fun observeProviderHealth(): Flow<List<AiProviderHealthEntity>> =
        db.aiProviderHealthDao().observeAllHealth()

    suspend fun getProviderHealthSnapshot(): List<AiProviderHealthEntity> =
        db.aiProviderHealthDao().getAllHealthSnapshot()

    suspend fun upsertProviderHealth(entity: AiProviderHealthEntity) =
        db.aiProviderHealthDao().upsert(entity)

    suspend fun clearProviderHealth() = db.aiProviderHealthDao().clearAll()

    suspend fun clearJournalEntries() = db.journalDao().deleteAll()

    suspend fun clearHabitsAndChecks() {
        db.withTransaction {
            db.habitDao().deleteAllChecks()
            db.habitDao().deleteAllHabits()
        }
    }

    suspend fun clearWellnessLogs() {
        db.withTransaction {
            db.waterLogDao().deleteAll()
            db.mealLogDao().deleteAll()
            db.sleepLogDao().deleteAll()
            db.workoutLogDao().deleteAll()
        }
    }

    suspend fun clearAllUserData() {
        db.withTransaction {
            db.waterLogDao().deleteAll()
            db.mealLogDao().deleteAll()
            db.sleepLogDao().deleteAll()
            db.workoutLogDao().deleteAll()
            db.habitDao().deleteAllChecks()
            db.habitDao().deleteAllHabits()
            db.journalDao().deleteAll()
            db.bookmarkDao().deleteAll()
            db.aiMessageDao().clearAllHistory()
            db.aiMemoryDao().clearAll()
            db.aiConversationSummaryDao().clearAll()
            db.aiTaskStateDao().clearAll()
            db.aiProviderHealthDao().clearAll()
        }
    }
}

