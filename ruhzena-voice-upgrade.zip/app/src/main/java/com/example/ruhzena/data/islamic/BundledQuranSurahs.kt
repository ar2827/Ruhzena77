package com.example.ruhzena.data.islamic

object BanglaPhoneticConverter {
    /**
     * Converts standard Latin Quran transliteration into readable Bangla phonetic reading aid
     * when a Surah is downloaded dynamically from verified Quran datasets.
     */
    fun toBanglaPhonetic(latin: String): String {
        if (latin.isBlank()) return ""
        val normalized = latin
            .replace("'", "আ")
            .replace("’", "আ")
            .replace("dh", "য")
            .replace("Dh", "য")
            .replace("th", "ছ")
            .replace("Th", "ছ")
            .replace("kh", "খ")
            .replace("Kh", "খ")
            .replace("gh", "গ")
            .replace("Gh", "গ")
            .replace("sh", "শ")
            .replace("Sh", "শ")
            .replace("aa", "আ")
            .replace("ee", "ঈ")
            .replace("oo", "ঊ")
            .replace("ai", "আই")
            .replace("aw", "আও")
            .replace("ay", "আই")

        val sb = StringBuilder()
        var i = 0
        while (i < normalized.length) {
            val ch = normalized[i]
            val lower = ch.lowercaseChar()
            val mapped = when (lower) {
                'a' -> "আ"
                'b' -> "ব"
                'c' -> "স"
                'd' -> "দ"
                'e' -> "এ"
                'f' -> "ফ"
                'g' -> "গ"
                'h' -> "হ"
                'i' -> "ই"
                'j' -> "জ"
                'k' -> "ক"
                'l' -> "ল"
                'm' -> "ম"
                'n' -> "ন"
                'o' -> "ও"
                'p' -> "প"
                'q' -> "ক্ব"
                'r' -> "র"
                's' -> "স"
                't' -> "ত"
                'u' -> "উ"
                'v' -> "ভ"
                'w' -> "ওয়া"
                'y' -> "ইয়"
                'z' -> "য"
                else -> ch.toString()
            }
            sb.append(mapped)
            i++
        }
        return sb.toString()
    }
}

object BundledQuranSurahs {
    private val map: Map<Int, List<QuranAyah>> = mapOf(
        1 to listOf(
            QuranAyah(1, 1, 1, "بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ", "In the name of Allah, the Entirely Merciful, the Especially Merciful.", "পরম করুণাময় অসীম দয়ালু আল্লাহর নামে শুরু করছি।", "Bismillāhir-Raḥmānir-Raḥīm", "বিসমিল্লাহির রাহমানির রাহীম"),
            QuranAyah(1, 2, 2, "ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَـٰلَمِينَ", "All praise is due to Allah, Lord of the worlds.", "সমস্ত প্রশংসা জগতসমূহের প্রতিপালক আল্লাহর জন্য।", "Al-ḥamdu lillāhi Rabbil-'ālamīn", "আলহামদু লিল্লাহি রাব্বিল আলামীন"),
            QuranAyah(1, 3, 3, "ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ", "The Entirely Merciful, the Especially Merciful.", "পরম করুণাময়, অসীম দয়ালু।", "Ar-Raḥmānir-Raḥīm", "আর-রাহমানির রাহীম"),
            QuranAyah(1, 4, 4, "مَـٰلِكِ يَوْمِ ٱلدِّينِ", "Sovereign of the Day of Recompense.", "প্রতিদান দিবসের মালিক।", "Māliki yawmid-dīn", "মালিকি ইয়াওমিদ্দীন"),
            QuranAyah(1, 5, 5, "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", "It is You we worship and You we ask for help.", "আমরা কেবল আপনারই ইবাদত করি এবং আপনারই সাহায্য চাই।", "Iyyāka na'budu wa iyyāka nasta'īn", "ইয়্যাকা না'বুদু ওয়া ইয়্যাকা নাস্তাঈন"),
            QuranAyah(1, 6, 6, "ٱهْدِنَا ٱلصِّرَٰطَ ٱلْمُسْتَقِيمَ", "Guide us to the straight path.", "আমাদেরকে সরল পথ প্রদর্শন করুন।", "Ihdinaṣ-ṣirāṭal-mustaqīm", "ইহদিনাস সিরাতাল মুস্তাক্বীম"),
            QuranAyah(1, 7, 7, "صِرَٰطَ ٱلَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ ٱلْمَغْضُوبِ عَلَيْهِمْ وَلَا ٱلضَّآلِّينَ", "The path of those upon whom You have bestowed favor, not of those who have evoked anger or of those who are astray.", "তাদের পথ, যাদের আপনি অনুগ্রহ করেছেন; তাদের নয় যারা ক্রোধের শিকার ও পথভ্রষ্ট হয়েছে।", "Ṣirāṭallaḏīna an'amta 'alayhim ġayril-maġḍūbi 'alayhim wa laḍ-ḍāllīn", "সিরাতাল্লাযীনা আনআমতা আলাইহিম গাইরিল মাগদূবি আলাইহিম ওয়ালাদ দ্বাল্লীন")
        ),
        97 to listOf(
            QuranAyah(97, 1, 6126, "إِنَّآ أَنزَلْنَـٰهُ فِى لَيْلَةِ ٱلْقَدْرِ", "Indeed, We sent the Qur'an down during the Night of Decree.", "নিশ্চয়ই আমি এটি নাযিল করেছি কদরের রজনীতে।", "Innā anzalnāhu fī laylatil-qadr", "ইন্না আনযালনাহু ফী লাইলাতিল ক্বাদর"),
            QuranAyah(97, 2, 6127, "وَمَآ أَدْرَىٰكَ مَا لَيْلَةُ ٱلْقَدْرِ", "And what can make you know what is the Night of Decree?", "আর আপনি কি জানেন কদরের রজনী কী?", "Wa mā adrāka mā laylatul-qadr", "ওয়ামা আদরাকা মা লাইলাতুল ক্বাদর"),
            QuranAyah(97, 3, 6128, "لَيْلَةُ ٱلْقَدْرِ خَيْرٌ مِّنْ أَلْفِ شَهْرٍ", "The Night of Decree is better than a thousand months.", "কদরের রজনী হাজার মাসের চেয়েও উত্তম।", "Laylatul-qadri khayrum min alfi shahr", "লাইলাতুল ক্বাদরি খাইরুম মিন আলফি শাহর"),
            QuranAyah(97, 4, 6129, "تَنَزَّلُ ٱلْمَلَـٰٓئِكَةُ وَٱلرُّوحُ فِيهَا بِإِذْنِ رَبِّهِم مِّن كُلِّ أَمْرٍ", "The angels and the Spirit descend therein by permission of their Lord for every matter.", "সে রাতে ফেরেশতারা ও রূহ তাদের প্রতিপালকের অনুমতিক্রমে প্রতিটি সিদ্ধান্ত নিয়ে অবতরণ করেন।", "Tanazzalul-malā'ikatu war-rūḥu fīhā bi-idhni rabbihim min kulli amr", "তানাযযালুল মালাইকাতু ওয়ার-রূহু ফীহা বিইযনি রাব্বিহিম মিন কুল্লি আমর"),
            QuranAyah(97, 5, 6130, "سَلَـٰمٌ هِىَ حَتَّىٰ مَطْلَعِ ٱلْفَجْرِ", "Peace it is until the emergence of dawn.", "ফজরের উদয় পর্যন্ত তা শান্তিময়।", "Salāmun hiya ḥattā maṭla'il-fajr", "সালামুন হিয়া হাত্তা মাতলা'ইল ফাজর")
        ),
        103 to listOf(
            QuranAyah(103, 1, 6177, "وَٱلْعَصْرِ", "By time,", "মহাকালের শপথ,", "Wal-'aṣr", "ওয়াল আসর"),
            QuranAyah(103, 2, 6178, "إِنَّ ٱلْإِنسَـٰنَ لَفِى خُسْرٍ", "Indeed, mankind is in loss,", "নিশ্চয় মানুষ ক্ষতির মধ্যে রয়েছে,", "Innal-insāna lafī khusr", "ইন্নাল ইনসানা লাফী খুসর"),
            QuranAyah(103, 3, 6179, "إِلَّا ٱلَّذِينَ ءَامَنُوا۟ وَعَمِلُوا۟ ٱلصَّـٰلِحَـٰتِ وَتَوَاصَوْا۟ بِٱلْحَقِّ وَتَوَاصَوْا۟ بِٱلصَّبْرِ", "Except for those who have believed and done righteous deeds and advised each other to truth and advised each other to patience.", "তবে তারা ব্যতীত যারা ঈমান এনেছে, সৎকর্ম করেছে এবং পরস্পরকে সত্য ও ধৈর্যের উপদেশ দিয়েছে।", "Illallaḏīna āmanū wa 'amiluṣ-ṣāliḥāti wa tawāṣaw bil-ḥaqqi wa tawāṣaw biṣ-ṣabr", "ইল্লাল্লাযীনা আমানূ ওয়া আমিলুস সালিহাতি ওয়া তাওয়াসাও বিল-হাক্কি ওয়া তাওয়াসাও বিস-সাবর")
        ),
        108 to listOf(
            QuranAyah(108, 1, 6205, "إِنَّآ أَعْطَيْنَـٰكَ ٱلْكَوْثَرَ", "Indeed, We have granted you Al-Kawthar.", "নিশ্চয়ই আমি আপনাকে কাউসার দান করেছি।", "Innā a'ṭaynākal-kawthar", "ইন্না আ'তাইনাকাল কাউসার"),
            QuranAyah(108, 2, 6206, "فَصَلِّ لِرَبِّكَ وَٱنْحَرْ", "So pray to your Lord and sacrifice.", "অতএব আপনার প্রতিপালকের উদ্দেশ্যে নামাজ আদায় করুন এবং কুরবানি করুন।", "Faṣalli lirabbika wanḥar", "ফাসাল্লি লিরাব্বিকা ওয়ানহার"),
            QuranAyah(108, 3, 6207, "إِنَّ شَانِئَكَ هُوَ ٱلْأَبْتَرُ", "Indeed, your enemy is the one cut off.", "নিশ্চয়ই আপনার বিদ্বেষীই নির্বংশ।", "Inna shāni'aka huwal-abtar", "ইন্না শানি'আকা হুওয়াল আবতার")
        ),
        109 to listOf(
            QuranAyah(109, 1, 6208, "قُلْ يَـٰٓأَيُّهَا ٱلْكَـٰفِرُونَ", "Say, 'O disbelievers,'", "বলুন, হে কাফিরগণ,", "Qul yā ayyuhal-kāfirūn", "কুল ইয়া আইয়্যুহাল কাফিরূন"),
            QuranAyah(109, 2, 6209, "لَآ أَعْبُدُ مَا تَعْبُدُونَ", "I do not worship what you worship.", "আমি তার ইবাদত করি না, যার ইবাদত তোমরা কর।", "Lā a'budu mā ta'budūn", "লা আ'বুদু মা তা'বুদূন"),
            QuranAyah(109, 3, 6210, "وَلَآ أَنتُمْ عَـٰبِدُونَ مَآ أَعْبُدُ", "Nor are you worshippers of what I worship.", "এবং তোমরাও তাঁর ইবাদতকারী নও, যাঁর ইবাদত আমি করি।", "Wa lā antum 'ābidūna mā a'bud", "ওয়া লা আনতুম আবিদুনা মা আ'বুদ"),
            QuranAyah(109, 4, 6211, "وَلَآ أَنَا۠ عَابِدٌ مَّا عَبَدتُّمْ", "Nor will I be a worshipper of what you worship.", "এবং আমি কখনো তার ইবাদতকারী হবো না যার ইবাদত তোমরা করেছ।", "Wa lā ana 'ābidum mā 'abattum", "ওয়া লা আনা আবিদুম মা আবাত্তুম"),
            QuranAyah(109, 5, 6212, "وَلَآ أَنتُمْ عَـٰبِدُونَ مَآ أَعْبُدُ", "Nor will you be worshippers of what I worship.", "এবং তোমরাও তাঁর ইবাদতকারী নও যাঁর ইবাদত আমি করি।", "Wa lā antum 'ābidūna mā a'bud", "ওয়া লা আনতুম আবিদুনা মা আ'বুদ"),
            QuranAyah(109, 6, 6213, "لَكُمْ دِينُكُمْ وَلِىَ دِينِ", "For you is your religion, and for me is my religion.", "তোমাদের জন্য তোমাদের দ্বীন, আর আমার জন্য আমার দ্বীন।", "Lakum dīnukum wa liya dīn", "লাকুম দীনুকুম ওয়ালিয়া দীন")
        ),
        110 to listOf(
            QuranAyah(110, 1, 6214, "إِذَا جَآءَ نَصْرُ ٱللَّهِ وَٱلْفَتْحُ", "When the victory of Allah has come and the conquest,", "যখন আল্লাহর সাহায্য ও বিজয় আসবে,", "Idhā jā'a naṣrullāhi wal-fatḥ", "ইযা জা'আ নাসরুল্লাহি ওয়াল ফাতহ"),
            QuranAyah(110, 2, 6215, "وَرَأَيْتَ ٱلنَّاسَ يَدْخُلُونَ فِى دِينِ ٱللَّهِ أَفْوَاجًا", "And you see the people entering into the religion of Allah in multitudes,", "এবং আপনি মানুষকে দলে দলে আল্লাহর দ্বীনে প্রবেশ করতে দেখবেন,", "Wa ra'aytan-nāsa yadkhulūna fī dīnillāhi afwājā", "ওয়া রাআইতান নাসা ইয়াদখুলূনা ফী দীনিল্লাহি আফওয়াজা"),
            QuranAyah(110, 3, 6216, "فَسَبِّحْ بِحَمْدِ رَبِّكَ وَٱسْتَغْفِرْهُ ۚ إِنَّهُۥ كَانَ تَوَّابًۢا", "Then exalt Him with praise of your Lord and ask forgiveness of Him. Indeed, He is ever Accepting of repentance.", "তখন আপনার প্রতিপালকের প্রশংসাসহ পবিত্রতা ঘোষণা করুন এবং তাঁর কাছে ক্ষমা প্রার্থনা করুন। নিশ্চয় তিনি তওবা কবুলকারী।", "Fasabbiḥ biḥamdi rabbika wastaghfirh, innahu kāna tawwābā", "ফাসাব্বিহ বিহামদি রাব্বিকা ওয়াস্তাগফিরহু, ইন্নাহু কানা তাউওয়াবা")
        ),
        112 to listOf(
            QuranAyah(112, 1, 6222, "قُلْ هُوَ ٱللَّهُ أَحَدٌ", "Say, 'He is Allah, [who is] One,'", "বলুন, তিনি আল্লাহ, এক ও অদ্বিতীয়।", "Qul huwallāhu aḥad", "কুল হুওয়াল্লাহু আহাদ"),
            QuranAyah(112, 2, 6223, "ٱللَّهُ ٱلصَّمَدُ", "Allah, the Eternal Refuge.", "আল্লাহ অমুখাপেক্ষী।", "Allāhuṣ-ṣamad", "আল্লাহুস সামাদ"),
            QuranAyah(112, 3, 6224, "لَمْ يَلِدْ وَلَمْ يُولَدْ", "He neither begets nor is born,", "তিনি কাউকে জন্ম দেননি এবং তাঁকেও জন্ম দেওয়া হয়নি।", "Lam yalid wa lam yūlad", "লাম ইয়ালিদ ওয়া লাম ইউলাদ"),
            QuranAyah(112, 4, 6225, "وَلَمْ يَكُن لَّهُۥ كُفُوًا أَحَدٌۢ", "Nor is there to Him any equivalent.", "এবং তাঁর সমতুল্য কেউ নেই।", "Wa lam yakul lahu kufuwan aḥad", "ওয়া লাম ইয়াকুল লাহু কুফুওয়ান আহাদ")
        ),
        113 to listOf(
            QuranAyah(113, 1, 6226, "قُلْ أَعُوذُ بِرَبِّ ٱلْفَلَقِ", "Say, 'I seek refuge in the Lord of daybreak'", "বলুন, আমি আশ্রয় প্রার্থনা করছি ভোরের প্রতিপালকের,", "Qul a'ūdhu birabbil-falaq", "কুল আউযু বিরাব্বিল ফালাক"),
            QuranAyah(113, 2, 6227, "مِن شَرِّ مَا خَلَقَ", "From the evil of that which He created", "তিনি যা সৃষ্টি করেছেন তার অনিষ্ট থেকে,", "Min sharri mā khalaq", "মিন শাররি মা খালাক"),
            QuranAyah(113, 3, 6228, "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ", "And from the evil of darkness when it settles", "অন্ধকার রাতের অনিষ্ট থেকে যখন তা গভীর হয়,", "Wa min sharri ghāsiqin idhā waqab", "ওয়া মিন শাররি গাসিক্বিন ইযা ওয়াকাব"),
            QuranAyah(113, 4, 6229, "وَمِن شَرِّ ٱلنَّفَّـٰثَـٰتِ فِى ٱلْعُقَدِ", "And from the evil of the blowers in knots", "এবং গিঁটে ফুঁ দানকারিণীদের অনিষ্ট থেকে,", "Wa min sharrin-naffāthāti fil-'uqad", "ওয়া মিন শাররিন নাফফাসাতি ফিল উক্বাদ"),
            QuranAyah(113, 5, 6230, "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", "And from the evil of an envier when he envies.", "এবং হিংসুকের অনিষ্ট থেকে যখন সে হিংসা করে।", "Wa min sharri ḥāsidin idhā ḥasad", "ওয়া মিন শাররি হাসিদিন ইযা হাসাদ")
        ),
        114 to listOf(
            QuranAyah(114, 1, 6231, "قُلْ أَعُوذُ بِرَبِّ ٱلنَّاسِ", "Say, 'I seek refuge in the Lord of mankind,'", "বলুন, আমি আশ্রয় প্রার্থনা করছি মানুষের প্রতিপালকের,", "Qul a'ūdhu birabbin-nās", "কুল আউযু বিরাব্বিন নাস"),
            QuranAyah(114, 2, 6232, "مَلِكِ ٱلنَّاسِ", "The Sovereign of mankind,", "মানুষের অধিপতির,", "Malikin-nās", "মালিকিন নাস"),
            QuranAyah(114, 3, 6233, "إِلَـٰهِ ٱلنَّاسِ", "The God of mankind,", "মানুষের উপাস্যের,", "Ilāhin-nās", "ইলাহিন নাস"),
            QuranAyah(114, 4, 6234, "مِن شَرِّ ٱلْوَسْوَاسِ ٱلْخَنَّاسِ", "From the evil of the retreating whisperer", "আত্মগোপনকারী কুমন্ত্রণাদাতার অনিষ্ট থেকে,", "Min sharril-waswāsil-khannās", "মিন শাররিল ওয়াসওয়াসিল খান্নাস"),
            QuranAyah(114, 5, 6235, "ٱلَّذِى يُوَسْوِسُ فِى صُدُورِ ٱلنَّاسِ", "Who whispers [evil] into the breasts of mankind", "যে মানুষের অন্তরে কুমন্ত্রণা দেয়,", "Alladhī yuwaswisu fī ṣudūrin-nās", "আল্লাযী ইউওয়াসউইসু ফী সুদূরিন নাস"),
            QuranAyah(114, 6, 6236, "مِنَ ٱلْجِنَّةِ وَٱلنَّاسِ", "From among the jinn and mankind.", "জিন এবং মানুষের মধ্য থেকে।", "Minal-jinnati wan-nās", "মিনাল জিন্নাতি ওয়ান নাস")
        )
    )

    fun getBundledSurah(surahNumber: Int): List<QuranAyah>? = map[surahNumber]
    fun bundledSurahNumbers(): Set<Int> = map.keys
}
