package com.example.ruhzena.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.SelfImprovement
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ruhzena.core.i18n.AppLanguage
import com.example.ruhzena.core.i18n.LocalAppLanguage
import com.example.ruhzena.media.LocalRuhZenaSound
import com.example.ui.theme.LocalRuhZenaPalette

enum class DockDestination(val testTag: String) {
    HOME("nav_home"),
    DEEN("nav_spirituality"),
    AI("nav_ai"),
    LEARN("nav_learn"),
    LIFE("nav_life")
}

/**
 * Full customizable catalog of urgent & high-utility Quick Jump destinations.
 * Users can pick and reorder 4–8 active shortcuts right from Settings!
 */
enum class PortalQuickLaunch(
    val titleEn: String,
    val titleBn: String,
    val subtitleEn: String,
    val subtitleBn: String,
    val icon: ImageVector,
    val testTag: String,
    val isUrgentDefault: Boolean = false
) {
    CONTINUE_QURAN(
        "Continue Quran", "কুরআন পড়ুন",
        "Resume last ayah instantly", "শেষ আয়াত থেকে শুরু",
        Icons.Default.MenuBook, "portal_continue_quran", isUrgentDefault = true
    ),
    PRAYER_QIBLA(
        "Prayer & Qibla", "নামাজ ও কিবলা",
        "Live Salah times & compass", "নামাজের সময় ও কিবলা",
        Icons.Default.Explore, "portal_prayer_qibla", isUrgentDefault = true
    ),
    DAILY_DUAS(
        "Daily Duas", "দৈনিক দুআ",
        "Every daily life Sunnah Dua", "সকল দৈনন্দিন দুআ",
        Icons.Default.VolunteerActivism, "portal_daily_duas", isUrgentDefault = true
    ),
    TASBIH_3D(
        "Tasbih", "তাসবিহ",
        "Dhikr bead counter", "যিকির ও তাসবিহ",
        Icons.Default.RadioButtonChecked, "portal_tasbih", isUrgentDefault = true
    ),
    URGE_RESET(
        "Calm Reset", "প্রশান্তি ও শ্বাস",
        "Emergency breathing calm", "জরুরি শ্বাস ও নিয়ন্ত্রণ",
        Icons.Default.Air, "portal_urge_reset", isUrgentDefault = true
    ),
    QUICK_WATER(
        "+250ml Water", "+২৫০ মি.লি. পানি",
        "Instant hydration log", "তাৎক্ষণিক পানি লগ",
        Icons.Default.WaterDrop, "portal_quick_water", isUrgentDefault = true
    ),
    WORKOUTS_3D(
        "Workouts", "ব্যায়াম",
        "3D anatomical exercise guide", "৩ডি ব্যায়াম গাইড",
        Icons.Default.FitnessCenter, "portal_workouts"
    ),
    MEAL_SCANNER(
        "Meal Scanner", "খাবার স্ক্যান",
        "AI halal & nutrition scan", "খাবারের পুষ্টি স্ক্যান",
        Icons.Default.CameraAlt, "portal_meal_scanner"
    ),
    ARABIC_STUDIO(
        "Arabic Studio", "আরবি লেখা",
        "Alphabet & handwriting practice", "আরবি হরফ ও অনুশীলন",
        Icons.Default.Draw, "portal_arabic_studio"
    ),
    HABITS_JOURNAL(
        "Habits & Log", "অভ্যাস ও জার্নাল",
        "Daily streaks & reflection", "অভ্যাস ও জার্নাল",
        Icons.Default.CheckCircle, "portal_habits"
    ),
    HIFZ_COMPANION(
        "Hifz Loop", "হিফজ লুপ",
        "Ayah memorization repeater", "কুরআন মুখস্থ লুপ",
        Icons.Default.Repeat, "portal_hifz"
    ),
    STORIES(
        "Stories", "ইসলামী গল্প",
        "Detailed prophet stories", "নবীদের পূর্ণ গল্প",
        Icons.Default.AutoStories, "portal_stories"
    ),
    BOOKMARKS(
        "Bookmarks", "বুকমার্ক",
        "Saved verses & duas", "সংরক্ষিত আয়াত ও দুআ",
        Icons.Default.Bookmark, "portal_bookmarks"
    ),
    GLOBAL_SEARCH(
        "Instant Search", "দ্রুত খুঁজুন",
        "Find any Surah, Dua or topic", "সূরা, দুআ বা বিষয় খুঁজুন",
        Icons.Default.Search, "portal_global_search"
    );

    companion object {
        val defaultUrgentShortcuts: List<PortalQuickLaunch> =
            entries.filter { it.isUrgentDefault }

        fun fromCsv(csv: String?): List<PortalQuickLaunch> {
            if (csv.isNullOrBlank()) return defaultUrgentShortcuts
            val parsed = csv.split(',')
                .mapNotNull { token ->
                    val clean = token.trim()
                    entries.firstOrNull { it.name.equals(clean, ignoreCase = true) }
                }
                .distinct()
                .take(8)
            return if (parsed.size >= 3) parsed else defaultUrgentShortcuts
        }

        fun toCsv(list: List<PortalQuickLaunch>): String =
            list.distinct().take(8).joinToString(",") { it.name }
    }
}

/**
 * Symmetrical 5-Slot Brushed-Silver Liquid Glass Floating Navigation Dock.
 * Tap center emblem = open RuhZena AI; Long-press or swipe up = open Customizable Quick Jump Deck.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SanctuaryCompassDock(
    selected: DockDestination,
    portalExpanded: Boolean,
    onSelect: (DockDestination) -> Unit,
    onTogglePortal: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val haptics = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal))
            .padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 64.dp)
                .shadow(
                    elevation = if (palette.isLight) 10.dp else 18.dp,
                    shape = RoundedCornerShape(28.dp),
                    ambientColor = Color.Black.copy(alpha = if (palette.isLight) 0.14f else 0.55f),
                    spotColor = palette.accentPrimary.copy(alpha = 0.22f)
                )
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            palette.cardElevatedBg,
                            palette.navBarBg
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        listOf(
                            palette.borderAccent,
                            palette.borderNeutral
                        )
                    ),
                    shape = RoundedCornerShape(28.dp)
                )
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DockTabSlot(
                label = if (isBn) "হোম" else "Home",
                selected = selected == DockDestination.HOME,
                selectedIcon = Icons.Filled.Home,
                unselectedIcon = Icons.Outlined.Home,
                onClick = {
                    if (portalExpanded) onTogglePortal(false)
                    onSelect(DockDestination.HOME)
                },
                modifier = Modifier
                    .weight(1f)
                    .tutorialTarget(TutorialTargetKeys.DOCK_HOME)
                    .testTag(DockDestination.HOME.testTag)
            )
            DockTabSlot(
                label = if (isBn) "দ্বীন" else "Deen",
                selected = selected == DockDestination.DEEN,
                selectedIcon = Icons.AutoMirrored.Filled.MenuBook,
                unselectedIcon = Icons.AutoMirrored.Outlined.MenuBook,
                onClick = {
                    if (portalExpanded) onTogglePortal(false)
                    onSelect(DockDestination.DEEN)
                },
                modifier = Modifier
                    .weight(1f)
                    .tutorialTarget(TutorialTargetKeys.DOCK_DEEN)
                    .testTag(DockDestination.DEEN.testTag)
            )

            CenterAiEmblemTab(
                selected = selected == DockDestination.AI,
                portalExpanded = portalExpanded,
                onClick = {
                    if (portalExpanded) {
                        onTogglePortal(false)
                    } else {
                        haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(DockDestination.AI)
                    }
                },
                onLongClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onTogglePortal(!portalExpanded)
                },
                onSwipeUp = {
                    if (!portalExpanded) {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        onTogglePortal(true)
                    }
                },
                onSwipeDown = {
                    if (portalExpanded) onTogglePortal(false)
                },
                modifier = Modifier
                    .weight(1f)
                    .tutorialTarget(TutorialTargetKeys.DOCK_CENTER_AI)
                    .testTag(DockDestination.AI.testTag)
            )

            DockTabSlot(
                label = if (isBn) "শিক্ষা" else "Learn",
                selected = selected == DockDestination.LEARN,
                selectedIcon = Icons.Filled.School,
                unselectedIcon = Icons.Outlined.School,
                onClick = {
                    if (portalExpanded) onTogglePortal(false)
                    onSelect(DockDestination.LEARN)
                },
                modifier = Modifier
                    .weight(1f)
                    .tutorialTarget(TutorialTargetKeys.DOCK_LEARN)
                    .testTag(DockDestination.LEARN.testTag)
            )
            DockTabSlot(
                label = if (isBn) "জীবন" else "Life",
                selected = selected == DockDestination.LIFE,
                selectedIcon = Icons.Filled.SelfImprovement,
                unselectedIcon = Icons.Outlined.SelfImprovement,
                onClick = {
                    if (portalExpanded) onTogglePortal(false)
                    onSelect(DockDestination.LIFE)
                },
                modifier = Modifier
                    .weight(1f)
                    .tutorialTarget(TutorialTargetKeys.DOCK_LIFE)
                    .testTag(DockDestination.LIFE.testTag)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CenterAiEmblemTab(
    selected: Boolean,
    portalExpanded: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onSwipeUp: () -> Unit,
    onSwipeDown: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    val sound = LocalRuhZenaSound.current
    val isActive = selected || portalExpanded
    val iconScale by animateFloatAsState(
        targetValue = if (isActive) 1.12f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "centerAiTabScale"
    )
    val tintColor = if (isActive) palette.accentSoft else palette.textSecondary
    val labelColor = if (isActive) palette.accentSoft else palette.textMuted

    Column(
        modifier = modifier
            .heightIn(min = 52.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (isActive) palette.accentContainer else Color.Transparent)
            .border(
                width = if (isActive) 1.dp else 0.dp,
                color = if (isActive) palette.borderAccent else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .pointerInput(portalExpanded) {
                var totalDrag = 0f
                detectVerticalDragGestures(
                    onDragStart = { totalDrag = 0f },
                    onDragEnd = {
                        if (totalDrag < -24f) onSwipeUp()
                        else if (totalDrag > 24f) onSwipeDown()
                        totalDrag = 0f
                    },
                    onDragCancel = { totalDrag = 0f }
                ) { _, dragAmount ->
                    totalDrag += dragAmount
                }
            }
            .combinedClickable(
                onClick = {
                    sound?.playClick(pitch = 1.08f)
                    onClick()
                },
                onLongClick = {
                    sound?.playFoldDropdown(opening = !portalExpanded)
                    onLongClick()
                }
            )
            .padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (portalExpanded) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close Quick Jump",
                tint = tintColor,
                modifier = Modifier.size(22.dp).scale(iconScale)
            )
        } else {
            Image(
                painter = painterResource(id = R.drawable.ruhzena_emblem),
                contentDescription = "RuhZena AI (Hold or Swipe Up for Quick Jump)",
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(tintColor, BlendMode.SrcIn),
                modifier = Modifier.size(24.dp).scale(iconScale)
            )
        }
        Spacer(modifier = Modifier.height(1.dp))
        Text(
            text = "AI",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
            ),
            color = labelColor,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun DockTabSlot(
    label: String,
    selected: Boolean,
    selectedIcon: ImageVector,
    unselectedIcon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalRuhZenaPalette.current
    val sound = LocalRuhZenaSound.current
    val iconScale by animateFloatAsState(
        targetValue = if (selected) 1.12f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "dockTabScale"
    )
    Column(
        modifier = modifier
            .heightIn(min = 52.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) palette.accentContainer else Color.Transparent)
            .border(
                width = if (selected) 1.dp else 0.dp,
                color = if (selected) palette.borderAccent else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .clickable {
                sound?.playClick()
                onClick()
            }
            .padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (selected) selectedIcon else unselectedIcon,
            contentDescription = label,
            tint = if (selected) palette.accentSoft else palette.textSecondary,
            modifier = Modifier.size(22.dp).scale(iconScale)
        )
        Spacer(modifier = Modifier.height(1.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
            ),
            color = if (selected) palette.accentSoft else palette.textMuted,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Upgraded Futuristic Liquid-Glass Customizable Quick Jump Command Deck anchored above the center AI tab.
 * Supports 4–8 user-chosen shortcuts with instant access to urgent daily Islamic & wellness tools
 * plus a direct "Edit Shortcuts" button to customize in Settings.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SanctuaryPortalOverlay(
    visible: Boolean,
    activeShortcuts: List<PortalQuickLaunch> = PortalQuickLaunch.defaultUrgentShortcuts,
    onDismiss: () -> Unit,
    onLaunch: (PortalQuickLaunch) -> Unit,
    onEditInSettings: () -> Unit = {}
) {
    val palette = LocalRuhZenaPalette.current
    val isBn = LocalAppLanguage.current == AppLanguage.BANGLA
    val haptics = LocalHapticFeedback.current
    val items = remember(activeShortcuts) {
        activeShortcuts.ifEmpty { PortalQuickLaunch.defaultUrgentShortcuts }
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(180)),
        exit = fadeOut(tween(150))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = if (palette.isLight) 0.42f else 0.68f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .testTag("sanctuary_portal_overlay"),
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = slideInVertically(
                    initialOffsetY = { it / 2 },
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    )
                ) + scaleIn(initialScale = 0.88f) + fadeIn(tween(180)),
                exit = slideOutVertically(targetOffsetY = { it / 3 }) + scaleOut(targetScale = 0.9f) + fadeOut(tween(140)),
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 104.dp)
                    .widthIn(max = 460.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(
                            elevation = 24.dp,
                            shape = RoundedCornerShape(28.dp),
                            spotColor = palette.accentPrimary.copy(alpha = 0.35f)
                        )
                        .clip(RoundedCornerShape(28.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    palette.cardElevatedBg.copy(alpha = 0.96f),
                                    palette.surfaceBg.copy(alpha = 0.97f)
                                )
                            )
                        )
                        .border(
                            width = 1.2.dp,
                            brush = Brush.linearGradient(
                                listOf(
                                    palette.accentSoft.copy(alpha = 0.55f),
                                    palette.gold.copy(alpha = 0.45f)
                                )
                            ),
                            shape = RoundedCornerShape(28.dp)
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        )
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Futuristic Liquid-Glass Top Glow Pill
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .width(44.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(palette.accentSoft.copy(alpha = 0.6f), palette.gold.copy(alpha = 0.9f), palette.accentSoft.copy(alpha = 0.6f))
                                )
                            )
                    )

                    // Header row: Quick Jump badge + Customize pill
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isBn) "দ্রুত জাম্প • কুইক ডেক" else "Quick Jump Deck",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.gold,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isBn) "জরুরি ফিচারে এক ট্যাপে পৌঁছান" else "Instant 1-tap launch to your pinned sanctuary tools",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textSecondary
                            )
                        }
                        Row(
                            modifier = Modifier
                                .heightIn(min = 40.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(palette.accentContainer)
                                .border(0.9.dp, palette.borderAccent, RoundedCornerShape(999.dp))
                                .clickable {
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onDismiss()
                                    onEditInSettings()
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                .testTag("portal_edit_shortcuts_btn"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = if (isBn) "কাস্টমাইজ করুন" else "Customize Quick Jump",
                                tint = palette.accentSoft,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = if (isBn) "সাজান" else "Customize",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.accentSoft,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Responsive Liquid-Glass Grid of Active Shortcuts (2 or 3 columns depending on count)
                    val columns = if (items.size <= 4) 2 else 3
                    val rows = items.chunked(columns)
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        rows.forEach { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                rowItems.forEach { action ->
                                    val accentTint = when (action) {
                                        PortalQuickLaunch.URGE_RESET -> palette.coral
                                        PortalQuickLaunch.QUICK_WATER -> Color(0xFF38BDF8)
                                        PortalQuickLaunch.PRAYER_QIBLA,
                                        PortalQuickLaunch.CONTINUE_QURAN -> palette.gold
                                        PortalQuickLaunch.WORKOUTS_3D,
                                        PortalQuickLaunch.MEAL_SCANNER -> Color(0xFF34D399)
                                        else -> palette.accentSoft
                                    }
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 92.dp)
                                            .clip(RoundedCornerShape(20.dp))
                                            .background(
                                                Brush.verticalGradient(
                                                    listOf(
                                                        accentTint.copy(alpha = 0.12f),
                                                        palette.blockBg.copy(alpha = 0.90f)
                                                    )
                                                )
                                            )
                                            .border(
                                                width = 1.dp,
                                                brush = Brush.linearGradient(
                                                    listOf(
                                                        accentTint.copy(alpha = 0.55f),
                                                        palette.borderNeutral
                                                    )
                                                ),
                                                shape = RoundedCornerShape(20.dp)
                                            )
                                            .clickable {
                                                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                onLaunch(action)
                                            }
                                            .padding(horizontal = 6.dp, vertical = 10.dp)
                                            .testTag(action.testTag)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    Brush.radialGradient(
                                                        listOf(accentTint.copy(alpha = 0.28f), accentTint.copy(alpha = 0.10f))
                                                    )
                                                )
                                                .border(1.1.dp, accentTint.copy(alpha = 0.55f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = action.icon,
                                                contentDescription = if (isBn) action.titleBn else action.titleEn,
                                                tint = accentTint,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = if (isBn) action.titleBn else action.titleEn,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = palette.textPrimary,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = if (isBn) action.subtitleBn else action.subtitleEn,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = palette.textMuted,
                                            textAlign = TextAlign.Center,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                repeat(columns - rowItems.size) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }

                    Text(
                        text = if (isBn) "টিপস: যেকোনো পেজ থেকে নিচের AI লোগোতে লং-প্রেস বা ওপরে সোয়াইপ করুন।"
                        else "Tip: Long-press or swipe up on the center AI emblem from any screen anytime.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
