package com.example.ruhzena.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "water_logs")
data class WaterLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountMl: Int,
    val dateKey: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "meal_logs")
data class MealLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val mealType: String, // Breakfast, Lunch, Dinner, Suhoor, Iftar, Snack
    val calories: Int,
    val proteinGrams: Int,
    val carbsGrams: Int,
    val fatGrams: Int,
    val isVerifiedReference: Boolean = false,
    val sourceAttribution: String = "User Estimate",
    val dateKey: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "sleep_logs")
data class SleepLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val durationMinutes: Int,
    val bedtimeLabel: String,
    val wakeTimeLabel: String,
    val qualityRating: Int, // 1..5
    val note: String = "",
    val dateKey: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "workout_logs")
data class WorkoutLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routineTitle: String,
    val exercisesCompleted: Int,
    val durationMinutes: Int,
    val estimatedCalories: Int,
    val dateKey: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String, // Spirituality, Health, Discipline, Learning
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val reminderEnabled: Boolean = false,
    val reminderTime: String = "08:00",
    val lastCompletedDate: String = "",
    val recoveryNote: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "habit_checks")
data class HabitCheckEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val habitId: Long,
    val dateKey: String,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "journal_entries")
data class JournalEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val mood: String, // Grateful, Calm, Focused, Struggling, Hopeful
    val achievement: String = "",
    val dateKey: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val key: String, // e.g. "QURAN_1_1" or "DUA_morning_1"
    val itemType: String, // QURAN, DUA, ADHKAR, LESSON
    val title: String,
    val subtitle: String,
    val arabicText: String,
    val surahNumber: Int = 0,
    val ayahNumber: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "ai_messages")
data class AiMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: String,
    val mode: String, // ISLAMIC, WELLNESS
    val role: String, // USER, ASSISTANT
    val content: String,
    val evidenceJson: String = "",
    val usedOnlineResearch: Boolean = false,
    val engineLabel: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_surahs")
data class CachedSurahEntity(
    @PrimaryKey val surahNumber: Int,
    val ayahsJson: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "ai_memories")
data class AiMemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // PREFERENCE, GOAL, SPIRITUAL, FITNESS, NUTRITION, GENERAL
    val content: String,
    val sourcePrompt: String = "",
    val isApproved: Boolean = true,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "ai_conversation_summaries")
data class AiConversationSummaryEntity(
    @PrimaryKey val sessionId: String,
    val summaryText: String,
    val coveredUpToMessageId: Long = 0L,
    val activeTopicsCsv: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "ai_task_states")
data class AiTaskStateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: String = "unified",
    val title: String,
    val objective: String,
    val constraints: String = "",
    val completedStepsJson: String = "[]",
    val remainingStepsJson: String = "[]",
    val findingsJson: String = "[]",
    val workingNotes: String = "",
    val nextAction: String = "",
    val unresolvedQuestionsJson: String = "[]",
    val status: String = "ACTIVE", // ACTIVE, PAUSED, COMPLETED
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "ai_provider_health")
data class AiProviderHealthEntity(
    @PrimaryKey val modelKey: String, // e.g. "GROQ::openai/gpt-oss-120b"
    val providerId: String,
    val modelId: String,
    val consecutiveFailures: Int = 0,
    val cooldownUntilMillis: Long = 0L,
    val lastLatencyMs: Long = 0L,
    val lastErrorKind: String = "",
    val lastErrorSummary: String = "",
    val totalSuccesses: Int = 0,
    val totalFailures: Int = 0,
    val sessionDisabled: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

