package com.example.ruhzena.data.cloud

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class CloudUserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val language: String = "ENGLISH",
    val characterGender: String = "",
    val hydrationGoalMl: Int = 2500,
    val tasbihTotalCount: Int = 0,
    val lastReadSurah: Int = 1,
    val lastReadAyah: Int = 1,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudHabit(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val category: String = "Spirituality",
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val lastCompletedDate: String = "",
    val recoveryNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudJournalEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val content: String = "",
    val mood: String = "Grateful",
    val achievement: String = "",
    val dateKey: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudWorkoutLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val routineTitle: String = "",
    val exercisesCompleted: Int = 0,
    val durationMinutes: Int = 0,
    val estimatedCalories: Int = 0,
    val dateKey: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudWaterLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val amountMl: Int = 250,
    val dateKey: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudBookmark(
    @DocumentId val id: String = "",
    val userId: String = "",
    val itemType: String = "QURAN",
    val title: String = "",
    val subtitle: String = "",
    val arabicText: String = "",
    val surahNumber: Int = 0,
    val ayahNumber: Int = 0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class CloudSyncStatus(
    val synced: Boolean = false,
    val syncing: Boolean = false,
    val lastSyncedEpochMs: Long = 0L,
    val syncedCountsSummary: String = "",
    val errorMessage: String? = null
)
