package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RuhZena Brushed Sterling Silver & Crisp Obsidian Graphite Surfaces (Zero Foggy White Wash)
val ObsidianVoid = Color(0xFF090B0E)
val ObsidianCharcoal = Color(0xFF101318)
val ObsidianSurface = Color(0xFF151920)
val ObsidianElevated = Color(0xFF1E232C)

// Crisp Solid-Contrast Graphite Surfaces (No milky haze)
val GlassCardBg = Color(0xFF14181F)
val GlassCardElevatedBg = Color(0xFF1C212A)
val GlassPillBg = Color(0xFF191E26)

// Crisp Porcelain & Brushed Pewter-Silver Surfaces (Light Mode)
val LightVoid = Color(0xFFF3F5F8)
val LightCharcoal = Color(0xFFE8ECF1)
val LightSurface = Color(0xFFDFE4EC)
val LightElevated = Color(0xFFFFFFFF)
val LightGlassCardBg = Color(0xFFFFFFFF)
val LightGlassCardElevatedBg = Color(0xFFF9FAFC)
val LightGlassPillBg = Color(0xFFE9EDF3)
val LightInkPrimary = Color(0xFF12161D)
val LightInkSecondary = Color(0xFF424A57)
val LightInkMuted = Color(0xFF697282)
val LightBorderGreyBlack = Color(0xFFCBD2DD)
val LightBorderEmerald = Color(0xFF5A6475)
val LightHighlightTop = Color(0xFFD5DCE6)

// Sharp Metallic Silver Hairline Borders (Crisp definition, zero chalky blur)
val GlassBorderSilver = Color(0xFF2B323E)
val GlassBorderEmerald = Color(0xFF7B879B)
val GlassHighlightTop = Color(0xFF343C4A)

// Primary Accent Palette — Brushed Sterling Silver & Gunmetal
val EmeraldAccent = Color(0xFFD6DCE6)        // Solid Sterling Silver primary action button in Dark Mode
val EmeraldSoft = Color(0xFFF2F5FA)          // Crisp Platinum text/icon highlight in Dark Mode
val EmeraldDeep = Color(0xFF2B313C)          // Crisp Deep Gunmetal primary button in Light Mode
val EmeraldDeepInk = Color(0xFF1A1F28)       // Sharp Charcoal active ink in Light Mode
val EmeraldContainer = Color(0xFF272E39)     // Crisp Brushed Gunmetal selected tab/chip container (Dark — ZERO fog!)
val LightEmeraldContainer = Color(0xFFD7DEE8) // Crisp Brushed Silver selected tab/chip container (Light — ZERO fog!)

// Crisp Neutral Platinum & Graphite Text Hierarchy
val SilverPrimary = Color(0xFFF4F6FA)
val SilverSecondary = Color(0xFFB3BCC9)
val SilverMuted = Color(0xFF7C8594)

// Warm Champagne Gold & Antique Bronze Accents (Refined Sacred/Source Highlight)
val ChampagneGold = Color(0xFFE3C485)
val ChampagneGoldDeep = Color(0xFF966B1C)
val ChampagneGoldMuted = Color(0x28E3C485)

// Refined Semantic Status Colors
val StatusSuccess = Color(0xFF38B88C)
val StatusSuccessDeep = Color(0xFF1A8460)
val StatusAmber = Color(0xFFE9B44C)
val StatusAmberDeep = Color(0xFFB45309)
val StatusCoral = Color(0xFFE86C6A)
val StatusCoralDeep = Color(0xFFCC2E2E)
val StatusSky = Color(0xFF9EB4CC)       // Cool Mist Silver-Slate
val StatusSkyDeep = Color(0xFF4B627A)   // Brushed Pewter-Slate for Light Mode
