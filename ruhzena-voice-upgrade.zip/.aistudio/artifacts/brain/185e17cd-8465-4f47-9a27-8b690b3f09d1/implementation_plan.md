# RuhZena — Persistent Multi-Provider AI Agent & Experience Upgrade Plan

> Upgrading RuhZena into a server-independent, model-resilient intelligent companion (**RuhZena AI**) with seamless automatic multi-provider failover, paired with a signature Liquid Glass navigation system, dedicated Islamic Learning Academy, 3D-shaded articulated boy & girl workout figures, GPS-first onboarding, maxed-out Quran Audio Player, and a realistic 3D tactile Tasbih experience — while preserving every existing RuhZena feature intact.

---

## User Review & Critical Decisions

Please review these architectural decisions before implementation begins:

- **Zero-Server Independence & Credential Security**: Per your preference for complete server independence, the app requires **no external backend server**. Groq, OpenRouter, and Cloudflare Workers AI are called directly over HTTPS/SSE from Android, reading credentials from AI Studio Secrets (`BuildConfig`) and/or an **optional Android Keystore–encrypted API Keys screen** in Settings (so keys can be added, updated, or cleared anytime on-device). **Keyless Firebase AI Logic** (`gemini-3.8-flash` & `gemini-3.5-flash-lite` via App Check) remains active in the failover pool so RuhZena AI and the Nutrition Meal Scanner work immediately out-of-the-box even if third-party keys are not yet configured.
  - *Security transparency note*: Any third-party API keys embedded in a client APK via build secrets can be extracted by reverse engineering; for public Play Store scale, setting per-key provider spend limits (or later pointing the optional custom proxy URL field in Settings to your own lightweight endpoint) is recommended.
- **Complete Rebrand to "RuhZena AI" & Unified Single Chat**: Every remaining reference to `RuhZeba AI` will be cleanly renamed to **RuhZena AI**, and the separate Islamic / Wellness chat split will be unified into **one continuous conversation thread** where both **Peace & Life Companion** and **Practical & Knowledge Expert** personalities work seamlessly across all topics.
- **Sanctuary Compass Dock Navigation**: To give the dedicated Islamic Learning section a memorable, joyful, 1-tap home without crowding phones, the bottom navigation evolves into a floating Liquid Glass dock featuring **Home**, **Deen**, an elevated central **RuhZena Portal Orb**, **Learn (Islamic Academy)**, and **Life (Wellness & Discipline)** — where tapping the central orb opens **RuhZena AI** and swiping up or long-pressing it blooms a spring-animated **Radial Glass Wheel** for instant 1-gesture jumps to any tool.

---

## 1. Overview & Core Concept

RuhZena's core principle for this upgrade is **"The Agent Outlives the Model."** AI providers and models are treated purely as interchangeable inference engines behind a persistent local agent layer. Conversation continuity, personality tone, user-approved memories, multi-step task progress, and strict Islamic citation integrity live inside RuhZena's on-device Room database and routing controller — never inside a single vendor session.

When any provider hits a rate limit (HTTP 429), high-demand overload, server outage (500/502/503/504), timeout, invalid/decommissioned model ID, or mid-stream network drop, RuhZena AI transparently rotates to the healthiest compatible model in the background — recovering partial streamed text without duplicating output or resetting the chat. The exact same multi-provider failover architecture powers the **Nutrition Photo & Meal Checker** for resilient multimodal vision analysis.

---

## 2. User Experience & Visual Design

### Unified RuhZena AI Interface
- **Single Continuous Conversation**: One unified chat space handles Quran/Hadith questions, personal reflection, workout planning, nutrition coaching, and everyday life without switching tabs.
- **Persistent Personality Switcher**: A tactile Liquid Glass pill lets the user switch smoothly between:
  - **Peace & Life Companion** — calm, empathetic, warm, emotionally supportive, natural flow.
  - **Practical & Knowledge Expert** — direct, structured, analytical, precise, evidence-first.
- **Memory Permission Chips & Memory Manager**: When RuhZena AI notices a helpful long-term preference or goal (e.g., fitness goal, dietary preference, learning track), it surfaces an unobtrusive inline **"Save to Memory?"** approval chip (Save / Dismiss). A dedicated **Memory & Active Tasks Drawer** lets users inspect, edit, pin, add, or delete any saved memory or active multi-step task at any time.
- **Invisible Failover UX**: Users never see raw HTTP codes, stack traces, quota walls, or manual model pickers. On transient failover, a subtle breathing glass indicator displays calm status text (e.g., *"Continuing thoughtfully..."*), preserves the user's message on total offline failure, and offers a single clean retry action.

### Signature Navigation: The Sanctuary Compass Dock
- **Compact Phones**: A floating Liquid Glass pill dock respecting system navigation insets (`WindowInsets.navigationBars`):
  1. **Home** — Daily Sanctuary Dashboard, My Day & 7-Day Journey, Ramadan & Quick Actions.
  2. **Deen** — Quran, Prayer & Qibla, Adhkar & Dua, Tasbih (switched via a clean **top Liquid Glass Dropdown Selector** replacing the old sliding tab strip).
  3. **Center Elevated Glowing Orb (RuhZena Portal)** — Single tap launches **RuhZena AI** immediately; long-press or upward drag blooms a spring-physics **Radial Glass Portal Wheel** with tactile haptics for fun 1-motion jumps to **Arabic Canvas**, **3D Workouts**, **Meal Scanner**, **Qibla**, **Tasbih**, and **Habits & Journal**.
  4. **Learn** — The new **Dedicated Islamic Learning Academy** (first-class top-level destination).
  5. **Life** — Unified **Wellness** (Workouts, Hydration, Nutrition) and **Discipline** (Habits, Urge Breathing Recovery, Private Journal) via a crisp top dropdown/segmented selector.
- **Tablets & Foldables (Medium / Expanded)**: Automatically adapts to a spacious **Liquid Glass NavigationRail** exposing Home, Deen, RuhZena AI, Learn, Wellness, and Discipline side-by-side.

### Dedicated Islamic Learning Academy
- **One-Time 2-Phase Entry Experience** (changeable anytime in the Academy header or Settings):
  - **Path 1 — New Muslim / Beginner**: Step-by-step guided journey starting from Shahadah, Wudu, Salah step-by-step, Core Beliefs (Aqeedah), Essential Daily Sunnah, Halal & Haram basics, and Arabic Alphabet fundamentals with progress tracking.
  - **Path 2 — Practicing / Veteran Muslim**: Instant searchable Islamic Knowledge Encyclopedia with structured deep-dives across Quran & Hadith sciences, Stories of the Prophets & Sahaba, Fiqh Essentials, Dos & Don'ts, Understanding Bid'ah vs. Sunnah, Etiquette (Adab), and verified references with direct links.
- **Interactive Arabic Alphabet & Writing Canvas**: Full 28-letter Arabic script studio showing isolated/initial/medial/final forms, Makharij pronunciation guide, human audio pronunciation, animated directional stroke guides, and an interactive touch-drawing canvas with trace overlay, brush/undo/clear controls, and practice mastery tracking.

### Spirituality Dropdown & Maxed-Out Quran Audio Player
- **Top Dropdown Selector**: Replaces the cramped horizontally sliding sub-tabs in Spirituality with a clean, spacious Liquid Glass dropdown showing section icon, title, and subtle count/status subtitle.
- **Maxed-Out Liquid Glass Quran Audio Player**: Upgrades both the floating mini-bar and an expandable **Full-Screen Now Playing Sheet** featuring:
  - Animated audio waveform visualizer & ayah-by-ayah live synced highlight.
  - Scrubbable timeline slider with elapsed/remaining timestamps and jump-by-ayah controls.
  - Searchable **Reciter Dropdown**, **Playback Speed** (`0.75×` to `2.0×`), **Repeat Mode** (Off / Repeat Ayah / Repeat Surah / Custom Ayah-Range Hifz Loop with configurable pause-gap for memorization), **Sleep Timer** (`15m`, `30m`, `45m`, End of Surah), and **Volume** control.
  - Resilient human-recitation audio queue with graceful error recovery and Hifz Companion integration.

### Detailed 3D-Shaded Articulated Boy & Girl Training Figures
- **3D-Shaded Articulated Vector-Mesh Engine**: Upgrades the existing exercise animation canvas into a volumetric 3D-shaded anatomical figure renderer with distinct **Boy (Male)** and **Girl (Female)** body proportions, realistic modest athletic attire silhouettes, 3D radial cylindrical limb shading, directional studio rim-lighting, ground cast shadows, depth-sorted foreground/background limbs (perspective occlusion), smooth joint blending, and active glowing **target muscle-group overlays** synchronized with breathing cues and phase progress.
- **Automatic Gender Binding**: Automatically renders the matching Boy or Girl 3D figure from the user's selected gender in Onboarding (editable anytime in Profile/Settings).

### Onboarding Phase 1 & Phase 2 Upgrades
- **Phase 1 — GPS-First Country Detection + Searchable Dropdown**: Offers one-tap **GPS Auto-Detect** (requesting fine/coarse location via Android `ActivityResultContracts.RequestMultiplePermissions`, resolving country & coordinates via `Geocoder` into `CountryCatalog` for accurate prayer times and Qibla), with an instant **Searchable Country Dropdown** fallback if GPS is unavailable or permission is declined.
- **Phase 2 — Clean Gender Selection**: Replaces "Workout Character" wording with clear **Gender Selection** (`Male / Boy` or `Female / Girl`), automatically configuring the 3D workout figure alongside the existing empty-by-default profile fields.

### Tasbih Square-Ripple Fix & Realistic 3D Tactile Button
- **Root-Cause Bug Fix**: Strictly clips the interactive clickable surface and ripple indication to `CircleShape` (eliminating the square ripple artifact completely).
- **Realistic 3D Glass/Pearl Bezel Design**: Multi-layered physical tactile button with brushed metallic gold outer bezel, recessed inner groove, domed translucent glass/pearl center with directional top-left specular sheen, soft ambient bottom shadow, spring-compression press physics, expanding concentric circular golden aura rings, and crisp haptic feedback.

---

## 3. Key Product Decisions & Trade-Offs

### Verified Real Multi-Provider Model Registry
All provider endpoints and model IDs have been verified against current live catalogs (zero fictional or deprecated models):

| Tier & Role | Provider | Verified Model IDs | Strengths & Verified Free-Tier Profile |
| :--- | :--- | :--- | :--- |
| **Tier 1 (Primary Fast & Reasoning)** | **Groq** (`api.groq.com/openai/v1`) | `openai/gpt-oss-120b` (deep reasoning / structured / 128K), `llama-3.3-70b-versatile` (general & Islamic nuance), `openai/gpt-oss-20b` (mid-tier 128K), `llama-3.1-8b-instant` (ultra-fast short queries & summaries), `qwen/qwen3-8-27b` (multimodal vision) | Ultra-low latency LPU inference; Free tier ~30 RPM, ~6K–8K TPM, ~1,000 RPD per model (shared org limits). |
| **Tier 2 (Independent Router & Vision Fallback)** | **OpenRouter** (`openrouter.ai/api/v1`) | `openrouter/free` (official `$0` auto-router for text & vision), `google/gemma-4-31b-it:free`, `google/gemma-4-26b-a4b-it:free`, `nvidia/nemotron-3-ultra-550b-a55b:free`, `nvidia/nemotron-3.5-super-vl:free` + live `/models` free-tier discovery cache | Automatic `$0` model rotation via `openrouter/free` + live model refresh prevents stale-model failures; Free tier 20 RPM, 50 RPD (1,000 RPD with $10+ lifetime credits). |
| **Tier 3 (Independent Serverless Redundancy)** | **Cloudflare Workers AI** (`api.cloudflare.com/.../ai/v1`) | `@cf/meta/llama-3.3-70b-instruct-fp8-fast` (fast 70B text), `@cf/google/gemma-4-26b-a4b-it` (native vision + text) | Independent edge GPU infrastructure; 10,000 Free Neurons/day resetting at 00:00 UTC. |
| **Tier 4 (Always-Ready Keyless Fallback)** | **Firebase AI Logic** (`Firebase.ai` + App Check) | `gemini-3.8-flash` (general, Islamic, & multimodal meal vision), `gemini-3.5-flash-lite` (ultra-fast fallback & background summarization) | Zero API key required (App Check attested); guarantees RuhZena AI & Meal Scanner work out-of-the-box on first install. |
| **Emergency Offline Safety Net** | **On-Device Verified Corpus** | Local verified Quran/Hadith & wellness engine | Activates only when the device has zero network connectivity or every cloud provider is simultaneously unreachable — clearly labeled and never fabricates citations. |

### Key Trade-Offs Considered
- **Direct Client Calls vs. External Proxy Server**: Choosing direct client calls + keyless Firebase AI Logic guarantees 100% server independence as requested. An optional "Custom Proxy Base URL" override in AI Provider Settings allows advanced users to route through their own proxy later with zero app rebuilds.
- **Smart Context Budgeting vs. Sending Full Raw History**: Sending unbounded chat history causes TPM/context overflows on free tiers (especially Groq's ~8K TPM free cap). Instead, RuhZena builds a token-budgeted prompt combining: (1) System identity, personality, & Islamic citation guardrails, (2) User-approved long-term memories, (3) Active multi-step task snapshot, (4) Rolling compressed conversation summary for older turns, and (5) The most recent raw turns.
- **Privacy Boundary Enforcement**: Private Journal entries and unrelated wellness logs are **never** attached to any AI prompt unless the user explicitly invokes an in-context "Ask RuhZena AI" action on that specific item.

---

## 4. Technical Architecture & Data Strategy

### Multi-Provider Persistent Agent Architecture

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        RUHZENA UNIFIED UI LAYER                            │
│  ┌──────────────────────────────┐     ┌─────────────────────────────────┐  │
│  │ Unified RuhZena AI Chat UI   │     │ Nutrition Photo / Meal Scanner  │  │
│  │ • 2 Personality Modes        │     │ • Camera / Photo Picker Input   │  │
│  │ • Memory Approve Chips       │     │ • Structured Macro & Halal JSON │  │
│  │ • Memory & Task Drawer       │     │ • Editable Review + Retry       │  │
│  └──────────────┬───────────────┘     └────────────────┬────────────────┘  │
└─────────────────┼──────────────────────────────────────┼───────────────────┘
                  ▼                                      ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                  PERSISTENT RUHZENA AGENT ORCHESTRATOR                     │
│                                                                            │
│  ┌─────────────────────┐  ┌──────────────────────┐  ┌───────────────────┐  │
│  │ Context & Memory    │  │ Intelligent Task &   │  │ Failover & Stream │  │
│  │ Builder             │  │ Complexity Router    │  │ Recovery Engine   │  │
│  │ • Identity & Guard  │─►│ • Query Classifier   │─►│ • Error Taxonomy  │  │
│  │ • Approved Memories │  │ • Health & Cooldown  │  │ • Cooldown Timers │  │
│  │ • Task State Block  │  │ • Vision / Context   │  │ • Partial Output  │  │
│  │ • Rolling Summary   │  │   Capability Filter  │  │   Continuation    │  │
│  └──────────▲──────────┘  └──────────▲───────────┘  └─────────┬─────────┘  │
│             │                        │                        │            │
│  ┌──────────┴────────────────────────┴────────────────────────┴─────────┐  │
│  │                PROVIDER HEALTH & MODEL REGISTRY                      │  │
│  │  Consecutive Failures • Latency EWMA • Retry-After • Cooldowns       │  │
│  └───────────────────────────────────┬──────────────────────────────────┘  │
└──────────────────────────────────────┼─────────────────────────────────────┘
                                       ▼
      ┌────────────────┬───────────────┴┬───────────────────┬───────────────┐
      ▼                ▼                ▼                   ▼               ▼
┌───────────┐   ┌────────────┐   ┌──────────────┐   ┌──────────────┐ ┌──────────┐
│   Groq    │   │ OpenRouter │   │  Cloudflare  │   │ Firebase AI  │ │ Verified │
│  Adapter  │   │  Adapter   │   │  Workers AI  │   │Logic Adapter │ │ Offline  │
│ (SSE/JSON)│   │(SSE + Live │   │   Adapter    │   │ (Keyless     │ │  Corpus  │
│           │   │ Free List) │   │  (SSE/JSON)  │   │  App Check)  │ │ Fallback │
└───────────┘   └────────────┘   └──────────────┘   └──────────────┘ └──────────┘
```

### Failure Taxonomy & Automatic Failover Flow

```
  Attempt Primary Ranked Model (with 35s–60s stream/read timeout)
         │
         ├─► Success ──► Record latency & reset failure streak ──► Persist reply + Task/Memory updates
         │
         └─► Failure Classified:
               • HTTP 429 / Quota / Retry-After ──► Respect Retry-After or exponential cooldown (60s–15m)
               • High Demand / Overloaded (529/503/msg) ──► Short model cooldown (45s–120s), swap model/provider
               • Server Error (500/502/504) ──► Cooldown provider (60s), failover immediately
               • Invalid / Decommissioned Model (404/400) ──► Disable model ID for session, try next candidate
               • Timeout / Network Drop / Mid-Stream Stall:
                   ├─ If partial meaningful text already streamed:
                   │    Preserve partial buffer internally ──► Send seamless continuation prompt
                   │    to next healthy provider with overlap de-duplication (no repeated text!)
                   └─ If no text streamed yet:
                        Immediately failover to next healthy provider/model
               │
               ▼
         All Cloud Candidates Exhausted / Offline?
               └─► Preserve user prompt + offer calm offline guidance / 1-tap Retry (never loop infinitely)
```

### Persistent On-Device Storage Strategy (Room v2 + Encrypted Keystore + DataStore)
- **Room Database Migration (`v1 → v2`, non-destructive SQL migration preserving all existing user data)**:
  - **Unified Conversation History**: Retains existing chat messages seamlessly under a unified thread while preserving personality metadata, citations, and timestamps.
  - **Conversation Summaries Table**: Stores rolling condensed summaries + covered message watermark so long multi-day chats stay fast and within tight free-tier token windows.
  - **Approved Long-Term Memories Table**: Stores user-approved facts/preferences (category, content, source turn, timestamps, active toggle).
  - **Persistent Agent Task State Table**: Tracks active/paused multi-step tasks (objective, constraints, completed steps, remaining steps, working notes, next action, unresolved questions) so multi-step plans survive provider failovers and full app restarts.
  - **Provider Health Snapshot**: Persists cooldown deadlines and recent error states across restarts so rate-limited providers aren't immediately hammered again on reopen.
- **Android Keystore–Encrypted Credential Store**: Uses AES-256-GCM wrapped by an Android Keystore key for optional user-entered Groq/OpenRouter/Cloudflare keys, falling back to `BuildConfig` secrets if configured at build time — zero plaintext keys in logs, crash reports, or backups.
- **DataStore Preferences**: Adds `learningTrackSelected` (Beginner vs. Veteran), `arabicMasteredLettersCsv`, `quranSleepTimerMinutes`, and completes wiring the Hifz & Ramadan state cleanly.

### Verification & Automated Test Suite (All 19 Required Scenarios)
A comprehensive local JVM + Robolectric test suite (run via `gradle :app:testDebugUnitTest`) using deterministic fake/local HTTP & adapter harnesses will verify every required resilience scenario:
1. Primary provider healthy normal response.
2. HTTP 429 rate-limit immediate failover & Retry-After cooldown handling.
3. High-demand / overloaded provider failover.
4. Temporary HTTP 503 outage failover.
5. Network timeout / stalled stream failover.
6. Mid-stream disconnection with partial output preserved.
7. Invalid or decommissioned model ID auto-skip & recovery.
8. Quota exhausted handling without tight retry loops.
9. Clean failover success across tiers (Groq → OpenRouter → Cloudflare → Firebase AI).
10. Sequential multi-provider failures stepping through all remaining candidates.
11. All providers temporarily unavailable (graceful message, preserved input, zero infinite spinner).
12. Cooldown expiration & automatic recovery probe returning to primary provider.
13. Mid-long-conversation provider switch preserving rolling summary & full continuity.
14. App restart persistence restoring conversation, memories, and active task state.
15. Multi-step task state resumption seamlessly across a failover boundary.
16. Partial-response continuation with prefix/overlap de-duplication (no duplicated sentences).
17. Both **Peace & Life Companion** and **Practical & Knowledge Expert** personalities consistently enforced across provider switches.
18. Strict Islamic citation standards & zero-fabrication guardrails retained across all providers.
19. Concurrency & UI safety: no endless loading state, no lost messages, and no duplicated messages on rapid/failed sends.
20. Plus Nutrition Meal Photo Vision failover verification & full APK compilation verification via `compile_applet`.
